/*
 * BAlbumManager.java
 *
 * Created on April 21, 2007, 10:25 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.jdesktop.appframework.beansbinding.album;

import application.Action;
import java.util.List;
import net.java.dev.properties.BaseBean;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.events.PropertyListener;
import org.jdesktop.appframework.FormDialog;


/**
 * 
 */
public class BAlbumManager extends BaseBean {
    
    /**
     * Holds the List of Albums. Albums are added and removed from this List.
     * The ObservableList implements ListModel, and so, we can directly
     * use this List for the UI and can observe changes.<p>
     * 
     * In a real world application this List may be kept 
     * in synch with a database.
     */
    public final IndexedProperty<Album> managedAlbums = new ObservableIndexed<Album>();
    
    public final Property<Boolean> albumSelected = new ObservableProperty<Boolean>(false);
    
    public final Property<Integer> selection = new ObservableProperty<Integer>(-1);
    
    public BAlbumManager() {
        BeanContainer.bind(this);
    }
    
    /**
     * Constructs a AlbumManager for the given list of Albums.
     * 
     * @param albums   the list of Albums to manage
     */
    public BAlbumManager(List<Album> albums) {
        this();
        this.managedAlbums.set(albums);
        BeanContainer.get().addListener(selection, new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                albumSelected.set(((Number)newValue).intValue() > -1);
            }
        });
    }
    
    
    // Managing Albums *********************************************************
    
    /**
     * Creates and return a new Album.
     * 
     * @return the new Album
     */
    public Album createItem() {
        return new Album();
    }
    
    
    /**
     * Adds the given Album to the List of managed Albums
     * and notifies observers of the managed Albums ListModel
     * about the change.
     * 
     * @param albumToAdd   the Album to add
     */
    public void addItem(Album albumToAdd) {
        managedAlbums.add(albumToAdd);
    }
    
    
    /**
     * Removes the given Album from the List of managed Albums
     * and notifies observers of the managed Albums ListModel
     * about the change.
     * 
     * @param albumToRemove    the Album to remove
     */
    public void removeItem(Album albumToRemove) {
        managedAlbums.remove(albumToRemove);
    }

    @Action
    public void newAlbum() {
        Album a = new Album();
        a.title.set("Untitled");
        managedAlbums.add(a);
    }
 

    public boolean isAlbumSelected() {
        return albumSelected.get();
    }
    
    @Action (enabledProperty = "albumSelected")
    public void deleteAlbum() {
        managedAlbums.remove(selection.get());
    }

    @Action(enabledProperty = "albumSelected")
    public void editAlbum() {
        Album a = (Album)BeanContainer.get().clone(managedAlbums.get(selection.get()));
        BAlbumEditorView view = new BAlbumEditorView(a);
        FormDialog dialog = new FormDialog(null, view);
        dialog.open();
        if(!dialog.hasBeenCanceled()) {
            managedAlbums.set(selection.get(), a);
            selection.set(-1);
        }
    }
}
