/*
 * Album.java
 *
 * Created on April 21, 2007, 9:23 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.jdesktop.appframework.beansbinding.album;

import java.util.Arrays;
import java.util.List;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;

/**
 * Based on the album demo from Jeanette here: 
 * https://jdnc-incubator.dev.java.net/source/browse/jdnc-incubator/src/kleopatra/java/org/jdesktop/appframework/beansbinding/album/
 * All of her rights apply...
 *
 * @author kleopatra, shai
 */
public class Album {
    
        
        // Examples ***************************************************************
        
        /** An example Album. */
        public static final Album ALBUM1 = createExample1();

        /** An example Album. */
        public static final Album ALBUM2 = createExample2();

        /** An example Album. */
        public static final Album ALBUM3 = createExample3();

        /** An example Album. */
        public static final Album ALBUM4 = createExample4();
        
        /** A List of Albums made of the examples 1 to 4. */
        public static final List<Album> ALBUMS = Arrays.asList(new Album[]{
                ALBUM1, ALBUM2, ALBUM3, ALBUM4});
                
        
        // Instance Fields ********************************************************
        
        /**
         * This Album's title as associated with its ISBN,
         * for example "Symphony No. 5".
         */
        public final Property<String> title = new ObservableProperty<String>();
        
        /**
         * Holds this Album's artist, for example: "Albert Ayler",
         * or "Berliner Philharmoniker".
         */
        public final Property<String> artist = new ObservableProperty<String>();

        /**
         * Describes if this Album is classical music; in this case
         * it has a composer.
         */
        public final Property<Boolean> classical = new ObservableProperty<Boolean>(false);
        
        /**
         * Holds the composer of this Album's music, for example "Beethoven". 
         * Available if and only if this is a classical album.
         */
        public final Property<String> composer = new ObservableProperty<String>();
        

        // Instance Creation ******************************************************
        
        /**
         * Constructs an empty Album: empty title and artist, not classical
         * and no composer set.
         */
        public Album() {
            this("", "");
        }
        
        
        private Album(String title, String artist) {
            BeanContainer.bind(this);
            this.title.set(title);
            this.artist.set(artist);
        }
        
        
        private Album(String title, String artist, String composer) {
            this(title, artist);
            this.classical.set(true);
            this.composer.set(composer);
        }

        
        // Creating Example Instances *********************************************
        
        private static Album createExample1() {
            return new Album(
                    "A Love Supreme", 
                    "John Coltrane");
        }
        
        private static Album createExample2() {
            return new Album(
                    "In a Silent Way", 
                    "Miles Davis");
        }
        
        private static Album createExample3() {
            return new Album(
                    "Sheik Yerbouti", 
                    "Frank Zappa");
        }
        
        private static Album createExample4() {
            return new Album(
                    "Tristan und Isolde", 
                    "Berliner Philharmoniker",
                    "Richard Wagner");
        }    
}
