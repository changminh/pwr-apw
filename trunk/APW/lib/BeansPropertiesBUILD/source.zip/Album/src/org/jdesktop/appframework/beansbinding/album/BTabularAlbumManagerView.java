package org.jdesktop.appframework.beansbinding.album;

import javax.swing.ActionMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import net.java.dev.properties.binding.swing.adapters.SwingBind;
import net.java.dev.properties.container.PropertyContext;

import org.jdesktop.appframework.swingx.VetoableListSelectionModel;
import org.jdesktop.swingx.JXTable;

import application.ApplicationContext;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

public class BTabularAlbumManagerView {

    private BAlbumManager albumManager;
    private JXTable  albumTable;
    private JButton newButton;
    private JButton editButton;
    private JButton deleteButton;
    private JComponent content;

    public BTabularAlbumManagerView(BAlbumManager model) {
        this.albumManager = model;
    }

    public JComponent getContent() {
        if (content == null) {
            initComponents();
            content = build();
            bind();
        }
        return content;
    }

    private void bind() {
        albumTable.setEditable(false);
        SwingBind context = SwingBind.get();
        Album a = new Album();
        context.bindContent(albumManager.managedAlbums, 
            new PropertyContext[] {
                a.artist.getContext(), 
                a.title.getContext(),
                a.classical.getContext(),
                a.composer.getContext()
            }, albumTable);
        context.bindSelectionIndex(albumManager.selection, albumTable);
    }

    private JComponent build() {
        FormLayout layout = new FormLayout(
                "fill:100dlu:grow",
                "p, 1dlu, p, 6dlu, p");
                
        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();
        
        JLabel label = builder.addTitle("", cc.xy(1, 1));
        label.setName("albumsTitle");
        builder.add(new JScrollPane(albumTable), cc.xy(1, 3));
        builder.add(buildButtonBar(),            cc.xy(1, 5));
        JComponent overview = builder.getPanel();
        return overview;
        
    }
    
    private JComponent buildButtonBar() {
        return ButtonBarFactory.buildLeftAlignedBar(
                newButton,
                editButton,
                deleteButton);
    }

    private void initComponents() {
        albumTable = new JXTable();
        albumTable.setName("albumTable");
        newButton = new JButton();
        editButton = new JButton();
        deleteButton = new JButton();
        ApplicationContext context = ApplicationContext.getInstance();
        ActionMap actionMap = context.getActionMap(albumManager.getClass(), 
                albumManager);
        newButton.setAction(actionMap.get("newAlbum"));
        deleteButton.setAction(actionMap.get("deleteAlbum"));
        editButton.setAction(actionMap.get("editAlbum"));
        
    }

}
