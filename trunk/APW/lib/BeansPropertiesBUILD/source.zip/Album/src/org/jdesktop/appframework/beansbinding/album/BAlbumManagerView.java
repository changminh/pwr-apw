package org.jdesktop.appframework.beansbinding.album;

import application.*;
import java.awt.Component;
import javax.swing.ActionMap;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.ListCellRenderer;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.binding.swing.adapters.SwingBind;
import net.java.dev.properties.container.BeanContainer;

import org.jdesktop.appframework.swingx.VetoableListSelectionModel;
import org.jdesktop.swingx.JXList;
import org.jdesktop.swingx.renderer.DefaultListRenderer;

import application.ApplicationContext;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

/**
 * Combined view to show list of Albums and edit the current selection.
 * 
 * @author Jeanette Winzenburg
 */
public class BAlbumManagerView {
    private BAlbumManager albumManager;
    private JXList  albumList;
    
    private BAlbumEditorView detailsView;
    
    private JButton newButton;
    private JButton deleteButton;
    private JComponent content;

    private JButton applyButton;
    private JButton discardButton;
    private Album bound;
    

    public BAlbumManagerView(BAlbumManager model) {
        this.albumManager = model;
    }

    public JComponent getContent() {
        if (content == null) {
            initComponents();
            content = build();
            bind();
        }
        return content;
    }

    private void bind() {
        SwingBind context = SwingBind.get();
        context.bindContent(albumManager.managedAlbums, albumList);
        albumList.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                Album selection = (Album)albumList.getSelectedValue();
                if(selection != null) {
                    bound = (Album)BeanContainer.get().clone(selection);
                    detailsView.bind(bound);
                    enableButtons(true);
                } else {
                    enableButtons(false);
                    detailsView.bind(new Album());
                }
            }
        });
        context.bindSelectionIndex(albumManager.selection, albumList);
    }

    private void initComponents() {
        albumList = new JXList();
        albumList.setName("albumList");
        albumList.setCellRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList jList, Object object, int i, boolean b, boolean b0) {
                return super.getListCellRendererComponent(jList, ((Album)object).title.get(), i, b, b0);
            }
        });
        newButton = new JButton();
        deleteButton = new JButton();
        ApplicationContext context = ApplicationContext.getInstance();
        ActionMap actionMap = context.getActionMap(albumManager.getClass(), 
                albumManager);
        newButton.setAction(actionMap.get("newAlbum"));
        deleteButton.setAction(actionMap.get("deleteAlbum"));
        // PENDING: bind later ...
        detailsView = new BAlbumEditorView(new Album());
        applyButton = new JButton();
        discardButton = new JButton();
        ActionMap detailsActions = context.getActionMap(getClass(), this);
        applyButton.setAction(detailsActions.get("apply"));
        discardButton.setAction(detailsActions.get("discard"));
    }

    /**
     * Rather than enable/disable these with the property, I will use a more efficient way with existing 
     * events.
     */
    @Action
    public void apply() {
        albumManager.managedAlbums.set(albumManager.selection.get(), bound);
    }

    @Action
    public void discard() {
        bound = null;
        albumList.clearSelection();
        enableButtons(false);
        detailsView.bind(new Album());
    }
    
    private void enableButtons(boolean val) {
        applyButton.getAction().setEnabled(val);
        discardButton.getAction().setEnabled(val);
    }

    public JComponent build() {
        FormLayout layout = new FormLayout(
                "fill:100dlu:grow",
                "p, 1dlu, p, 6dlu, p");
                
        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();
        
        JLabel label = builder.addTitle("", cc.xy(1, 1));
        label.setName("albumsTitle");
        builder.add(new JScrollPane(albumList), cc.xy(1, 3));
        builder.add(buildButtonBar(),            cc.xy(1, 5));
        JComponent overview = builder.getPanel();
        JComponent panel = buildDetailsPane();
        JSplitPane splitPane = new JSplitPane();
        splitPane.setLeftComponent(overview);
        splitPane.setRightComponent(panel);
        return splitPane;
    }


    private JPanel buildDetailsButtonBar() {
        return ButtonBarFactory.buildCenteredBar(applyButton, discardButton);
    }
    
    private JComponent buildDetailsPane() {
        FormLayout layout = new FormLayout(
                "fill:pref", 
                "fill:pref, 6dlu, pref");
        PanelBuilder builder = new PanelBuilder(layout);
        builder.getPanel().setBorder(new EmptyBorder(18, 12, 12, 12));
        CellConstraints cc = new CellConstraints();
        builder.add(detailsView.getContent(), cc.xy(1, 1));
        builder.add(buildDetailsButtonBar(),   cc.xy(1, 3));
        return builder.getPanel();
    }
    
    private JComponent buildButtonBar() {
        return ButtonBarFactory.buildLeftAlignedBar(
                newButton,
                deleteButton);
    }
    

}
