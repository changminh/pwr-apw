package org.jdesktop.appframework.beansbinding.album;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;
import net.java.dev.properties.binding.swing.adapters.SwingBind;

import org.jdesktop.appframework.FormView;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

public class BAlbumEditorView implements FormView {

    private Album albumModel;
    
    private JTextComponent titleField;
    private JTextComponent artistField;
    private JCheckBox      classicalBox;
    private JTextComponent composerField;
    // debug: visualize buffering status
    private JCheckBox bufferingBox;
    
    private JComponent content;

    private JLabel composerLabel;

    public BAlbumEditorView(Album albumModel) {
        this.albumModel = albumModel;
    }
    
//-------------- implement FormView
    
    public Object getActionsObject() {
        return albumModel;
    }

    public JComponent getContent() {
        if (content == null) {
            initComponents();
            content = build();
            if(albumModel != null) {
                bind(albumModel);
            }
        }
        return content;
    }
   
    public String getName() {
        return "editorView";
    }
    
    // Initialization *********************************************************

    void bind(Album a) {
        SwingBind context = SwingBind.get();
        albumModel = a;
        context.bind(a.title, titleField);
        context.bind(a.composer, composerField);
        context.bind(a.artist, artistField);
        context.bind(a.classical, classicalBox);
    }

    /**
     *  Creates and intializes the UI components.
     */
    private void initComponents() {
        titleField = new JTextField();
        artistField = new JTextField();
        classicalBox = new JCheckBox();
        composerField = new JTextField();
        composerLabel = new JLabel();
        bufferingBox = new JCheckBox("debug: buffering");
    }
    
    /**
     * Builds and returns the editor panel.
     * 
     * @return the built panel
     */
    private JComponent build() {
        initComponents();
        FormLayout layout = new FormLayout(
                "right:pref, 3dlu, 150dlu:grow",
                "p, 3dlu, p, 3dlu, p, 3dlu, p, 3dlu, p");
        layout.setRowGroups(new int[][]{{1, 3, 5, 7}});
        
        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();
        
        JLabel label = builder.addLabel("",   cc.xy(1, 1));
        label.setName("artistLabel");
        builder.add(artistField,     cc.xy(3, 1));
        label = builder.addLabel("",    cc.xy(1, 3));
        label.setName("titleLabel");
        builder.add(titleField,      cc.xy(3, 3));
        builder.add(classicalBox,    cc.xy(3, 5));
        classicalBox.setName("classicalBox");
        builder.add(composerLabel, cc.xy(1, 7));
        composerLabel.setName("composerLabel");
        composerLabel.setLabelFor(composerField);
        builder.add(composerField,   cc.xy(3, 7));
        builder.add(bufferingBox, cc.xy(3, 9));
        JPanel panel = builder.getPanel();
        panel.setName(getName());
        
        return panel;
        
    }


}
