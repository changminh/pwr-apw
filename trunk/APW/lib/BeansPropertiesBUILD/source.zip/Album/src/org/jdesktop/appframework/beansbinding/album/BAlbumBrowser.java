package org.jdesktop.appframework.beansbinding.album;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JTabbedPane;

import org.jdesktop.appframework.swingx.SingleXFrameApplication;
import org.jdesktop.swingx.JXHeader;
import org.jdesktop.swingx.JXPanel;

public class BAlbumBrowser extends SingleXFrameApplication {
    @Override
    public void startup() {
        JComponent content = getContent();
        show(content);
    }

    /**
     * @return
     */
    private JComponent getContent() {
        JComponent content = new JXPanel(new BorderLayout());
        content.add(createHeader("header"), BorderLayout.NORTH);
        content.add(getAlbumManagerContent());
        content.add(createHeader("footer"), BorderLayout.SOUTH);
        return content;
    }
    
    /**
     * @return
     */
    private JTabbedPane getAlbumManagerContent() {
        
        BAlbumManager albumManager = getBAlbumManager();
        JTabbedPane pane = new JTabbedPane();
        pane.setName("albumManagerTab");
        pane.addTab("Edit in place", new BAlbumManagerView(albumManager).getContent());
        pane.addTab("Edit in dialog", new BTabularAlbumManagerView(albumManager).getContent());
        return pane;
    }

    /**
     * @return
     */
    private BAlbumManager getBAlbumManager() {
        List<Album> exampleAlbums = Album.ALBUMS;
        BAlbumManager albumManager = new BAlbumManager(exampleAlbums);
        return albumManager;
    }


    /**
     * @param footerName
     * @return
     */
    private JXHeader createHeader(String footerName) {
        JXHeader footer = new JXHeader();
          footer.setName(footerName);
          enableHTML(footer, false);
        return footer;
    }

    /**
     * Hack around functionality regression in reviewed JXHeader.
     * The internal JEditorPane now is a hidden implementation
     * detail (with html disabled) so we need to go dirty.
     * 
     * @param header
     * @param hyperlinkEndabled
     */
    private void enableHTML(JXHeader header, boolean hyperlinkEndabled) {
        JEditorPane editor = null;
        for (int i = 0; i < header.getComponentCount(); i++) {
            if (header.getComponent(i) instanceof JEditorPane) {
                editor = (JEditorPane) header.getComponent(i);
                break;
            }
        }
        if (editor == null) return;
        editor.setName(header.getName() + "-editor");
        editor.setContentType("text/html");
    }




    public static void main(String[] args) {
        launch(BAlbumBrowser.class, args);
    }

}