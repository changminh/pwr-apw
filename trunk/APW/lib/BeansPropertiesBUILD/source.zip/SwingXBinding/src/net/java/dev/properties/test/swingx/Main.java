/*
 * Main.java
 *
 * Created on March 7, 2007, 11:07 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.swingx;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.event.ActionEvent;
import java.util.Locale;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.binding.PropertySelectionListener;
import net.java.dev.properties.binding.swing.SwingComponentFactory;
import net.java.dev.properties.binding.swing.SwingFactory;
import net.java.dev.properties.binding.swing.adapters.SwingBind;
import net.java.dev.properties.binding.swingx.SwingXComponentFactory;
import net.java.dev.properties.binding.swingx.SwingXFactory;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.test.binding.studio.*;
import org.jdesktop.swingx.JXTable;
import org.jdesktop.swingx.decorator.AlternateRowHighlighter;
import org.jdesktop.swingx.decorator.FilterPipeline;
import org.jdesktop.swingx.decorator.PatternFilter;

/**
 * Handles the glue code between the bean and the UI code
 *
 * @author Shai Almog
 */
public class Main {
    private SwingFactory factory;
    private SwingFactory masterFactory;
    private StudioBean studio;
    private final PropertyContext whoContext = new AttendanceBean().who.getContext();
    private final PropertyContext typeContext = new AttendanceBean().type.getContext();
    private final PropertyContext regularsContext = new YogaClassBean().regulars.getContext();
    
    /** Creates a new instance of Main */
    private Main() throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        SwingXFactory.init();
        factory = SwingFactory.customColumnLayoutFactory(2);
        masterFactory = SwingFactory.centerLayoutFactory();
        masterFactory.componentFactory.set(new OverrideComponentFactory());
        
        factory.componentFactory.get().registerBinding(regularsContext, new StudentBinding());
        
        studio = new StudioBean();
        for(char iter = 'A' ; iter <= 'Z' ; iter++) {
            studio.students.add(new StudentBean("First" + iter, "Surname" + iter));
        }
        for(char iter = 'a' ; iter <= 'z' ; iter++) {
            studio.students.add(new StudentBean("More" + iter, "Additional" + iter));
        }

        JFrame frm = new JFrame(BeanContainer.get().getContext(studio.getClass()).getDisplayName());
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane pane = new JTabbedPane();
        BeanContext context = BeanContainer.get().getContext(new StudentBean().getClass());
        addTab(pane, studio.students, context);

        YogaClassBean yogaClass = new YogaClassBean();
        context = BeanContainer.get().getContext(yogaClass.getClass());
        factory.componentFactory.get().registerBinding(yogaClass.time.getContext(), 
            new SwingComponentFactory.CustomPropertyBinding() {
                public JComponent createComponent(PropertyContext prop) {
                    return new TimeComponent();
                }
                public void bind(Object bean, PropertyContext property, PropertyContext selection, JComponent comp) {
                    ((TimeComponent)comp).bind(bean, property);
                }
            });
        addTab(pane, studio.classes, context);

        factory = SwingXFactory.customColumnLayoutFactory(1);
        factory.componentFactory.get().registerBinding(whoContext, new StudentBinding());
        factory.componentFactory.get().registerBinding(typeContext, 
            new SwingComponentFactory.CustomPropertyBinding() {
                public JComponent createComponent(PropertyContext prop) {
                    return new JComboBox();
                }
                public void bind(Object bean, PropertyContext property, PropertyContext selection, JComponent comp) {
                    SwingBind.get().bindContent(studio.classes, (JComboBox)comp);
                    SwingBind.get().bindItem(typeContext.getValue(bean), (JComboBox)comp);
                }
            });
        context = BeanContainer.get().getContext(AttendanceBean.class);
        addTab(pane, studio.attendance, context);
        
        frm.add(pane, BorderLayout.CENTER);
        frm.pack();
        frm.setLocationByPlatform(true);
        frm.setVisible(true);
    }
    
    /**
     * Adds the component to the tabbed pane and adds the appropriate add/remove
     * operations etc.
     */
    private void addTab(JTabbedPane pane, final IndexedProperty property, BeanContext context) {
        class AddAction extends AbstractAction {
            public AddAction() {
                putValue(NAME, "Add");
            }
            
            public void actionPerformed(ActionEvent ev) {
                try {
                    property.add(property.getContext().getType().newInstance());
                } catch(Exception err) {
                    err.printStackTrace();
                }
            }
        }

        class RemoveAction extends AbstractAction implements PropertySelectionListener {
            private int[] selection;
            public RemoveAction(JComponent cmp) {
                putValue(NAME, "Remove");
                setEnabled(false);
                factory.addPropertySelectionListener(this, property, cmp);
            }
            
            public void actionPerformed(ActionEvent ev) {
                for(int iter = selection.length - 1 ; iter > -1 ; iter--) {
                    property.remove(selection[iter]);
                }
            }

            public void selectionChanged(IndexedProperty property, int[] selection) {
                this.selection = selection;
                setEnabled(selection != null && selection.length > 0);
            }
        }
        
        JPanel panel = new JPanel(new BorderLayout());
        final JComponent cmp = factory.createMasterDetail(property, context, masterFactory);
        panel.add(cmp, BorderLayout.CENTER);
        JPanel buttonPane = new JPanel();
        JButton addButton = new JButton(new AddAction());
        JButton removeButton = new JButton(new RemoveAction(cmp));
        buttonPane.add(addButton);
        buttonPane.add(removeButton);
        OverrideComponentFactory swingXFactory = (OverrideComponentFactory)masterFactory.componentFactory.get();
        panel.add(swingXFactory.getFilter(), BorderLayout.NORTH);
        panel.add(buttonPane, BorderLayout.SOUTH);
        pane.addTab(context.getDisplayName(), panel);
    }
    
    class StudentBinding implements SwingComponentFactory.CustomPropertyBinding {
        private PropertyContext prop;
        public JComponent createComponent(PropertyContext prop) {
            this.prop = prop;
            return new JList();
        }

        public void bind(Object bean, PropertyContext property, PropertyContext selection, JComponent comp) {
            SwingBind.get().bindContent(studio.students, (JList)comp);
            SwingBind.get().bindSelectionItems((IndexedProperty<Object>)prop.getValue(bean), (JList)comp);
        }
    }
     
    /**
     * Simple override to allow the creation of a JTable that can properly render
     * hours, lists of people, days of week etc..
     */
    class OverrideComponentFactory extends SwingXComponentFactory {
        private JTextField lastFilter;
        public JComponent createComponent(PropertyContext propertyContext, PropertyContext selection) {
            JComponent retValue = super.createComponent(propertyContext, selection);
            if(retValue instanceof JXTable) {
                final JXTable table = (JXTable)retValue;
                if(propertyContext == studio.classes.getContext()) {
                    table.setDefaultRenderer(Byte.class, new DefaultTableCellRenderer() {
                        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                            return super.getTableCellRendererComponent(table, YogaClassBean.getDOW(value), 
                                isSelected, hasFocus, row, column);
                        }
                    });
                    table.setDefaultRenderer(Integer.class, new DefaultTableCellRenderer() {
                        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                            return super.getTableCellRendererComponent(table, 
                                YogaClassBean.getTime(value), isSelected, 
                                hasFocus, row, column);
                        }
                    });
                }
                final JTextField filter = new JTextField(20);
                table.setHighlighters(new AlternateRowHighlighter());
                final PatternFilter pattern = new PatternFilter() {
                    public boolean test(int row) {
                        if(filter.getText().length() == 0) {
                            return true;
                        }
                        int columns = table.getColumnCount();
                        for(int iter = 0 ; iter < columns ; iter++) {
                            Object value = getInputValue(row, iter);
                            if (value != null) {
                                boolean matches = pattern.matcher(value.toString()).find();
                                if(matches) {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                };
                table.setFilters(new FilterPipeline(pattern));
                lastFilter = filter;
                filter.getDocument().addDocumentListener(new DocumentListener() {
                    public void changedUpdate(DocumentEvent documentEvent) {
                        updateFilter();
                    }
                    public void insertUpdate(DocumentEvent documentEvent) {
                        updateFilter();
                    }
                    public void removeUpdate(DocumentEvent documentEvent) {
                        updateFilter();
                    }
                    private void updateFilter() {
                        pattern.setPattern(filter.getText(), 0);
                        pattern.refresh();
                    }
                });
            }
            return retValue;
        }

        public JTextField getFilter() {
            return lastFilter;
        }
    }

    
    public static void main(String[] argv) throws Exception {
        new Main();
    }
}
