/*
 * TreeBinding.java
 *
 * Created on April 4, 2007, 2:31 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.swingx;

import java.awt.BorderLayout;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.binding.swingx.adapters.SwingXBind;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.container.PropertyContext;
import org.jdesktop.swingx.JXTreeTable;

/**
 * Simple test for binding to a JXTreeTable
 *
 * @author Shai Almog
 */
public class TreeTableBindingTest {
    public final Property<String> data = new ObservableProperty<String>("");
    public final IndexedProperty<TreeTableBindingTest> children = new ObservableIndexed<TreeTableBindingTest>();
   
    public final Property<Date> dateColumn = new ObservableProperty<Date>();
    public final Property<String> stringColumn = new ObservableProperty<String>();
    
    /** Creates a new instance of TreeBinding */
    public TreeTableBindingTest() {
        BeanContainer.bind(this);
    }

    public TreeTableBindingTest(String data) {
        this();
        this.data.set(data);
    }

    public String toString() {
        return data.get();
    }
    
    private static TreeTableBindingTest createTree() {
        TreeTableBindingTest t = new TreeTableBindingTest("Data Node");
        t.children.add(new TreeTableBindingTest("First"));
        t.children.add(new TreeTableBindingTest("Second"));
        t.children.add(new TreeTableBindingTest("Third"));
        t.children.add(new TreeTableBindingTest("Forth"));
        TreeTableBindingTest t2 = new TreeTableBindingTest("Has Children");
        t2.stringColumn.set("Simple String");
        t2.children.add(new TreeTableBindingTest("Inner Child 1"));
        t2.children.add(new TreeTableBindingTest("Inner Child 2"));
        t.children.add(t2);
        return t;
    }
    
    public static void main(String[] argv) throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        JFrame frm = new JFrame("Tree Test");
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JXTreeTable tree = new JXTreeTable();
        tree.setRootVisible(true);
        TreeTableBindingTest t = createTree();
        SwingXBind.get().bindContent(t, 
            new PropertyContext[] {t.children.getContext()}, 
            new PropertyContext[]{t.dateColumn.getContext(), t.stringColumn.getContext()}, 
            tree);
        frm.add(new JScrollPane(tree), BorderLayout.CENTER);
        frm.pack();
        frm.setLocationByPlatform(true);
        frm.setVisible(true);
    }
}
