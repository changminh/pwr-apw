/*
 * SwingXBind.java
 *
 * Created on April 11, 2007, 11:37 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swingx.adapters;

import java.util.Date;
import javax.swing.JComponent;
import javax.swing.JTable;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.binding.swing.adapters.SwingBind;
import net.java.dev.properties.binding.swing.adapters.TableIndexAdapter;
import net.java.dev.properties.binding.swing.adapters.TableIndicesAdapter;
import net.java.dev.properties.binding.swingx.SwingXFactory;
import net.java.dev.properties.container.PropertyContext;
import org.jdesktop.swingx.JXDatePicker;
import org.jdesktop.swingx.JXTreeTable;

/**
 * Generic binding implementation for SwingX
 *
 * @author shai
 */
public class SwingXBind extends SwingBind {

    public static void init() {
        set(new SwingXBind());
    }
    
    public static SwingXBind get() {
        try {
            return (SwingXBind)SwingBind.get();
        } catch(ClassCastException err) {
            // try to be clever about this... but still don't recurse..
            SwingXFactory.init();
            return (SwingXBind)SwingBind.get();
        }
    }
    
    /** Creates a new instance of SwingXBind */
    protected SwingXBind() {
        addAdapter(new DatePickerAdapter());
        addAdapter(new SwingXTableIndexAdapter());
        addAdapter(new SwingXTableIndicesAdapter());
    }
    
    
    public void bind(BaseProperty<Date> property, JXDatePicker cmp) {
        new DatePickerAdapter().bind(property, cmp);
    }

    public void bindSelectionIndex(BaseProperty<Integer> property, JTable cmp) {
        new TableIndexAdapter().bind(property, cmp);
    }

    public void bindSelectionIndices(IndexedProperty<Integer> property, JTable cmp) {
        new TableIndicesAdapter().bind(property, cmp);
    }

    public void bindContent(Object root, PropertyContext[] children, PropertyContext[] columns, JXTreeTable cmp) {
        cmp.setTreeTableModel(new TreeTableAdapterModel(root, children, columns, null));
    }
}
