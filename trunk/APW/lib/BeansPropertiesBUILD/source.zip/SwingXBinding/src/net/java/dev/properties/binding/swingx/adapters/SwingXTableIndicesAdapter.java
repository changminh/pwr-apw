/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swingx.adapters;

import java.util.ArrayList;
import java.util.List;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import net.java.dev.properties.binding.swing.adapters.TableIndicesAdapter;
import org.jdesktop.swingx.JXTable;


/**
 * Implements list support for propagating UI changes
 *
 * @author Shai Almog
 */
public class SwingXTableIndicesAdapter extends TableIndicesAdapter {
    protected void updateUI(List<Integer> newValue) {
        JXTable t = (JXTable)getComponent();
        t.clearSelection();
        ListSelectionModel model = t.getSelectionModel();
        for(Integer i : newValue) {
            int current = t.convertRowIndexToView(i);
            model.addSelectionInterval(current, current);
        }
    }            

    public void valueChanged(ListSelectionEvent e) {
        JXTable t = (JXTable)getComponent();
        int[] rows = t.getSelectedRows();
        List<Integer> l = new ArrayList<Integer>();
        for(int row : rows) {
            l.add(t.convertRowIndexToModel(row));
        }
        callWhenUIChanged(l);
    }
}