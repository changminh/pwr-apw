/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swingx.adapters;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.binding.Adapter;
import net.java.dev.properties.binding.swing.adapters.SwingAdapter;
import net.java.dev.properties.constraints.swing.SwingValidation;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.util.Utils;
import org.jdesktop.swingx.JXDatePicker;

/**
 * Implements a picker for
 *
 * @author Shai Almog
 */
public class DatePickerAdapter extends SwingAdapter<Date, JXDatePicker> implements ActionListener {
    protected void bindListener(BaseProperty<Date> property, JXDatePicker cmp) {
        cmp.addActionListener(this);
    }

    protected void unbindListener(BaseProperty<Date> property, JXDatePicker cmp) {
        cmp.removeActionListener(this);
    }

    protected void updateUI(Date newValue) {
        getComponent().setDate(newValue);
    }            

    public void actionPerformed(ActionEvent ev) {
        callWhenUIChanged(getComponent().getDate());
    }
    
    protected Class getType() {
        return Date.class;
    }

    protected Class getComponentType() {
        return JXDatePicker.class;
    }

    protected void setEmptyValue() {
        getComponent().setDate(new Date());
    }
}