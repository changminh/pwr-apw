/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swingx.adapters;

import javax.swing.event.ListSelectionEvent;
import net.java.dev.properties.binding.swing.adapters.TableIndexAdapter;
import org.jdesktop.swingx.JXTable;

/**
 * Implements table support for propagating selection UI changes
 *
 * @author Shai Almog
 */
public class SwingXTableIndexAdapter extends TableIndexAdapter {
    protected void updateUI(Integer newValue) {
        int val = ((JXTable)getComponent()).convertRowIndexToView(newValue);
        getComponent().setRowSelectionInterval(val, val);
    }            

    public void valueChanged(ListSelectionEvent e) {
        int val = ((JXTable)getComponent()).convertRowIndexToModel(getComponent().getSelectedRow());
        callWhenUIChanged(val);
    }
}