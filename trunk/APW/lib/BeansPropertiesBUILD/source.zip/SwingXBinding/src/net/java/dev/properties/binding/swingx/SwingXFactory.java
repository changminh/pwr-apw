/*
 * SwingXFactory.java
 *
 * Created on April 12, 2007, 12:00 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swingx;

import javax.swing.JComponent;
import javax.swing.JTable;
import net.java.dev.properties.binding.swing.SwingFactory;
import net.java.dev.properties.binding.swingx.adapters.SwingXBind;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.PropertyContext;
import org.jdesktop.swingx.JXTable;

/**
 * Dummy class that has no meaning of its own other than intializing the componet
 * factory appropriately
 *
 * @author shai
 */
public abstract class SwingXFactory extends SwingFactory {
    
    public static void init() {
        SwingXBind.init();
        setDefaultFactory(new SwingXComponentFactory());
    }
    
    /** Creates a new instance of SwingXFactory */
    public SwingXFactory() {
        BeanContainer.bind(this);
    }
}
