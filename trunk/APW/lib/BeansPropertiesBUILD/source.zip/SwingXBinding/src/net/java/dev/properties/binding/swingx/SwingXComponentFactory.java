/*
 * SwingXComponentFactory.java
 *
 * Created on March 13, 2007, 11:58 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swingx;

import java.util.Date;
import javax.swing.JComponent;
import javax.swing.JTable;
import net.java.dev.properties.binding.swing.*;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.PropertyContext;
import org.jdesktop.swingx.JXDatePicker;
import org.jdesktop.swingx.JXList;
import org.jdesktop.swingx.JXTable;

/**
 * A component factory for SwingX components 
 *
 * @author Shai Almog
 */
public class SwingXComponentFactory extends SwingComponentFactory {
    
    /** Creates a new instance of SwingXComponentFactory */
    public SwingXComponentFactory() {
        BeanContainer.bind(this);
        registerType(Date.class, JXDatePicker.class);
        registerIndexedTypeMulti(String.class, JXList.class);
        registerIndexedTypeMulti(Number.class, JXList.class);
        registerIndexedTypeMulti(Date.class, JXList.class);
    }
    
    /**
     * Optionally allows a subclass to return a default when all else fails
     */
    public JComponent createComponentFallback(PropertyContext propertyContext, PropertyContext selection, boolean indexed, boolean multiSelection) {
        if(indexed) {
            JXTable t = new JXTable();
            t.setColumnControlVisible(true);
            t.setFillsViewportHeight(true);
            return t;
        }
        return null;
    }
    
    

    protected int rowToModel(JTable t, int row) {
        return ((JXTable)t).convertRowIndexToModel(row);
    }
}
