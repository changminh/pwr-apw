/*
 * TableAdapterModel.java
 *
 * Created on March 3, 2007, 4:48 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swingx.adapters;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableInterface;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.IndexedPropertyListener;
import net.java.dev.properties.events.PropertyListener;
import org.jdesktop.swingx.treetable.*;
import org.jdesktop.swingx.treetable.TreeTableModel;

/**
 * The tree table model adapter is installed on treetables in order to enable binding
 * to a set of beans. Unlike a table, the treetable doesn't need to be "aware" of
 * all its children and so changes to sub nodes aren't reflected unless they
 * were requested by the model. However, once a node has been obtained by the model
 * then it will be tracked for changes from here on...
 *
 * @author Shai Almog
 */
public class TreeTableAdapterModel implements TreeTableModel {
    private Object root;
    private PropertyContext[] children;
    private PropertyContext[] columns;
    private PropertyContext isLeafProperty;
    private boolean automateLeafDetection = true;
    private boolean lock = false;
    private List<TreeModelListener> listeners = new CopyOnWriteArrayList<TreeModelListener>();
    private Map<Object, TreePath> pathCache = new WeakHashMap<Object, TreePath>();
    private PropertyListener globalListener = new IndexedPropertyListener() {
        private IndexedProperty prop;
        private Object value;
        private int index;
        private boolean isRemove;
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
            fireTreeNodesChanged(new TreeModelEvent(TreeTableAdapterModel.this, getPath(prop.getParent())));
        }
        
        private boolean shouldProcess(boolean isRemove, IndexedProperty prop, Object value, int index) {
            if(this.isRemove == isRemove && this.prop == prop && this.value == value && this.index == index) {
                return false;
            }
            this.isRemove = isRemove;
            this.prop = prop;
            this.value = value;
            this.index = index;
            return true;
        }

        public void propertyRemoved(IndexedProperty prop, Object value, int index) {
            // prevent duplicate events..
            if(shouldProcess(true, prop, value, index)) {
                fireTreeNodesRemoved(new TreeModelEvent(TreeTableAdapterModel.this, 
                    getPath(prop.getParent()), 
                    new int[] {index},new Object[] {value}));
            }
        }

        public void propertyInserted(IndexedProperty prop, Object value, int index) {
            // prevent duplicate events..
            if(shouldProcess(false, prop, value, index)) {
                fireTreeNodesInserted(new TreeModelEvent(TreeTableAdapterModel.this, 
                    getPath(prop.getParent()), 
                    new int[] {index},new Object[] {value}));
            }
        }
    };
    
    /**
     * The property context array must point at properties that are either indexed or
     * single but MUST be of the same type as the root! This allows the "tree" strucutre
     * to be maintained. The "leaf" property is optional and can be null, it is a boolean
     * property that would return true for leaf nodes.
     */
    public TreeTableAdapterModel(Object root, PropertyContext[] children, PropertyContext[] columns, PropertyContext isLeafProperty) {
        this.root = root;
        this.children = children;
        this.columns = columns;
        this.isLeafProperty = isLeafProperty;
    }

    /**
     * Returns the path for the given object
     */
    public TreePath getPath(Object o) {
        TreePath p = pathCache.get(o);
        if(p == null) {
            if(o == root) {
                p = new TreePath(o);
            } else {
                List l = new ArrayList();
                l.add(root);
                p = pathTo(l, o);
            }
            pathCache.put(o, p);
        }
        return p;
    }
    
    /**
     * Traverses the tree looking for a given path
     */
    private TreePath pathTo(List currentPath, Object o) {
        Object lastNode = currentPath.get(currentPath.size() - 1);
        int size = getChildCount(lastNode);
        for(int iter = 0 ; iter < size ; iter++) {
            Object child = getChildImpl(lastNode, iter);
            if(child == o) {
                currentPath.add(child);
                return new TreePath(currentPath.toArray());
            }
            currentPath.add(child);
            TreePath p = pathTo(currentPath, o);
            if(p != null) {
                return p;
            }
            currentPath.remove(currentPath.size() - 1);
        }
        return null;
    }
    
    /**
     * Returns the root of the tree.  Returns <code>null</code>
     * only if the tree has no nodes.
     * 
     * 
     * @return the root of the tree
     */
    public Object getRoot() {
        return root;
    }

    /**
     * Returns the index of child in parent.  If either <code>parent</code>
     * or <code>child</code> is <code>null</code>, returns -1.
     * If either <code>parent</code> or <code>child</code> don't
     * belong to this tree model, returns -1.
     * 
     * 
     * @param parent a node in the tree, obtained from this data source
     * @param child the node we are interested in
     * @return the index of the child in the parent, or -1 if either
     *    <code>child</code> or <code>parent</code> are <code>null</code>
     *    or don't belong to this tree model
     */
    public int getIndexOfChild(Object parent, Object child) {
        int count = getChildCount(parent);
        for(int iter = 0 ; iter < count ; iter++) {
            if(getChild(parent, iter) == child) {
                return iter;
            }
        }
        return -1;
    }

    /**
     * Returns the child of <code>parent</code> at index <code>index</code>
     * in the parent's
     * child array.  <code>parent</code> must be a node previously obtained
     * from this data source. This should not return <code>null</code>
     * if <code>index</code>
     * is a valid index for <code>parent</code> (that is <code>index >= 0 &&
     * index < getChildCount(parent</code>)).
     * 
     * 
     * @param parent  a node in the tree, obtained from this data source
     * @return the child of <code>parent</code> at index <code>index</code>
     */
    public Object getChild(Object parent, int index) {
        int offset = 0;
        for(PropertyContext p : children) {
            if(p.isIndexedProperty()) {
                IndexedProperty indexed = (IndexedProperty)p.getValue(parent);
                if(!BeanContainer.get().isListening(indexed, globalListener)) {
                    BeanContainer.get().addListener(indexed, globalListener);
                }
                int size = indexed.size();
                if(offset + size > index) {
                    Object value = indexed.get(index - offset);
                    if(value != null && BeanContainer.get().isNewBean(value.getClass()) && 
                            (!BeanContainer.get().isListening(value, globalListener))) {
                        BeanContainer.get().addListener(value, globalListener);
                    } 
                    return value;
                } else {
                    offset += size;
                    continue;
                }
            } 
            if(offset == index) {
                BaseProperty prop = p.getValue(parent);
                if(!BeanContainer.get().isListening(prop, globalListener)) {
                    BeanContainer.get().addListener(prop, globalListener);
                }
                return p.getInternalValue(parent);
            }
            offset++;
        }
        throw new IllegalArgumentException("Node: " + parent + " doesn't have a child at: " + index);
    }

    private Object getChildImpl(Object parent, int index) {
        int offset = 0;
        for(PropertyContext p : children) {
            if(p.isIndexedProperty()) {
                IndexedProperty indexed = (IndexedProperty)p.getValue(parent);
                int size = indexed.size();
                if(offset + size >= index) {
                    return indexed.get(index - offset);
                } else {
                    offset += size;
                    continue;
                }
            } 
            if(offset == index) {
                return p.getInternalValue(parent);
            }
            offset++;
        }
        throw new IllegalArgumentException("Node: " + parent + " doesn't have a child at: " + index);
    }
    
    /**
     * Returns <code>true</code> if <code>node</code> is a leaf.
     * It is possible for this method to return <code>false</code>
     * even if <code>node</code> has no children.
     * A directory in a filesystem, for example,
     * may contain no files; the node representing
     * the directory is not a leaf, but it also has no children.
     * 
     * 
     * @param node  a node in the tree, obtained from this data source
     * @return true if <code>node</code> is a leaf
     */
    public boolean isLeaf(Object node) {
        if(isLeafProperty != null) {
            return ((Boolean)isLeafProperty.getInternalValue(node)).booleanValue();
        } else {
            if(automateLeafDetection) {
                return node.getClass() != root.getClass();
            }
        }
        return false;
    }

    /**
     * Returns the number of children of <code>parent</code>.
     * Returns 0 if the node
     * is a leaf or if it has no children.  <code>parent</code> must be a node
     * previously obtained from this data source.
     * 
     * 
     * @param parent  a node in the tree, obtained from this data source
     * @return the number of children of the node <code>parent</code>
     */
    public int getChildCount(Object parent) {
        int count = 0;
        for(PropertyContext p : children) {
            if(p.isIndexedProperty()) {
                count += ((IndexedProperty)p.getValue(parent)).size();
            } else {
                count++;
            }
        }
        return count;
    }

    /**
     * Removes a listener previously added with
     * <code>addTreeModelListener</code>.
     * 
     * 
     * @param l       the listener to remove
     * @see #addTreeModelListener
     */
    public void removeTreeModelListener(TreeModelListener l) {
        listeners.remove(l);
    }

    /**
     * Adds a listener for the <code>TreeModelEvent</code>
     * posted after the tree changes.
     * 
     * 
     * @param l       the listener to add
     * @see #removeTreeModelListener
     */
    public void addTreeModelListener(TreeModelListener l) {
        listeners.add(l);
    }

    private void fireTreeNodesChanged(TreeModelEvent e) {
        for(TreeModelListener listener : listeners) {
            listener.treeNodesChanged(e);
        }
    }

    private void fireTreeNodesInserted(TreeModelEvent e) {
        for(TreeModelListener listener : listeners) {
            listener.treeNodesInserted(e);
        }
    }

    private void fireTreeNodesRemoved(TreeModelEvent e) {
        for(TreeModelListener listener : listeners) {
            try {
                listener.treeNodesRemoved(e);
            } catch(NullPointerException err) {
                // this is caused by javax.swing.JTree.TreeModelHandler.treeNodesRemoved()
                // I have no idea why????
                err.printStackTrace();
            }
        }
    }

    private void fireTreeStructureChanged(TreeModelEvent e) {
        for(TreeModelListener listener : listeners) {
            listener.treeStructureChanged(e);
        }
    }
    
    /**
     * Messaged when the user has altered the value for the item identified
     * by <code>path</code> to <code>newValue</code>. 
     * If <code>newValue</code> signifies a truly new value
     * the model should post a <code>treeNodesChanged</code> event.
     * 
     * 
     * @param path path to the node that the user has altered
     * @param newValue the new value from the TreeCellEditor
     */
    public void valueForPathChanged(TreePath path, Object newValue) {
    }

    public boolean isAutomateLeafDetection() {
        return automateLeafDetection;
    }

    public void setAutomateLeafDetection(boolean automateLeafDetection) {
        this.automateLeafDetection = automateLeafDetection;
    }

    public void setValueAt(Object value, Object node, int column) {
        ((WProperty)columns[column - 1].getValue(node)).set(value);
    }

    public boolean isCellEditable(Object node, int column) {
        if(column == 0) {
            // tree uneditable for now...
            return false;
        }

        // technically a check whether the property exists on the given bean
        // seems to be a better approach, however it would cause a performance
        // penalty even when support for multiple bean types isn't necessary
        // and its a major change. So for now this is a simpler solution.
        try {
            return columns[column - 1].getValue(node) instanceof WProperty;
        } catch(BeanBindException err) {
            return false;
        }
    }

    public Object getValueAt(Object node, int column) {
        if(column == 0) {
            return node;
        }
    
        // technically a check whether the property exists on the given bean
        // seems to be a better approach, however it would cause a performance
        // penalty even when support for multiple bean types isn't necessary
        // and its a major change. So for now this is a simpler solution.
        try {
            return columns[column - 1].getInternalValue(node);
        } catch(BeanBindException err) {
            return null;
        }
    }

    public String getColumnName(int column) {
        if(column == 0) {
            return children[0].getDisplayName();
        }

        return columns[column - 1].getDisplayName();
    }

    public Class getColumnClass(int column) {
        if(column == 0) {
            return AbstractTreeTableModel.hierarchicalColumnClass;
        }

        return columns[column - 1].getType();
    }

    public int getColumnCount() {
        return columns.length + 1;
    }

    public int getHierarchicalColumn() {
        return 0;
    }
}
