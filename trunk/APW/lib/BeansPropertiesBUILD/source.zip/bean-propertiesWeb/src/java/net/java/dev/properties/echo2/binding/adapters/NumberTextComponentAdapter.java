/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import java.text.DecimalFormat;
import java.text.Format;
import java.text.ParseException;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import net.java.dev.properties.util.Utils;
import nextapp.echo2.app.event.DocumentEvent;
import nextapp.echo2.app.event.DocumentListener;
import nextapp.echo2.app.text.TextComponent;

/**
 * Implements toggle button support for the state change/ui
 *
 * @author Shai Almog
 */
class NumberTextComponentAdapter extends Echo2Adapter<Number, TextComponent> implements DocumentListener {
    private static Format FORMAT = DecimalFormat.getNumberInstance();
    protected void bindListener(BaseProperty<Number> property, TextComponent cmp) {
        cmp.getDocument().addDocumentListener(this);
    }

    protected void unbindListener(BaseProperty<Number> property, TextComponent cmp) {
        cmp.getDocument().removeDocumentListener(this);
    }

    protected void updateUI(Number newValue) {
        if(newValue == null) {
            getComponent().setText("");
        } else {
            getComponent().setText(FORMAT.format(newValue));
        }
    }            

    public void documentUpdate(DocumentEvent e) {
        try {
            Number n = (Number)FORMAT.parseObject(getComponent().getText());
            callWhenUIChanged(Utils.normalizeType(n, getProperty().getContext().getType()));
        } catch(ParseException err) {
            // not much to do here...
            err.printStackTrace();
        }
    }

    protected Class getType() {
        return Number.class;
    }

    protected Class getComponentType() {
        return TextComponent.class;
    }
}