/*
 * YogaStudio.java
 *
 * Created on March 29, 2007, 8:24 PM
 */

package net.java.dev.properties.echo2.test.recipe;

import net.java.dev.properties.binding.UIFactory;
import net.java.dev.properties.echo2.test.*;
import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.binding.PropertySelectionListener;
import net.java.dev.properties.echo2.binding.Echo2Factory;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.SessionConfiguration;
import net.java.dev.properties.test.recipe.CookBook;
import net.java.dev.properties.test.recipe.Recipe;
import nextapp.echo2.app.Alignment;
import nextapp.echo2.app.ApplicationInstance;
import nextapp.echo2.app.Button;
import nextapp.echo2.app.Column;
import nextapp.echo2.app.Component;
import nextapp.echo2.app.ContentPane;
import nextapp.echo2.app.Extent;
import nextapp.echo2.app.Row;
import nextapp.echo2.app.TextArea;
import nextapp.echo2.app.Window;
import nextapp.echo2.app.event.ActionEvent;
import nextapp.echo2.app.event.ActionListener;
import nextapp.echo2.app.layout.ColumnLayoutData;
import nextapp.echo2.webcontainer.WebContainerServlet;

/**
 * 
 *
 * @author Shai Almog
 */
public class CookBookServlet extends WebContainerServlet {
    public ApplicationInstance newApplicationInstance() {
        return new ApplicationInstance() {
            public Window init() {
                final CookBook m = CookBook.initCookBookDB();

                Window window = new Window();
                window.setTitle("Cook Book");

                ContentPane contentPane = new ContentPane();
                window.setContent(contentPane);
                Column layout = new Column();
                contentPane.add(layout);

                UIFactory<Component> factory = Echo2Factory.columnLayoutFactory(1);
                Recipe recipe = new Recipe();
                factory.ignoreProperties.add(recipe.id.getContext());
                factory.componentFactory.get().overrideCreate.set(recipe.instructions.getContext(), TextArea.class);
                Component masterDetail = factory.createMasterDetail(m.recipes, factory);
                layout.add(masterDetail);
                
                Row buttonPane = new Row();
                buttonPane.setCellSpacing(new Extent(5));
                ColumnLayoutData columnLayoutData = new ColumnLayoutData();
                columnLayoutData.setAlignment(new Alignment(Alignment.CENTER, Alignment.DEFAULT));
                buttonPane.setLayoutData(columnLayoutData);                
                
                Button addButton = new Button("Add");
                Button removeButton = new Button("Remove");
                Button saveButton = new Button("Save");
                buttonPane.add(addButton);
                buttonPane.add(removeButton);
                buttonPane.add(saveButton);
                layout.add(buttonPane);
                
                addButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Recipe r = new Recipe("Title");
                        CurrentSession.get().insert(r);
                        m.recipes.add(r);
                    }
                });
                class RemoveAction implements ActionListener, PropertySelectionListener {
                    private int[] selection;
                    public void actionPerformed(ActionEvent e) {
                        for(int iter = selection.length - 1 ; iter > -1 ; iter--) {
                            Recipe r = m.recipes.get(selection[iter]);
                            m.recipes.remove(selection[iter]);
                            CurrentSession.get().delete(r);
                        }
                    }
                    public void selectionChanged(IndexedProperty property, int[] selection) {
                        this.selection = selection;
                    }
                }
                RemoveAction removeListener = new RemoveAction();
                factory.addPropertySelectionListener(removeListener, m.recipes, masterDetail);

                removeButton.addActionListener(removeListener);

                saveButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        CurrentSession.get().flushAndCommit();
                    }
                });
                
                return window;
            }
        };
    };
}
