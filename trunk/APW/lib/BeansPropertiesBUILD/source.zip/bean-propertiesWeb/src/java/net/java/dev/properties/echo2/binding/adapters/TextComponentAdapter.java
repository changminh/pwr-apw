/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import nextapp.echo2.app.event.ActionEvent;
import nextapp.echo2.app.event.ActionListener;
import nextapp.echo2.app.event.DocumentEvent;
import nextapp.echo2.app.event.DocumentListener;
import nextapp.echo2.app.text.TextComponent;

/**
 * Implements toggle button support for the state change/ui
 *
 * @author Shai Almog
 */
class TextComponentAdapter extends Echo2Adapter<String, TextComponent> implements DocumentListener {
    protected void bindListener(BaseProperty<String> property, TextComponent cmp) {
        cmp.getDocument().addDocumentListener(this);
    }

    protected void unbindListener(BaseProperty<String> property, TextComponent cmp) {
        cmp.getDocument().removeDocumentListener(this);
    }

    protected void updateUI(String newValue) {
        getComponent().setText(newValue);
    }            

    public void documentUpdate(DocumentEvent e) {
        callWhenUIChanged(getComponent().getText());
    }

    protected Class getType() {
        return String.class;
    }

    protected Class getComponentType() {
        return TextComponent.class;
    }
}