/*
 * YogaStudio.java
 *
 * Created on March 29, 2007, 8:24 PM
 */

package net.java.dev.properties.echo2.test;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;
import nextapp.echo2.app.ApplicationInstance;
import nextapp.echo2.webcontainer.WebContainerServlet;

/**
 *
 * @author Shai Almog
 * @version
 */
public class YogaStudio extends WebContainerServlet {
    public ApplicationInstance newApplicationInstance() {
        return new StudioApp();
    }
}
