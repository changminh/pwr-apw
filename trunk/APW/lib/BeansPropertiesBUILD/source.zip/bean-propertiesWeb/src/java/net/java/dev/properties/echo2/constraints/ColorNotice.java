/*
 * ColorNotice.java
 *
 * Created on March 31, 2007, 10:02 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.constraints;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.echo2.binding.Echo2ClientProperty;
import net.java.dev.properties.echo2.binding.adapters.TableAdapterModel;
import net.java.dev.properties.constraints.ValidationNotice;
import net.java.dev.properties.container.BeanContainer;
import nextapp.echo2.app.Color;
import nextapp.echo2.app.Component;
import nextapp.echo2.app.Label;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.MutableStyle;
import nextapp.echo2.app.SelectField;
import nextapp.echo2.app.Style;
import nextapp.echo2.app.Table;
import nextapp.echo2.app.table.TableCellRenderer;
import nextapp.echo2.app.text.TextComponent;

/**
 * A simple validation notice that paints the component in a given color
 *
 * @author Shai Almog
 */
public class ColorNotice implements ValidationNotice<Component>, java.io.Serializable {
    public final Property<Color> invalidColor = new PropertyImpl<Color>(Color.RED);
    private Map<Table, List<Cell>> tableInvalids = new HashMap<Table, List<Cell>>();
    
    public ColorNotice() {
        BeanContainer.bind(this);
    }
    
    private MutableStyle copyStyle(Style s) {
        // TODO: this should probably use DerivedMutableStyle, but I need to understand
        // the implications firts...
        MutableStyle m = new MutableStyle();
        if(s == null) {
            return new MutableStyle();
        }
        Iterator i = s.getPropertyNames();
        while(i.hasNext()) {
            String prop = (String)i.next();
            Object value = s.getProperty(prop);
            m.setProperty(prop, value);
        }
        return m;
    }

    /**
     * Makes sure the cell column is wrapped in a renderer that can display
     * validity information properly...
     */
    private void applyProxyRenderer(int row, int column, Table t) {
        Class c = t.getModel().getColumnClass(column);
        TableCellRenderer renderer = t.getDefaultRenderer(c);
        if(renderer == null || renderer == Table.DEFAULT_TABLE_CELL_RENDERER) {
            renderer = new ProxyRenderer(Table.DEFAULT_TABLE_CELL_RENDERER);
            t.setDefaultRenderer(c, renderer);
            return;
        } 
        
        if(!(renderer instanceof ProxyRenderer)) {
            renderer = new ProxyRenderer(renderer);
            t.setDefaultRenderer(c, renderer);
        }
    }
    
    public void updateValidationStatus(BaseProperty property, 
        Component component, boolean valid, String message) {
        Style s = component.getStyle();
        if(component instanceof Table) {
            Map<BaseProperty, Integer> invalids = (Map<BaseProperty, Integer>)Echo2ClientProperty.get(component, "InvalidMap");
            Table table = (Table)component;
            List<Cell> rowColumnInvalid = tableInvalids.get(table);
            if(rowColumnInvalid == null) {
                rowColumnInvalid = new ArrayList<Cell>();
                tableInvalids.put(table, rowColumnInvalid);
            }
            rowColumnInvalid.clear();
            if(invalids != null && invalids.size() > 0) {
                MutableStyle m = copyStyle(table.getStyle());
                for(Map.Entry<BaseProperty, Integer> entry : invalids.entrySet()) {
                    TableAdapterModel model = (TableAdapterModel)table.getModel();
                    int column = model.getColumn(entry.getKey().getContext());
                    int row = entry.getValue();
                    rowColumnInvalid.add(new Cell(row, column));
                    applyProxyRenderer(row, column, table);
                }
                table.setStyle(m);
            }
            return;
        }
        if(valid) {
            Color c = (Color)Echo2ClientProperty.get(component, "old_color");
            if(s != null && s.getProperty(Component.PROPERTY_BACKGROUND) == invalidColor.get()) {
                MutableStyle m = copyStyle(s);
                if(c != null) {
                    m.setProperty(Component.PROPERTY_BACKGROUND, c);
                } else {
                    m.removeProperty(Component.PROPERTY_BACKGROUND);
                }
                component.setStyle(m);
            }
        } else {
            Color c = (Color)Echo2ClientProperty.get(component, "old_color");
            if(c != invalidColor.get()) {
                if(s != null) {
                    Echo2ClientProperty.put(component, "old_color", s.getProperty(Component.PROPERTY_BACKGROUND));
                }
                MutableStyle m = copyStyle(s);
                if(component instanceof TextComponent) {
                    m.setProperty(TextComponent.PROPERTY_TOOL_TIP_TEXT, message);
                } else {
                    if(component instanceof ListBox) {
                        m.setProperty(ListBox.PROPERTY_TOOL_TIP_TEXT, message);
                    } else {
                        if(component instanceof SelectField) {
                            m.setProperty(SelectField.PROPERTY_TOOL_TIP_TEXT, message);
                        }
                    }
                }
                m.setProperty(Component.PROPERTY_BACKGROUND, invalidColor.get());
                component.setStyle(m);
            }
        }
    }   
    
    private class ProxyRenderer implements TableCellRenderer {
        private TableCellRenderer parent;
        private Color original;
        
        public ProxyRenderer(TableCellRenderer parent) {
            this.parent = parent;
        }
        
        public Component getTableCellRendererComponent(Table table, Object value, int column, int row) {
            Component val = parent.getTableCellRendererComponent(table, value, column, row);
            List<Cell> rowColumnInvalid = tableInvalids.get(table);
            
            // If this cell is invalid
            if(rowColumnInvalid.contains(new Cell(row, column))) {
                if(val == null) {
                    val = new Label();
                    val.setBackground(invalidColor.get());
                    return val;
                }
                if(val.getBackground() != invalidColor.get()) {
                    original = val.getBackground();
                    val.setBackground(invalidColor.get());
                }
            } else {
                if(val == null) {
                    return null;
                }
                if(val.getBackground() == invalidColor.get()) {
                    val.setBackground(original);
                }
            }
            
            return val;
        }
    }
    
    private static class Cell implements java.io.Serializable {
        private int row;
        private int column;
        public Cell(int row, int column) {
            this.row = row;
            this.column = column;
        }
        
        public boolean equals(Object o) {
            return (o instanceof Cell) && ((Cell)o).row == row && ((Cell)o).column == column;
        }

        public int hashCode() {
            return row;
        }
    }
}
