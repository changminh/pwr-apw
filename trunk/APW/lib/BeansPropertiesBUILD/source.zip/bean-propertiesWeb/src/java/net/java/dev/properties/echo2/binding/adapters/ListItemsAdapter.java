/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import java.util.Arrays;
import java.util.List;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.event.ChangeEvent;
import nextapp.echo2.app.event.ChangeListener;
import nextapp.echo2.app.list.ListSelectionModel;

/**
 * Implements list support for propagating UI changes
 *
 * @author Shai Almog
 */
class ListItemsAdapter extends Echo2Adapter<List<Object>, ListBox> implements ChangeListener {
    protected void bindListener(BaseProperty<List<Object>> property, ListBox cmp) {
        cmp.getSelectionModel().addChangeListener(this);
        cmp.setSelectionMode(ListSelectionModel.MULTIPLE_SELECTION);
    }

    protected void unbindListener(BaseProperty<List<Object>> property, ListBox cmp) {
        cmp.getSelectionModel().removeChangeListener(this);
    }

    private int getOffset(Object o) {
        IndexedProperty<Object> p = (IndexedProperty<Object>)getProperty();
        for(int iter = 0 ; iter < p.size() ; iter++) {
            if(p.get(iter).equals(o)) {
                return iter;
            }
        }
        return -1;
    }
    
    protected void updateUI(List<Object> newValue) {
        int[] array = new int[newValue.size()];
        for(int iter = 0 ; iter < array.length ; iter++) {
            array[iter] = getOffset(newValue.get(iter));
        }
        getComponent().setSelectedIndices(array);
    }            

    public void stateChanged(ChangeEvent e) {
        callWhenUIChanged(Arrays.asList(getComponent().getSelectedValues()));
    }

    protected Class getType() {
        return List.class;
    }

    protected Class getComponentType() {
        return ListBox.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}