/*
 * TableAdapterModel.java
 *
 * Created on March 3, 2007, 4:48 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.IndexedPropertyListener;
import net.java.dev.properties.events.PropertyListener;
import nextapp.echo2.app.table.AbstractTableModel;

/**
 * The table model adapter is installed on tables in order to enable binding
 * to a set of beans. A set of property context objects describe the columns 
 * within the table. The default implementation uses some reflection so in order
 * to slightly improve performance one can derive this class and override all the
 * methods that use reflection (they are marked appropriately).
 *
 * @author Shai Almog
 */
public class TableAdapterModel extends AbstractTableModel {
    private IndexedProperty<Object> beans;
    private PropertyContext[] columns;
    private boolean lock = false;
    
    /** Creates a new instance of TableAdapterModel */
    public TableAdapterModel(IndexedProperty<Object> beans, PropertyContext[] columns) {
        this.beans = beans;
        this.columns = columns;
        BeanContainer.get().addListener(beans, new Listener());
    }

    public void fireSafe(int row) {
        if(!lock){ 
            lock = true;
            fireTableRowsUpdated(row, row);
            lock = false;
        }
    }
    
    /**
     * Uses reflection
     */
    public Object getValueAt(int columnIndex, int rowIndex) {
        BaseProperty val = columns[columnIndex].getValue(beans.get(rowIndex));
        return ((RProperty)val).get();
    }

    public int getRowCount() {
        return beans.size();
    }

    public int getColumnCount() {
        return columns.length;
    }

    public String getColumnName(int column) {
        return columns[column].getDisplayName();
    }

    /**
     * Uses reflection
     */
    public Class<?> getColumnClass(int columnIndex) {
        Class<?> c = columns[columnIndex].getType();
        return c;
    }
    
    /**
     * Returns the column offset for the given column
     */
    public int getColumn(PropertyContext context) {
        for(int iter = 0 ; iter < columns.length ; iter++) {
            if(columns[iter] == context) {
                return iter;
            }
        }
        return -1;
    }
    
    class Listener implements IndexedPropertyListener, java.io.Serializable {
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
            if(!lock) {
                lock = true;
                fireTableRowsUpdated(index, index);
                lock = false;
            }
        }

        public void propertyRemoved(IndexedProperty prop, Object value, int index) {
            if(!lock) {
                lock = true;
                fireTableRowsDeleted(index, index);
                lock = false;
            }
        }

        public void propertyInserted(IndexedProperty prop, Object value, int index) {
            if(!lock) {
                lock = true;
                fireTableRowsInserted(index, index);
                lock = false;
            }
        }
    }
}
