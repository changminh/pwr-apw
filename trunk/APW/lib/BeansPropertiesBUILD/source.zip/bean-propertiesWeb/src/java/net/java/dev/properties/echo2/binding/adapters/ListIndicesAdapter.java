/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import java.util.ArrayList;
import java.util.List;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.util.Utils;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.event.ChangeEvent;
import nextapp.echo2.app.event.ChangeListener;
import nextapp.echo2.app.list.ListSelectionModel;

/**
 * Implements list support for propagating UI changes
 *
 * @author Shai Almog
 */
class ListIndicesAdapter extends Echo2Adapter<List<Integer>, ListBox> implements ChangeListener {
    protected void bindListener(BaseProperty<List<Integer>> property, ListBox cmp) {
        cmp.getSelectionModel().addChangeListener(this);
        cmp.setSelectionMode(ListSelectionModel.MULTIPLE_SELECTION);
    }

    protected void unbindListener(BaseProperty<List<Integer>> property, ListBox cmp) {
        cmp.getSelectionModel().removeChangeListener(this);
    }

    protected void updateUI(List<Integer> newValue) {
        getComponent().setSelectedIndices((int[])
        Utils.asArray((IndexedProperty<Integer>)getProperty(), Integer.TYPE));
    }            

    public void stateChanged(ChangeEvent e) {
        callWhenUIChanged((List<Integer>)
        Utils.addToCollection(getComponent().getSelectedIndices(), new ArrayList<Integer>()));
    }

    protected Class getType() {
        return List.class;
    }

    protected Class getComponentType() {
        return ListBox.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}