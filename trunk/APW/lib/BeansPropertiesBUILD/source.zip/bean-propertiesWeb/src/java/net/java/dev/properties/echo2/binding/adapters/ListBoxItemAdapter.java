/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.event.ChangeEvent;
import nextapp.echo2.app.event.ChangeListener;
import nextapp.echo2.app.list.ListModel;

/**
 * Implements combo box support for propagating UI changes
 *
 * @author Shai Almog
 */
class ListBoxItemAdapter extends Echo2Adapter<Object, ListBox> implements ChangeListener {
    protected void bindListener(BaseProperty<Object> property, ListBox cmp) {
        cmp.getSelectionModel().addChangeListener(this);
    }

    protected void unbindListener(BaseProperty<Object> property, ListBox cmp) {
        cmp.getSelectionModel().removeChangeListener(this);
    }

    protected void updateUI(Object newValue) {
        if(newValue == null) {
            getComponent().getSelectionModel().clearSelection();
            return;
        }
        ListModel m = getComponent().getModel();
        int size = m.size();
        for(int iter = 0 ; iter < size ; iter++) {
            if(m.get(iter).equals(newValue)) {
                getComponent().setSelectedIndex(iter);
                return;
            }
        }
    }            

    public void stateChanged(ChangeEvent e) {
        callWhenUIChanged(getComponent().getSelectedValue());
    }

    protected Class getType() {
        return Object.class;
    }

    protected Class getComponentType() {
        return ListBox.class;
    }
}