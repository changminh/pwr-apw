/*
 * SwingAdapter.java
 *
 * Created on March 6, 2007, 11:43 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import net.java.dev.properties.echo2.binding.Echo2ClientProperty;
import nextapp.echo2.app.Component;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;

/**
 * An adapter customized for the needs of Swing
 *
 * @author Shai Almog
 */
abstract class Echo2Adapter<T, V extends Component> extends Adapter<T, V> {    
    protected void bindUI(BaseProperty<T> property, V component) {
        if(isSelectionBind()) {
            Echo2ClientProperty.put(component, "SelectionProperty", property);
            Echo2ClientProperty.put(component, "SelectionAdapter", this);
        } else {
            Echo2ClientProperty.put(component, "Property", property);
            Echo2ClientProperty.put(component, "Adapter", this);
        }
        bindListener(property, component);
    }

    /**
     * Unbinds the listeners in the subclass appropriately
     */
    protected void unbindUI(BaseProperty<T> property, V component) {
        Echo2ClientProperty.put(component, "Property", null);
        Echo2ClientProperty.put(component, "Adapter", null);
        Echo2ClientProperty.put(component, "SelectionProperty", null);
        Echo2ClientProperty.put(component, "SelectionAdapter", null);
        unbindListener(property, component);
    }
    
    protected Echo2Adapter<T, V> getBoundAdapter(V component) {
        return (Echo2Adapter<T, V>)Echo2ClientProperty.get(component, "Adapter");
    }

    protected Echo2Adapter<T, V> getBoundSelectionAdapter(V component) {
        return (Echo2Adapter<T, V>)Echo2ClientProperty.get(component, "SelectionAdapter");
    }

    public static void unbindComponent(Component c) {
        Adapter a = (Adapter)Echo2ClientProperty.get(c, "Adapter");
        if(a != null) {
            a.unbind(c);
        }
        a = (Adapter)Echo2ClientProperty.get(c, "SelectionAdapter");
        if(a != null) {
            a.unbind(c);
        }
    }
    
    /**
     * Indicates the selection based binding
     */
    protected boolean isSelectionBind() {
        return false;
    }
    
    /**
     * Binds the listeners in the subclass appropriately
     */
    protected abstract void bindListener(BaseProperty<T> property, V component);

    /**
     * Binds the listeners in the subclass appropriately
     */
    protected abstract void unbindListener(BaseProperty<T> property, V component);

    /**
     * Since Swing adapters are package protected they must be created from within
     * this class...
     */
    public void createBoundInstance(BaseProperty property, V component) {
        try {
            Echo2Adapter<T,V> newInstance = (Echo2Adapter<T, V>)getClass().newInstance();
            newInstance.bind((BaseProperty<T>)property, component);
        } catch(Exception err) {
            throw new BeanBindException(err);
        }
    }
}
