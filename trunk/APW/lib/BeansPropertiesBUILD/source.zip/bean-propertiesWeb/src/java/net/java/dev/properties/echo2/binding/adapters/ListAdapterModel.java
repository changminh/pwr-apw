/*
 * ComboAndListModel.java
 *
 * Created on March 3, 2007, 4:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import java.util.ArrayList;
import java.util.List;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.IndexedPropertyListener;
import net.java.dev.properties.events.PropertyListener;
import nextapp.echo2.app.list.AbstractListModel;

/**
 * A class representing the model installed to bound lists, it is
 * only necessary to have this model installed if the data for the list
 * is bound. If the data is hardcoded in the application then these models are
 * unnecessary.
 * <p>When binding the combo or list this model will be installed automatically
 * overriding any existing model so technically a user doesn't need to be aware
 * of its existence. It is however exposed via the API to allow some manual 
 * manipulation.
 *
 * @author Shai Almog
 */
public class ListAdapterModel<T> extends AbstractListModel {
    private IndexedProperty<T> prop;
    
    /** Creates a new instance of ComboAndListModel */
    public ListAdapterModel(IndexedProperty<T> prop) {
        this.prop = prop;
        BeanContainer.get().addListener(prop, new IndexedPropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                fireContentsChanged(index, index);
            }
            public void propertyInserted(IndexedProperty prop, Object value, int index) {
                fireIntervalAdded(index, index);
            }
            public void propertyRemoved(IndexedProperty prop, Object value, int index) {
                fireIntervalRemoved(index, index);
            }
        });
    }

    public int size() {
        return prop.size();
    }

    public Object get(int index) {
        return prop.get(index);
    }
}
