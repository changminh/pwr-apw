/*
 * SwingValidation.java
 *
 * Created on March 5, 2007, 2:43 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.constraints;

import java.util.HashMap;
import java.util.Map;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.echo2.binding.Echo2ClientProperty;
import net.java.dev.properties.constraints.ValidationManager;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.echo2.constraints.ColorNotice;
import net.java.dev.properties.events.PropertyListener;
import nextapp.echo2.app.Component;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.Table;
import nextapp.echo2.app.event.ChangeEvent;
import nextapp.echo2.app.event.ChangeListener;
import nextapp.echo2.app.list.ListSelectionModel;

/**
 * The echo2 implementation of the ValidationManager
 *
 * @author Shai Almog
 */
public class Echo2Validation extends ValidationManager<Component> implements java.io.Serializable {
    private static final String VALIDATION_TAG = "Validation Marker";
    private static final String VALIDATION_LISTENER = "Validation Listener";
    private static Echo2Validation instance;
    
    protected Echo2Validation() {
        notice.set(new ColorNotice());
    }

    /**
     * This method canbe invoked by the binding layer to indicate that a validation
     * error occured that can't be conveyed to the model.
     */
    public void setComponentValidity(final BaseProperty prop, Component component, boolean value) {
        Boolean b = (Boolean)Echo2ClientProperty.get(component, VALIDATION_TAG);
        if(b == null || b.booleanValue() != value) {
            Echo2ClientProperty.put(component, VALIDATION_TAG, value);
            PropertyListener listener = findListener(component);
            if(listener != null) {
                if(prop instanceof RProperty) {
                    listener.propertyChanged(prop, "", ((RProperty)prop).get(), 0);
                } else {
                    listener.propertyChanged(prop, "", "", 0);
                }
            }
            String message = "";
            if(prop instanceof RProperty) {
                message = prop.getContext().getValidationMessage(prop, ((RProperty)prop).get());
            }
            notice.get().updateValidationStatus(prop, component, value, message);
        }
    }

    /**
     * This method is invoked to refresh the view side of the component. Calling setComponent
     * validity removes the need to invoke this method.
     */
    public void refreshComponentValidity(BaseProperty prop, Component component, boolean value, String message) {
        Object p = Echo2ClientProperty.get(component, "Property");
        if(p == prop) {
            Boolean b = (Boolean)Echo2ClientProperty.get(component, VALIDATION_TAG);
            if(b == null || b.booleanValue() != value) {
                PropertyListener listener = findListener(component);
                notice.get().updateValidationStatus(prop, component, value, message);
            }
            return;
        }
        
        // iterate over the components and look for the component matching this property
        for(Component comp : component.getComponents()) {
            refreshComponentValidity(prop, comp, value, message);
        }
    }

    protected PropertyListener getListener(Component cmp) {
        return (PropertyListener)Echo2ClientProperty.get(cmp, VALIDATION_LISTENER);
    }

    /**
     * Finds the listener hiding within the client property
     */
    private PropertyListener findListener(Component cmp) {
        PropertyListener l = (PropertyListener)Echo2ClientProperty.get(cmp, VALIDATION_LISTENER);
        if(l != null) {
            return l;
        }
        Component c = cmp.getParent();
        if(c != null) {
            return findListener(c);
        }
        return null;
    }
    
    public static Echo2Validation getInstance() {
        if(instance == null) {
            instance = new Echo2Validation();
        }
        return instance;
    }
    
    protected void setEnabled(Component component, boolean enabled) {
        component.setEnabled(enabled);
    }

    /**
     * Registers interest in changes to any of the components within parent component
     * if validation state changes this listener should be notified
     */
    protected void registerInterest(Component parentComponent, PropertyListener listener) {
        Echo2ClientProperty.put(parentComponent, VALIDATION_LISTENER, listener);
    }

    /**
     * Tracks the validity of complex components that are bound to indexed properties
     * such as tables and lists.
     */
    public void trackIndexedValidity(final IndexedProperty indexed, final Component component) {
        ListSelectionModel selectionModel;
        if(component instanceof Table) {
            selectionModel = ((Table)component).getSelectionModel();
        } else {
            if(component instanceof ListBox) {
                selectionModel = ((ListBox)component).getSelectionModel();
            } else {
                // no other options supported at the moment...
                return;
            }
        }
        final PropertyListener l = new PropertyListener() {
            // The list of invalid bean 
            private Map<BaseProperty, Integer> invalids = new HashMap<BaseProperty, Integer>();
            
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                boolean val = prop.getContext().validate(prop, newValue);
                String message = "";
                if(index < 0) {
                    if(component instanceof Table) {
                        index = ((Table)component).getSelectionModel().getMinSelectedIndex();
                    }
                }
                if(val) {
                    invalids.remove(prop);
                    if(invalids.size() > 0) {
                        BaseProperty p = invalids.keySet().iterator().next();
                        message = p.getContext().getValidationMessage(p);
                    }
                } else {
                    if(!invalids.containsKey(prop)) {
                        invalids.put(prop, index);
                    }
                    message = prop.getContext().getValidationMessage(prop, newValue);
                }
                Echo2ClientProperty.put(component, "InvalidMap", invalids);
                refreshComponentValidity(indexed, component, 
                    invalids.size() == 0, 
                    message);
            }
        };
        selectionModel.addChangeListener(new ChangeListener() {
            // The last selected bean
            private Object bean;
            private int lastIndex = -1;
            public void stateChanged(ChangeEvent e) {
                int index = ((ListSelectionModel)e.getSource()).getMinSelectedIndex();
                if(lastIndex == index) {
                    return;
                }
                lastIndex = index;
                
                if(bean != null) {
                    BeanContainer.get().removeListener(bean, l);
                }
                if(index > -1) {
                    bean = indexed.get(index);
                } else {
                    bean = null;
                    return; 
                }
                registerInterest(component, l);
                BeanContainer.get().addListener(bean, l);
                refreshBeanComponentValidity(bean, component);        
            }
        });
    }

    /**
     * Returns true if all the bindings beween the given components hierarchy and
     * the bean are valid. A good example of when something like this might fail
     * is when a bean property is numeric but the user entered text in the view.
     */
    public boolean isComponentValid(Component component) {
        Boolean b = (Boolean)Echo2ClientProperty.get(component, VALIDATION_TAG);
        if(b != null && (!b.booleanValue())) {
            return false;
        }
        
        // traverse the component tree and seek components marked as invalid
        for(Component currentCmp : component.getComponents()) {
            b = (Boolean)Echo2ClientProperty.get(currentCmp, VALIDATION_TAG);
            if(b != null && (!b.booleanValue())) {
                return false;
            }
            if(!isComponentValid(currentCmp)) {
                return false;
            }
        }
        return true;
    }
}
