/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.event.ChangeEvent;
import nextapp.echo2.app.event.ChangeListener;
import nextapp.echo2.app.list.ListModel;

/**
 * Implements combo box support for propagating UI changes
 *
 * @author Shai Almog
 */
class ListBoxIndexAdapter extends Echo2Adapter<Integer, ListBox> implements ChangeListener {
    protected void bindListener(BaseProperty<Integer> property, ListBox cmp) {
        cmp.getSelectionModel().addChangeListener(this);
    }

    protected void unbindListener(BaseProperty<Integer> property, ListBox cmp) {
        cmp.getSelectionModel().removeChangeListener(this);
    }

    protected void updateUI(Integer newValue) {
        getComponent().setSelectedIndex(newValue);
    }            

    public void stateChanged(ChangeEvent e) {
        callWhenUIChanged(getComponent().getSelectionModel().getMinSelectedIndex());
    }

    protected Class getType() {
        return Integer.class;
    }

    protected Class getComponentType() {
        return ListBox.class;
    }
}