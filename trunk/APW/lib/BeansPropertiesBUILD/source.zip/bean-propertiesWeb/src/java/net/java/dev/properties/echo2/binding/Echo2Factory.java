/*
 * UIFactory.java
 *
 * Created on March 6, 2007, 6:25 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding;

import java.util.ArrayList;
import java.util.List;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.binding.PropertySelectionListener;
import net.java.dev.properties.binding.UIFactory;
import net.java.dev.properties.echo2.binding.adapters.Echo2Bind;
import net.java.dev.properties.echo2.binding.adapters.TableAdapterModel;
import net.java.dev.properties.constraints.ValidationManager;
import net.java.dev.properties.echo2.constraints.Echo2Validation;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.PropertyListener;
import nextapp.echo2.app.Alignment;
import nextapp.echo2.app.ApplicationInstance;
import nextapp.echo2.app.Column;
import nextapp.echo2.app.Component;
import nextapp.echo2.app.Extent;
import nextapp.echo2.app.Grid;
import nextapp.echo2.app.Insets;
import nextapp.echo2.app.Label;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.Row;
import nextapp.echo2.app.Table;
import nextapp.echo2.app.TaskQueueHandle;
import nextapp.echo2.app.event.ActionEvent;
import nextapp.echo2.app.event.ActionListener;
import nextapp.echo2.app.event.ChangeEvent;
import nextapp.echo2.app.event.ChangeListener;
import nextapp.echo2.app.layout.ColumnLayoutData;
import nextapp.echo2.app.layout.GridLayoutData;
import nextapp.echo2.app.list.ListSelectionModel;

/**
 * The UI factory is a tool that automatically creates a form UI to match a given
 * bean. It uses the properties of the given bean to create fields and entries
 * appropriately and can accept simple hints when needed, all properties are
 * bound and validated transparently. This is mostly useful for form based 
 * applications where the requirements include a great deal of uniform data entry.
 *
 * @author Shai Almog
 */
public abstract class Echo2Factory extends UIFactory<Component> implements java.io.Serializable {
    private static final LabelPlacement<Component> none = new LabelPlacement<Component>();
    private static final ActionListener DUMMY_LISTENER = 
        new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            }
        };
    
    private static final LabelPlacement<Component> beside = new LabelPlacement<Component>() {
        public Component createLabel(Component targetComponent, PropertyContext context) {
            Label l = new Label();
            Echo2Bind.get().bindLabel(context, l, targetComponent);
            return l;
        }
    };
    
    private static final LabelPlacement<Component> above = new LabelPlacement<Component>();
    
    private static final LabelPlacement<Component> asBorder = new LabelPlacement<Component>();
    
    
    /** Creates a new instance of UIFactory */
    protected Echo2Factory() {
        super(new Echo2ComponentFactory());
    }
    
    public static Echo2Factory centerLayoutFactory() {
        return new CenterLayout();
    }

    public static Echo2Factory columnLayoutFactory(int columns) {
        return new ColumnLayout(columns);
    }

    
    protected ValidationManager<Component> getValidation() {
        return Echo2Validation.getInstance();
    }
    
    /**
     * Binds the component to changes in selection within the given property
     * bound component.
     */
    public void addPropertySelectionListener(final PropertySelectionListener listener, final IndexedProperty property, Component component) {
        Component bound = Echo2Bind.get().findComponent(component, property);
        if(bound == null) {
            throw new IllegalArgumentException("Can't find a component bound to " + property.getContext().getName());
        }
        if(bound instanceof Table) {
            final Table table = (Table)bound;
            // dummy to cause selection events to be delivered
            table.addActionListener(DUMMY_LISTENER);
            table.getSelectionModel().addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent e) {
                    ListSelectionModel selection = table.getSelectionModel();
                    if(selection.isSelectionEmpty()) {
                        listener.selectionChanged(property, new int[0]);
                        return;
                    }
                    if(selection.getMinSelectedIndex() == 
                        selection.getMaxSelectedIndex()) {
                        listener.selectionChanged(property, new int[] {
                            selection.getMinSelectedIndex()});
                        return;
                    }
                    List<Integer> selectionList = new ArrayList<Integer>();
                    int rows = table.getModel().getRowCount();
                    for(int iter = 0 ; iter < rows ; iter++) {
                        if(selection.isSelectedIndex(iter)) {
                            selectionList.add(iter);
                        }
                    }
                    int[] arr = new int[selectionList.size()];
                    for(int iter = 0 ; iter < arr.length ; iter++) {
                        arr[iter] = selectionList.get(iter);
                    }
                    listener.selectionChanged(property, arr);
                }
            });
            return;
        }
        if(bound instanceof ListBox) {
            final ListBox list = (ListBox)bound;
            // dummy to cause selection events to be delivered
            list.addActionListener(DUMMY_LISTENER);
            list.getSelectionModel().addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent e) {
                    listener.selectionChanged(property, list.getSelectedIndices());
                }
            });
            return;
        }
        throw new IllegalArgumentException("Property selection listener can't be bound to this component type");
    }
    
    /**
     * Binds the given UI as a master detail set
     */
    public void bindMasterDetail(Component master, final Component detail, final IndexedProperty property) {        
        componentFactory.get().bindComponentTree(this, property.getParent(), master);
        final Table t = (Table)findComponent(Table.class, master);
        t.addActionListener(DUMMY_LISTENER);
        getValidation().trackIndexedValidity(property, t);
        class UpdateListener implements PropertyListener {
            private int row;
            public UpdateListener(int row) {
                this.row = row;
            }
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                TableAdapterModel model = (TableAdapterModel)t.getModel();
                if(oldValue != newValue) {
                    model.fireSafe(row);
                }
            }
            public void doRemove(final Object previousRow) {
                // make sure to prevent a listener from being removed too soon,
                // this allows events to continue propagating correctly for the
                // duration of the current loop
                final ApplicationInstance app = ApplicationInstance.getActive();
                final TaskQueueHandle taskQueue = app.createTaskQueue();
                app.enqueueTask(taskQueue, new Runnable() {
                    public void run() {
                        BeanContainer.get().removeListener(previousRow, UpdateListener.this);
                        app.removeTaskQueue(taskQueue);
                    }
                });
            }
        }
        t.getSelectionModel().addChangeListener(new ChangeListener() {
            private Object previousRow = null;
            private UpdateListener tableUpdater;
            public void stateChanged(ChangeEvent e) {
                // currently only support single selection
                if(previousRow != null) {
                    tableUpdater.doRemove(previousRow);
                    getValidation().stopTracking(previousRow, detail);
                    componentFactory.get().unbindComponentTree(detail);
                    previousRow = null;
                }
                
                int row = t.getSelectionModel().getMinSelectedIndex();
                if(row > -1) {
                    if(!detail.isEnabled()) {
                        enableComponentTree(detail, true);
                    }
                    previousRow = property.get(row);
                    componentFactory.get().bindComponentTree(Echo2Factory.this, previousRow, detail);
                    tableUpdater = new UpdateListener(row);
                    BeanContainer.get().addListener(previousRow, tableUpdater);
                    getValidation().trackValidity(previousRow, detail);
                } else {
                    enableComponentTree(detail, false);
                }
            }
        });
    }
    
    /**
     * Disables or enables the components within a component tree recursively
     */
    private void enableComponentTree(Component cmp, boolean enable) {
        cmp.setEnabled(enable);
        for(Component c : cmp.getComponents()) {
            c.setEnabled(enable);
            enableComponentTree(c, enable);
        }
    }
    
    /**
     * Traverses the component tree and finds the given component
     */
    private static Component findComponent(Class c, Component component) {
        for(Component cmp : component.getComponents()) {
            if(c.isAssignableFrom(cmp.getClass())) {
                return cmp;
            }
            Component result = findComponent(c, cmp);
            if(result != null) {
                return result;
            }
        }
        return null;
    }
    
    /**
     * Returns a single layout containing the master detail elements
     */
    public Component combineMasterDetail(Component master, Component detail) {
        Column b = new Column();
        b.setCellSpacing(new Extent(6));
        ColumnLayoutData layoutData = new ColumnLayoutData();
        layoutData.setAlignment(new Alignment(Alignment.CENTER, Alignment.DEFAULT));
        master.setLayoutData(layoutData);
        detail.setLayoutData(layoutData);
        b.add(master);
        b.add(detail);
        enableComponentTree(detail, false);
        return b;
    }
    
    public LabelPlacement<Component> getLabelPalcementNone() {
        return none;
    }
    
    public LabelPlacement<Component> getLabelPalcementBeside() {
        return beside;
    }
    
    public LabelPlacement<Component> getLabelPalcementAbove() {
        return above;
    }
    
    public LabelPlacement<Component> getLabelPalcementAsBorder() {
        return asBorder;
    }

    protected Component createLabel(Component component, PropertyContext property) {
        return getPlacement(property).createLabel(component, property);
    }
    
    static class ColumnLayout extends Echo2Factory implements java.io.Serializable {
        private int columns;
        
        /**
         * creates an instance for the given number of columns
         */
        public ColumnLayout(int columns) {
            // number is multiplied for the sake of the labels
            this.columns = columns * 2;
        }
        public ColumnLayout() {}
        
        /**
         * Creates an instance of the container that would be populated with the objects
         */
        public Component createLayout(int elements) {
            return new Grid(columns);
        }

        /**
         * Adds the given pair of components to the layout
         */
        public void add(Component layout, Component component, PropertyContext property) {
            Label label = new Label();
            Echo2Bind.get().bindLabel(property, label);
            GridLayoutData layoutData = new GridLayoutData();
            layoutData.setInsets(new Insets(1, 1, 1, 1));
            Alignment align = new Alignment(Alignment.DEFAULT, Alignment.TOP);
            layoutData.setAlignment(align);
            label.setLayoutData(layoutData);
            layout.add(label);

            layoutData = new GridLayoutData();
            layoutData.setInsets(new Insets(1, 1, 10, 1));
            layoutData.setAlignment(align);
            component.setLayoutData(layoutData);
            layout.add(component);
        }
    }

    
    static class CenterLayout extends Echo2Factory implements java.io.Serializable {
        public void add(Component layout, Component component, PropertyContext property) {
            layout.add(component);
        }

        public Component createLayout(int elements) {
            Row p = new Row();
            return p;
        }
    }
}
