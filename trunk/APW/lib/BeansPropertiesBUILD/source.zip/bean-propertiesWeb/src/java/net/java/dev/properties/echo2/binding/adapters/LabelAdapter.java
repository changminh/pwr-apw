/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import nextapp.echo2.app.Label;

/**
 * Implements UI update for the JLabel
 *
 * @author Shai Almog
 */
class LabelAdapter extends Echo2Adapter<String, Label> implements PropertyChangeListener {
    protected void bindListener(BaseProperty<String> property, Label cmp) {
        cmp.addPropertyChangeListener(this);
    }

    protected void unbindListener(BaseProperty<String> property, Label cmp) {
        cmp.removePropertyChangeListener(this);
    }

    protected void updateUI(String newValue) {
        getComponent().setText(newValue);
    }            

    public void propertyChange(PropertyChangeEvent evt) {
        if("text".equals(evt.getPropertyName())) {
            callWhenUIChanged(getComponent().getText());
        }
    }

    protected Class getType() {
        return String.class;
    }

    protected Class getComponentType() {
        return Label.class;
    }
}