/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.util.Date;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import nextapp.echo2.app.event.DocumentEvent;
import nextapp.echo2.app.event.DocumentListener;
import nextapp.echo2.app.text.TextComponent;

/**
 * Implements toggle button support for the state change/ui
 *
 * @author Shai Almog
 */
class DateTextComponentAdapter extends Echo2Adapter<Date, TextComponent> implements DocumentListener {
    private static Format FORMAT = DateFormat.getDateInstance(DateFormat.SHORT);
    protected void bindListener(BaseProperty<Date> property, TextComponent cmp) {
        cmp.getDocument().addDocumentListener(this);
    }

    protected void unbindListener(BaseProperty<Date> property, TextComponent cmp) {
        cmp.getDocument().removeDocumentListener(this);
    }

    protected void updateUI(Date newValue) {
        if(newValue != null) {
            getComponent().setText(FORMAT.format(newValue));
        } else {
            getComponent().setText("");
        }
    }            

    public void documentUpdate(DocumentEvent e) {
        try {
            callWhenUIChanged((Date)FORMAT.parseObject(getComponent().getText()));
        } catch(ParseException err) {
            // not much to do here...
            err.printStackTrace();
        }
    }

    protected Class getType() {
        return Date.class;
    }

    protected Class getComponentType() {
        return TextComponent.class;
    }
}