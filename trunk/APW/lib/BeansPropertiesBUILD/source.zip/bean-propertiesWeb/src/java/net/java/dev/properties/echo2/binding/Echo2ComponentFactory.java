/*
 * SwingComponentFactory.java
 *
 * Created on March 7, 2007, 2:27 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.RPropertyImpl;
import net.java.dev.properties.binding.ComponentFactory;
import net.java.dev.properties.binding.UIFactory;
import net.java.dev.properties.echo2.binding.adapters.Echo2Bind;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import nextapp.echo2.app.Border;
import nextapp.echo2.app.CheckBox;
import nextapp.echo2.app.Color;
import nextapp.echo2.app.Component;
import nextapp.echo2.app.Extent;
import nextapp.echo2.app.Insets;
import nextapp.echo2.app.Label;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.MutableStyle;
import nextapp.echo2.app.SelectField;
import nextapp.echo2.app.Style;
import nextapp.echo2.app.Table;
import nextapp.echo2.app.TextField;
import nextapp.echo2.app.event.ActionEvent;
import nextapp.echo2.app.event.ActionListener;
import nextapp.echo2.app.list.ListSelectionModel;
import nextapp.echo2.app.table.DefaultTableCellRenderer;
import nextapp.echo2.app.table.TableCellRenderer;

/**
 * An implementation of the component factory that creates and binds swing components
 * to properties.
 *
 * @author Shai Almog
 */
public class Echo2ComponentFactory extends ComponentFactory<Component> {
    private static final ActionListener DUMMY = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        }
    };
    
    /**
     * This read only property contains the mapping for cell renderers that get applied,
     * some cell renderers are placed by default such as check box and date renderers
     */
    public final RProperty<Map<Class, TableCellRenderer>> renderers = 
        new RPropertyImpl<Map<Class, TableCellRenderer>>(new HashMap<Class, TableCellRenderer>());
    
    /**
     * The default style for the text field
     */
    public final Property<String> defaultTextFieldStyleName = new PropertyImpl<String>();

    /**
     * The default style for the checkbox
     */
    public final Property<String> defaultCheckBoxStyleName = new PropertyImpl<String>();

    /**
     * The default style for the list box
     */
    public final Property<String> defaultListBoxStyleName = new PropertyImpl<String>();

    /**
     * The default style for the select field
     */
    public final Property<String> defaultSelectFieldStyleName = new PropertyImpl<String>();
    
    /**
     * The default style for the table
     */
    public final Property<String> defaultTableStyleName = new PropertyImpl<String>();
    
    /**
     * The default style for the text field
     */
    public final Property<Style> defaultTextFieldStyle = new PropertyImpl<Style>();

    /**
     * The default style for the checkbox
     */
    public final Property<Style> defaultCheckBoxStyle = new PropertyImpl<Style>();

    /**
     * The default style for the list box
     */
    public final Property<Style> defaultListBoxStyle = new PropertyImpl<Style>();

    /**
     * The default style for the select field
     */
    public final Property<Style> defaultSelectFieldStyle = new PropertyImpl<Style>();
    
    /**
     * The default style for the table
     */
    public final Property<Style> defaultTableStyle = new PropertyImpl<Style>();
    
    /** Creates a new instance of SwingComponentFactory */
    public Echo2ComponentFactory() {
        BeanContainer.bind(this);
        registerType(String.class, TextField.class);
        registerType(Number.class, TextField.class);
        registerType(Date.class, TextField.class);
        registerType(Boolean.class, CheckBox.class);
        registerIndexedTypeMulti(String.class, ListBox.class);
        registerIndexedTypeMulti(Number.class, ListBox.class);
        registerIndexedTypeMulti(Date.class, ListBox.class);
        registerIndexedTypeSingle(String.class, SelectField.class);
        registerIndexedTypeSingle(Number.class, SelectField.class);
        registerIndexedTypeSingle(Date.class, SelectField.class);
        renderers.get().put(Boolean.class, new TableCellRenderer() {
            public Component getTableCellRendererComponent(Table table, Object value, int column, int row) {
                CheckBox box = new CheckBox();
                box.setEnabled(false);
                box.setSelected(value != null && ((Boolean)value).booleanValue());
                return box;
            }
        });
        renderers.get().put(Date.class, new DefaultTableCellRenderer() {
            private DateFormat format = DateFormat.getDateInstance(DateFormat.SHORT);
            public Component getTableCellRendererComponent(Table table, Object value, int column, int row) {
                if(value != null) {
                    value = format.format((Date)value);
                }
                return super.getTableCellRendererComponent(table, value, column, row);
            }
        });
    }
    
    private void applyStyle(Property<String> d, Property<Style> s, Component c) {
        if(d.get() != null) {
            c.setStyleName(d.get());
        }
        if(s.get() != null) {
            c.setStyle(s.get());
        }
    }
    
    /**
     * Optionally allows a subclass to return a default when all else fails
     */
    @Override
    public Component createComponentFallback(PropertyContext propertyContext, PropertyContext selection, boolean indexed, boolean multiSelection) {
        if(indexed) {
            Table t = createTable();
            for(Map.Entry<Class, TableCellRenderer> entry : renderers.get().entrySet()) {
                t.setDefaultRenderer(entry.getKey(), entry.getValue());
            }
            return t;
        }
        return new SelectField();
    }
    
    /**
     * Method that is called for creation of Echo2 tables to simplify the tasks of subclasses
     * that wish to customize the look of the default table.
     */
    protected Table createTable() {
        Table t = new Table();
        t.setSelectionEnabled(true);
        t.setWidth(new Extent(100, Extent.PERCENT));
        if(defaultTableStyle.get() == null && defaultTableStyleName.get() == null) {
            MutableStyle style = new MutableStyle();
            style.setProperty(Table.PROPERTY_ROLLOVER_ENABLED, true);
            style.setProperty(Table.PROPERTY_ROLLOVER_BACKGROUND, Color.YELLOW);
            style.setProperty(Table.PROPERTY_BORDER, new Border(3, Color.LIGHTGRAY, Border.STYLE_RIDGE));
            style.setProperty(Table.PROPERTY_INSETS, new Insets(3, 3));
            style.setProperty(Table.PROPERTY_SELECTION_BACKGROUND, Color.BLUE);
            style.setProperty(Table.PROPERTY_SELECTION_ENABLED, true);
            t.setStyle(style);
        } else {
            applyStyle(defaultTableStyleName, defaultTableStyle, t);
        }
        return t;
    }
    
    /**
     * Associates the given property contexts with the given component so a followup
     * call to bind component tree would work correctly.
     */
    public void bindContexts(Component component, PropertyContext context, PropertyContext selection) {
        Echo2ClientProperty.put(component, "PropertyContext", context);
        Echo2ClientProperty.put(component, "PropertyContextSelection", selection);
    }
    
    /**
     * Binds a component tree previously created by this API
     */
    public void bindComponentTree(UIFactory<Component> factory, Object bean, Component component) {
        PropertyContext context = (PropertyContext)Echo2ClientProperty.get(component, "PropertyContext");
        if(context != null) {
            PropertyContext selection = (PropertyContext)Echo2ClientProperty.get(component, "PropertyContextSelection");
            bindComponent(factory, bean, context, selection, component);
        }
        for(Component cmp : component.getComponents()) {
            if(cmp instanceof Component) {
                bindComponentTree(factory, bean, cmp);
            }
        }
    }

    /**
     * Creates a label component to match the property component
     */
    public Component createLabel(PropertyContext p, Component component) {
        Label l = new Label();
        Echo2Bind.get().bindLabel(p, l, component);
        return l;
    }

    /**
     * Creates a component object to match the given property type
     */
    public void bindComponent(UIFactory<Component> factory, BaseProperty property, BaseProperty selection, Component component) {
        if(component instanceof Table) {
            BeanContext ctx = BeanContainer.get().getContext(property.getContext().getType());
            Echo2Bind.get().bindContent((IndexedProperty)property, (Table)component, factory.getPropertiesArray(ctx));
        } else {
            Echo2Bind.get().bindGeneric(property, selection, component);
        }
    }

    /**
     * The oposite of the bind component method
     */
    public void unbindComponent(Component component) {
        Echo2Bind.get().unbind(component);
    }
    
    /**
     * Binds a component tree previously created by this API
     */
    public void unbindComponentTree(Component component) {
        unbindComponent(component);
        for(Component cmp : component.getComponents()) {
            unbindComponentTree(cmp);
        }
    }
    
    /**
     * Overriden to correct a few minor defaults that are broken such as the fact
     * that a checkbox is opaque by default.
     */
    @Override
    public Component createComponent(PropertyContext propertyContext, PropertyContext selection) {
        Component retValue = super.createComponent(propertyContext, selection);
        if(retValue instanceof ListBox) {
            if(selection != null && selection.isIndexedProperty()) {
                ((ListBox)retValue).setSelectionMode(ListSelectionModel.MULTIPLE_SELECTION);
            } else {
                ((ListBox)retValue).setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            }
            ((ListBox)retValue).addActionListener(DUMMY);
            applyStyle(defaultListBoxStyleName, defaultListBoxStyle, retValue);
            return retValue;
        } 
        
        if(retValue instanceof SelectField) {
            ((SelectField)retValue).addActionListener(DUMMY);
            applyStyle(defaultSelectFieldStyleName, defaultSelectFieldStyle, retValue);
            return retValue;
        } 
        
        if(retValue instanceof CheckBox) {
            ((CheckBox)retValue).addActionListener(DUMMY);
            applyStyle(defaultCheckBoxStyleName, defaultCheckBoxStyle, retValue);
            return retValue;
        } 
        
        if(retValue instanceof TextField) {
            ((TextField)retValue).addActionListener(DUMMY);
            applyStyle(defaultTextFieldStyleName, defaultTextFieldStyle, retValue);
            return retValue;
        } 
        
        return retValue;
    }

    public static interface CustomPropertyBinding extends ComponentFactory.CustomPropertyBinding<Component> {
    }
}
