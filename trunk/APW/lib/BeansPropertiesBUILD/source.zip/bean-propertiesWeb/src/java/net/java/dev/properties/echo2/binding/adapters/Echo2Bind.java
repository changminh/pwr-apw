/*
 * SwingBind.java
 *
 * Created on March 2, 2007, 1:50 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.binding.BindManager;
import net.java.dev.properties.echo2.binding.Echo2ClientProperty;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import nextapp.echo2.app.Component;
import nextapp.echo2.app.Label;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.SelectField;
import nextapp.echo2.app.Table;
import nextapp.echo2.app.button.ToggleButton;
import nextapp.echo2.app.text.TextComponent;

/**
 * A singleton allowing Swing developers to bind components and create models
 * that match beans and bean properties.
 *
 * @author Shai Almog
 */
public class Echo2Bind extends BindManager<Component> {
    private static Echo2Bind instance;
    private Echo2Adapter[] adapters = new Echo2Adapter[] {
        new SelectFieldIndexAdapter(),
        new SelectFieldItemAdapter(),
        new ListBoxIndexAdapter(),
        new ListBoxItemAdapter(),
        new LabelAdapter(),
        new ListIndicesAdapter(),
        new ListItemsAdapter(),
        new ToggleButtonAdapter(),
        new TextComponentAdapter(),
        new NumberTextComponentAdapter(),
        new DateTextComponentAdapter()
    };
    
    /** Creates a new instance of SwingBind */
    private Echo2Bind() {
    }
    
    /**
     * Binds a generic component, this method isn't nearly as efficient or "safe"
     * as the standard methods and so it is used mostly for dynamic UI construction
     * rather than as the default type safe methods
     */
    public void bindGeneric(BaseProperty property, BaseProperty selection, Component cmp) {
        if(property instanceof IndexedProperty) {
            if(cmp instanceof ListBox) {
                bindContent((IndexedProperty)property, (ListBox)cmp);
                if(selection != null) {
                    bindSelectionIndices((IndexedProperty<Integer>)selection, (ListBox)cmp);
                }
                return;
            } 

            if(cmp instanceof SelectField) {
                bindContent((IndexedProperty)property, (SelectField)cmp);
                if(selection != null) {
                    bindSelection((BaseProperty<Integer>)selection, (SelectField)cmp);
                }
                return;
            } 
              
            if(cmp instanceof Table) {
                bindContent((IndexedProperty)property, property.getContext().getType(), (Table)cmp);
                return;
            }
        } else {
            for(Echo2Adapter adapter : adapters) {
                if(adapter.canHandle(property, cmp)) {
                    adapter.createBoundInstance(property, cmp);
                    return;
                }
            }
        }
        throw new BeanBindException("Couldn't bind the property: " + property + " to the component " + cmp.getClass().getName());
    }
    
    public static Echo2Bind get() {
        if(instance == null) {
            instance = new Echo2Bind();
        }
        return instance;
    }

    public void bind(BaseProperty<Boolean> property, ToggleButton button) {
        new ToggleButtonAdapter().bind(property, button);
    }
    
    public void bindItem(BaseProperty<Object> property, ListBox cmp) {
        new ListBoxItemAdapter().bind(property, cmp);
    }

    public void bindItem(BaseProperty<Object> property, SelectField cmp) {
        new SelectFieldItemAdapter().bind(property, cmp);
    }

    public void bindIndex(BaseProperty<Integer> property, ListBox cmp) {
        new ListBoxIndexAdapter().bind(property, cmp);
    }

    public void bind(BaseProperty<String> property, TextComponent cmp) {
        new TextComponentAdapter().bind(property, cmp);
    }

    public void bindItem(BaseProperty<Object> property, ListBox cmp, Label label) {
        bindItem(property, cmp);
        bindLabel(property, label, cmp);
    }

    public void bindIndex(BaseProperty<Integer> property, ListBox cmp, Label label) {
        bindIndex(property, cmp);
        bindLabel(property, label, cmp);
    }

    public void bind(BaseProperty<String> property, TextComponent cmp, Label label) {
        bind(property, cmp);
        bindLabel(property, label, cmp);
    }
    
    public void bind(BaseProperty<String> property, Label cmp) {
        new LabelAdapter().bind(property, cmp);
    }

    /**
     * A one way bind that assigns to the label the value of the display property
     * for the given property.
     */
    public void bindLabel(BaseProperty property, Label cmp) {
        bindLabel(property.getContext(), cmp);
    }

    /**
     * A one way bind that assigns to the label the value of the display property
     * for the given property.
     */
    public void bindLabel(PropertyContext property, Label cmp) {
        cmp.setText(property.getDisplayName());
    }

    /**
     * A one way bind that assigns to the label the value of the display property
     * for the given property.
     */
    public void bindLabel(BaseProperty property, Label cmp, Component c) {
        bindLabel(property.getContext(), cmp, c);
    }

    /**
     * A one way bind that assigns to the label the value of the display property
     * for the given property.
     */
    public void bindLabel(PropertyContext property, Label cmp, Component c) {
        cmp.setText(property.getDisplayName());
        // Seems unsupported in Echo2...
        //cmp.setLabelFor(c);
    }

    public void bindSelectionItems(IndexedProperty<Object> property, ListBox cmp) {
        new ListItemsAdapter().bind(property, cmp);
    }

    public void bindSelectionIndices(IndexedProperty<Integer> property, ListBox cmp) {
        new ListIndicesAdapter().bind(property, cmp);
    }

    public void bindSelectionIndices(IndexedProperty<Integer> property, ListBox cmp, Label label) {
        bindSelectionIndices(property, cmp);
        bindLabel(property, label, cmp);
    }

    public void bindSelection(BaseProperty<Integer> property, SelectField cmp) {
        new SelectFieldIndexAdapter().bind(property, cmp);
    }

    /**
     * This method will install the ComboAndListModel on cmp
     */
    public void bindContent(IndexedProperty<?> property, ListBox cmp, Label label) {
        bindContent(property, cmp);
        bindLabel(property, label, cmp);
    }
    
    /**
     * This method will install the ComboAndListModel on cmp
     */
    public void bindContent(IndexedProperty<?> property, ListBox cmp) {
        Echo2ClientProperty.put(cmp, "Property", property);
        cmp.setModel(new ListAdapterModel(property));
    }
    
    /**
     * This method will install the ComboAndListModel on cmp
     */
    public void bindContent(IndexedProperty<?> property, SelectField cmp) {
        Echo2ClientProperty.put(cmp, "Property", property);
        cmp.setModel(new ListAdapterModel(property));
    }
    
    /**
     * This method will install the ComboAndListModel on cmp
     */
    public void bindContent(IndexedProperty<?> property, SelectField cmp, Label label) {
        bindContent(property, cmp);
        bindLabel(property, label, cmp);
    }
    
    /**
     * This method will install the TableModel on cmp
     */
    public void bindContent(IndexedProperty beans, Table cmp, PropertyContext... columns) {
        Echo2ClientProperty.put(cmp, "Property", beans);
        cmp.setModel(new TableAdapterModel(beans, columns));
    }

    /**
     * This method will install the TableModel on cmp
     */
    public void bindContent(IndexedProperty beans, BeanContext bean, Table cmp) {
        bindContent(beans, cmp, bean.getPropertiesArray());
    }

    /**
     * This method will install the TableModel on cmp
     */
    public void bindContent(IndexedProperty beans, Class bean, Table cmp) {
        bindContent(beans, cmp, BeanContainer.get().getContext(bean).getPropertiesArray());
    }

    public void unbind(Component cmp) {
        Echo2Adapter.unbindComponent(cmp);
    }
    
    /**
     * Searches within the tree for the component bound to the given property
     */
    public Component findComponent(Component root, BaseProperty property) {
        if(Echo2ClientProperty.get(root, "Property") == property) {
            return root;
        }
        for(Component c : root.getComponents()) {
            Component cmp = findComponent(c, property);
            if(cmp != null) {
                return cmp;
            }
        }
        return null;
    }
}
