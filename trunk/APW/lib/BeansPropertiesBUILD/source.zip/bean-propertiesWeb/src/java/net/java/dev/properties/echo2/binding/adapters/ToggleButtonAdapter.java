/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding.adapters;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import nextapp.echo2.app.button.ToggleButton;
import nextapp.echo2.app.event.ChangeEvent;
import nextapp.echo2.app.event.ChangeListener;

/**
 * Implements toggle button support for the state change/ui
 *
 * @author Shai Almog
 */
class ToggleButtonAdapter extends Echo2Adapter<Boolean, ToggleButton> implements ChangeListener {
    protected void bindListener(BaseProperty<Boolean> property, ToggleButton button) {
        button.addChangeListener(this);
    }

    protected void unbindListener(BaseProperty<Boolean> property, ToggleButton button) {
        button.removeChangeListener(this);
    }

    public void stateChanged(ChangeEvent e) {
        callWhenUIChanged(getComponent().isSelected());
    }

    protected void updateUI(Boolean newValue) {
        getComponent().setSelected(newValue);
    }            

    protected Class getType() {
        return Boolean.class;
    }

    protected Class getComponentType() {
        return ToggleButton.class;
    }

    protected void setEmptyValue() {
        getComponent().setSelected(false);
    }
}