/*
 * TimeComponent.java
 *
 * Created on March 13, 2007, 3:31 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.test;

import java.text.Format;
import java.text.NumberFormat;
import java.text.ParseException;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.PropertyListener;
import nextapp.echo2.app.Label;
import nextapp.echo2.app.Row;
import nextapp.echo2.app.TextField;
import nextapp.echo2.app.event.ActionEvent;
import nextapp.echo2.app.event.ActionListener;
import nextapp.echo2.app.event.DocumentEvent;
import nextapp.echo2.app.event.DocumentListener;

/**
 * A simple UI widget that implements a time selection control based on hours and
 * minutes using a spinner
 *
 * @author Shai Almog
 */
public class TimeComponent extends Row implements PropertyListener, DocumentListener {
    private static final ActionListener DUMMY = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        }
    };

    private TextField hours = new TextField();
    private TextField minutes = new TextField();
    private static final Format format = NumberFormat.getIntegerInstance();
    private Object bean;
    private PropertyContext property;
    private boolean lock = false;
    TimeComponent() {
        add(hours);
        hours.addActionListener(DUMMY);
        add(new Label(":"));
        add(minutes);
        minutes.addActionListener(DUMMY);
        hours.getDocument().addDocumentListener(this);
        minutes.getDocument().addDocumentListener(this);
    }

    public void bind(Object bean, PropertyContext property) {
        if(this.property != null) {
            BeanContainer.get().removeListener(this.property.getValue(bean), this);
        }
        this.bean = bean;
        this.property = property;
        updateValue((Number)property.getInternalValue(bean));
        BeanContainer.get().addListener(property.getValue(bean), this);
    }

    private void updateValue(Number val) {
        int value = 0;
        if(val != null) {
            value = val.intValue();
        }
        hours.setText(format.format(new Integer(value / 60)));
        minutes.setText(format.format(new Integer(value % 60)));
    }


    public void documentUpdate(DocumentEvent e) {
        if(lock) return;
        lock = true;
        if(bean != null) {
            BaseProperty p = property.getValue(bean);
            if(p instanceof WProperty) {
                try {
                    int hourInt = ((Number)format.parseObject(hours.getText())).intValue();
                    int minuteInt = ((Number)format.parseObject(minutes.getText())).intValue();
                    ((WProperty)p).set(hourInt * 60 + minuteInt);
                } catch(ParseException err) {}
            }
        }
        lock = false;
    }

    public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        if(lock) return;
        lock = true;
        updateValue((Number)property.getInternalValue(bean));
        lock = false;
    }
}
