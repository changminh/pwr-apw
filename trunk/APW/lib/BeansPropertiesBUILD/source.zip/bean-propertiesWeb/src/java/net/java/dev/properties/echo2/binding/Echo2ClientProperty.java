/*
 * Echo2ClientProperty.java
 *
 * Created on March 29, 2007, 9:36 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.binding;

import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import nextapp.echo2.app.Component;

/**
 * Simulates the client property feature of Swing which is useful for binding meta-data
 *
 * @author Shai Almog
 */
public class Echo2ClientProperty {
    private static Map<Component, Map<String, Object>> map = new WeakHashMap<Component, Map<String, Object>>();
    
    /** Creates a new instance of Echo2ClientProperty */
    private Echo2ClientProperty() {
    }

    public static void put(Component c, String key, Object value) {
        Map<String, Object> componentMap = map.get(c);
        if(componentMap == null) {
            componentMap = new HashMap<String, Object>();
            map.put(c, componentMap);
        }
        if(value != null) {
            componentMap.put(key, value);
        } else {
            componentMap.remove(key);
        }
    }
    
    public static Object get(Component c, String key) {
        Map<String, Object> componentMap = map.get(c);
        if(componentMap == null) {
            return null;
        }
        return componentMap.get(key);
    }
}
