/*
 * StudioApp.java
 *
 * Created on March 29, 2007, 8:59 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.echo2.test;

import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.binding.PropertySelectionListener;
import net.java.dev.properties.binding.UIFactory;
import net.java.dev.properties.echo2.binding.Echo2ComponentFactory;
import net.java.dev.properties.echo2.binding.Echo2Factory;
import net.java.dev.properties.echo2.binding.adapters.Echo2Bind;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.test.binding.studio.AttendanceBean;
import net.java.dev.properties.test.binding.studio.StudentBean;
import net.java.dev.properties.test.binding.studio.StudioBean;
import net.java.dev.properties.test.binding.studio.YogaClassBean;
import nextapp.echo2.app.Alignment;
import nextapp.echo2.app.ApplicationInstance;
import nextapp.echo2.app.Border;
import nextapp.echo2.app.Button;
import nextapp.echo2.app.Color;
import nextapp.echo2.app.Column;
import nextapp.echo2.app.Component;
import nextapp.echo2.app.ContentPane;
import nextapp.echo2.app.Extent;
import nextapp.echo2.app.Insets;
import nextapp.echo2.app.ListBox;
import nextapp.echo2.app.MutableStyle;
import nextapp.echo2.app.ResourceImageReference;
import nextapp.echo2.app.Row;
import nextapp.echo2.app.SelectField;
import nextapp.echo2.app.SplitPane;
import nextapp.echo2.app.Style;
import nextapp.echo2.app.Table;
import nextapp.echo2.app.Window;
import nextapp.echo2.app.event.ActionEvent;
import nextapp.echo2.app.event.ActionListener;
import nextapp.echo2.app.event.ChangeEvent;
import nextapp.echo2.app.event.ChangeListener;
import nextapp.echo2.app.layout.ColumnLayoutData;
import nextapp.echo2.app.table.DefaultTableCellRenderer;

/**
 *
 * @author Shai Almog
 */
public class StudioApp extends ApplicationInstance {
    private StudioBean studio = new StudioBean();
    private UIFactory<Component> factory;
    private UIFactory<Component> masterFactory;
    private final PropertyContext whoContext = new AttendanceBean().who.getContext();
    private final PropertyContext typeContext = new AttendanceBean().type.getContext();
    private final PropertyContext regularsContext = new YogaClassBean().regulars.getContext();
    
    public Window init() {
        for(char iter = 'A' ; iter <= 'Z' ; iter++) {
            studio.students.add(new StudentBean("First" + iter, "Surname" + iter));
        }
        Window window = new Window();
        window.setTitle(BeanContainer.get().getContext(studio.getClass()).getDisplayName());
        
        ContentPane contentPane = new ContentPane();
        window.setContent(contentPane);
        
        factory = Echo2Factory.columnLayoutFactory(2);
        factory.componentFactory.get().registerBinding(regularsContext, new StudentBinding());
        masterFactory = Echo2Factory.centerLayoutFactory();
        YogaClassBean yogaClass = new YogaClassBean();
        masterFactory.componentFactory.set(new OverrideComponentFactory());
        factory.componentFactory.get().registerBinding(yogaClass.time.getContext(), 
            new Echo2ComponentFactory.CustomPropertyBinding() {
                public Component createComponent(PropertyContext prop) {
                    return new TimeComponent();
                }
                public void bind(Object bean, PropertyContext property, PropertyContext selection, Component comp) {
                    ((TimeComponent)comp).bind(bean, property);
                }
            });
        
        /*Style componentStyle = createComponentStyle();
        Echo2ComponentFactory componentFactory = (Echo2ComponentFactory)factory.componentFactory.get();
        componentFactory.defaultCheckBoxStyle.set(componentStyle);
        componentFactory.defaultListBoxStyle.set(componentStyle);
        componentFactory.defaultSelectFieldStyle.set(componentStyle);
        componentFactory.defaultTextFieldStyle.set(componentStyle);*/
               
        final SplitPane mainSplitPane = new SplitPane(SplitPane.ORIENTATION_VERTICAL, new Extent(30));        
        mainSplitPane.setSeparatorWidth(new Extent(1, Extent.PX));
        final SelectField options = new SelectField(new Object[] {
            studio.students.getContext().getDisplayName(),
            studio.classes.getContext().getDisplayName(),
            studio.attendance.getContext().getDisplayName()
        });
        final Component studentsScreen = createComponent(studio.students, getContext(new StudentBean()));
        final Component classesScreen = createComponent(studio.classes, getContext(yogaClass));

        factory = Echo2Factory.columnLayoutFactory(1);
        factory.componentFactory.get().registerBinding(whoContext, new StudentBinding());
        factory.componentFactory.get().registerBinding(typeContext, 
            new Echo2ComponentFactory.CustomPropertyBinding() {
                public Component createComponent(PropertyContext prop) {
                    return new SelectField();
                }
                public void bind(Object bean, PropertyContext property, PropertyContext selection, Component comp) {
                    Echo2Bind.get().bindContent(studio.classes, (SelectField)comp);
                    Echo2Bind.get().bindItem(typeContext.getValue(bean), (SelectField)comp);
                }
            });
        
        final Component attendanceScreen = createComponent(studio.attendance, getContext(new AttendanceBean()));
        mainSplitPane.add(options);
        mainSplitPane.add(studentsScreen);
     
        // dummy to cause selection events to be delivered
        options.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) {}});
        options.getSelectionModel().addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int i = options.getSelectedIndex();
                mainSplitPane.remove(1);
                switch(i) {
                    case 0: 
                        mainSplitPane.add(studentsScreen);
                        return;
                    case 1: 
                        mainSplitPane.add(classesScreen);
                        return;
                    default: 
                        mainSplitPane.add(attendanceScreen);
                        return;
                }
            }
        });
        contentPane.add(mainSplitPane);
        return window;
    }
    
    private Component createComponent(final IndexedProperty property, BeanContext context) {
        class RemoveAction implements ActionListener, PropertySelectionListener {
            private int[] selection;
            private Button btn;
            public RemoveAction(Component cmp, Button btn) {
                factory.addPropertySelectionListener(this, property, cmp);
                this.btn = btn;
            }
            
            public void actionPerformed(ActionEvent ev) {
                for(int iter = selection.length - 1 ; iter > -1 ; iter--) {
                    if(property.size() > selection[iter]) {
                        property.remove(selection[iter]);
                    }
                }
            }

            public void selectionChanged(IndexedProperty property, int[] selection) {
                this.selection = selection;
                btn.setEnabled(selection != null && selection.length > 0);
            }
        }
        
        Column panel = new Column();
        panel.setCellSpacing(new Extent(5));
        Component cmp = factory.createMasterDetail(property, context, masterFactory);
        panel.add(cmp);

        Row buttonPane = new Row();
        ColumnLayoutData columnLayoutData = new ColumnLayoutData();
        columnLayoutData.setAlignment(new Alignment(Alignment.CENTER, Alignment.DEFAULT));
        columnLayoutData.setInsets(new Insets(10, 10));
        buttonPane.setLayoutData(columnLayoutData);
        buttonPane.setCellSpacing(new Extent(5));
        Style buttonStyle = createButtonStyle();
        Button addButton = new Button("Add", new ResourceImageReference("/net/java/dev/properties/echo2/test/add.png"));
        addButton.setStyle(buttonStyle);
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                try {
                    property.add(property.getContext().getType().newInstance());
                } catch(Exception err) {
                    err.printStackTrace();
                }
            }
        });
        Button removeButton = new Button("Remove", new ResourceImageReference("/net/java/dev/properties/echo2/test/delete.png"));
        removeButton.setStyle(buttonStyle);
        removeButton.addActionListener(new RemoveAction(cmp, removeButton));
        buttonPane.add(addButton);
        buttonPane.add(removeButton);
        panel.add(buttonPane);
        return panel;
    }
    
    private Style createButtonStyle() {
        MutableStyle style = new MutableStyle();
        style.setProperty(Button.PROPERTY_BACKGROUND, Color.LIGHTGRAY);
        style.setProperty(Button.PROPERTY_BORDER, new Border(3, Color.BLACK, Border.STYLE_OUTSET));
        style.setProperty(Button.PROPERTY_PRESSED_BORDER, new Border(3, Color.BLACK, Border.STYLE_GROOVE));
        style.setProperty(Button.PROPERTY_INSETS, new Insets(8, 3, 8, 3));
        style.setProperty(Button.PROPERTY_ROLLOVER_ENABLED, true);
        style.setProperty(Button.PROPERTY_ROLLOVER_BACKGROUND, Color.YELLOW);
        style.setProperty(Button.PROPERTY_PRESSED_ENABLED, true);
        return style;
    }
        
    private BeanContext getContext(Object o) {
        return BeanContainer.get().getContext(o.getClass());
    }
    
    class StudentBinding implements Echo2ComponentFactory.CustomPropertyBinding {
        private PropertyContext prop;
        public Component createComponent(PropertyContext prop) {
            this.prop = prop;
            return new ListBox();
        }

        public void bind(Object bean, PropertyContext property, PropertyContext selection, Component comp) {
            Echo2Bind.get().bindContent(studio.students, (ListBox)comp);
            Echo2Bind.get().bindSelectionItems((IndexedProperty<Object>)prop.getValue(bean), (ListBox)comp);
        }
    }
    
    /**
     * Simple override to allow the creation of Tables that can properly render
     * hours, lists of people, days of week, checkboxes etc..
     */
    class OverrideComponentFactory extends Echo2ComponentFactory {
        public Component createComponent(PropertyContext propertyContext, PropertyContext selection) {
            Component retValue = super.createComponent(propertyContext, selection);
            if(propertyContext == studio.classes.getContext()) {
                Table table = (Table)retValue;
                table.setDefaultRenderer(Byte.class, new DefaultTableCellRenderer() {
                    public Component getTableCellRendererComponent(Table table, Object value, int column, int row) {
                        return super.getTableCellRendererComponent(table, YogaClassBean.getDOW(value), row, column);
                    }
                });
                table.setDefaultRenderer(Integer.class, new DefaultTableCellRenderer() {
                    public Component getTableCellRendererComponent(Table table, Object value, int column, int row) {
                        return super.getTableCellRendererComponent(table, YogaClassBean.getTime(value), row, column);
                    }
                });
                return table;
            }
            return retValue;
        }
    }    
}
