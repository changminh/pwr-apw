package net.java.dev.properties.enterprise;

import java.util.Iterator;
import java.util.Map;
import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.thread.ThreadManager;
import net.java.dev.properties.jdbc.ORMThread;

/**
 * This is the enterprise version of the bean container that delivers events on
 * the current thread and stores context information in the JNDI scope rather than
 * the maps.
 *
 * @author Shai Almog
 */
public class EnterpriseContainer extends BeanContainer {

    private String rootName = "properties";
    static {
        set(new EnterpriseContainer());
        ThreadManager.defaultInstance.set(new ThreadManager() {
            @Override
            protected boolean isRightManager(Object listener) {
                return true;
            }
        });
        // cause the static initializer to register the class then remove it...
        try {
            Class.forName(ORMThread.class.getName());
        } catch(Exception err) {}
        ThreadManager.managers.remove(0);
    }

    /**
     * Helper method allowing us to invoke the static initializer more easily.
     */
    public static void init() {
    }
    
    public void setDefaultRoot(String name) {
        rootName = name;
    }

    private String getClassName(Class<?> cls) {
        return rootName + "/" + cls.getName();
    }

    @Override
    protected void putBeanContext(Class<?> cls, BeanContext context) {
        try {
            InitialContext c = new InitialContext();
            c.bind(getClassName(cls), c);
        } catch (NamingException ex) {
            throw new BeanBindException(ex);
        }
    }

    @Override
    protected BeanContext getBeanContext(Class<?> cls) {
        try {
            InitialContext c = new InitialContext();
            return (BeanContext) c.lookupLink(getClassName(cls));
        } catch (NamingException ex) {
            throw new BeanBindException(ex);
        }
    }


    @Override
    protected boolean isRegistered(Class<?> cls) {
        try {
            InitialContext c = new InitialContext();
            return c.list(getClassName(cls)).hasMore();
        } catch (NamingException ex) {
            throw new BeanBindException(ex);
        }
    }

    @Override
    protected Iterator<Map.Entry<Class, BeanContext>> iterateBeans() {
        try {
            final InitialContext c = new InitialContext();
            final NamingEnumeration<NameClassPair> elements = c.list(rootName);
            return new Iterator<Map.Entry<Class, BeanContext>>() {
                public boolean hasNext() {
                    try {
                        return elements.hasMore();
                    } catch (NamingException ex) {
                        throw new BeanBindException(ex);
                    }
                }

                public Map.Entry<Class, BeanContext> next() {
                    final NameClassPair element = elements.nextElement();
                    return new Map.Entry<Class, BeanContext>() {
                        public Class getKey() {
                            try {
                                return Class.forName(element.getName());
                            } catch (ClassNotFoundException ex) {
                                throw new BeanBindException(ex);
                            }
                        }

                        public BeanContext getValue() {
                            try {
                                return (BeanContext) c.lookup(element.getNameInNamespace());
                            } catch (NamingException ex) {
                                throw new BeanBindException(ex);
                            }
                        }

                        public BeanContext setValue(BeanContext arg0) {
                            throw new UnsupportedOperationException("Operation is not supported");
                        }
                    };
                }

                public void remove() {
                    throw new UnsupportedOperationException("Remove is not supported!");
                }
            };
        } catch (NamingException ex) {
            throw new BeanBindException(ex);
        }
    }
}
