/**
 * 
 */
package net.java.dev.properties.spring;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.ClassPathResource;

/**
 * @author Rik
 * 
 */
public class InstantationStrategyUsageTest {

    @Test
    public void testBeanPropertiesXmlBeanFactory() {

        ClassPathResource resource = new ClassPathResource("applicationContext.xml");
        BeanFactory factory = new BeanPropertiesXmlBeanFactory(resource);

        BeanB bean1 = (BeanB) factory.getBean("bean1");
        Assert.assertNotNull(bean1.beanPropA.get());
    }

    @Test
    public void testBeanPropertiesClassPathXmlApplicationContext() {

        ApplicationContext context = new BeanPropertiesClassPathXmlApplicationContext(
                "applicationContext.xml");

        BeanB bean1 = (BeanB) context.getBean("bean1");
        Assert.assertNotNull(bean1.beanPropA.get());
    }
}
