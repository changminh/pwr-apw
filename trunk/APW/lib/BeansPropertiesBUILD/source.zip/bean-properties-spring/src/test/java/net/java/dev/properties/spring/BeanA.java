/*
 * BeanA.java
 *
 * Created on May 28, 2007, 6:06:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package net.java.dev.properties.spring;

/**
 * Bean that is used for unit testing Bean Properties Spring integration.
 * 
 * @author Rik van der Kleij
 */
public class BeanA {

    public String getName() {

        return "BeanA";
    }
}
