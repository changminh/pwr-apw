package net.java.dev.properties.spring;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.test.AbstractSingleSpringContextTests;

/**
 * Unit test BeanPropertiesSpringTest
 * 
 * @author Rik van der Kleij
 */
public class BeanPropertiesSpringTest extends AbstractSingleSpringContextTests {

    private static final Log logger = LogFactory.getLog(BeanPropertiesSpringTest.class);

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.test.AbstractSingleSpringContextTests#customizeBeanFactory(org.springframework.beans.factory.support.DefaultListableBeanFactory)
     */
    @Override
    protected void customizeBeanFactory(DefaultListableBeanFactory beanFactory) {

        beanFactory.setInstantiationStrategy(new BeanPropertiesInstantiationStrategy());
        logger.debug("SetInstantiationStrategy done");
    }

    public void testDependencyInjectionWithNotNestedBeanProperty() {

        logger.debug("Get bean1 start");
        BeanB beanB = (BeanB) applicationContext.getBean("bean1");
        logger.debug("Get bean1 done");
        assertEquals("BeanA", beanB.beanPropA.get().getName());
        logger.debug("Get name beanA of bean1 done");
    }

    public void testDependencyInjectionWithNestedBeanProperty() {

        logger.debug("Get bean2 start");
        BeanB beanB = (BeanB) applicationContext.getBean("bean2");
        logger.debug("Get bean2 done");
        assertEquals("BeanA", beanB.beanPropA.get().getName());
        logger.debug("Get name beanA of bean2 done");
    }

    public void testDependencyInjectionWithIndexedPropertyString() {

        BeanB beanB = (BeanB) applicationContext.getBean("bean3");
        assertEquals("string2", beanB.indexedBeanPropString.get(1));
    }

    public void testDependencyInjectionWithNotNestedBeanPropertyAndIndexedPropertyBeanC() {

        BeanB beanB = (BeanB) applicationContext.getBean("bean4");
        assertEquals("BeanC", beanB.indexedBeanPropBeanC.get(0).getName());
        assertEquals("BeanC", beanB.indexedBeanPropBeanC.get(1).getName());
    }

    @Override
    protected String[] getConfigLocations() {

        return new String[] { "applicationContext.xml" };
    }
}
