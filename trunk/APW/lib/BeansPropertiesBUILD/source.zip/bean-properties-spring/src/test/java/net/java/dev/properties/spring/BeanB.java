/*
 * BeanB.java
 *
 * Created on May 28, 2007, 6:07:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package net.java.dev.properties.spring;

import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.IndexedPropertyImpl;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.container.ObservableProperty;

/**
 * Bean that is used for unit testing Bean Properties Spring integration.
 * 
 * @author Rik van der Kleij
 */
public class BeanB {

    public final Property<BeanA> beanPropA = new PropertyImpl<BeanA>();
    public final Property<BeanC> beanPropC = new ObservableProperty<BeanC>();
    public final Property<String> beanPropString = new PropertyImpl<String>();
    public final IndexedProperty<String> indexedBeanPropString = new IndexedPropertyImpl<String>();
    public final IndexedProperty<BeanC> indexedBeanPropBeanC = new IndexedPropertyImpl<BeanC>();
    public final Property<Object> beanBoundedProp = new PropertyImpl<Object>();
}
