package net.java.dev.properties.spring;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.test.AbstractSingleSpringContextTests;

public class JavaBeanSetterTest extends AbstractSingleSpringContextTests {

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.test.AbstractSingleSpringContextTests#customizeBeanFactory(org.springframework.beans.factory.support.DefaultListableBeanFactory)
     */
    @Override
    protected void customizeBeanFactory(DefaultListableBeanFactory beanFactory) {

        beanFactory.setInstantiationStrategy(new BeanPropertiesInstantiationStrategy());
    }

    @Override
    protected String[] getConfigLocations() {

        return new String[] { "applicationContext.xml" };
    }

    public void testPropertySetter() {

        BeanB beanB = (BeanB) applicationContext.getBean("beanB");
        try {
            // Make sure we can invoke the setBeanPropA method.
            Method method = beanB.getClass().getMethod("setBeanPropA", new Class[] { BeanA.class });
            method.invoke(beanB, new Object[] { new BeanA() });
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        // Test that we actually invoked a setBeanPropA method.
        assertEquals("BeanA", beanB.beanPropA.get().getName());
    }

    public void testPropertyIndexSetter() {

        BeanB beanB = (BeanB) applicationContext.getBean("beanB");
        try {
            // Make sure we can invoke the setIndexedBeanPropString method.
            Method method = beanB.getClass().getMethod("setIndexedBeanPropString",
                    new Class[] { List.class });
            List<String> l = new ArrayList<String>();
            l.add("hello");
            method.invoke(beanB, new Object[] { l });
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        // Test that we actually invoked a setIndexedBeanPropString method.
        assertEquals(1, beanB.indexedBeanPropString.get().size());
        assertEquals("hello", beanB.indexedBeanPropString.get(0));
    }
}
