/**
 * 
 */
package net.java.dev.properties.spring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;

/**
 * @author Rik van der Kleij
 * 
 */
public class BeanPropertiesClassPathXmlApplicationContext extends
        org.springframework.context.support.ClassPathXmlApplicationContext {

    @SuppressWarnings("unchecked")
    public BeanPropertiesClassPathXmlApplicationContext(String path, Class clazz)
            throws BeansException {

        super(path, clazz);
    }

    public BeanPropertiesClassPathXmlApplicationContext(String configLocation)
            throws BeansException {

        super(configLocation);
    }

    public BeanPropertiesClassPathXmlApplicationContext(String[] configLocations,
            ApplicationContext parent) throws BeansException {

        super(configLocations, parent);
    }

    public BeanPropertiesClassPathXmlApplicationContext(String[] configLocations, boolean refresh,
            ApplicationContext parent) throws BeansException {

        super(configLocations, refresh, parent);
        // TODO Auto-generated constructor stub
    }

    public BeanPropertiesClassPathXmlApplicationContext(String[] configLocations, boolean refresh)
            throws BeansException {

        super(configLocations, refresh);
    }

    @SuppressWarnings("unchecked")
    public BeanPropertiesClassPathXmlApplicationContext(String[] paths, Class clazz,
            ApplicationContext parent) throws BeansException {

        super(paths, clazz, parent);
    }

    @SuppressWarnings("unchecked")
    public BeanPropertiesClassPathXmlApplicationContext(String[] paths, Class clazz)
            throws BeansException {

        super(paths, clazz);
    }

    public BeanPropertiesClassPathXmlApplicationContext(String[] configLocations)
            throws BeansException {

        super(configLocations);
    }

    @Override
    protected void customizeBeanFactory(DefaultListableBeanFactory beanFactory) {

        beanFactory.setInstantiationStrategy(new BeanPropertiesInstantiationStrategy());
        super.customizeBeanFactory(beanFactory);
    }
}
