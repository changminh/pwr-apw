/**
 * 
 */
package net.java.dev.properties.spring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.Resource;

/**
 * @author Rik van der Kleij
 * 
 */
public class BeanPropertiesXmlBeanFactory extends XmlBeanFactory {

    /**
     * @param resource
     * @throws BeansException
     */
    public BeanPropertiesXmlBeanFactory(Resource resource) throws BeansException {

        super(resource);
        setBeanPropertiesInstantiationStrategy();

    }

    /**
     * @param resource
     * @param parentBeanFactory
     * @throws BeansException
     */
    public BeanPropertiesXmlBeanFactory(Resource resource, BeanFactory parentBeanFactory)
            throws BeansException {

        super(resource, parentBeanFactory);
        setBeanPropertiesInstantiationStrategy();

    }

    public void setBeanPropertiesInstantiationStrategy() {

        super.setInstantiationStrategy(new BeanPropertiesInstantiationStrategy());
    }
}
