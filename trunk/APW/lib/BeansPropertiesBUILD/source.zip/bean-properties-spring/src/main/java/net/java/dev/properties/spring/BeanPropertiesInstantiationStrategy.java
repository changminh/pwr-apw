/**
 *
 */
package net.java.dev.properties.spring;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.java.dev.properties.container.BeanContainer;
import net.sf.cglib.asm.Type;
import net.sf.cglib.core.Signature;
import net.sf.cglib.proxy.Callback;
import net.sf.cglib.proxy.CallbackFilter;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.InterfaceMaker;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;
import net.sf.cglib.proxy.NoOp;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.support.CglibSubclassingInstantiationStrategy;
import org.springframework.beans.factory.support.RootBeanDefinition;

/**
 * Implementation of InstantionStrategy that creates a subclass of a bean class
 * in case this bean class contains minimal one bean property. The subclass will
 * contain a setter for each property. This setter can be used by the Spring
 * Framework to inject dependencies which are defined in a Spring configuration.
 * In all other cases it will delegate instantation to it's parent.
 * 
 * @author Rik van der Kleij
 */
public class BeanPropertiesInstantiationStrategy extends CglibSubclassingInstantiationStrategy {

    private static final Log logger = LogFactory.getLog(BeanPropertiesInstantiationStrategy.class);
    /**
     * Index in the CGLIB callback array for passthrough behavior, in which case
     * the subclass won't override the original class.
     */
    private static final int PASSTHROUGH = 0;
    /**
     * Index in the CGLIB callback array for a intercept a set method.
     */
    private static final int SETTER = 1;

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.beans.factory.support.SimpleInstantiationStrategy#instantiate(org.springframework.beans.factory.support.RootBeanDefinition,
     *      java.lang.String, org.springframework.beans.factory.BeanFactory)
     */
    @Override
    public Object instantiate(RootBeanDefinition beanDefinition, String beanName, BeanFactory owner) {

        return instantiate(beanDefinition, beanName, owner, null, null);
    }

    /**
     * In case the class of beanDefinition contains minimal one bean property,
     * this class will be subclassed by CGLIB. Otherwise it will call
     * instantiate of parent.
     * 
     * @see org.springframework.beans.factory.support.SimpleInstantiationStrategy#instantiate(org.springframework.beans.factory.support.RootBeanDefinition,
     *      java.lang.String,org.springframework.beans.factory.BeanFactory,
     *      java.lang.reflect.Constructor,java.lang.Object[])
     */
    @SuppressWarnings("unchecked")
    @Override
    public Object instantiate(RootBeanDefinition beanDefinition, String beanName,
            BeanFactory owner, Constructor ctor, Object[] args) {

        if (logger.isDebugEnabled()) {
            logger.debug("Start instantiating bean with name: " + beanName + " of class "
                    + beanDefinition.getBeanClassName());
        }
        Map<String, Field> beanPropertiesFields = getBeanPropertiesFields(beanDefinition);
        if (beanPropertiesFields.size() == 0) {
            logger.debug(beanName + " contains NO bean properties");
            return super.instantiate(beanDefinition, beanName, owner);
        } else {
            logger.debug(beanName + " contains bean properties");
            return new BeanPropertiesSubclassCreator(beanPropertiesFields, beanDefinition)
                    .instantiate(ctor, args);
        }
    }

    /**
     * Returns all bean properties which extends from WProperty of a bean
     * definition .
     * 
     * @param beanDefinition
     * @return map which contains as key the property field name and as value
     *         the Field instance
     */
    private Map<String, Field> getBeanPropertiesFields(RootBeanDefinition beanDefinition) {

        Map<String, Field> beanProperties = new HashMap<String, Field>();
        Field[] fields = beanDefinition.getBeanClass().getFields();
        for (Field field : fields) {
            logger.debug("Field: " + field.getName());
            if ((net.java.dev.properties.WProperty.class.isAssignableFrom(field.getType()))) {
                logger.debug("Found bean property: " + field.getName());
                beanProperties.put(field.getName(), field);
            }
        }
        return beanProperties;
    }

    /**
     * An inner class so we don't have a CGLIB dependency in bean properties.
     */
    private static class BeanPropertiesSubclassCreator {

        private static final Log logger = LogFactory.getLog(BeanPropertiesSubclassCreator.class);
        private Map<String, Field> beanPropertiesFields;
        private RootBeanDefinition beanDefinition;

        /**
         * @param beanPropertiesFields
         * @param beanDefinition
         */
        public BeanPropertiesSubclassCreator(Map<String, Field> beanPropertiesFields,
                RootBeanDefinition beanDefinition) {

            this.beanPropertiesFields = beanPropertiesFields;
            this.beanDefinition = beanDefinition;
        }

        /**
         * Create a new instance of a dynamically generated subclass
         * implementing the required setters.
         * 
         * @param ctor
         *                constructor to use. If this is <code>null</code>,
         *                use the no-arg constructor (no parameterization, or
         *                Setter Injection)
         * @param args
         *                arguments to use for the constructor. Ignored if the
         *                ctor parameter is <code>null</code>.
         * @return new instance of the dynamically generated class
         */
        @SuppressWarnings("unchecked")
        public Object instantiate(Constructor ctor, Object[] args) {

            // Create a dynamic interface
            InterfaceMaker im = new InterfaceMaker();
            // Define a JavaBean setter method for bean property, i.e.,
            // setPropertyA.
            for (Field property : beanPropertiesFields.values()) {
                Type[] parameters;
                if ((net.java.dev.properties.IndexedProperty.class.isAssignableFrom(property
                        .getType()))) {
                    logger.debug("Type of property: List<?>");
                    Type beanPropertyType = Type.getType(List.class);
                    parameters = new Type[] { beanPropertyType };
                } else {
                    Class<?> beanPropertyTypeClass = (Class<?>) ((java.lang.reflect.ParameterizedType) property
                            .getGenericType()).getActualTypeArguments()[0];
                    logger.debug("Type of property: " + beanPropertyTypeClass);
                    Type beanPropertyType = Type.getType(beanPropertyTypeClass);
                    parameters = new Type[] { beanPropertyType };
                }
                String setter = getSetterMethodName(property);
                Signature signature = new Signature(setter, Type.VOID_TYPE, parameters);
                im.add(signature, parameters);
            }
            Class<?> setterInterface = im.create();
            Enhancer enhancer = new Enhancer();
            enhancer.setSuperclass(this.beanDefinition.getBeanClass());
            enhancer.setInterfaces(new Class[] { setterInterface });
            enhancer.setCallbackFilter(new CallbackFilterImpl());
            enhancer.setCallbacks(new Callback[] { NoOp.INSTANCE,
                    new BeanPropertiesMethodInterceptor(), new BeanPropertiesMethodInterceptor() });
            // Instantiate bean and bind this bean to BeanContainer
            Object bean;
            if (ctor == null) {
                bean = enhancer.create();
            } else {
                bean = enhancer.create(ctor.getParameterTypes(), args);
            }
            BeanContainer.bind(bean);
            return bean;
        }

        /**
         * Returns name of setter method by using the Field instance name.
         * 
         * @param property
         *                as Field object
         * @return name of setter method
         */
        private String getSetterMethodName(Field property) {

            String setter = "set" + property.getName().substring(0, 1).toUpperCase()
                    + property.getName().substring(1);
            return setter;
        }

        /**
         * Returns field name of property by using the name of the setter.
         * 
         * @param methodName
         * @return name of property
         */
        private String getPropertyName(String methodName) {

            String propertyName = methodName.substring(3, 4).toLowerCase()
                    + methodName.substring(4);
            return propertyName;
        }

        /**
         * Class providing hashCode and equals methods required by CGLIB to
         * ensure that CGLIB doesn't generate a distinct class per bean.
         * Identity is based on class and bean definition.
         */
        private class CglibIdentitySupport {

            /**
             * Exposed for equals method to allow access to enclosing class
             * field
             */
            protected RootBeanDefinition getBeanDefinition() {

                return beanDefinition;
            }

            public int hashCode() {

                return beanDefinition.hashCode();
            }

            public boolean equals(Object other) {

                return (other.getClass() == getClass())
                        && ((CglibIdentitySupport) other).getBeanDefinition() == beanDefinition;
            }
        }

        private class BeanPropertiesMethodInterceptor extends CglibIdentitySupport implements
                MethodInterceptor {

            /**
             * CGLIB MethodInterceptor that implements JavaBean setter by
             * calling the method set of WProperty interface.
             * 
             * @see net.sf.cglib.proxy.MethodInterceptor#intercept(java.lang.Object,
             *      java.lang.reflect.Method, java.lang.Object[],
             *      net.sf.cglib.proxy.MethodProxy)
             */
            public Object intercept(Object bean, Method method, Object[] args, MethodProxy mp)
                    throws Throwable {

                String propertyName = getPropertyName(method.getName());
                Field propertyField = beanPropertiesFields.get(propertyName);
                Class<?> propertyClass = propertyField.getType();
                logger.debug("Class of property: " + propertyClass);
                Method setter = propertyClass.getMethod("set", new Class[] { Object.class });
                setter.invoke(propertyField.get(bean), args[0]);
                return null;
            }
        }

        /**
         * CGLIB object to filter method interception behavior. This filter
         * takes care for intercepting only method calls to JavaBean setters in
         * which bean properties are set.
         * 
         */
        private class CallbackFilterImpl extends CglibIdentitySupport implements CallbackFilter {

            /**
             * (non-Javadoc)
             * 
             * @see net.sf.cglib.proxy.CallbackFilter#accept(java.lang.reflect.Method)
             */
            public int accept(Method method) {

                String methodName = method.getName();
                if (!(methodName.startsWith("set"))) {
                    return PASSTHROUGH;
                }
                String property = getPropertyName(methodName);
                logger.debug("Property name: " + property);
                if (beanPropertiesFields.containsKey(property)) {
                    return SETTER;
                } else {
                    return PASSTHROUGH;
                }
            }
        }
    }
}
