package net.model3.props.orm;

import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import junit.framework.TestCase;

import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.test.util.UnitTestConfigurator;

import org.hsqldb.jdbcDriver;

public class ManyAssociationTest extends AbstractManWomanTest {

	private final boolean dropTables = false;
	
	public static void main(String[] args) throws Exception {
		ManyAssociationTest test = new ManyAssociationTest();
		test.setUp();
		test.test1();
	}
	

    public void test1() {

    	Session session = CurrentSession.get();
    	
        ORMMan man = new ORMMan();
        man.name.set( "Adam" );
        man.id.set( 1 );
        
        ORMWoman woman = new ORMWoman();
        woman.name.set( "Eve" );
        woman.id.set( 2 );
        
        woman.husband.set(man);
        man.womanFriend.set(woman);
        
        ORMMan man3 = new ORMMan();
        man3.name.set( "Kevin" );
        man3.id.set( 3 );

        session.insert(man);
        session.insert(man3);
        session.insert(woman);

        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
        
        assertEquals(1, woman.manFriends.size());

        man3.womanFriend.set(woman);

        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();

        assertEquals(2, woman.manFriends.size());

        ORMWoman hydratedWoman = session.fetchByPK(ORMWoman.class, 2);
        ORMMan hydratedMan = session.fetchByPK(ORMMan.class, 1);
        ORMMan hydratedMan3 = session.fetchByPK(ORMMan.class, 3);
        
        assertEquals(2, hydratedWoman.manFriends.size());

        ORMMan hydratedMan2 = hydratedWoman.husband.get();

        hydratedWoman.toString();

        assertEquals(hydratedWoman, woman);
        assertEquals(hydratedMan2, man);
        assertEquals(hydratedWoman, hydratedMan2.wife.get());
        assertEquals(hydratedMan2, hydratedWoman.husband.get());
        
    }

}
