package net.model3.props.orm;

import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;


public class ORMPerson {
	
	public final Property<String> name = ObservableProperty.create();

	@Column( key=true )
        public final Property<Integer> id = ObservableProperty.create();
	
	public ORMPerson() {
		BeanContainer.bind(this);
	}
	
	@Override
	public String toString() {
		return id.get() + " - " + name.get() + " - " + BeanContainer.get().hashCode(this);
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		Integer id1 = id.get();
		result = PRIME * result + ((id1 == null) ? 0 : id1.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final ORMPerson other = (ORMPerson) obj;
		Integer id1 = id.get();
		Integer id2 = other.id.get();
		if (id1 == null) {
			if (id2 != null)
				return false;
		} else if (!id1.equals(id2))
			return false;
		return true;
	}
	
	

}
