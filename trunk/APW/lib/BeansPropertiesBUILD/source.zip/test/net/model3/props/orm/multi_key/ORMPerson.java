package net.model3.props.orm.multi_key;

import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.annotations.NotNull;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;


public class ORMPerson { 
	
	public final Property<String> name = new ObservableProperty<String>();

        @Column(  key=true, compositeKeySequence=1  )
	@NotNull
        public final Property<Integer> id1 = new ObservableProperty<Integer>();
	
        @Column(  key=true, compositeKeySequence=2  )
	@NotNull
        public final Property<String> id2 = new ObservableProperty<String>();
	
	public ORMPerson() {
            BeanContainer.bind(this);
	}
	
	@Override
	public String toString() {
		return name.get();
	}

	/*@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = PRIME * result + id1.get().hashCode();
		result = PRIME * result + id2.get().hashCode();
		return result;
	}*/

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		//if (!super.equals(obj))
		//	return false;
		if (getClass() != obj.getClass())
			return false;
		final ORMPerson other = (ORMPerson) obj;
		if (id1 == null) {
			if (other.id1 != null)
				return false;
		} else if (!id1.get().equals(other.id1.get()))
			return false;
		if (id2 == null) {
			if (other.id2 != null)
				return false;
		} else if (!id2.get().equals(other.id2.get()))
			return false;
		return true;
	}
	
	

}
