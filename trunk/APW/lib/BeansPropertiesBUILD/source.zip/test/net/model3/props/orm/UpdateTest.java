package net.model3.props.orm;

import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import junit.framework.TestCase;
import net.java.dev.properties.jdbc.ConnectionFactory;
import org.hsqldb.jdbcDriver;

public class UpdateTest extends AbstractManWomanTest {


    public void testUpdateSingleMan() {

        Session session = CurrentSession.get();

        ORMMan man = new ORMMan();
        man.name.set("Adam");
        man.id.set(1);

        session.insert(man);
        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();

        ORMMan updateMan = session.fetchByPK(ORMMan.class, 1 );
        updateMan.name.set( "Bob" );
        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
        
        ORMMan updateMan2 = session.fetchByPK(ORMMan.class, 1 );
        
        assertEquals(updateMan.name.get(), updateMan2.name.get());        
    }

}
