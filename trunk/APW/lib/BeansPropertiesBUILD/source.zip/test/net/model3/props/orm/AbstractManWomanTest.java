package net.model3.props.orm;

import net.java.dev.properties.jdbc.AbstractJdbcTest;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;

public abstract class AbstractManWomanTest extends AbstractJdbcTest {

	@Override
	protected void setUp() throws Exception {

		super.setUp();
		
        Session session = CurrentSession.get();
        SessionConfiguration configuration = SessionConfiguration.getInstance();

        configuration.addClass(ORMMan.class);
        configuration.addClass(ORMWoman.class);           

        configuration.getPersister(ORMMan.class).createTable();
        configuration.getPersister(ORMWoman.class).createTable();

	}
	
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		
        Session session = CurrentSession.get();
        SessionConfiguration configuration = SessionConfiguration.getInstance();

        configuration.getPersister(ORMMan.class).dropTable();
        configuration.getPersister(ORMWoman.class).dropTable();
        
        SessionConfiguration.setInstance(null);

        session.clear();
	}
	
}
