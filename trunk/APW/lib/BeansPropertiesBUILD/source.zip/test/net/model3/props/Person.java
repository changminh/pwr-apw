package net.model3.props;

import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;


public class Person {
	
	public final Property<String> name = new ObservableProperty<String>();
	
	@Bidirectional( "friends" )
	public transient final IndexedProperty<Person> friends = ObservableIndexed.create();
	
	public Person() {
		BeanContainer.bind(this);
	}
	
	@Override
	public String toString() {
		return name.get();
	}

}
