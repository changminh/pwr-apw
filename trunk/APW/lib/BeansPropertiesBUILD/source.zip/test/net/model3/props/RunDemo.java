package net.model3.props;

public class RunDemo {

	public static void main(String[] args) {
		
		Man man1 = new Man( "Bob" );
		Woman woman1 = new Woman( "Tonya" );
		Woman woman2 = new Woman( "Debbie" );

		show(man1,woman1,woman2);
		
		man1.wife.set(woman1);

		show(man1,woman1,woman2);

		man1.wife.set(null);
		show(man1,woman1,woman2);
		
		man1.wife.set(woman2);
		show(man1,woman1,woman2);
		
		man1.wife.set(woman1);
		show(man1,woman1,woman2);
		
	}
	
	static void show( Man man, Woman woman, Woman woman2 ) {
		System.out.println( "-----" );
		System.out.println( man + "  wife=" + man.wife.get() );
		System.out.println( woman + "  husband=" + woman.husband.get() );
		System.out.println( woman2 + "  husband=" + woman2.husband.get() );
	}
	
}
