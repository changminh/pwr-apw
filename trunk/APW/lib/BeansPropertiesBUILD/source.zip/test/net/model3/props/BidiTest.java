package net.model3.props;

import junit.framework.TestCase;

public class BidiTest extends TestCase {

	public void testOneToOne() {

		Man man1 = new Man( "Bob" );
		Woman woman1 = new Woman( "Tonya" );
		Woman woman2 = new Woman( "Debbie" );

		assertNull( man1.wife.get() );
		assertNull( woman1.husband.get() );
		assertNull( woman2.husband.get() );

		man1.wife.set(woman1);
		assertEquals( man1.wife.get(), woman1 );
		assertEquals( woman1.husband.get(), man1 );
		assertNull( woman2.husband.get() );

		man1.wife.set(woman2);
		assertEquals( man1.wife.get(), woman2 );
		assertNull( woman1.husband.get() );
		assertEquals( woman2.husband.get(), man1 );
		
		man1.wife.set(null);
		assertNull( man1.wife.get() );
		assertNull( woman1.husband.get() );
		assertNull( woman2.husband.get() );

		woman1.husband.set(man1);
		assertEquals( man1.wife.get(), woman1 );
		assertEquals( woman1.husband.get(), man1 );
		assertNull( woman2.husband.get() );
		
		woman2.husband.set(man1);
		assertEquals( man1.wife.get(), woman2 );
		assertNull( woman1.husband.get() );
		assertEquals( woman2.husband.get(), man1 );
		
	}

	public void testManyToManySet() {

		Man man1 = new Man( "Bob" );
		Woman woman1 = new Woman( "Tonya" );
		Woman woman2 = new Woman( "Debbie" );
		
		man1.friends.add(woman1);
		assertEquals( 1, man1.friends.size() );
		assertTrue(man1.friends.get().contains(woman1));
		assertEquals( 1, woman1.friends.size() );
		assertTrue(woman1.friends.get().contains(man1));
		assertEquals( 0, woman2.friends.size() );
		
		man1.friends.remove(woman1);
		assertEquals( 0, man1.friends.size() );
		assertEquals( 0, woman1.friends.size() );
		assertEquals( 0, woman2.friends.size() );

		man1.friends.add(woman1);
		assertEquals( 1, man1.friends.size() );
		assertTrue(man1.friends.get().contains(woman1));
		assertEquals( 1, woman1.friends.size() );
		assertTrue(woman1.friends.get().contains(man1));
		assertEquals( 0, woman2.friends.size() );
		
		woman1.friends.remove(man1);
		assertEquals( 0, man1.friends.size() );
		assertEquals( 0, woman1.friends.size() );
		assertEquals( 0, woman2.friends.size() );

		woman2.friends.add(woman1);
		man1.friends.add(woman2);
		assertEquals( 1, man1.friends.size() );
		assertTrue(man1.friends.get().contains(woman2));
		assertEquals( 1, woman1.friends.size() );
		assertTrue(woman1.friends.get().contains(woman2));
		assertEquals( 2, woman2.friends.size() );
		assertTrue(woman2.friends.get().contains(man1));
		assertTrue(woman2.friends.get().contains(woman1));

		woman2.friends.remove(woman1);
		woman2.friends.remove(man1);
		assertEquals( 0, man1.friends.size() );
		assertEquals( 0, woman1.friends.size() );
		assertEquals( 0, woman2.friends.size() );
		
		woman2.friends.add(woman1);
		woman2.friends.add(woman1);
		assertEquals( 0, man1.friends.size() );
		assertEquals( 1, woman1.friends.size() );
		assertTrue(woman1.friends.get().contains(woman2));
		assertEquals( 1, woman2.friends.size() );
		assertTrue(woman2.friends.get().contains(woman1));
		
	}
	
}
