package net.model3.props.orm;

import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import junit.framework.TestCase;
import net.java.dev.properties.jdbc.ConnectionFactory;
import org.hsqldb.jdbcDriver;

public class InsertTest extends AbstractManWomanTest {


    public void testInsertSingleMan() {

        Session session = CurrentSession.get();

        ORMMan man = new ORMMan();
        man.name.set("Adam");
        man.id.set(1);

        session.insert(man);

        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
    }

    public void testInsertSingleWoman() {

        Session session = CurrentSession.get();

        ORMWoman woman = new ORMWoman();
        woman.name.set("Betty");
        woman.id.set(2);
        session.insert(woman);

        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
    }

    public void testInsertCouple() {

        Session session = CurrentSession.get();

        ORMMan man = new ORMMan();
        man.name.set("Adam");
        man.id.set(3);

        ORMWoman woman = new ORMWoman();
        woman.name.set("Eve");
        woman.id.set(4);

        woman.husband.set(man);

        session.insert(man);
        session.insert(woman);

        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
    }
}
