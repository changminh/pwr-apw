package net.model3.props;

import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;

public class Man extends Person {

	@Bidirectional("marriage partner")
	public final Property<Woman> wife = ObservableProperty.create();

	public Man() {
		BeanContainer.bind(this);
	}

	public Man(String name) {
		this();
		this.name.set(name);
	}
	
}
