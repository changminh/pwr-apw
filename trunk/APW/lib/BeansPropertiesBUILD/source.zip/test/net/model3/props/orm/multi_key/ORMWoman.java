package net.model3.props.orm.multi_key;

import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;

public class ORMWoman extends ORMPerson {

	@Bidirectional("marriage partner")
	public final Property<ORMMan> husband = ObservableProperty.create();

	@Bidirectional( "friends" )
	//public transient final SetPropertyImpl<ORMMan> manFriends = new EntityBidiSetProperty<ORMMan>();
        public final IndexedProperty<ORMMan> manFriends = ObservableIndexed.create();

	public ORMWoman() {
		BeanContainer.bind(this);
	}

}
