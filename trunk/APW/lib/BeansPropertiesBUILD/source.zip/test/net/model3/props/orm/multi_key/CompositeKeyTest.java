package net.model3.props.orm.multi_key;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import junit.framework.TestCase;

import net.java.dev.properties.jdbc.AbstractJdbcTest;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;

import org.hsqldb.jdbcDriver;

public class CompositeKeyTest extends AbstractJdbcTest {
	
	public static void main(String[] args) {
		//LoggingConfigurator.getInstance().addConsoleAppender();
		new CompositeKeyTest().test1();
	}

    public void test1() {

        Session session = CurrentSession.get();
        SessionConfiguration configuration = SessionConfiguration.getInstance();

        configuration.addClass(ORMMan.class);
        configuration.addClass(ORMWoman.class);           

        configuration.getPersister(ORMMan.class).createTable();
        configuration.getPersister(ORMWoman.class).createTable();

        ORMMan man = new ORMMan();
        man.name.set( "Adam" );
        man.id1.set( 1 );
        man.id2.set( "1" );

        ORMWoman woman = new ORMWoman();
        woman.name.set( "Eve" );
        woman.id1.set( 2 );
        woman.id2.set( "2" );

        woman.husband.set(man);

        session.insert(man);
        session.insert(woman);

        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();

        List<ORMMan> entries2 = session.fetchAll(ORMMan.class);       
        System.out.println(entries2.size());

        List<ORMWoman> entries3 = session.fetchAll(ORMWoman.class);       
        System.out.println(entries3.size());

        ORMWoman woman2 = session.fetchByPK(ORMWoman.class, 2, "2");
        ORMMan man2 = woman2.husband.get();

        woman2.toString();

        assertEquals(woman2, woman);
        assertEquals(man2, man);
        assertEquals(woman2, man2.wife.get());
        assertEquals(man2, woman2.husband.get());
        
    }

}
