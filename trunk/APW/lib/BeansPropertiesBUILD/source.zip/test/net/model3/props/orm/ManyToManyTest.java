package net.model3.props.orm;

import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.annotations.ManyToMany;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.container.thread.ThreadManager;
import net.java.dev.properties.jdbc.AbstractJdbcTest;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;
import net.java.dev.properties.jdbc.handlers.ManyToManyHandler;


public class ManyToManyTest extends AbstractJdbcTest {


	public static void main(String[] args) throws Exception {
		ManyToManyTest test = new ManyToManyTest();
		test.setUp();
		test.testMutateAfterInsert();
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
            ThreadManager.defaultInstance.set(new ThreadManager() {
                @Override
                public boolean isRightThread() {
                    return true;
                }
            });
            while(ThreadManager.managers.size() > 0) {
                ThreadManager.managers.remove(0);
            }

		SessionConfiguration cfg = SessionConfiguration.getInstance();
		
		cfg.addClass( Item.class );
		cfg.addClass( Category.class );
		
		SessionConfiguration.getInstance().createDatabaseTables();
	}

	public void testMutateAfterInsert() {
		performInserts(true);
	}

	public void testMutateBeforeInsert() {
		performInserts(false);
	}
	
	private void performInserts( boolean peformInterimFlush ) {

		SessionConfiguration.getInstance().clearDatabaseTables();

		Session session = CurrentSession.get();

		Item item1 = new Item("item1");	
		Item item2 = new Item("item2");
		Item item3 = new Item("item3");
		Category category1 = new Category("category1");
		Category category2 = new Category("category2");
		Category category3 = new Category("category3");

		session.insert(item1);
		session.insert(item2);
		session.insert(item3);

		session.insert(category1);
		session.insert(category2);
		session.insert(category3);

		if ( peformInterimFlush ) { 
			session.flushAndCommit();
		}

		item1.categories.add(category1);
		item1.categories.add(category2);

		item3.categories.add(category2);
		item3.categories.add(category3);

		assertEquals(1, category1.items.size());
		assertEquals(2, category2.items.size());
		assertEquals(1, category3.items.size());
		
		assertEquals(2, item1.categories.size());
		assertEquals(2, item3.categories.size());
		
		session.flushAndCommit();

		// make sure we get newly instantiated objects of this point
		session.clear();
		
		Item item1b = session.fetchByPK(Item.class, "item1");	
		Item item2b = session.fetchByPK(Item.class, "item2");	
		Item item3b = session.fetchByPK(Item.class, "item3");	
		Category category1b = session.fetchByPK(Category.class, "category1");
		Category category2b = session.fetchByPK(Category.class, "category2");
		Category category3b = session.fetchByPK(Category.class, "category3");
		
		assertEquals(item1.categories.size(), item1b.categories.size());
		assertEquals(item2.categories.size(), item2b.categories.size());
		assertEquals(item3.categories.size(), item3b.categories.size());
		assertEquals(1, category1b.items.size());
		assertEquals(2, category2b.items.size());
		assertEquals(1, category3b.items.size());

	}

	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
        SessionConfiguration.getInstance().dropDatabaseTables();
	}
	
	
	public static class Item {
		@Column(key=true)
		public final ObservableProperty<String> name = ObservableProperty.create();

		@Column(typeHandler=ManyToManyHandler.class)
		@Bidirectional("category-items")
		@ManyToMany()
		public final ObservableIndexed<Category> categories = ObservableIndexed.create();

		public Item() {
			BeanContainer.bind(this);
		}
		
		public Item(String name) {
			BeanContainer.bind(this);
			this.name.set(name);
		}
		
	}
	
	public static class Category {
		@Column(key=true)
		public final ObservableProperty<String> name = ObservableProperty.create();
		
		@Column(typeHandler=ManyToManyHandler.class)
		@ManyToMany(transientSide=true)
		@Bidirectional("category-items")
		public final ObservableIndexed<Item> items = ObservableIndexed.create();

		public Category() {
			BeanContainer.bind(this);
		}
		
		public Category(String name) {
			BeanContainer.bind(this);
			this.name.set(name);
		}

	}
	
}
