package net.model3.props;

import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Table;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;

@Table
public class Woman extends Person {

	@Bidirectional("marriage partner")
	public final Property<Man> husband = ObservableProperty.create();

	public Woman() {
		BeanContainer.bind(this);
	}
	
	public Woman(String name) {
		this();
		this.name.set(name);
	}

}
