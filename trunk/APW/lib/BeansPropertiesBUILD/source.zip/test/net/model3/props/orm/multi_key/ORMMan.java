package net.model3.props.orm.multi_key;

import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;

public class ORMMan extends ORMPerson {

	@Bidirectional("marriage partner")
	public final Property<ORMWoman> wife = ObservableProperty.create();
	
	@Bidirectional( "friends" )
	public final Property<ORMWoman> womanFriend = ObservableProperty.create();

	public ORMMan() {
		BeanContainer.bind(this);
	}

}
