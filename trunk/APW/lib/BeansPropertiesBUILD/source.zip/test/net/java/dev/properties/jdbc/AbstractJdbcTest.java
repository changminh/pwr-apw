package net.java.dev.properties.jdbc;

import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import junit.framework.TestCase;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.test.util.UnitTestConfigurator;

import org.hsqldb.jdbcDriver;

public abstract class AbstractJdbcTest extends TestCase {

    @Override
    protected void setUp() throws Exception {
		UnitTestConfigurator.configureLogging();
		UnitTestConfigurator.configureInMemoryJbc();
    }
}
