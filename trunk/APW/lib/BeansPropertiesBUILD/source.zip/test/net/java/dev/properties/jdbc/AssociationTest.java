package net.java.dev.properties.jdbc;

import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;
import junit.framework.TestCase;
import net.java.dev.properties.container.thread.ThreadManager;

public class AssociationTest extends TestCase {

	@Override
	protected void setUp() throws Exception {
            ThreadManager.defaultInstance.set(new ThreadManager() {
                @Override
                public boolean isRightThread() {
                    return true;
                }
            });
            while(ThreadManager.managers.size() > 0) {
                ThreadManager.managers.remove(0);
            }
            
            SessionConfiguration.getInstance().addClass(Parent.class);
            SessionConfiguration.getInstance().addClass(Child.class);
	}

	public void testParentChildDisAssociation() {
		{
			Parent parent1 = new Parent();
			parent1.id.set(1);
			
			Child child1 = new Child();
			child1.id.set(1);
			
			parent1.children.add(child1);
			
			assertEquals(parent1, child1.parent.get() );
	
			child1.parent.set(null);
	
			assertEquals( 0, parent1.children.size() );
		}
		
		{
			Parent parent1 = new Parent();
			parent1.id.set(1);
			
			Child child1 = new Child();
			child1.id.set(1);
			
			parent1.children.add(child1);
			
			assertTrue( parent1 == child1.parent.get() );
	
			Parent parent2 = new Parent();
			parent2.id.set(2);
			
			Child child2 = new Child();
			child2.id.set(2);
			
			child2.parent.set(parent2);
	
			assertTrue( child2 == parent2.children.get(0) );
	
			// try to re-associate
			child2.parent.set(parent1);
	
			assertTrue( child2 == parent1.children.get(1) );
			assertTrue( parent2.children.size() == 0 );
		}
		
	}
	
	
	
	
	
	public static class Parent {
		@Column(key=true)
		public final Property<Integer> id = ObservableProperty.create();

		@Bidirectional("parent-child")
		public final IndexedProperty<Child> children = ObservableIndexed.create();
		
		public Parent() {
			BeanContainer.bind(this);
		}
		
	}
	
	
	public static class Child {
		@Column(key=true)
		public final Property<Integer> id = ObservableProperty.create();

		@Bidirectional("parent-child")
		public final Property<Parent> parent = ObservableProperty.create();		

		public Child() {
			BeanContainer.bind(this);
		}

	}
	
}
