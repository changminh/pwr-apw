package net.java.dev.properties.jdbc;

import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.jdbc.handlers.IdGeneratorHandler;
import junit.framework.TestCase;

/**
 * @author Glen Marchesani
 */
public class IdGeneratorHandlerTest extends AbstractJdbcTest {
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		SessionConfiguration.getInstance().addClass(InsertMe.class);
		
		EntityPersister<InsertMe> insertMePersister = SessionConfiguration.getInstance().getPersister(InsertMe.class);
		
		insertMePersister.createTable();
		
		InsertMe bean = new InsertMe();
		
		IdGeneratorHandler idGeneratorHandler = (IdGeneratorHandler) insertMePersister.getTypeHandler(bean.id.getContext());

		idGeneratorHandler.createTable();
		
	}

	public void testOneToOne() {

		Session session = CurrentSession.get();
		
		InsertMe i1 = new InsertMe();
		session.insert(i1);
		
		session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
		
		InsertMe i2 = new InsertMe();
		session.insert(i2);
		
		session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
        
        assertEquals((Object) 1L, i1.id.get());
        assertEquals((Object) 2L, i2.id.get());
		
	}
	
	public static class InsertMe {
		@Column( typeHandler=IdGeneratorHandler.class, key=true )
		public final Property<Long> id = ObservableProperty.create();
		
		InsertMe() {
			BeanContainer.bind(this);
		}
	}
	
}
