package net.java.dev.properties.studio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import junit.framework.TestCase;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.EntityPersister;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;
import net.java.dev.properties.test.binding.studio.AttendanceBean;
import net.java.dev.properties.test.binding.studio.StudentBean;
import net.java.dev.properties.test.binding.studio.StudioBean;
import net.java.dev.properties.test.binding.studio.YogaClassBean;
import net.java.dev.properties.test.demos.orm.PersistantAttendance;
import net.java.dev.properties.test.demos.orm.PersistantStudent;
import net.java.dev.properties.test.demos.orm.PersistantStudioBean;
import net.java.dev.properties.test.demos.orm.PersistantYogaClass;
import net.java.dev.properties.test.demos.orm.PersistentId;
import org.hsqldb.jdbcDriver;

public class StudioORMTest extends TestCase {

    protected void setUp() throws Exception {
        try {
            DriverManager.registerDriver(new jdbcDriver());
            //Class.forName("org.apache.derby.jdbc.ClientDriver");
//            Class.forName("com.mysql.jdbc.Driver");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        SessionConfiguration.getInstance().connectionFactory.set(new ConnectionFactory() {

            public void log(String output) {
                System.out.print("ORM: ");
                System.out.println(output);
            }

            public Connection newConnection() throws SQLException {
                Connection con = DriverManager.getConnection("jdbc:hsqldb:.", "sa", "");
                con.setAutoCommit(false);
                return con;
            }
        });

        SessionConfiguration configuration = SessionConfiguration.getInstance();

        configuration.addClassesAndCreateTables(false, true, PersistantStudent.class, 
                PersistantYogaClass.class, PersistantAttendance.class);
    }
    
    
    public void testInsertSelect() {

        Session session = CurrentSession.get();

        PersistantStudent student = new PersistantStudent();
        student.id.set(1);
        student.firstName.set("Student Name");

        PersistantYogaClass yoga = new PersistantYogaClass();
        yoga.id.set(1);
        yoga.dayOfWeek.set((byte)3);
        
        PersistantAttendance attend = new PersistantAttendance();
        attend.id.set(1);
        Date date = new Date(1, 1, 45);
        attend.when.set(date);
        
        /*PersistantStudioBean studio = new PersistantStudioBean();
        studio.id.set(1);
        studio.attendance.add(attend);
        studio.classes.add(yoga);
        studio.students.add(student);*/
        
        /*session.insert(student);
        session.insert(attend);
        session.insert(yoga);
        //session.insert(studio);

        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
        
        checkList(StudentBean.class, student.firstName.getContext(), "Student Name");       
        checkList(AttendanceBean.class, attend.when.getContext(), date);
        checkList(YogaClassBean.class, yoga.dayOfWeek.getContext(), (byte)3);
                
        List<StudioBean> list = CurrentSession.get().fetchAll(StudioBean.class);
        assertEquals(list.size(), 1);
        assertEquals(((PersistentId)list.get(0)).id().get().intValue(), 1);
        assertEquals(list.get(0).attendance.size(), 1);
        assertEquals(list.get(0).classes.size(), 1);
        assertEquals(list.get(0).students.size(), 1);*/
    }
    
    private void checkList(Class<?> cls, PropertyContext prop, Object value) {
        List<?> list = CurrentSession.get().fetchAll(cls);
        assertEquals(list.size(), 1);
        assertEquals(((PersistentId)list.get(0)).id().get().intValue(), 1);
        assertEquals(prop.getInternalValue(list.get(0)), value);
    }
}
