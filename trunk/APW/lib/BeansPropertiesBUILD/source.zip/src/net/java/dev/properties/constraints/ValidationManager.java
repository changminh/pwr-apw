/*
 * ValidationManager.java
 *
 * Created on March 5, 2007, 4:24 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.PropertyListener;

/**
 * Abstract base class for validation functionality relating mostly to its 
 * UI integration. Customized versions of this class can be adapted for various
 * view technologies.
 *
 * @author Shai Almog
 */
public abstract class ValidationManager<C> {        
    /**
     * Indicates the validation notice instance registered for the 
     */
    public final Property<ValidationNotice> notice = new PropertyImpl<ValidationNotice>();
    
    /** Creates a new instance of ValidationManager */
    protected ValidationManager() {
        BeanContainer.bind(this);
    }

    /**
     * This method can be invoked by the binding layer to indicate that a validation
     * error occured that can't be conveyed to the model.
     */
    public abstract void setComponentValidity(BaseProperty prop, C component, boolean value);

    /**
     * This method is invoked to refresh the view side of the component. Calling setComponent
     * validity removes the need to invoke this method.
     */
    public abstract void refreshComponentValidity(BaseProperty prop, C component, boolean value, String message);

    /**
     * Recursively invokes refresh for all the bean properties
     */
    public void refreshBeanComponentValidity(Object bean, C component) {
        for(RProperty prop : BeanContainer.get().getContext(bean).getRPropertiesArray(bean)) {
            refreshComponentValidity(prop, component, prop.getContext().validate(prop, ((RProperty)prop).get()), 
                prop.getContext().getValidationMessage(prop, prop.get()));
        }
    }
    
    /**
     * Returns true if all the bindings beween the given components hierarchy and
     * the bean are valid. A good example of when something like this might fail
     * is when a bean property is numeric but the user entered text in the view.
     */
    protected abstract boolean isComponentValid(C component);
    
    /**
     * Validates in two layers the component and the bean layer
     */
    public boolean isValid(Object bean, C component) {
        return BeanContainer.get().isValid(bean) && isComponentValid(component);
    }
    
    /**
     * Registers interest in changes to any of the components within parent component
     * if validation state changes this listener should be notified
     */
    protected abstract void registerInterest(C parentComponent, PropertyListener listener);

    /**
     * Tracks the validity of complex components that are bound to indexed properties
     * such as tables and lists.
     */
    public abstract void trackIndexedValidity(IndexedProperty indexed, C component);
    
    /**
     * By default bean validity isn't monitored this allows a component to update
     * the UI regarding its validity state
     */
    public void trackValidity(final Object bean, final C parentComponent) {
        PropertyListener l = new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                refreshComponentValidity(prop, parentComponent, 
                    prop.getContext().validate(prop, newValue), 
                    prop.getContext().getValidationMessage(prop, newValue));
            }
        };
        registerInterest(parentComponent, l);
        BeanContainer.get().addListener(bean, l);
        refreshBeanComponentValidity(bean, parentComponent);
    }
 
    /**
     * Stops tracking the validity of the given component
     */
    public void stopTracking(Object bean, C parentComponent) {
        PropertyListener l = getListener(parentComponent);
        registerInterest(parentComponent, null);
        BeanContainer.get().removeListener(bean, l);
    }
    
    
    /**
     * Returns the listener on which we invoked registerInterest previously
     */
    protected abstract PropertyListener getListener(C cmp);

    /**
     * Makes sure the given component gets enabled only when the given bean is valid
     */
    public void enableWhenValid(final Object bean, final C enable, final C parentComponent) {
        boolean value = isValid(bean, parentComponent);
        setEnabled(enable, value);
        PropertyListener l = new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                setEnabled(enable, isValid(bean, parentComponent));
                
                // validation on a specific property might pass while the whole bean still fails
                // so we need a second validation test
                refreshComponentValidity(prop, parentComponent, 
                    prop.getContext().validate(prop, newValue), 
                    prop.getContext().getValidationMessage(prop, newValue));
            }
        };
        registerInterest(parentComponent, l);
        BeanContainer.get().addListener(bean, l);
        refreshBeanComponentValidity(bean, parentComponent);
    }
    
    /**
     * Makes sure the given component gets enabled only when the given set of beans are valid.
     * Notice these beans don't have to be of the same type
     */
    public void enableWhenValid(final Object[] beans, final C enable, final C parentComponent) {
        setEnabled(enable, areValid(beans, parentComponent));
        PropertyListener l = new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                setEnabled(enable, isValid(prop.getParent(), parentComponent));
                
                // validation on a specific property might pass while the whole bean still fails
                // so we need a second validation test
                refreshComponentValidity(prop, parentComponent, 
                        prop.getContext().validate(prop, newValue), 
                        prop.getContext().getValidationMessage(prop, newValue));
            }
        };
        registerInterest(parentComponent, l);
        for(Object bean : beans) {
            BeanContainer.get().addListener(bean, l);
            refreshBeanComponentValidity(bean, parentComponent);
        }
    }
    
    /**
     * Enables/disables given component according to the enabled property
     */
    protected abstract void setEnabled(C component, boolean enabled);
    
    /**
     * Returns true if all the given beans are valid otherwise false.
     */
    public boolean areValid(Object[] beans, final C parentComponent) {
        for(Object bean : beans) {
            if(!isValid(bean, parentComponent)) {
                return false;
            }
        }
        return true;
    }
}
