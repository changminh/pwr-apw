/*
 * AttendanceBean.java
 *
 * Created on March 7, 2007, 11:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.mirror;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Indicates which students attended a particular class on a given date
 *
 * @author Shai Almog
 */
public class AttendanceBean implements java.io.Serializable {
    private YogaClassBean type;
    
    private Date when;
    
    private StudentBean[] who;
    
    public String toString() {
        if(getWho() == null) return "";
        return getWho().toString();
    }

    public YogaClassBean getType() {
        return type;
    }

    public void setType(YogaClassBean type) {
        this.type = type;
    }

    public Date getWhen() {
        return when;
    }

    public void setWhen(Date when) {
        this.when = when;
    }

    public StudentBean[] getWho() {
        return who;
    }

    public void setWho(StudentBean[] who) {
        this.who = who;
    }
}
