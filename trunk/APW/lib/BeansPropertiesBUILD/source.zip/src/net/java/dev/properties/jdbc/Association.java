/*
 * Association.java
 *
 * Created on Aug 18, 2007, 8:38:04 AM
 *
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.java.dev.properties.jdbc;

import java.util.Collection;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.ObservableInterface;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.OnGet;
import net.java.dev.properties.events.OnGetListener;
import net.java.dev.properties.MapProperty;

/**
 * The association class tracks a bidirectional relationship and updates its members upon change
 *
 * @author Shai Almog, Glen Marchesani
 */
public class Association implements ORMThread.PropertyListener, OnGet {

    private Association _foreignProperty;

    /**
     * Prevents propertyChanged from recursing due to changes propagated back
     * from the foreign side of the relation.
     */
    boolean lock;
    
    private Object[] _foreignKeyValues;
    
    private BaseProperty prop;
    

    private Association(BaseProperty prop) {
        this.prop = prop;
    }

    /**
     * Makes sure an association is created for the bean property if no such
     * association already exists.
     */
    public static void bind(PropertyContext propContext, Object bean) {
        Association a = propContext.getRelationalAssociation(bean);
        if(a == null) {
            // since there is no association just bind to the bean
            RProperty<?> value = (RProperty)propContext.getValue(bean);
            
            // a valid state since this might be triggred by a base class calling bind()
            if(value == null) {
                return;
            }
            if(value instanceof IndexedProperty) {
                a = new IndexedAssociation(value);
            } else {
                if(value instanceof MapProperty) {
                    a = new MapAssociation(value);
                } else {
                    a = new Association(value);
                }
            }
            
            BeanContainer.get().addListener(value, a);
            ((OnGetListener)value).setOnGet(a);
        }
    }

    public PropertyContext getForeignPropertyContext(PropertyContext context) {
        if(!context.isBidirectional()) {
            return null;
        }
        Class foreignType = context.getType();
        String bidiValue = context.getRelationName();
        BeanContext foreignContext = BeanContainer.get().getContext(foreignType);
        for (PropertyContext tryThisField : foreignContext.getPropertiesArray()) {
            if(tryThisField.isBidirectional()) {
                if (tryThisField.getRelationName().equals(bidiValue)) {
                    return tryThisField;
                }
            }
        }

        throw new BeanBindException("no @Bidirectional " + bidiValue + " found in " + foreignType.getName());
    }

    public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
    	
    	if ( oldValue == newValue ) {
    		return;
    	}
    	
        if (!lock) {
            try {
                lock = true;
                Association oldForeignProperty = _foreignProperty;

                if(oldValue != null) {
                    disassociate(prop, oldValue);
                    if(oldForeignProperty != null) {
                        oldForeignProperty.disassociate(getForeignProperty(prop, oldValue), prop.getParent());
                    }
                }

                associate(prop, newValue);
                if(_foreignProperty != null) {
                    _foreignProperty.associate(getForeignProperty(prop, newValue), ((RProperty)prop).getParent());
                }
            } finally {
                lock = false;
            }
        }
    }
    
    private BaseProperty getForeignProperty(BaseProperty thisProp, Object foreignObject) {
        PropertyContext c = getForeignPropertyContext(thisProp.getContext());
        return c.getValue(foreignObject);
    }

    protected void associate(BaseProperty prop, Object value) {
        // if already associated auto dis-associate
        Object currentValue = ((RProperty)prop).get();
        if(currentValue != null) {
            if ( !getForeignPropertyContext(prop.getContext()).isIndexedProperty() && _foreignProperty != null ) {
                ((WProperty<?>)_foreignProperty.prop).set(null);
            }
            disassociate(prop, currentValue);
        }

        if ( value != null ) {
            _foreignProperty = getForeignPropertyContext(prop.getContext()).getRelationalAssociation(value);
            ((WProperty)prop).set(value);
        }
    }

    protected void disassociate(BaseProperty prop, Object value) {
        ((WProperty)prop).set(null);
        _foreignProperty = null;
    }

    public void onGet(RProperty<?> p) {        
        if ( _foreignKeyValues != null && (!lock)) {
            try {
                lock = true;
                ((WProperty)p).set(CurrentSession.get().fetchByPK(p.getContext().getType(), _foreignKeyValues));
                _foreignKeyValues = null;
            } finally {
                lock = false;
            }
        }
    }
    
    
    public void setPrimaryKeyValues( Object...pk) {
        _foreignKeyValues = pk;
    }
    
    void setForeignProperty(Association foreignProperty) {
        _foreignProperty = foreignProperty;
    }
    
    /**
     * An implementation of association that enables indexed property mapping
     */
    private static class IndexedAssociation extends Association implements ORMThread.IndexedPropertyListener {
        private IndexedAssociation(BaseProperty prop) {
            super(prop);
        }
        protected void disassociate(BaseProperty prop, Object value) {
            ((IndexedProperty)prop).remove(value);
            setForeignProperty(null);
        }

        protected void associate(BaseProperty prop, Object value) {
            Collection c = (Collection) ((RProperty)prop).get();
            if ( prop.getContext().isAllowsBidirectionalDuplicates() || !c.contains(value) ) {
                    ((IndexedProperty)prop).add(value);
            }
        }

        /**
         * Method is overriden to "do nothing" all the work should go on in the property insert/remove events
         */
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        }

        public void propertyInserted(IndexedProperty prop, Object value, int index) {
            associate(prop, value);
            PropertyContext pc = prop.getContext();
            if(pc.isBidirectional()) {
                PropertyContext foreign = getForeignPropertyContext(prop.getContext());
                foreign.getRelationalAssociation(value).associate(foreign.getValue(value), prop.getParent());
            }         }

        public void propertyRemoved(IndexedProperty prop, Object value, int index) {
            disassociate(prop, value);
            PropertyContext pc = prop.getContext();
            if(pc.isBidirectional()) {
                PropertyContext foreign = getForeignPropertyContext(prop.getContext());
                foreign.getRelationalAssociation(value).disassociate(foreign.getValue(value), prop.getParent());
            } 
        }
    }

    /**
     * An implementation of association that enables map property mapping
     * 
     * TODO: this is just a skeleton implementation that needs work and thought
     */
    private static class MapAssociation extends Association implements ORMThread.MapPropertyListener {
        private MapAssociation(BaseProperty prop) {
            super(prop);
        }
        protected void disassociate(BaseProperty prop, Object value) {
            ((MapProperty)prop).remove(value);
            setForeignProperty(null);
        }

        /**
         * Method is overriden to "do nothing" all the work should go on in the property insert/remove events
         */
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        }

        public void propertyInserted(MapProperty prop, Object key, Object value) {
        }

        public void propertyRemoved(MapProperty prop, Object key) {
        }
    }
}
