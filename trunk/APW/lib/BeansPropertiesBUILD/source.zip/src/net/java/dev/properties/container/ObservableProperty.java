/*
 * ObservableProperty.java
 *
 * Created on February 21, 2007, 2:57 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import net.java.dev.properties.events.OnGetListener;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.events.OnGet;
import net.java.dev.properties.events.PropertyListener;

/**
 * Simple read/write bean implementation that supports property change
 * observability
 *
 * @author Shai Almog
 */
public class ObservableProperty<T> extends PropertyImpl<T> implements ObservableInterface, OnGetListener {    
    private final ObservableDelegate<PropertyListener> delegate = new ObservableDelegate<PropertyListener>();
    private OnGet onGet;

    public ObservableProperty() {
    }
    
    public ObservableProperty(T t) {
        super(t);
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> ObservableProperty<K> create() {
        return new ObservableProperty<K>();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> ObservableProperty<K> create(K k) {
        return new ObservableProperty<K>(k);
    }

    /**
     * @inheritDoc
     */
    @Override
    public void set(T t) {
        T old = get();
        super.set(t);
        getContext().onChange(this, getParent(), old, t, -1);
    }

    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<PropertyListener> getDelegate() {
        return delegate;
    }

    /**
     * @inheritDoc
     */
    @Override
    public void setOnGet(OnGet onGet) {
        this.onGet = onGet;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public T get() {
        if(onGet != null) {
            onGet.onGet(this);
        }
        return super.get();
    }    
}
