package net.java.dev.properties.jdbc;


/**
 * A Session context strategy is responsible for
 * creating sessions
 */
public interface SessionContextStrategy {
	Session currentSession();
	void close(Session session);
}
