/*
 * DTD.java
 *
 * Created on March 25, 2007, 4:28 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.xml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.constraints.NotNullConstraint;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;

/**
 * The DTD class abstracts the document structure, currently only DTD but in the
 * future it could be extended for schema/relax NG etc. 
 * <p>The general idea is that this class knows how to treat "special" properties
 * such as ID's and value properties to provide a wider range of XML functionality.
 * As a utility feature this class can also manufacture a DTD from a bean object
 * tree.
 *
 * @author Shai Almog
 */
public class DTD {
    private List<PropertyContext> idProperties = new ArrayList<PropertyContext>();
    private List<PropertyContext> valueProperties = new ArrayList<PropertyContext>();
    public final Property<BeanContext> root = new PropertyImpl<BeanContext>();
    public final Property<Class> rootClass = new PropertyImpl<Class>();
    public final Property<Boolean> validate = new PropertyImpl<Boolean>(false);
    public final Property<String> dtd = new PropertyImpl<String>();
    public final Property<String> encoding = new PropertyImpl<String>("utf-8");
    private Map<String, Class> tagNameToClassCache = new HashMap<String, Class>();
    
    /** Creates a new instance of DTD */
    public DTD(Class rootClass) {
        BeanContainer.bind(this);
        root.set(BeanContainer.get().getContext(rootClass));
        this.rootClass.set(rootClass);
    }

    /**
     * Returns the class for the given tag name
     */
    Class getBeanForName(String name) {
        Class c = tagNameToClassCache.get(name);
        if(c == null) {
            if(name.equals(root.get().getName())) {
                c = rootClass.get();
            } else {
                c = findBeanNamed(rootClass.get(), name);
            }
            tagNameToClassCache.put(name, c);
        }
        return c;
    }
    
    /**
     * Recursively searches the bean tree until it finds the right bean
     */
    private Class findBeanNamed(Class current, String name) {
        BeanContext context = BeanContainer.get().getContext(current);
        Iterator<PropertyContext> iter = context.getProperties();
        while(iter.hasNext()) {
            PropertyContext c = iter.next();
            Class type = c.getType();
            if(c.getName().equals(name)) {
                return type;
            }
            if(BeanContainer.get().isNewBean(type)) {
                Class result = findBeanNamed(type, name);
                if(result != null) {
                    return result;
                }
            }
        }
        return null;
    }
    
    /**
     * Marks the given property as the id attribute for the XML bean
     */
    public void setIDProperty(PropertyContext p) {
        idProperties.add(p);
    }

    void clearIDProperty(PropertyContext p) {
        idProperties.remove(p);
    }

    PropertyContext getPropertyContext(BeanContext bean) {
        for(PropertyContext p : bean.getPropertiesArray()) {
            if(valueProperties.contains(p)) {
                return p;
            }
        }
        return null;
    }
    
    PropertyContext getIDContext(BeanContext bean) {
        for(PropertyContext p : bean.getPropertiesArray()) {
            if(idProperties.contains(p)) {
                return p;
            }
        }
        return null;
    }
    
    /**
     * Marks the given property as the value attribute which won't appear as an
     * attribute but rather map directly to the elements value
     */
    public void setValueProperty(PropertyContext p) {
        valueProperties.add(p);
    }
    
    boolean isIDProperty(PropertyContext p) {
        return idProperties.contains(p);
    }

    boolean isValueProperty(PropertyContext p) {
        return valueProperties.contains(p);
    }
}
