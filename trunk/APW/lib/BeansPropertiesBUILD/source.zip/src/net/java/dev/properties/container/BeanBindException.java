/*
 * BeanBindException.java
 *
 * Created on February 21, 2007, 2:23 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

/**
 * The bean bind exception is a runtime exception since there is not much you
 * can do about it. Normally a bean would not fail in binding so if such a 
 * problem occurs in production then you are f*ed.
 *
 * @author Shai Almog
 */
public class BeanBindException extends RuntimeException {
    
    /** Creates a new instance of BeanBindException */
    public BeanBindException() {
    }

    public BeanBindException(String err) {
        super(err);
    }

    /** Creates a new instance of BeanBindException */
    public BeanBindException(Exception cause) {
        super(cause);
    }
    
}
