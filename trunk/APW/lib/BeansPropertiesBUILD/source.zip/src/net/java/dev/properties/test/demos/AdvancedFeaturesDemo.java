package net.java.dev.properties.test.demos;

import java.awt.Color;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.constraints.ConstraintFailedException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.VetoListener;
import net.java.dev.properties.test.AdvancedFeatures;
import net.java.dev.properties.test.DemoInterface;

/**
 * A demo for some of the advanced features in the API
 *
 * @author shai
 */
public class AdvancedFeaturesDemo extends DemoInterface.DefaultConsoleDemo {
    public AdvancedFeaturesDemo() {
        super("Highlighted Features", "<html><body><h1>Highlighted Features</h1>Demonstrates some features of the API such as " +
                "validations, indexed properties and failure behavior on validation. Goes into some " +
                "details about custom validators. Also demonstrates vetoable properties that allow " +
                "an external event handler to reject a veto change.", 
                new Class[] {AdvancedFeatures.class, AdvancedFeaturesDemo.class});
    }

    public void run() {
        AdvancedFeatures adv = new AdvancedFeatures();
        adv.attr.set(5);
        try {
            adv.attr.set(null);
        } catch(ConstraintFailedException err) {
            getOutput().println("Exception thrown when trying to assign null to attribute");
        }
        getOutput().println(adv.attr);
        
        getOutput().println(adv.lightColor);
        adv.lightColor.set(Color.WHITE);
        getOutput().println(adv.lightColor);
        adv.lightColor.set(Color.BLACK);
        getOutput().println(adv.lightColor);
        

        getOutput().println(adv.indexed);
        adv.indexed.add(0, "New");
        getOutput().println(adv.indexed);
        adv.indexed.remove(1);
        getOutput().println(adv.indexed);

        getOutput().println(adv.vetoable);
        BeanContainer.get().addVetoListener(adv.vetoable, new VetoListener() {
            public boolean propertyChangeCheck(BaseProperty prop, Object oldValue, Object newValue, int index) {
                // disallow a number larger from 11
                return ((Number)newValue).intValue() < 11;
            }
        });
        adv.vetoable.set(50);
        getOutput().println(adv.vetoable);
        adv.vetoable.set(10);
        getOutput().println(adv.vetoable);        
    }
}
