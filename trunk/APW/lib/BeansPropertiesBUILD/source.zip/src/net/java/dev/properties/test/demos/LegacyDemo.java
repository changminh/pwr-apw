/*
 * LegacyDemo.java
 *
 * Created on April 15, 2007, 10:27 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.demos;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import net.java.dev.properties.test.DemoInterface;
import net.java.dev.properties.test.LegacyBean;

/**
 * A demo of using a legacy bean for the purposes of comparison to the new beans
 *
 * @author shai
 */
public class LegacyDemo extends DemoInterface.DefaultConsoleDemo {
    public LegacyDemo() {
        super("Legacy Bean", "<html><body><h1>Legacy Bean</h1>" +
                "This demo tries to illustrate the difference between " +
                "building/using a legacy bean and defining/working with a new bean " +
                "the code in this demo should be familiar to every Java developer since " +
                "it has nothing to do with bean-properties other than as a reference.",
                new Class[] {LegacyBean.class, LegacyDemo.class});
    }

    public void run() {
        LegacyBean legacy = new LegacyBean();
        legacy.setX(1);
        getOutput().println("Legacy x is: " + legacy.getX());
        PropertyChangeListener l = new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent ev) {
               getOutput().println("Legacy " + ev.getPropertyName() + " was changed " + ev.getNewValue());
            }
        };
        legacy.addPropertyChangeListener(l);
        legacy.setX(2);
        legacy.removePropertyChangeListener(l);
        legacy.addPropertyChangeListener("x", l);
        legacy.setX(3);
    }
}
