/*
 * TreeBinding.java
 *
 * Created on April 4, 2007, 2:31 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding;

import java.awt.BorderLayout;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.binding.swing.adapters.SwingBind;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.test.DemoGUI;
import net.java.dev.properties.test.DemoInterface;

/**
 * Simple test for binding to a JTree
 *
 * @author Shai Almog
 */
public class TreeBindingTest implements DemoInterface {
    public final Property<String> data = ObservableProperty.create("");
    public final IndexedProperty<TreeBindingTest> children = ObservableIndexed.create();
    public final Property<Boolean> leaf = ObservableProperty.create(false);
    
    /** Creates a new instance of TreeBinding */
    public TreeBindingTest() {
        BeanContainer.bind(this);
    }

    public TreeBindingTest(String data) {
        this();
        this.data.set(data);
        leaf.set(true);
    }

    public String toString() {
        return data.get();
    }
    
    private static TreeBindingTest createTree() {
        TreeBindingTest t = new TreeBindingTest("Data Node");
        t.leaf.set(false);
        t.children.add(new TreeBindingTest("First"));
        t.children.add(new TreeBindingTest("Second"));
        t.children.add(new TreeBindingTest("Third"));
        t.children.add(new TreeBindingTest("Forth"));
        TreeBindingTest t2 = new TreeBindingTest("Has Children");
        t2.leaf.set(false);
        t2.children.add(new TreeBindingTest("Inner Child 1"));
        t2.children.add(new TreeBindingTest("Inner Child 2"));
        t.children.add(t2);
        return t;
    }
    
    public static void main(String[] argv) throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        JFrame frm = new JFrame("Tree Test");
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JTree tree = new JTree();
        TreeBindingTest t = createTree();
        SwingBind.get().bindContent(t, 
            new PropertyContext[] {t.children.getContext()}, 
            t.leaf.getContext(), tree);
        frm.add(new JScrollPane(tree), BorderLayout.CENTER);
        frm.pack();
        frm.setLocationByPlatform(true);
        frm.setVisible(true);
    }

    public String[] fileNames() {
        return DemoGUI.demoFiles(new Class[]{getClass()});
    }

    public JComponent execute() {
        JTree tree = new JTree();
        TreeBindingTest t = createTree();
        SwingBind.get().bindContent(t, 
            new PropertyContext[] {t.children.getContext()}, 
            t.leaf.getContext(), tree);
        return new JScrollPane(tree);
    }

    public String demoName() {
        return "Tree Binding";
    }

    public String demoDescription() {
        return "<html><body><h1>Tree Binding</h1>Demonstrates the complexity of binding to a tree " +
                "which is a component that contains hierarchy. This hierachy needs to be expressed in " +
                "the object model and conveyed to the binding layer which makes the code rather elaborate.";
    }

    public void cleanup() {
    }
}
