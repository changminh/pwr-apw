/**
 * 
 */
package net.java.dev.properties.jdbc;

import java.sql.SQLException;
import java.util.List;

import net.java.dev.properties.jdbc.ConnectionFactory;

public abstract class BatchUpdateExecutor<T> extends SQLExecutor {
	
    private List<T> _beans;
    
    public BatchUpdateExecutor(String query, List<T> beans) {
        super(query,null,false);
        _beans = beans;
        execute();
    }
    
    
    protected void runQuery() throws SQLException {
        getStatement().executeBatch();
        setQueryExecutionResponse(true);
    }

    @Override
    protected void prepareQuery() throws SQLException {
        for(T bean : _beans) {
            addBeanToBatchStatement(bean);
            getStatement().addBatch();
        }
    }

    protected abstract void addBeanToBatchStatement( T bean ) throws SQLException;

}