package net.java.dev.properties.test.recipe;

import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.annotations.Regex;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.jdbc.handlers.IdGeneratorHandler;

/**
 * A demo similar to the RoR recipe demo available here:
 * http://www.onlamp.com/pub/a/onlamp/2005/01/20/rails.html?page=1
 *
 * @author Shai Almog
 */
public class Recipe {
    @Column(key=true, typeHandler=IdGeneratorHandler.class)
    public final Property<Long> id = ObservableProperty.create();
    
    @Regex(exp="[A-Z][a-zA-Z ]*", message="A title must contain only English characters and must start with an uppercase character")
    public final Property<String> title = ObservableProperty.create();
    public final Property<String> instructions = ObservableProperty.create();

    public Recipe() {
        BeanContainer.bind(this);
    }

    public Recipe(String title) {
        this();
        this.title.set(title);
    }
}
