/*
 * SwingAdapter.java
 *
 * Created on March 6, 2007, 11:43 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import javax.swing.JComponent;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;
import net.java.dev.properties.container.BeanBindException;

/**
 * An adapter customized for the needs of Swing
 *
 * @author Shai Almog
 */
public abstract class SwingAdapter<T, V extends JComponent> extends Adapter<T, V> {    
    protected void bindUI(BaseProperty<T> property, V component) {
        if(isSelectionBind()) {
            component.putClientProperty("SelectionProperty", property);
            component.putClientProperty("SelectionAdapter", this);
        } else {
            component.putClientProperty("Property", property);
            component.putClientProperty("Adapter", this);
        }
        bindListener(property, component);
    }

    /**
     * Unbinds the listeners in the subclass appropriately
     */
    protected void unbindUI(BaseProperty<T> property, V component) {
        component.putClientProperty("Property", null);
        component.putClientProperty("Adapter", null);
        component.putClientProperty("SelectionProperty", null);
        component.putClientProperty("SelectionAdapter", null);
        unbindListener(property, component);
    }
    
    protected SwingAdapter<T, V> getBoundAdapter(V component) {
        return (SwingAdapter<T, V>)component.getClientProperty("Adapter");
    }

    protected SwingAdapter<T, V> getBoundSelectionAdapter(V component) {
        return (SwingAdapter<T, V>)component.getClientProperty("SelectionAdapter");
    }

    public static void unbindComponent(JComponent c) {
        Adapter a = (Adapter)c.getClientProperty("Adapter");
        if(a != null) {
            a.unbind(c);
        }
        a = (Adapter)c.getClientProperty("SelectionAdapter");
        if(a != null) {
            a.unbind(c);
        }
    }
    
    /**
     * Indicates the selection based binding
     */
    protected boolean isSelectionBind() {
        return false;
    }
    
    /**
     * Binds the listeners in the subclass appropriately
     */
    protected abstract void bindListener(BaseProperty<T> property, V component);

    /**
     * Binds the listeners in the subclass appropriately
     */
    protected abstract void unbindListener(BaseProperty<T> property, V component);

    /**
     * Since Swing adapters are package protected they must be created from within
     * this class...
     */
    public void createBoundInstance(BaseProperty property, V component) {
        try {
            SwingAdapter<T,V> newInstance = (SwingAdapter<T, V>)getClass().newInstance();
            newInstance.bind((BaseProperty<T>)property, component);
        } catch(Exception err) {
            throw new BeanBindException(err);
        }
    }
}
