/*
 * Serializer.java
 *
 * Created on March 24, 2007, 12:44 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.xml;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.DefaultHandler;

/**
 * This class converts a new bean to XML and visa versa. It is associated with the
 * root bean which is the bean that signifies the root of the XML document and
 * builds the XML document from there on.
 *
 * @author Shai Almog
 */
public class Serializer {
    private BeanContext context;
    
    /** Creates a new instance of Serializer */
    private Serializer(BeanContext context) {
        this.context = context;
    }
    
    public static Serializer createSerializer(BeanContext context) {
        return new Serializer(context);
    }
    
    /**
     * Returns a W3C DOM document matching the given bean and DTD object
     */
    public Document createDocument(DTD dtd, Object bean) {
        return new BeanDocument(dtd, dtd.root.get().getName(), bean);
    }
    
    /**
     * Loads the given XML file and builds the appropriate bean based on the 
     * DTD object
     */
    public Object toBean(DTD dtd, Reader stream) throws IOException, SAXException {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            factory.setValidating(dtd.validate.get());
            SAXParser parser = factory.newSAXParser();
            ParseHandler handler = new ParseHandler(dtd);
            parser.parse(new InputSource(stream), handler);
            return handler.getRoot();
        } catch(ParserConfigurationException err) {
            // fucking redundant checked exception
            throw new SAXException(err);
        }
    }
    
    /**
     * Converts the given bean tree to an XML file
     */
    public void toXML(DTD dtd, Object bean, Writer output) throws IOException, SAXException {
        try {
            StreamResult streamResult = new StreamResult(output);
            SAXTransformerFactory tf = (SAXTransformerFactory) SAXTransformerFactory.newInstance();
            TransformerHandler hd = tf.newTransformerHandler();
            Transformer serializer = hd.getTransformer();
            serializer.setOutputProperty(OutputKeys.ENCODING, dtd.encoding.get());
            if(dtd.dtd.get() != null) {
                serializer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, dtd.dtd.get());
            }
            serializer.setOutputProperty(OutputKeys.INDENT, "yes");
            hd.setResult(streamResult);
            hd.startDocument();
            
            writeBean(dtd, dtd.root.get().getName(), bean, hd, new ArrayList());
            
            hd.endDocument();
        } catch (TransformerConfigurationException ex) {
            throw new SAXException(ex);
        }
    }

    /**
     * Writes the current bean recursively as XML output
     */
    private void writeBean(DTD dtd, String tag, Object bean, TransformerHandler hd, List cache) throws SAXException {
        BeanContext context = BeanContainer.get().getContext(bean.getClass());
        if(cache.contains(bean)) {
            PropertyContext idProperty = dtd.getIDContext(context);
            
            // we need to write a reference tag only since the bean was already written
            if(idProperty != null) {
                AttributesImpl atts = new AttributesImpl();
                Object val = idProperty.getInternalValue(bean);
                if(val != null) {
                    atts.addAttribute("", "", idProperty.getName(), "CDATA", val.toString());
                    hd.startElement("", "", tag, atts);                    
                    hd.endElement("", "", tag);                    
                    return;
                }
            }
        } 
        cache.add(bean);
         
        // iterate over all the elements and check out which ones are the attributes
        // and which ones are internal beans
        List<Property> beans = new ArrayList<Property>();
        AttributesImpl atts = new AttributesImpl();
        for(PropertyContext property : context.getPropertiesArray()) {
            BaseProperty current = property.getValue(bean);
            if(current instanceof Property) {
                if(BeanContainer.get().isNewBean(property.getType())) {
                    beans.add((Property)current);
                    continue;
                }
                Object value = ((Property<Object>)current).get();
                if(value != null) {
                    atts.addAttribute("", "", property.getName(), "CDATA", value.toString());
                }
            }
        }
        hd.startElement("", "", tag, atts);
        for(Property property : beans) {
            if(property.getContext().isIndexedProperty()) {
                IndexedProperty index = (IndexedProperty)property;
                int size = index.size();
                String name = property.getContext().getName();
                for(int iter = 0 ; iter < size ; iter++) {
                    writeBean(dtd, name, index.get(iter), hd, cache);
                }
            } else {
                writeBean(dtd, property.getContext().getName(), property.get(), hd, cache);
            }
        }
        hd.endElement("", "", tag);                            
    }
    
    /**
     * Implementation of the SAX parser that builds the beans
     */
    private static class ParseHandler extends DefaultHandler {
        private DTD dtd;
        private Object root;
        private List<Object> stack = new ArrayList<Object>();
        private String idValue;
        
        /**
         * This map contains the object ids to bean mapping thus allowing us to
         * cache instances of objects if they are reused
         */
        private Map<BeanContext, Map<String, Object>> beanIdCache = new HashMap<BeanContext, Map<String, Object>>();
        
        public ParseHandler(DTD dtd) {
            this.dtd = dtd;
            try {
                root = dtd.rootClass.get().newInstance();
            } catch (IllegalAccessException ex) {
                throw new BeanBindException(ex);
            } catch (InstantiationException ex) {
                throw new BeanBindException(ex);
            }
        }
        
        public Object getRoot() {
            return root;
        }

        
        
        private Object checkCache(BeanContext context, Attributes attributes) {
            idValue = null;
            PropertyContext prop = dtd.getIDContext(context);
            if(prop != null) {
                idValue = attributes.getValue(prop.getName());
            } else {
                return null;
            }
            Map<String, Object> idMap = beanIdCache.get(context);
            if(idMap != null) {
                return idMap.get(idValue);
            }
            return null;
        }
        
        private void cache(BeanContext context, Object bean, Attributes attributes) {
            if(idValue != null) {
                Map<String, Object> idMap = beanIdCache.get(context);
                if(idMap == null) {
                    idMap = new HashMap<String, Object>();
                    beanIdCache.put(context, idMap);
                }
                idMap.put(idValue, bean);
            }
        }
        
        /**
         * Receive notification of the start of an element.
         * 
         * <p>By default, do nothing.  Application writers may override this
         * method in a subclass to take specific actions at the start of
         * each element (such as allocating a new tree node or writing
         * output to a file).</p>
         * 
         * 
         * @param uri The Namespace URI, or the empty string if the
         *        element has no Namespace URI or if Namespace
         *        processing is not being performed.
         * @param localName The local name (without prefix), or the
         *        empty string if Namespace processing is not being
         *        performed.
         * @param qName The qualified name (with prefix), or the
         *        empty string if qualified names are not available.
         * @param attributes The attributes attached to the element.  If
         *        there are no attributes, it shall be an empty
         *        Attributes object.
         * @exception org.xml.sax.SAXException Any SAX exception, possibly
         *            wrapping another exception.
         * @see org.xml.sax.ContentHandler#startElement
         */
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            try {
                Class beanClass;
                Object beanInstance;
                BeanContext context;
                if(stack.size() == 0) {
                    beanClass = root.getClass();
                    beanInstance = root;
                    context = BeanContainer.get().getContext(beanClass);
                } else {
                    beanClass = dtd.getBeanForName(qName);
                    context = BeanContainer.get().getContext(beanClass);
                    beanInstance = checkCache(context, attributes);
                    if(beanInstance == null) {
                        beanInstance = beanClass.newInstance();
                        cache(context, beanInstance, attributes);
                    }
                    Object parent = stack.get(stack.size() - 1);
                    BeanContext parentContext = BeanContainer.get().getContext(parent.getClass());
                    PropertyContext parentProperty = parentContext.getContext(qName);
                    if(parentProperty.isIndexedProperty()) {
                        ((IndexedProperty<Object>)parentProperty.getValue(parent)).add(beanInstance);
                    } else {
                        ((WProperty<Object>)parentProperty.getValue(parent)).set(beanInstance);
                    }
                }
                
                stack.add(beanInstance);
                int length = attributes.getLength();
                for(int iter = 0 ; iter < length ; iter++) {
                    String name = attributes.getQName(iter);
                    String value = attributes.getValue(iter);
                    PropertyContext pContext = context.getContext(name);
                    
                    // fail silently for unrecognized properties... 
                    if(pContext != null) {
                        BaseProperty prop = pContext.getValue(beanInstance);
                        BeanDocument.setPropertyValue(prop, value);
                    }
                }
            } catch (InstantiationException ex) {
                throw new SAXException(ex);
            } catch (IllegalAccessException ex) {
                throw new SAXException(ex);
            }
        }

        /**
         * Receive notification of the end of an element.
         * 
         * <p>By default, do nothing.  Application writers may override this
         * method in a subclass to take specific actions at the end of
         * each element (such as finalising a tree node or writing
         * output to a file).</p>
         * 
         * 
         * @param uri The Namespace URI, or the empty string if the
         *        element has no Namespace URI or if Namespace
         *        processing is not being performed.
         * @param localName The local name (without prefix), or the
         *        empty string if Namespace processing is not being
         *        performed.
         * @param qName The qualified name (with prefix), or the
         *        empty string if qualified names are not available.
         * @exception org.xml.sax.SAXException Any SAX exception, possibly
         *            wrapping another exception.
         * @see org.xml.sax.ContentHandler#endElement
         */
        public void endElement(String uri, String localName, String qName) throws SAXException {
            stack.remove(stack.size() - 1);
        }

        /**
         * Receive notification of character data inside an element.
         * 
         * <p>By default, do nothing.  Application writers may override this
         * method to take specific actions for each chunk of character data
         * (such as adding the data to a node or buffer, or printing it to
         * a file).</p>
         * 
         * 
         * @param ch The characters.
         * @param start The start position in the character array.
         * @param length The number of characters to use from the
         *               character array.
         * @exception org.xml.sax.SAXException Any SAX exception, possibly
         *            wrapping another exception.
         * @see org.xml.sax.ContentHandler#characters
         */
        public void characters(char[] ch, int start, int length) throws SAXException {
            Object bean = stack.get(stack.size() - 1);
            PropertyContext p = dtd.getPropertyContext(BeanContainer.get().getContext(bean.getClass()));
            if(p != null) {
                Property<String> prop = (Property<String>)p.getValue(bean);
                if(prop.get() != null && prop.get().length() > 0) {
                    prop.set(prop.get() + new String(ch, start, length));
                } else {
                    prop.set(new String(ch, start, length));
                }
            }
        }
    }
}
