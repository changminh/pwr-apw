package net.java.dev.properties.jdbc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;

/**
 * 
 * A simple implementation of the Session interface.  
 * 
 * What is not yet implemented...
 *    not everything is properly vetted through the cache so the example given in the Session javadocs 
 *    does not hold (yet).
 * 
 * @author Glen Marchesani
 *
 * TODO add merged objects to cache and make sure they don't get remerged
 */
public class SessionImpl implements Session {
    static {
        ORMThread.init();
    }

	final private SessionContextStrategy _sessionContextStrategy;
	final private SessionConfiguration _sessionConfiguration;

	private Map<CacheEntry, Object> _entityCache = new HashMap<CacheEntry, Object>();
	
    /**
     * List of updated beans pending a flush() invocation
     */
    private List<Object> _pendingUpdate = new ArrayList<Object>();

    /**
     * List of deleted beans pending a flush() invocation
     */
    private List<Object> _pendingDelete = new ArrayList<Object>();

    /**
     * List of inserted beans pending a flush() invocation
     */
    private List<Object> _pendingInsert = new ArrayList<Object>();

    private LinkedHashSet<SessionAware> _sessionAwareObjects = new LinkedHashSet<SessionAware>();
    
    /**
     * List of inserted beans pending a flush() invocation
     */
    private Set<Property> _observedProperties = new HashSet<Property>();

    /**
     * This property indicates whether changes made to properties in the session
     * will be tracked so they can be reverted in memory without going to the database.
     * This is very useful for applications that might fail in persisting but would
     * still want to try again without going to the database.
     */
    public final Property<Boolean> trackClientChanges = PropertyImpl.create(false);
    
    /**
     * If trackClientChanges is true this list allows us to revert the changes to all the beans
     * if we wish to.
     */
    private List<BeanContainer.StrictMergePoint> mergePoints;
    
    /**
     * This is a listener to property change events that handles batching of 
     * update operations.
     * 
     */
    private ORMThread.PropertyListener _propertyListener = new ORMThread.PropertyListener() {
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
            // no need to synchronize since this call is single threaded
            Object bean = prop.getParent();
            if(!_pendingUpdate.contains(bean)) {
                // prevent a case where an add can occur just after the copy of the 
                // list and before the clearing of said list.
                synchronized(_pendingUpdate) {
                    _pendingUpdate.add(bean);
                }
                if(trackClientChanges.get()) {
                    if(mergePoints == null) {
                        mergePoints = new ArrayList<BeanContainer.StrictMergePoint>();
                    }
                    mergePoints.add(BeanContainer.get().strictMergePoint(bean));
                }
            }
        }
    };
    
    
    public SessionImpl(final SessionContextStrategy sessionContextStrategy, final SessionConfiguration sessionConfiguration) {
		super();
		_sessionContextStrategy = sessionContextStrategy;
		_sessionConfiguration = sessionConfiguration;
        BeanContainer.bind(this);
    }
    
    /**
     * Reverts in memory state of the objects to the value before the last commit.
     * This will only work when trackClientChanges is true!
     */
    public void revertMemoryState() {
        if(!trackClientChanges.get()) {
            throw new IllegalStateException("trackClientChanges is false, no changes to revert!");
        }
        if(mergePoints != null) {
            for(BeanContainer.StrictMergePoint point : mergePoints) {
                point.rollback();
                point.dispose();
            }
            mergePoints = null;
        }
    }

    /**
     * Clears current memory state so we can no longer revert to older states.
     * This operation is only valid when trackClientChanges is true.
     */
    public void clearMemoryState() {
        if(mergePoints != null) {
            for(BeanContainer.StrictMergePoint point : mergePoints) {
                point.dispose();
            }
            mergePoints = null;
        }
    }

    /**
     * This property indicates whether changes made to properties in the session
     * will be tracked so they can be reverted in memory without going to the database.
     * This is very useful for applications that might fail in persisting but would
     * still want to try again without going to the database.
     */
    public Property<Boolean> trackClientChanges() {
        return trackClientChanges;
    }

    public <T> T fetchOne(Class<T> clazz,String whereClause) {
    	List<T> list = fetchMany(clazz, whereClause);
    	if ( list.size() > 1 ) {
    		throw new TooManyResultsException( whereClause + " on " + clazz.getName() + " return more than 1 result" );
    	} else if ( list.size() == 1 ) {
    		return list.get(0);
    	} else {
    		return null;
    	}
    }


	public <T> T fetchByPK(Class<T> clazz, Object...primaryKey) {
		CacheEntry cacheEntry = new CacheEntry(clazz,primaryKey);
		T t = (T) _entityCache.get(cacheEntry);
		if ( t != null ) {
			return t;
		} else {
			EntityPersister<T> persister = _sessionConfiguration.getPersister(clazz);
			return persister.findByPK(primaryKey);
		}
	}

	
	public <T> List<T> fetchMany(Class<T> clazz, String sqlWhere) {
		EntityPersister<T> persister = _sessionConfiguration.getPersister(clazz);
		List<T> list = persister.select(persister.createWhere(sqlWhere), 0, Integer.MAX_VALUE, (Object[])null);
		return list;
	}

	public void flush() {
        try {
        	
        	List inserts = new ArrayList(_pendingInsert);
        	List updates = new ArrayList(_pendingUpdate);
        	List deletes = new ArrayList(_pendingDelete);

        	_pendingDelete.clear();
            _pendingInsert.clear();
            _pendingUpdate.clear();

        	inserts.removeAll(deletes);
        	updates.removeAll(deletes);
        	updates.removeAll(inserts);
	        
	        List<SessionEventListener> listeners = _sessionConfiguration.getListeners();
	        
	        for ( SessionAware sessionAware : _sessionAwareObjects ) {
	        	sessionAware.processInserts();
	        }
	        
	        // TODO: optimize 
	        List tempList = new ArrayList();
	        for ( Object o : inserts ) {
	        	for ( SessionEventListener listener : listeners ) {
	        		listener.preInsert(o);
	        	}
	        	tempList.clear();
	        	tempList.add(o);
	        	_sessionConfiguration.getPersister(o.getClass()).insertBatch(tempList);
	        	for ( SessionEventListener listener : listeners ) {
	        		listener.postInsert(o);
	        	}
	        }

	        for ( SessionAware sessionAware : _sessionAwareObjects ) {
	        	sessionAware.processUpdates();
	        }

	        for ( Object o : updates ) {
	        	for ( SessionEventListener listener : listeners ) {
	        		listener.preUpdate(o);
	        	}
	        	tempList.clear();
	        	tempList.add(o);
	        	_sessionConfiguration.getPersister(o.getClass()).updateBatch(tempList);
	        	for ( SessionEventListener listener : listeners ) {
	        		listener.postUpdate(o);
	        	}
	        }

	        for ( SessionAware sessionAware : _sessionAwareObjects ) {
	        	sessionAware.processDeletes();
	        }

	        for ( Object o : deletes ) {
	        	for ( SessionEventListener listener : listeners ) {
	        		listener.preDelete(o);
	        	}
	        	tempList.clear();
	        	tempList.add(o);
	        	getConfiguration().getPersister(o.getClass()).deleteBatch(tempList);
	        	for ( SessionEventListener listener : listeners ) {
	        		listener.postDelete(o);
	        	}
	        }

        } catch ( Exception e ) {
            if(e instanceof RuntimeException) {
                throw (RuntimeException)e;
            }
            throw new BeanBindException(e);
        }
        
	}
	
	SessionConfiguration getConfiguration() {
		return SessionConfiguration.getInstance();
	}
	
	public void insert(Object o) {
		if ( o instanceof SessionAware ) {
			_sessionAwareObjects.add((SessionAware)o);
		} else {
			addToCache(o);
			if ( !_pendingInsert.contains(o)) {
				_pendingInsert.add(o);			
				merge(o,true,true);
			}
		}
	}

	public void delete(Object o) {
		_pendingDelete.add(o);
	}
	
    /**
     * Updates the given bean in the database, this method should never be called unless
     * an object was modified externally.
     */
    public void update(Object o) {
        if(!_pendingUpdate.contains(o)) {
            _pendingUpdate.add(o);
        }
        merge(o,true,true);
    }
    
    public ORMThread.PropertyListener getPropertyListener() {
		return _propertyListener;
	}
	
	public <T> List<T> fetchAll(Class<T> clazz) {
		return fetchMany(clazz, null);
	}
	
	public <T> T fetchFromCache(Class<T> clazz, Object... keyValues) {
		return (T) _entityCache.get(new CacheEntry( clazz, keyValues ));
	}
	
	public boolean isCached( Object bean ) {
		Object[] keyValues = ((EntityPersister) getConfiguration().getPersister(bean.getClass())).getPrimaryKeyColumnValues(bean);
		return _entityCache.containsKey( new CacheEntry(bean.getClass(), keyValues));
	}

	public void addToCache(Object bean) {
		Object[] keyColumnValues = ((EntityPersister) getConfiguration().getPersister(bean.getClass())).getPrimaryKeyColumnValues(bean);
		_entityCache.put( new CacheEntry(bean.getClass(),keyColumnValues), bean );
	}

    /**
     * Binds the given bean to the persistence layer so it will be batch updated
     * in the background until flush is invoked...
     */
    public void merge(Object o) {
   		merge(o,true,true);
    }

    /**
     * Binds the given bean to the persistence layer so it will be batch updated
     * in the background until flush is invoked...
     */
    public void merge(Object bean, boolean mergeEagerProperties, boolean mergeNonEagerProperties) {
    	
    	if ( bean == null ) {
    		return;
    	}
    	
    	if ( bean instanceof SessionAware ) {
    		_sessionAwareObjects.add((SessionAware)bean);
    	} else {     	
	    	EntityPersister persister = SessionConfiguration.getInstance().getPersister(bean.getClass());
	    	persister.merge(this,bean, mergeEagerProperties, mergeNonEagerProperties, getPropertyListener());
    	}
    	
    }
    
    public void clear() {
    	_sessionAwareObjects.clear();
    	_pendingUpdate.clear();
    	_pendingInsert.clear();
    	_pendingDelete.clear();
    	_entityCache.clear();
    	
    	BeanContainer beanContainer = BeanContainer.get();
    	for( Property property : _observedProperties ) {
    		beanContainer.removeListener(property, _propertyListener);
    	}
    	
    	_observedProperties.clear();
    	
    }
    
    public <T> List<T> select(Class<T> clazz, String whereClause) {
    	return SessionConfiguration.getInstance().getPersister(clazz).select(whereClause);
    }

	
	private class CacheEntry {
		
		private Class _class;
		private Object[] _keyColumnValues;
		
		public CacheEntry(Class clazz, Object[] keyColumnValues) {
			super();
			_class = clazz;
			_keyColumnValues = keyColumnValues;
		}

		@Override
		public int hashCode() {
			final int PRIME = 31;
			int result = 1;
			result = PRIME * result + ((_class == null) ? 0 : _class.hashCode());
			result = PRIME * result + Arrays.hashCode(_keyColumnValues);
			return result;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final CacheEntry other = (CacheEntry) obj;
			if (_class == null) {
				if (other._class != null)
					return false;
			} else if (!_class.equals(other._class))
				return false;
			if (!Arrays.equals(_keyColumnValues, other._keyColumnValues))
				return false;
			return true;
		}
		
	}

	public void flushAndCommit() {
		flush();
		commit();
	}
	
	public void commit() {
		SessionConfiguration.getInstance().connectionFactory.get().commit();
	}
	
	public void close() {
		_sessionContextStrategy.close(this);
		clear();
	}
}
