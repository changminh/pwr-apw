/*
 * SwingComponentFactory.java
 *
 * Created on March 7, 2007, 2:27 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing;

import java.awt.Component;
import java.util.Date;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.binding.ComponentFactory;
import net.java.dev.properties.binding.UIFactory;
import net.java.dev.properties.binding.swing.adapters.SwingBind;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;

/**
 * An implementation of the component factory that creates and binds swing components
 * to properties. This class can be extended and replaced in order to provide
 * a version that creates custom made component types (e.g. MyTextField etc...). 
 *
 * @author Shai Almog
 */
public class SwingComponentFactory extends ComponentFactory<JComponent> {
    /**
     * Default number of columns for JTextFields returned from this class
     */
    public final Property<Integer> defaultTextFieldColumns = new PropertyImpl<Integer>(15);

    /**
     * Default number of rows for JTextArea's returned from this class
     */
    public final Property<Integer> defaultTextAreaRows = new PropertyImpl<Integer>(4);
    
    /** 
     * Creates a new instance of SwingComponentFactory 
     */
    public SwingComponentFactory() {
        BeanContainer.bind(this);
        registerType(String.class, JTextField.class);
        registerType(Number.class, JSpinner.class);
        registerType(Date.class, JFormattedTextField.class);
        registerType(Boolean.class, JCheckBox.class);
        registerIndexedTypeMulti(String.class, JList.class);
        registerIndexedTypeMulti(Number.class, JList.class);
        registerIndexedTypeMulti(Date.class, JList.class);
        registerIndexedTypeSingle(String.class, JComboBox.class);
        registerIndexedTypeSingle(Number.class, JComboBox.class);
        registerIndexedTypeSingle(Date.class, JComboBox.class);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public JComponent createComponentFallback(PropertyContext propertyContext, PropertyContext selection, boolean indexed, boolean multiSelection) {
        if(indexed) {
            return new JTable();
        }
        return new JComboBox();
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void bindContexts(JComponent component, PropertyContext context, PropertyContext selection) {
        component.putClientProperty("PropertyContext", context);
        component.putClientProperty("PropertyContextSelection", selection);
    }
    
    /**
     * Binds a component tree previously created by this API
     */
    public void bindComponentTree(UIFactory<JComponent> factory, Object bean, JComponent component) {
        PropertyContext context = (PropertyContext)component.getClientProperty("PropertyContext");
        if(context != null) {
            PropertyContext selection = (PropertyContext)component.getClientProperty("PropertyContextSelection");
            bindComponent(factory, bean, context, selection, component);
        }
        for(Component cmp : component.getComponents()) {
            if(cmp instanceof JComponent) {
                bindComponentTree(factory, bean, (JComponent)cmp);
            }
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public JComponent createLabel(PropertyContext p, JComponent component) {
        JLabel l = new JLabel();
        SwingBind.get().bindLabel(p, l, component);
        return l;
    }

    /**
     * @inheritDoc
     */
    @Override
    public void bindComponent(UIFactory<JComponent> factory, BaseProperty property, BaseProperty selection, JComponent component) {
        if(component instanceof JTable) {
            BeanContext ctx = BeanContainer.get().getContext(property.getContext().getType());
            SwingBind.get().bindContent((IndexedProperty)property, (JTable)component, factory.getPropertiesArray(ctx));
        } else {
            SwingBind.get().bindGeneric(property, selection, component);
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public void unbindComponent(JComponent component) {
        SwingBind.get().unbind(component);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void unbindComponentTree(JComponent component) {
        unbindComponent(component);
        for(Component cmp : component.getComponents()) {
            if(cmp instanceof JComponent) {
                unbindComponentTree((JComponent)cmp);
            }
        }
    }
    
    /**
     * Overriden to correct a few minor defaults that are broken such as the fact
     * that a checkbox is opaque by default.
     */
    @Override
    public JComponent createComponent(PropertyContext propertyContext, PropertyContext selection) {
        JComponent retValue = super.createComponent(propertyContext, selection);
        if(retValue instanceof JCheckBox) {
            retValue.setOpaque(false);
            return retValue;
        } 
        if(retValue instanceof JTextField) {
            ((JTextField)retValue).setColumns(defaultTextFieldColumns.get());
            return retValue;
        } 
        if(retValue instanceof JTextArea) {
            ((JTextArea)retValue).setColumns(defaultTextFieldColumns.get());
            ((JTextArea)retValue).setRows(defaultTextAreaRows.get());
            return retValue;            
        }
        return retValue;
    }


    /**
     * This implementation can be overriden by sublasses to implement sorting etc.
     */
    protected int rowToModel(JTable t, int row) {
        return row;
    }

    /**
     * This interface allows code to bind manually to a specific property
     * rather than allow the automated process of tree binding to handle
     * the binding.
     */
    public static interface CustomPropertyBinding extends ComponentFactory.CustomPropertyBinding<JComponent> {
    }
}

