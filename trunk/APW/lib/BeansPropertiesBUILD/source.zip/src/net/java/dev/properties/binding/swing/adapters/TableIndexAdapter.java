/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.BaseProperty;

/**
 * Implements table support for propagating selection UI changes, this class is made
 * public for subclasses in SwingX it is not intended for general use
 *
 * @author Shai Almog
 */
public class TableIndexAdapter extends SwingAdapter<Integer, JTable> implements ListSelectionListener {
    protected void bindListener(BaseProperty<Integer> property, JTable cmp) {
        cmp.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cmp.getSelectionModel().addListSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<Integer> property, JTable cmp) {
        cmp.getSelectionModel().removeListSelectionListener(this);
    }

    protected void updateUI(Integer newValue) {
        if(newValue < 0) {
            getComponent().clearSelection();
        } else {
            getComponent().setRowSelectionInterval(newValue, newValue);
        }
    }            

    public void valueChanged(ListSelectionEvent e) {
        callWhenUIChanged(getComponent().getSelectedRow());
    }

    protected Class getType() {
        return Integer.class;
    }

    protected Class getComponentType() {
        return JTable.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}