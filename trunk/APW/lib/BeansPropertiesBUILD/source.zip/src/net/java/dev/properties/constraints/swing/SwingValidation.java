/*
 * SwingValidation.java
 *
 * Created on March 5, 2007, 2:43 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints.swing;

import java.awt.Component;
import java.awt.Container;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.constraints.ValidationManager;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.PropertyListener;

/**
 * The swing implementation of the ValidationManager
 *
 * @author Shai Almog
 */
public class SwingValidation extends ValidationManager<JComponent> {
    private static final String VALIDATION_TAG = "Validation Marker";
    private static final String VALIDATION_LISTENER = "Validation Listener";
    private static SwingValidation instance;
    
    protected SwingValidation() {
        notice.set(new LayeredPaneIconNotice());
    }

    /**
     * @inheritDoc
     */
    @Override
    public void setComponentValidity(final BaseProperty prop, JComponent component, boolean value) {
        Boolean b = (Boolean)component.getClientProperty(VALIDATION_TAG);
        if(b == null || b.booleanValue() != value) {
            component.putClientProperty(VALIDATION_TAG, value);
            PropertyListener listener = findListener(component);
            if(listener != null) {
                if(prop instanceof RProperty) {
                    listener.propertyChanged(prop, "", ((RProperty)prop).get(), 0);
                } else {
                    listener.propertyChanged(prop, "", "", 0);
                }
            }
            String message = "";
            if(prop instanceof RProperty) {
                message = prop.getContext().getValidationMessage(prop, ((RProperty)prop).get());
            }
            notice.get().updateValidationStatus(prop, component, value, message);
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public void refreshComponentValidity(BaseProperty prop, JComponent component, boolean value, String message) {
        Object p = component.getClientProperty("Property");
        if(p == prop) {
            bindValidation(message, value, component, prop);
            return;
        }
        p = component.getClientProperty("SelectionProperty");
        if(p == prop) {
            bindValidation(message, value, component, prop);
            return;
        }
        
        // iterate over the components and look for the component matching this property
        for(Component comp : component.getComponents()) {
            if(comp instanceof JComponent) {
                refreshComponentValidity(prop, (JComponent)comp, value, message);
            }
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    protected PropertyListener getListener(JComponent cmp) {
        return (PropertyListener)cmp.getClientProperty(VALIDATION_LISTENER);
    }

    private void bindValidation(String message, boolean value, JComponent component, BaseProperty prop) {
        java.lang.Boolean b = (java.lang.Boolean) component.getClientProperty(VALIDATION_TAG);
        if (b == null || b.booleanValue() != value) {
            // TODO: is this still necessary?
            findListener(component);
            notice.get().updateValidationStatus(prop, component, value, message);
        }
    }

    /**
     * Finds the listener hiding within the client property
     */
    private PropertyListener findListener(JComponent cmp) {
        PropertyListener l = (PropertyListener)cmp.getClientProperty(VALIDATION_LISTENER);
        if(l != null) {
            return l;
        }
        Container c = cmp.getParent();
        if(c != null && c instanceof JComponent) {
            return findListener((JComponent)c);
        }
        return null;
    }
    
    public static SwingValidation getInstance() {
        if(instance == null) {
            instance = new SwingValidation();
        }
        return instance;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    protected void setEnabled(JComponent component, boolean enabled) {
        component.setEnabled(enabled);
    }

    /**
     * @inheritDoc
     */
    @Override
    protected void registerInterest(JComponent parentComponent, PropertyListener listener) {
        parentComponent.putClientProperty(VALIDATION_LISTENER, listener);
    }

    /**
     * @inheritDoc
     */
    @Override
    public void trackIndexedValidity(final IndexedProperty indexed, final JComponent component) {
        ListSelectionModel selectionModel;
        if(component instanceof JTable) {
            selectionModel = ((JTable)component).getSelectionModel();
        } else {
            if(component instanceof JList) {
                selectionModel = ((JList)component).getSelectionModel();
            } else {
                // no other options supported at the moment...
                return;
            }
        }
        final PropertyListener l = new PropertyListener() {
            /**
             * The list of invalid bean 
             */
            private Map<BaseProperty, Integer> invalids = new HashMap<BaseProperty, Integer>();
            
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                boolean val = prop.getContext().validate(prop, newValue);
                String message = "";
                if(index < 0) {
                    if(component instanceof JTable) {
                        index = ((JTable)component).getSelectedRow();
                    }
                }
                if(val) {
                    invalids.remove(prop);
                    if(invalids.size() > 0) {
                        BaseProperty p = invalids.keySet().iterator().next();
                        message = p.getContext().getValidationMessage(p);
                    }
                } else {
                    if(!invalids.containsKey(prop)) {
                        invalids.put(prop, index);
                    }
                    message = prop.getContext().getValidationMessage(prop, newValue);
                }
                component.putClientProperty("InvalidMap", invalids);
                refreshComponentValidity(indexed, component, 
                    invalids.size() == 0, 
                    message);
            }
        };
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            /**
             * The last selected bean
             */
            private Object bean;
            private int lastIndex = -1;
            public void valueChanged(ListSelectionEvent e) {
                int index = ((ListSelectionModel)e.getSource()).getLeadSelectionIndex();
                if(lastIndex == index) {
                    return;
                }
                lastIndex = index;
                
                if(bean != null) {
                    BeanContainer.get().removeListener(bean, l);
                }
                if(index > -1) {
                    bean = indexed.get(index);
                } else {
                    bean = null;
                    return; 
                }
                registerInterest(component, l);
                BeanContainer.get().addListener(bean, l);
                refreshBeanComponentValidity(bean, component);        
            }
        });
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean isComponentValid(JComponent component) {
        Boolean b = (Boolean)component.getClientProperty(VALIDATION_TAG);
        if(b != null && (!b.booleanValue())) {
            return false;
        }
        
        // traverse the component tree and seek components marked as invalid
        for(Component currentCmp : component.getComponents()) {
            if(currentCmp instanceof JComponent) {
                JComponent jcmp = (JComponent)currentCmp;
                b = (Boolean)jcmp.getClientProperty(VALIDATION_TAG);
                if(b != null && (!b.booleanValue())) {
                    return false;
                }
                if(!isComponentValid(jcmp)) {
                    return false;
                }
            }
        }
        return true;
    }
    
    
}
