/*
 * StudentBean.java
 *
 * Created on March 7, 2007, 10:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.mirror;

import java.util.Date;

/**
 * A bean representing a student in the yoga studio demo application
 *
 * @author Shai Almog
 */
public class StudentBean implements java.io.Serializable {
    private String firstName = "";

    private String surname = "";

    private Boolean male;
    
    private String street;
    
    private String streetNumber;
    private String city;
    private String phone;
    private String mobile;
    private String eMail;
    
    private Date birthDay;
    private String comment;
    private Boolean active;
    
    /** Creates a new instance of StudentBean */
    public StudentBean() {
    }

    /** Creates a new instance of StudentBean */
    public StudentBean(String name, String surname) {
        setFirstName(name);
        this.setSurname(surname);
    }
    
    public String toString() {
        return getFirstName() + " " + getSurname();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Boolean getMale() {
        return male;
    }

    public void setMale(Boolean male) {
        this.male = male;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getStreetNumber() {
        return streetNumber;
    }

    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEMail() {
        return eMail;
    }

    public void setEMail(String eMail) {
        this.eMail = eMail;
    }

    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}
