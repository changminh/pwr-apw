package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author Glen Marchesani
 */
public class LongHandler extends PrimitiveTypeHandler<Long> {

	public LongHandler() {
		super(Long.class,Types.BIGINT);		
	}

	public Long get( ResultSet resultSet, int offset) throws SQLException {
		return resultSet.getLong(offset);
	}

	public void initPreparedStatmentImpl(Long value, PreparedStatement preparedStatement, int offset) throws SQLException {
		preparedStatement.setLong(offset, value);		
	}

}
