/*
 * SQLOperators.java
 * 
 * Created on Aug 18, 2007, 10:49:10 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.java.dev.properties.jdbc;

public enum SQLOperators {
    EQUAL("="), 
    IS_NULL("IS NULL"), 
    NOT_NULL("NOT NULL"), 
    GREATER_THAN(">"), 
    SMALLER_THAN("<"), 
    GREATER_EQUAL(">="), 
    SMALLER_EQUAL("<="), 
    NOT_EQUAL("=") {
        String apply(String column) {
            return "NOT " + super.apply(column);
        }
    };
    private String value;

    SQLOperators(String value) {
        this.value = value;
    }

    String apply(String column) {
        return column + " " + value + " ? ";
    }
}

