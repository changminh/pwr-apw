/*
 * PropertyWrapper.java
 *
 * Created on April 5, 2007, 8:53 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import net.java.dev.properties.container.PropertyContext;

/**
 * This class simplifies the use case of wrapping a property within another
 * in order to override some but not all functionality. It has concrete inner
 * classes for Read/Write and ReadWrite. The use case is mostly for overriding
 * properties in a base class or another class (e.g. delegate, composite):
 * <pre>
 * class Base {
 *   public final Property&lt;Integer&gt; i = new PropertyImpl&lt;Integer&gt;();
 *
 *   public Property&lt;Integer&gt; i() {
 *       return i;
 *   }
 * }
 *
 * class SubClass {
 *   public Property&lt;Integer&gt; i() {
 *       return new PropertyWrapper<Integer>.ReadWrite(i) {
 *          public Integer get() {
 *             // my custom code here...
 *          }
 *       };
 *   }
 * }
 * </pre>
 *
 * @param T The type of the wrapper, the internal type of the property
 * @author Shai Almog
 */
public class PropertyWrapper<T> implements BaseProperty<T> {
    private BaseProperty[] properties;
    
    
    /** 
     * Creates a new instance of PropertyWrapper 
     * 
     * @param properties being wrapped, the first property gets elements delegated
     *  to it. The others are only useful for internal implementation purposes.
     */
    public PropertyWrapper(BaseProperty... properties) {
        this.properties = properties;
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> PropertyWrapper<K> create(BaseProperty... properties) {
        return new PropertyWrapper<K>(properties);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public Object getParent() {
        return properties[0].getParent();
    }

    /** 
     * Returns the properties wrapped by this wrapper. In theory many properties
     * can be wrapped by a single property e.g. fullName would wrap both givenName and surname.
     */
    public BaseProperty[] getProperties() {
        return properties;
    }
 
    /** 
     * Simplified method to return the first property in the getProperties array
     */
    public BaseProperty<?> getProperty() {
        return properties[0];
    }

    /**
     * @inheritDoc
     */
    @Override
    public PropertyContext getContext() {
        return properties[0].getContext();
    }

    public String toString() {
        return properties[0].toString();
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void setParent(Object parent) {
        properties[0].setParent(parent);
    }

    /**
     * @inheritDoc
     */
    @Override
    public void setContext(PropertyContext context) {
        properties[0].setContext(context);
    }
    
    /**
     * Read only version of the property wrapper class
     */
    public static class Read<T> extends PropertyWrapper<T> implements RProperty<T> {
        /** 
         * Creates a new instance of PropertyWrapper 
         * 
         * @param property being wrapped, the first property gets elements delegated
         *  to it. The others are only useful for internal implementation purposes.
         */
        public Read(BaseProperty<T>... property) {
            super(property);
        }
        
        /**
         * @inheritDoc
         */
        public T get() {
            return ((RProperty<T>)getProperty()).get();
        }
        
        /**
         * @inheritDoc
         */
        public String toString() {
            return getContext().getName() + " = " + get();
        }
    }

    /**
     * Write only version of the property wrapper class
     */
    public static class Write<T> extends PropertyWrapper<T> implements WProperty<T> {
        /** 
         * Creates a new instance of PropertyWrapper 
         * 
         * @param property being wrapped, the first property gets elements delegated
         *  to it. The others are only useful for internal implementation purposes.
         */
        public Write(BaseProperty<T>... property) {
            super(property);
        }
        
        /**
         * @inheritDoc
         */
        public void set(T t) {
            ((WProperty<T>)getProperty()).set(t);
        }
    }

    /**
     * Read/Write version of the property wrapper class
     */
    public static class ReadWrite<T> extends Read<T> implements Property<T> {
        /** 
         * Creates a new instance of PropertyWrapper 
         * 
         * @param property being wrapped, the first property gets elements delegated
         *  to it. The others are only useful for internal implementation purposes.
         */
        public ReadWrite(BaseProperty<T>... property) {
            super(property);
        }
        
        /**
         * @inheritDoc
         */
        public void set(T t) {
            ((WProperty<T>)getProperty()).set(t);
        }
    }
}
