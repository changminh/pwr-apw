package net.java.dev.properties.container;

import net.java.dev.properties.MapPropertyImpl;
import java.util.Map;
import net.java.dev.properties.*;
import net.java.dev.properties.events.PropertyListener;

/**
 * The observable version of the map property
 *
 * @author Shai Almog
 */
public class ObservableMap<K, T> extends MapPropertyImpl<K, T> implements ObservableInterface {    
    private final ObservableDelegate<PropertyListener> delegate = new ObservableDelegate<PropertyListener>();

    public ObservableMap() {
    }

    public ObservableMap(Map<K, T> l) {
        super(l);
    }
    
    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K, T> ObservableMap<K, T> create() {
        return new ObservableMap<K, T>();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K, T> ObservableMap<K, T> create(Map<K, T> l) {
        return new ObservableMap<K, T>(l);
    }


    /**
     * @inheritDoc
     */
    @Override
    public void set(K key, T t) {
        super.set(key, t);
        getContext().onInsert(this, getParent(), key, t);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void remove(K key) {
        get().remove(key);
        getContext().onRemove(this, getParent(), key);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<PropertyListener> getDelegate() {
        return delegate;
    }
}
