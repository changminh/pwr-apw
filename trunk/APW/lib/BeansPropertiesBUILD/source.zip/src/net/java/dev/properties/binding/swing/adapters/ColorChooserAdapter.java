/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.awt.Color;
import javax.swing.JColorChooser;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements color chooser support for propagating UI changes
 *
 * @author Shai Almog
 */
class ColorChooserAdapter extends SwingAdapter<Color, JColorChooser> implements ChangeListener {
    protected void bindListener(BaseProperty<Color> property, JColorChooser cmp) {
        cmp.getSelectionModel().addChangeListener(this);
    }

    protected void unbindListener(BaseProperty<Color> property, JColorChooser cmp) {
        cmp.getSelectionModel().removeChangeListener(this);
    }

    protected void updateUI(Color newValue) {
        getComponent().setColor(newValue);
    }            

    public void stateChanged(ChangeEvent e) {
        callWhenUIChanged(getComponent().getColor());
    }    

    protected Class getType() {
        return Color.class;
    }

    protected Class getComponentType() {
        return JColorChooser.class;
    }    
}