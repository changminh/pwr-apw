/*
 * ObservableInterface.java
 *
 * Created on March 5, 2007, 9:26 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import net.java.dev.properties.events.PropertyListener;

/**
 * Every observable property must implement this interface, it delegates the handling
 * of listener to an internal container class thus simplifying the process of writing
 * a property.
 *
 * @author Shai Almog
 */
public interface ObservableInterface {
    public ObservableDelegate<PropertyListener> getDelegate();
}
