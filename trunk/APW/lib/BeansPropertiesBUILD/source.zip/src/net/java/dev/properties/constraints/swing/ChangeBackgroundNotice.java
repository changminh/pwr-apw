/*
 * ChangeBackgroundNotice.java
 *
 * Created on March 6, 2007, 1:17 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints.swing;

import java.awt.Color;
import javax.swing.JComponent;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.constraints.ValidationNotice;

/**
 * An implementation of validation notice that changes the background to a color
 * that indicates invalid.
 *
 * @author Shai Almog
 */
public class ChangeBackgroundNotice implements ValidationNotice<JComponent> {
    private Color invalidColor;
    private static final String ORIGINAL_COLOR = "Original Color";
    
    /** Creates a new instance of ChangeBackgroundNotice */
    public ChangeBackgroundNotice() {
        this(new Color(255, 128, 128, 128));
    }

    public ChangeBackgroundNotice(Color invalidColor) {
        this.invalidColor = invalidColor;
    }

    /**
     * @inheritDoc
     */
    @Override
    public void updateValidationStatus(BaseProperty property, JComponent component, boolean valid, String message) {
        Color current = component.getBackground();
        if(valid) {
            if(current == invalidColor) {
                component.setBackground((Color)component.getClientProperty(ORIGINAL_COLOR));
            }
        } else {
            if(current != invalidColor) {
                component.putClientProperty(ORIGINAL_COLOR, current);
                component.setBackground(invalidColor);
            }
        }
    }
}
