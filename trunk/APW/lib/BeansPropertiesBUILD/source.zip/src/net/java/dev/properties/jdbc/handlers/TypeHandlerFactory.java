package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.jdbc.EntityPersister;

/**
 * @author Glen Marchesani
 */

public class TypeHandlerFactory {

	private List<TypeHandler> _handlers = new ArrayList<TypeHandler>();

	private Map<Class, TypeHandler> _resolvedHandlers = Collections.synchronizedMap(new HashMap<Class, TypeHandler>());

	{
		_handlers.add(new BooleanHandler());
		_handlers.add(new ByteHandler());
		_handlers.add(new CharacterHandler());
		_handlers.add(new DoubleHandler());
		_handlers.add(new FloatHandler());
		_handlers.add(new IntegerHandler());
		_handlers.add(new JavaDotSqlDotDateHandler());
		_handlers.add(new JavaDotSqlDotTimeHandler());
		_handlers.add(new LongHandler());
		_handlers.add(new ShortHandler());
		_handlers.add(new StringHandler());
	}

	public void add(TypeHandler handler) {
		_handlers.add(handler);
	}

        
	public <T> TypeHandler<T> createHandlerForPropertyContext(EntityPersister entityPersister, Class beanType,PropertyContext context) {
		Class type = context.getType();
		Class fieldType = context.getField().getType();
		TypeHandler typeHandler = _resolvedHandlers.get(type);

		if ( context.getTypeHandler() != null ) {
			try {
				typeHandler = context.getTypeHandler().newInstance();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
			
		} else if (context.isIndexedProperty()) {
			typeHandler = new ManyEntityHandler();

		} else if (typeHandler == null) {
			for (TypeHandler handler : _handlers) {
				if (handler.canHandleType(type)) {
					_resolvedHandlers.put(type, handler);
					typeHandler = handler;
					break;
				}
			}
			if (typeHandler == null) { // check for an @Handler annotation that
				// specifies the handler for the type
				Column column = (Column) type.getAnnotation(Column.class);
				if (column != null
						&& !column.typeHandler().equals(TypeHandler.class)) {
					try {
						typeHandler = column.typeHandler().newInstance();
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				}

				// see if there is a bean context with a type handler for the type
				BeanContext beanContextForType = BeanContainer.get().getContext(type);
				if ( beanContextForType != null && beanContextForType.getTypeHandler() != null ) {
					try {
						typeHandler = beanContextForType.getTypeHandler().newInstance();
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				}

				// check for a fallback handler such as a base class for a
				// persistent
				// entity
				if (typeHandler == null) {
					for (TypeHandler h : _handlers) {
						if (h.canHandleTypeFallback(type)) {
							_resolvedHandlers.put(type, h);
							typeHandler = h;
							break;
						}
					}
				}
			}
		}

		if (typeHandler == null) {
			throw new RuntimeException("no handler found for " + type.getName());
		}

		if (typeHandler instanceof CloneableTypeHandler) {
			typeHandler = ((CloneableTypeHandler) typeHandler).clone();
		} else {

			try {
				typeHandler = typeHandler.getClass().newInstance();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}

		BeanContext beanContext = BeanContainer.get().getContext(beanType);

		if ( typeHandler instanceof LifecycleAwareTypeHandler ) {
			LifecycleAwareTypeHandler fith = (LifecycleAwareTypeHandler) typeHandler;
			fith.setBeanContext(beanContext);
			fith.setPropertyContext(context);
			fith.setHandlerFactory(this);
			fith.setParentEntityPersister(entityPersister);
			fith.activated();
		}

		Iterator<ColumnContext> columnIterator = typeHandler.getColumns().iterator();
		if (context.getColumnSuffix().length() > 0) {
			String prefix = beanContext.getTablePrefix();
			for (String columnSuffix : context.getColumnSuffix().split(",")) {
				columnIterator.next().setName(prefix + columnSuffix.trim());
			}
		} else {
			if (context.getColumnName().length() > 0) {
				for (String columnName : context.getColumnName().split(",")) {
					if (columnIterator.hasNext()) {
						columnIterator.next().setName(columnName.trim());
					}
				}
			}
		}

		return typeHandler;

	}

}
