/*
 * YogaClass.java
 *
 * Created on March 7, 2007, 11:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.studio;

import net.java.dev.properties.BaseBean;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Bean;
import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.annotations.NotNull;
import net.java.dev.properties.annotations.Range;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;

/**
 *
 * @author Shai Almog
 */
@Bean(resourceBundle="net.java.dev.properties.test.binding.studio.resources", localize=true)
public class YogaClassBean implements java.io.Serializable {
    public final IndexedProperty<StudentBean> regulars = ObservableIndexed.create();
    
    @NotNull
    @Range(min=1, max=7)
    public final Property<Byte> dayOfWeek = ObservableProperty.create((byte)1);
    
    /**
     * Time in minutes within the day
     */
    @NotNull
    @Range(min=0, max=1440)
    @Column(name="TIME_COLUMN")
    public final Property<Integer> time = ObservableProperty.create();
    
    public final Property<Boolean> active = ObservableProperty.create(true);
    
    /** Creates a new instance of YogaClass */
    public YogaClassBean() {
        BeanContainer.bind(this);
    }    

    public String toString() {
        return getDOW(dayOfWeek.get()) + " " + getTime(time.get());
    }

    private static final String[] DOW = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    public static String getDOW(Object value) {
        if(value == null) return "";
        int day = ((Number)value).intValue();
        day--;
        day = Math.max(Math.min(day, 6), 0);
        return DOW[day];
    }

    public static String getTime(Object value) {
        if(value == null) return "";
        int minutes = ((Number)value).intValue();
        int hours = minutes / 60;
        minutes %= 60;
        if(minutes < 10) {
            return hours + ":0" + minutes;
        }
        return hours + ":" + minutes;
    }

}
