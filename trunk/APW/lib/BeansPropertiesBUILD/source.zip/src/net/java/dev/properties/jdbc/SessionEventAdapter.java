package net.java.dev.properties.jdbc;

public class SessionEventAdapter implements SessionEventListener {

	public void postDelete(Object o) {
	}

	public void postInsert(Object o) {
	}

	public void postUpdate(Object o) {
	}

	public void preDelete(Object o) {
	}

	public void preInsert(Object o) {
	}

	public void preUpdate(Object o) {
	}
	
	public void onLoad(Object o) {
	}

}
