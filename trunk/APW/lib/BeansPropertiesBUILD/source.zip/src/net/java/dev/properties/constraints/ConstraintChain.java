/*
 * NotNullConstraint.java
 *
 * Created on February 22, 2007, 9:45 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

import java.util.HashMap;
import java.util.Map;
import net.java.dev.properties.BaseProperty;

/**
 * A constraint chain allows us to define a set of constraints all of which 
 * must pass in order for the constraint chain to pass.
 *
 * @author Shai Almog
 */
public class ConstraintChain implements Constraint<Object> {
    private Map<Constraint, String> map = new HashMap<Constraint, String>();

    public ConstraintChain() {
    }
    
    /**
     * Adds a constraint to the chain
     */
    public void addConstraint(Constraint c, String message) {
        map.put(c, message);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public boolean validate(BaseProperty prop, Object value) {
        for(Constraint c : map.keySet()) {
            if(!c.validate(prop, value)) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Returns the error message for constraint failure on the given property
     */
    public String getFailedMessage(BaseProperty prop, Object value) {
        for(Map.Entry<Constraint, String> e : map.entrySet()) {
            if(!e.getKey().validate(prop, value)) {
                return e.getValue();
            }
        }
        return null;
    }
    
    /**
     * Returns the instance of the constraint of the given type
     */
    public Constraint getInstance(Class<? extends Constraint> constraint) {
        for(Constraint c : map.keySet()) {
            if(constraint.isAssignableFrom(c.getClass())) {
                return c;
            }
        }
        return null;
    }
}
