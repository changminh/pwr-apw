/*
 * PersistentId.java
 * 
 * Created on Aug 24, 2007, 11:29:36 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.java.dev.properties.test.demos.orm;

import net.java.dev.properties.Property;

/**
 * Useful interface to distinguish beans
 * 
 * @author Shai Almog
 */
public interface PersistentId {
    public Property<Integer> id();
}
