package net.java.dev.properties.test.demos;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.Mirror;
import net.java.dev.properties.container.MirrorContext;
import net.java.dev.properties.events.PropertyListener;
import net.java.dev.properties.test.DemoInterface;

/**
 * A demo of using the mirror bean approach to encapsulate a legacy bean
 *
 * @author shai
 */
public class MirrorBeanDemo extends DemoInterface.DefaultConsoleDemo {
    public MirrorBeanDemo() {
        super("Mirror Bean", "<html><body><h1>Mirror Beans</h1>" +
                "Mirror bean allows us to view a legacy bean as if it is <b>a new " +
                "bean without changing a single line of code</b>. Mirrors don't have some of the " +
                "advantages of the new beans (such as compile time safety) but they do allow us " +
                "to take advantage of the dynamic nature of the bean providing full observability " +
                "etc. useful for features such as binding/ORM/XML. The mirror objects can be used seamlessly " +
                "in binding and other similar API's.<br>" +
                "An interesting thing to notice in this demo, is that we created a brand new bean that " +
                "isn't observable... Yet the mirror is observable by copying. This allows you to <b>mirror " +
                "\"true\" POJO's</b> without forcing you to implement all the add/removePropertyChangeListener " +
                "methods and their corresponding fire methods! This is far easier to use than JSR 295 which " +
                "requires observability for all of its (so called) POJO's.",
                new Class[] {MirrorBeanDemo.class, LegacyPOJO.class});
    }

    public void run() {
        LegacyPOJO bean = new LegacyPOJO();
        Mirror beanMirror = MirrorContext.createStatic(bean);
        bean.setX(1);
        getOutput().println("Legacy POJO x is: " + bean.getX());
        getOutput().println("Mirror x is: " + beanMirror.getProperty("x"));
        beanMirror.update();
        
        // notice that a mirror can't recive events from the bean but can send updates
        // to the bean. If the bean implements property change listener the mirror can
        // be instructed to use it.
        getOutput().println("Mirror x after update is: " + beanMirror.getProperty("x"));
        
        PropertyListener l = new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
               getOutput().println("Mirror " + prop.getContext().getName() + " was changed " + newValue);
            }
        };
        
        BeanContainer.get().addListener(beanMirror, l);
        beanMirror.set("x", 2);
        getOutput().println("POJO bean after setting x through mirror is: " + bean.getX());
        
        BeanContainer.get().removeListener(beanMirror, l);
        BeanContainer.get().addListener(beanMirror.getProperty("x"), l);
        beanMirror.set("x", 3);
    }
}
