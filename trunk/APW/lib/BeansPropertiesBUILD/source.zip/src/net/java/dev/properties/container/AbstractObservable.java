/*
 * AbstractObservable.java
 *
 * Created on February 26, 2007, 7:56 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.events.PropertyListener;

/**
 * An observable property that doesn't include a state, this allows a property
 * to map to data that is held outside of the bean thus making the internal
 * variable unnecessary. However implementing BaseProperty might be tiresom
 * since it requires handling a context, and monitoring the parent. This is 
 * handled by this API which further exposes fire change methods to simplify
 * observability.
 * <p>In order to allow read only/write only and ReadWrite implementations of this
 * class it was refactored to include the appropriate subclasses as static inner
 * classes
 *
 * @author Shai Almog
 */
public abstract class AbstractObservable<T> implements BaseProperty<T>, java.io.Serializable, ObservableInterface {    
    private final ObservableDelegate<PropertyListener> delegate = new ObservableDelegate<PropertyListener>();

    private PropertyContext context;
    private Object parent;
    
    /** Creates a new instance of AbstractObservable */
    public AbstractObservable() {
    }

    /**
     * For easier firing of events for the property
     */
    public void firePropertyChanged(Object oldValue, Object newValue) {
        // if this is null then its probable that the bean was not bound!
        context.onChange(this, parent, oldValue, newValue, -1);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public PropertyContext getContext() {
        return context;
    }
    /**
     * @inheritDoc
     */
    @Override
    public void setContext(PropertyContext context) {
        this.context = context;
    }

    /**
     * @inheritDoc
     */
    @Override
    public Object getParent() {
        return parent;
    }

    /**
     * @inheritDoc
     */
    @Override
    public void setParent(Object parent) {
        this.parent = parent;
    }

    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<PropertyListener> getDelegate() {
        return delegate;
    }
    
    /**
     * Readonly version of the abstract observable class
     */
    public static abstract class Read<T> extends AbstractObservable<T> implements RProperty<T> {
        public String toString() {
            return getContext().getName() + " = " + get().toString();
        }
    }

    /**
     * Write only version of the abstract observable class
     */
    public static abstract class Write<T> extends AbstractObservable<T> implements WProperty<T> {
    }

    /**
     * Read/write version of the abstract observable class
     */
    public static abstract class ReadWrite<T> extends AbstractObservable<T> implements Property<T> {
        public String toString() {
            return getContext().getName() + " = " + get().toString();
        }
    }
}
