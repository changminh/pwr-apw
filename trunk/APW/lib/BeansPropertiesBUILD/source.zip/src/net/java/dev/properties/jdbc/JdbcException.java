package net.java.dev.properties.jdbc;

import net.java.dev.properties.container.BeanBindException;

public class JdbcException extends BeanBindException {

	public JdbcException() {
		super();
	}

	public JdbcException(Exception cause) {
		super(cause);
	}

	public JdbcException(String err) {
		super(err);
	}

}
