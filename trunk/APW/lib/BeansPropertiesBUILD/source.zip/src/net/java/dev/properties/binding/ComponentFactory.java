/*
 * ComponentFactory.java
 *
 * Created on March 7, 2007, 1:50 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding;

import java.util.HashMap;
import java.util.Map;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.MapProperty;
import net.java.dev.properties.MapPropertyImpl;

/**
 * This class is used by the UI factory in order to create individual components
 * for beans. Where the UI factory is responsible for layout and assembly this
 * class is responsible for creation and binding.
 *
 * @author Shai Almog
 */
public abstract class ComponentFactory<C> implements java.io.Serializable {
    /**
     * The type registry simplifies the process of creating components to match
     * data types. This map contains the types of properties that might exist
     * and maps to the type of visual components they might relate to.
     */
    private Map<Class, Class> typeRegistry = new HashMap<Class, Class>();
    private Map<Class, Class> indexedTypeSingleRegistry = new HashMap<Class, Class>();
    private Map<Class, Class> indexedTypeMultiRegistry = new HashMap<Class, Class>();

    /**
     * Allows using custom code in the binding process
     */
    private Map<PropertyContext, CustomPropertyBinding<C>> customBind = new HashMap<PropertyContext, CustomPropertyBinding<C>>();
    
    /**
     * Allows overriding the component type created for a particular property context.
     * This maps between a particular context instance and the UI component class.
     */
    public final MapProperty<PropertyContext, Class> overrideCreate = MapPropertyImpl.create();

    /** Creates a new instance of ComponentFactory */
    protected ComponentFactory() {
    }
    
    /**
     * Allows assigning custom binding code for a given property
     */
    public void registerBinding(PropertyContext context, CustomPropertyBinding<C> binding) {
        customBind.put(context, binding);
    }
    
    /**
     * This method defines the simple types used to map a class to a component e.g.
     * Property&lt;String&gt; should map to JTextField so type=String.class and uiClass=
     * JTextField.class
     */
    public void registerType(Class type, Class uiClass) {
        typeRegistry.put(type, uiClass);
    }

    /**
     * See registerType, this version works for indexed types since IndexedProperty&lt;String&gt;
     * should map to a different uiClass than Property&lt;String&gt;.
     */
    public void registerIndexedTypeSingle(Class type, Class uiClass) {
        indexedTypeSingleRegistry.put(type, uiClass);
    }

    /**
     * See registerType, this version works for indexed types since IndexedProperty&lt;String&gt;
     * should map to a different uiClass than Property&lt;String&gt;.
     */
    public void registerIndexedTypeMulti(Class type, Class uiClass) {
        indexedTypeMultiRegistry.put(type, uiClass);
    }

    /**
     * Optionally allows a subclass to return a default when all else fails
     */
    public C createComponentFallback(PropertyContext propertyContext, PropertyContext selection, boolean indexed, boolean multiSelection) {
        return null;
    }
    
    /**
     * Creates a component object to match the given property type
     */
    public C createComponent(PropertyContext propertyContext, PropertyContext selection) {
        Class type = null;
        try {
            boolean indexed = propertyContext.isIndexedProperty();
            boolean multiSelection = selection != null && selection.isIndexedProperty();

            Class componentType = overrideCreate.get(propertyContext);
            if(componentType != null) {
                C obj = (C)componentType.newInstance();
                bindContexts(obj, propertyContext, selection);
                return obj;
            }

            if(customBind.containsKey(propertyContext)) {
                CustomPropertyBinding<C> binding = customBind.get(propertyContext);
                C obj = binding.createComponent(propertyContext);
                bindContexts(obj, propertyContext, selection);
                return obj;
            }
            
            Map<Class, Class> typeRegistry = this.typeRegistry;
            if(indexed) {
                if(multiSelection) {
                    typeRegistry = indexedTypeMultiRegistry;
                } else {
                    typeRegistry = indexedTypeSingleRegistry;
                }
            }
            
            // lookup the class in the registry and return the default component.
            type = propertyContext.getType();
            if(typeRegistry.containsKey(type)) {
                C obj = (C)typeRegistry.get(type).newInstance();
                bindContexts(obj, propertyContext, selection);
                return obj;
            }
            
            // if this isn't a concrete type look for derived types
            for(Class currentType : typeRegistry.keySet()) {
                if(currentType.isAssignableFrom(type)) {
                    C obj = (C)typeRegistry.get(currentType).newInstance();
                    bindContexts(obj, propertyContext, selection);
                    return obj;
                }
            }
            C obj = createComponentFallback(propertyContext, selection, indexed, multiSelection);
            if(obj != null) {
                bindContexts(obj, propertyContext, selection);
                return obj;
            }
        } catch(Exception err) {
            throw new BeanBindException(err);
        }
        throw new BeanBindException("Couldn't bind property type: " + 
            type.getName() + " from property name: " + propertyContext.getName());
    }

    /**
     * Creates a component object to match the given property type
     */
    public abstract void bindComponent(UIFactory<C> factory, BaseProperty property, BaseProperty selection, C component);

    /**
     * Creates a component object to match the given property type
     */
    protected void bindComponent(UIFactory<C> factory, Object bean, PropertyContext property, PropertyContext selection, C component) {
        if(customBind.containsKey(property)) {
            CustomPropertyBinding<C> binding = customBind.get(property);
            binding.bind(bean, property, selection, component);
            return;
        }
        if(selection != null) {
            bindComponent(factory, property.getValue(bean), selection.getValue(bean), component);
        } else {
            bindComponent(factory, property.getValue(bean), null, component);
        }
    }

    /**
     * The oposite of the bind component method
     */
    public abstract void unbindComponent(C component);
    
    /**
     * Associates the given property contexts with the given component so a followup
     * call to bind component tree would work correctly.
     */
    public abstract void bindContexts(C component, PropertyContext context, PropertyContext selection);

    /**
     * Binds a component tree previously created by this API
     */
    public abstract void unbindComponentTree(C component);

    /**
     * Binds a component tree previously created by this API
     */
    public abstract void bindComponentTree(UIFactory<C> factory, Object bean, C component);
    
    /**
     * Creates a label component to match the property component
     */
    public abstract C createLabel(PropertyContext p, C component);
    
    /**
     * This interface allows code to bind manually to a specific property
     * rather than allow the automated process of tree binding to handle
     * the binding.
     */
    public static interface CustomPropertyBinding<C> {
        public C createComponent(PropertyContext p);        
        public void bind(Object bean, PropertyContext property, PropertyContext selection, C comp);
    }
}
