/*
 * Binding.java
 *
 * Created on March 6, 2007, 11:21 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding;

import net.java.dev.properties.constraints.ValidationNotice;

/**
 * The bind manager is the base class for binding implementations providing some
 * common functionality between toolkits. 
 *
 * @author Shai Almog
 */
public abstract class BindManager<C> {
    private ValidationNotice<C> validationNotice;
    
    /**
     * Sets the global validation notice that may be 
     */
    public void setValidationNotice(ValidationNotice<C> notice) {
        validationNotice = notice;
    }
    public ValidationNotice<C> getValidationNotice() {
        return validationNotice;
    }
}
