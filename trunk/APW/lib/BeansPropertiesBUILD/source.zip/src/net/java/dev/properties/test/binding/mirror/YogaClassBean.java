/*
 * YogaClass.java
 *
 * Created on March 7, 2007, 11:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.mirror;

/**
 *
 * @author Shai Almog
 */
public class YogaClassBean implements java.io.Serializable {
    private StudentBean[] regulars;
    private byte dayOfWeek = 1;
    private int time;
    private boolean active = true;
    
    public String toString() {
        return getDOW(getDayOfWeek()) + " " + getTime(getTime());
    }

    private static final String[] DOW = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    public static String getDOW(Object value) {
        if(value == null) return "";
        int day = ((Number)value).intValue();
        day--;
        day = Math.max(Math.min(day, 6), 0);
        return getDOW()[day];
    }

    public static String getTime(Object value) {
        if(value == null) return "";
        int minutes = ((Number)value).intValue();
        int hours = minutes / 60;
        minutes %= 60;
        if(minutes < 10) {
            return hours + ":0" + minutes;
        }
        return hours + ":" + minutes;
    }

    public StudentBean[] getRegulars() {
        return regulars;
    }

    public void setRegulars(StudentBean[] regulars) {
        this.regulars = regulars;
    }

    public byte getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(byte dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public static String[] getDOW() {
        return DOW;
    }

}
