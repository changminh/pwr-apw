/*
 * Property.java
 *
 * Created on February 20, 2007, 9:57 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

/**
 * Provides a base interface for read only properties, properties who only implement
 * this interface and not the WProperty interface cannot be modified externally.
 *
 * @author Shai Almog
 */
public interface RProperty<T> extends BaseProperty<T> {
    /**
     * Returns the value of the property
     */
    public T get();
}
