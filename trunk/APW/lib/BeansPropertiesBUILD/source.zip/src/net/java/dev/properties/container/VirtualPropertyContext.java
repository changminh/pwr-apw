/*
 * VirtualPropertyContext.java
 *
 * Created on March 27, 2007, 6:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import net.java.dev.properties.BaseProperty;

/**
 * A virtual property is a property that is created and strapped in during runtime,
 * the class won't show it but all tools that work with the bean container API
 * would see it as if it were a standard property within the bean. The main use
 * case for such a property is as a field whose usefulness is limited to a given
 * set of tools or customizable in runtime e.g. an "id" property in a bean to match
 * the id field in the database, which is useful only for the persistance aspect but
 * not for the general usage of the bean. 
 * <p>The virtual property is added using the bean context class.
 *
 * @author Shai Almog
 */
public class VirtualPropertyContext extends PropertyContext {
    private boolean indexed;
    private Class<?> type;
    private BeanContext context;
        
    /** Creates a new instance of VirtualPropertyContext */
    public VirtualPropertyContext(String name, boolean indexed, Class<?> type) {
        this.indexed = indexed;
        this.type = type;
        setName(name);
    }

    /** Creates a new instance of VirtualPropertyContext */
    public VirtualPropertyContext(String name, Class<?> type) {
        this(name, false, type);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public boolean isIndexedProperty() {
        return indexed;
    }

    /**
     * @inheritDoc
     */
    @Override
    public Class<?> getType() {
        return type;
    }

    /**
     * @inheritDoc
     */
    @Override
    public BaseProperty getValue(Object bean) {
        if(context == null) {
            context = BeanContainer.get().getContext(bean);
        }
        VirtualPropertyBean virtual = context.getVirtualBean(bean);
        BaseProperty value = virtual.getVirtual(this);
        if(value == null) {
            if(indexed) {
                value = new ObservableIndexed();
            } else {
                value = new ObservableProperty();
            }
            value.setContext(this);
            value.setParent(bean);
            virtual.putVirtual(this, value);
        }
        return value;
    }
}
