/*
 * GUIBean.java
 *
 * Created on February 27, 2007, 7:17 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import javax.swing.*;

/**
 * A simplified bean utilizing GUI features and deriving from the JPanel class 
 * rather that being concrete. This one is for demonstration purposes on how
 * a legacy bean would implement the same features as the NewGUIBean.
 * Notice that the listener implementation just delegates to the underlying
 * listener which sends the wrong source object. 
 *
 * @author Shai Almog
 */
public class OldGUIBean extends JPanel {
    private JLabel content = new JLabel("Test Color");
    
    /** Creates a new instance of GUIBean */
    public OldGUIBean() {
        setLayout(new BorderLayout());
        content.setOpaque(true);
        add(content, BorderLayout.CENTER);
        JPanel buttons = new JPanel();
        JButton btn = new JButton("Foreground");
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setFore(JColorChooser.showDialog(OldGUIBean.this, "Foreground", getFore()));
            }
        });
        buttons.add(btn);
        btn = new JButton("Background");
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setBack(JColorChooser.showDialog(OldGUIBean.this, "Background", getBack()));
            }
        });
        buttons.add(btn);
        add(buttons, BorderLayout.SOUTH);
    }

    public Color getFore() {
        return content.getForeground();
    }

    public void setFore(Color c) {
        content.setForeground(c);
    }

    public void setBack(Color c) {
        content.setBackground(c);
    }
    
    public Color getBack() {
        return content.getBackground();
    }

    public void addPropertyChangeListener(PropertyChangeListener l) {
        content.addPropertyChangeListener(l);
        super.addPropertyChangeListener(l);
    }

    public void addPropertyChangeListener(String s, PropertyChangeListener l) {
        content.addPropertyChangeListener(s, l);
        super.addPropertyChangeListener(s, l);
    }

    public void removePropertyChangeListener(PropertyChangeListener l) {
        content.removePropertyChangeListener(l);
        super.removePropertyChangeListener(l);
    }

    public void removePropertyChangeListener(String s, PropertyChangeListener l) {
        content.removePropertyChangeListener(s, l);
        super.removePropertyChangeListener(s, l);
    }
    
    public static void main(String[] argv) {
        JFrame frm = new JFrame("Test GUIBean");
        NewGUIBean bean = new NewGUIBean();
        frm.getContentPane().add(bean, BorderLayout.CENTER);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.pack();
        frm.setVisible(true);
    }
}
