/*
 * VirtualPropertyBean.java
 *
 * Created on March 28, 2007, 7:35 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import net.java.dev.properties.BaseProperty;

/**
 * This class holds the data regarding the virtual properties for a given bean 
 * instance. Just like a bean context has a 1 to 1 instance relationship with
 * the beans Class instance this class has a 1 to 1 relationship with the bean
 * instance. For every instance of a bean that has virtual properties there
 * is an instance of this class.
 * 
 * @author Shai Almog
 */
class VirtualPropertyBean {
    /**
     * Map containing the values for every property type
     */
    private Map<VirtualPropertyContext, BaseProperty> properties = new HashMap<VirtualPropertyContext, BaseProperty>();

    /**
     * A weak reference to the parent bean, this is really a "reverse" pointer
     * that allows the bean to be GC'd 
     */
    private WeakReference<Object> parentBean;
    
    /**
     * The bean context that holds this virtual property
     */
    private BeanContext parentContext;
    
    /** Creates a new instance of VirtualPropertyBean */
    public VirtualPropertyBean(BeanContext parentContext, Object bean) {
        this.parentContext = parentContext;
        parentBean = new WeakReference<Object>(bean) {
            public boolean enqueue() {
                // when the parent is removed we need to clear the property values
                // too...
                properties = null;
                VirtualPropertyBean.this.parentContext.removeVirtualBean(VirtualPropertyBean.this);
                return super.enqueue();
            }
        };
    }
    
    public Object getParentBean() {
        return parentBean.get();
    }
    
    public BaseProperty getVirtual(VirtualPropertyContext context) {
        return properties.get(context);
    }

    public void putVirtual(VirtualPropertyContext context, BaseProperty p) {
        properties.put(context, p);
    }
}
