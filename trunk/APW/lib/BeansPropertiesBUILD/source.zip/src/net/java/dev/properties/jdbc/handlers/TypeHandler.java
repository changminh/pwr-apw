package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.jdbc.EntityPersister;

/**
 * 
 * A type handler manages mapping a property to one or more database columns.
 * 
 * The factor that created the type handler and the property context that the 
 * handler is responsible for mapping is injected into the type handler via the setContext() and
 * setHandlerFactory() methods
 * 
 * @author Glen Marchesani
 */
public interface TypeHandler<T> {
	
	boolean canHandleType( Class<?> type );

    /**
     * Unlike canHandleType this is a fallback method that will be called if
     * no other type handler can handle the type. This may be useful for a generic
     * handler that can handle a base class of an entity.
     */
    boolean canHandleTypeFallback( Class<?> type );

	void loadProperty( WProperty<T> property, ResultSet resultSet, int resultSetOffset ) throws SQLException;
	void loadPreparedStatment( Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset ) throws SQLException;
	void loadColumnValues( RProperty<T> property, Object[] columnValues, int columnValuesOffset );

	PropertyContext getPropertyContext();
	List<ColumnContext> getColumns();
	
	boolean doesEagerFetching();

}
