/*
 * UIFactory.java
 *
 * Created on March 6, 2007, 6:25 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.Scrollable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.binding.PropertySelectionListener;
import net.java.dev.properties.binding.UIFactory;
import net.java.dev.properties.binding.UIFactory.LabelPlacement;
import net.java.dev.properties.binding.swing.adapters.SwingBind;
import net.java.dev.properties.constraints.ValidationManager;
import net.java.dev.properties.constraints.swing.SwingValidation;
import net.java.dev.properties.container.PropertyContext;

/**
 * The UI factory is a tool that automatically creates a form UI to match a given
 * bean. It uses the properties of the given bean to create fields and entries
 * appropriately and can accept simple hints when needed, all properties are
 * bound and validated transparently. This is mostly useful for form based 
 * applications where the requirements include a great deal of uniform data entry.
 *
 * @author Shai Almog
 */
public abstract class SwingFactory extends UIFactory<JComponent> {
    private static final LabelPlacement<JComponent> none = new LabelPlacement<JComponent>();
    private static SwingComponentFactory defaultFactory = new SwingComponentFactory();
    
    private static final LabelPlacement<JComponent> beside = new LabelPlacement<JComponent>() {
        /**
         * @inheritDoc
         */
        @Override
        public JComponent createLabel(JComponent targetComponent, PropertyContext context) {
            JLabel l = new JLabel();
            SwingBind.get().bindLabel(context, l, targetComponent);
            return l;
        }
    };
    
    private static final LabelPlacement<JComponent> above = new LabelPlacement<JComponent>() {
        /**
         * @inheritDoc
         */
        @Override
        public JComponent createLabel(JComponent targetComponent, PropertyContext context) {
            targetComponent.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(), context.getDisplayName()));
            return null;
        }
    };
    
    private static final LabelPlacement<JComponent> asBorder = new LabelPlacement<JComponent>() {
        /**
         * @inheritDoc
         */
        @Override
        public JComponent createLabel(JComponent targetComponent, PropertyContext context) {
            targetComponent.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), context.getDisplayName()));
            return null;
        }
    };
    
    
    /** Creates a new instance of UIFactory */
    protected SwingFactory() {
        super(defaultFactory);
    }
    
    /**
     * Allows us to override the default component factory with a custom built factory without
     * changing our existing code. This allows us to add support for creating and binding
     * custom component types.
     */
    protected static void setDefaultFactory(SwingComponentFactory factory) {
        defaultFactory = factory;
    }
    
    /**
     * Creates a factory instance with a center layout policy
     */
    public static SwingFactory centerLayoutFactory() {
        return new CenterLayout();
    }

    /**
     * Creates a factory instance with a column layout policy
     * 
     * @param columns number of columns for the layout (considering labels+components as one column)
     */
    public static SwingFactory columnLayoutFactory(int columns) {
        return new ColumnLayout(columns);
    }

    /**
     * Creates a factory instance with a column layout policy, this is more advanced than the columnLayoutFactory
     * since it makes use of a special purpose layout manager that is "smarter" about some edge cases.
     * 
     * @param columns number of columns for the layout (considering labels+components as one column)
     */
    public static SwingFactory customColumnLayoutFactory(int columns) {
        return new CustomColumns(columns, true);
    }
        
    /**
     * Same as the columnLayoutFactory only tries to "balance" the amount of components between
     * the columns more
     * 
     * @param columns number of columns for the layout (considering labels+components as one column)
     */
    public static SwingFactory balancedColumnLayoutFactory(int columns) {
        return new BalancedColumnLayout(columns);
    }
    
    /**
     * Uses the box layout to construct a single column form
     */
    public static SwingFactory boxColumnLayoutFactory() {
        return new BoxColumn();
    }
    
    /**
     * @inheritDoc
     */
    @Override
    protected ValidationManager<JComponent> getValidation() {
        return SwingValidation.getInstance();
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public final void add(JComponent layout, JComponent component, PropertyContext property) {
        if(component instanceof Scrollable && (!(component instanceof JTextField))) {
            addImpl(layout, new JScrollPane(component), property);
        } else {
            addImpl(layout, component, property);
        }
    }

    /**
     * Internal implementation of the add method that can be used by custom factory instances to build
     * a UI.
     */
    protected abstract void addImpl(JComponent layout, JComponent component, PropertyContext property);

    /**
     * @inheritDoc
     */
    @Override
    public void addPropertySelectionListener(final PropertySelectionListener listener, final IndexedProperty property, JComponent component) {
        JComponent bound = SwingBind.get().findComponent(component, property);
        if(bound == null) {
            throw new IllegalArgumentException("Can't find a component bound to " + property.getContext().getName());
        }
        if(bound instanceof JTable) {
            final JTable table = (JTable)bound;
            table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    int[] arr = table.getSelectedRows();
                    rowsToModel(table, arr);
                    listener.selectionChanged(property, arr);
                }
            });
            return;
        }
        if(bound instanceof JList) {
            final JList list = (JList)bound;
            list.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    listener.selectionChanged(property, list.getSelectedIndices());
                }
            });
            return;
        }
        if(bound instanceof JComboBox) {
            final JComboBox combo = (JComboBox)bound;
            combo.addItemListener(new ItemListener() {
                public void itemStateChanged(ItemEvent e) {
                    int index = combo.getSelectedIndex();
                    if(index > -1) {
                        listener.selectionChanged(property, new int[] {index});
                    } else {
                        listener.selectionChanged(property, null);
                    }
                }
            });
            return;
        }
        throw new IllegalArgumentException("Property selection listener can't be bound to this component type");
    }
    
    /**
     * @inheritDoc
     */
    @Override
    protected void bindMasterDetail(JComponent master, final JComponent detail, final IndexedProperty property) {
        componentFactory.get().bindComponentTree(this, property.getParent(), master);
        final JTable t = (JTable)findComponent(JTable.class, master);
        String ver = System.getProperty("java.class.version");
        if(Double.parseDouble(ver) > 49) {
            t.setFillsViewportHeight(true);
        }
        getValidation().trackIndexedValidity(property, t);
        // For some reason this crap clears the selection in the table fucking up
        // everything... No idea???
        /*final PropertyListener tableUpdater = new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                TableAdapterModel model = (TableAdapterModel)t.getModel();
                if(oldValue != newValue) {
                    model.fireSafe(index);
                }
            }
        };*/
        t.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            private Object previousRow = null;
            public void valueChanged(ListSelectionEvent e) {
                // currently only support single selection
                if(previousRow != null) {
                    //BeanContainer.get().removeListener(previousRow, tableUpdater);
                    getValidation().stopTracking(previousRow, detail);
                    componentFactory.get().unbindComponentTree(detail);
                    previousRow = null;
                }
                
                int row = t.getSelectedRow();
                if(row > -1) {
                    row = rowToModel(t, row);
                    if(!detail.isEnabled()) {
                        enableComponentTree(detail, true);
                    }
                    previousRow = property.get(row);
                    componentFactory.get().bindComponentTree(SwingFactory.this, previousRow, detail);
                    //BeanContainer.get().addListener(previousRow, tableUpdater);
                    getValidation().trackValidity(previousRow, detail);
                } else {
                    enableComponentTree(detail, false);
                }
            }
        });
    }
    
    /**
     * Invokes the component factory to map rows in order to allow alternative component
     * factories to generate sortable/filterable tables (e.g. SwingX's JXTable).
     */
    private int rowToModel(JTable t, int row) {
        return ((SwingComponentFactory)componentFactory.get()).rowToModel(t, row);
    }

    /**
     * Invokes rowToModel for every row
     */
    private void rowsToModel(JTable t, int[] rows) {
        for(int iter = 0 ; iter < rows.length ; iter++) {
            rows[iter] = rowToModel(t, rows[iter]);
        }
    }
    
    /**
     * Disables or enables the components within a component tree recursively
     */
    private void enableComponentTree(JComponent cmp, boolean enable) {
        cmp.setEnabled(enable);
        for(Component c : cmp.getComponents()) {
            c.setEnabled(enable);
            if(c instanceof JComponent) {
                enableComponentTree((JComponent)c, enable);
            }
        }
    }
    
    /**
     * Traverses the component tree and finds the given component
     */
    private static JComponent findComponent(Class c, JComponent component) {
        for(Component cmp : component.getComponents()) {
            if(c.isAssignableFrom(cmp.getClass())) {
                return (JComponent)cmp;
            }
            if(cmp instanceof JComponent) {
                JComponent result = findComponent(c, (JComponent)cmp);
                if(result != null) {
                    return result;
                }
            }
        }
        return null;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    protected JComponent combineMasterDetail(JComponent master, JComponent detail) {
        Box b = new Box(BoxLayout.Y_AXIS);
        b.add(master);
        b.add(detail);
        enableComponentTree(detail, false);
        b.setOpaque(false);
        return b;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public LabelPlacement<JComponent> getLabelPalcementNone() {
        return none;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public LabelPlacement<JComponent> getLabelPalcementBeside() {
        return beside;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public LabelPlacement<JComponent> getLabelPalcementAbove() {
        return above;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public LabelPlacement<JComponent> getLabelPalcementAsBorder() {
        return asBorder;
    }

    /**
     * Creates the label for the given property/component pair based on the placement rules.
     * This method can be overloaded by subclasses to create more elaborate labels and 
     * mnemonics.
     */
    protected JComponent createLabel(JComponent component, PropertyContext property) {
        return getPlacement(property).createLabel(component, property);
    }
    
    /**
     * Implements the column layout
     */
    static class ColumnLayout extends SwingFactory {
        private int columns;
        private GridBagConstraints constraints = new GridBagConstraints();
        private int elements;
        private int offset = 0;
        private Insets labelInsets = new java.awt.Insets(1, 4, 1, 4);
        private Insets componentInsets = new java.awt.Insets(1, 1, 1, 1);
        
        /**
         * creates an instance for the given number of columns
         */
        public ColumnLayout(int columns) {
            // number is multiplied for the sake of the labels
            this.columns = columns * 2;
            constraints.fill = GridBagConstraints.HORIZONTAL;
            constraints.anchor = GridBagConstraints.PAGE_START;
        }
        
        /**
         * @inheritDoc
         */
        @Override
        public JComponent createLayout(int elements) {
            if(elements % columns != 0) {
                elements += elements % columns;
            }
            this.elements = elements;
            JPanel p = new JPanel(new GridBagLayout());
            p.setOpaque(false);
            return p;
        }

        /**
         * @inheritDoc
         */
        @Override
        protected void addImpl(JComponent layout, JComponent component, PropertyContext property) {
            constraints.gridx = offset / (elements / (columns / 2)) * 2;
            constraints.gridy = offset % (elements / (columns / 2));
            constraints.insets = labelInsets;
            constraints.weightx = 0;
            JComponent label = createLabel(component, property);
            if(label != null) {
                constraints.gridwidth = 1;
                layout.add(label, constraints);        
                constraints.gridx++;
            } else {
                constraints.gridwidth = 2;
            }
            constraints.insets = componentInsets;
            constraints.weightx = 1;
            layout.add(component, constraints);
            offset++;
        }
    }

    /**
     * This is a simple layout that works as a single column based on the box layout
     */
    static class BoxColumn extends SwingFactory {
        private List<JComponent> labels = new ArrayList<JComponent>();
        protected void addImpl(JComponent layout, JComponent component, PropertyContext property) {
            if(component instanceof JTextField) {
                Dimension d = component.getMaximumSize();
                d.height = component.getPreferredSize().height;
                component.setMaximumSize(d);
            }
            layout.add(Box.createVerticalStrut(3));
            Box pair = new Box(BoxLayout.LINE_AXIS);
            pair.setOpaque(false);
            JComponent label = createLabel(component, property);
            if(label != null) {
                pair.add(label);
                labels.add(label);
                pair.add(Box.createHorizontalStrut(5));
            }
            pair.add(component);
            pair.setAlignmentX(0);
            layout.add(pair);
        }

        public JComponent createLayout(int elements) {
            Box b = new Box(BoxLayout.Y_AXIS);
            b.setOpaque(false);
            return b;
        }

        public JComponent finishLayout(JComponent layout) {
            int maxWidth = 0;
            for(JComponent cmp : labels) {
                maxWidth = Math.max(maxWidth, cmp.getPreferredSize().width);
            }
            for(JComponent cmp : labels) {
                Dimension d = cmp.getPreferredSize();
                d.width = maxWidth;
                cmp.setPreferredSize(d);
            }            
            return layout;
        }
    }
    
    /**
     * Unlike the column layout this layout balances the columns not based on 
     * a count of elements but based on their height, so one column might have 5
     * elements while another column would have just one really tall element
     */
    static class BalancedColumnLayout extends SwingFactory {
        private int columns;
        private int offset;
        private JComponent[] cmps;
        private PropertyContext[] properties;
        private Insets labelInsets = new java.awt.Insets(1, 4, 1, 4);
        private Insets componentInsets = new java.awt.Insets(1, 1, 1, 1);
        
        /**
         * creates an instance for the given number of columns
         */
        public BalancedColumnLayout(int columns) {
            this.columns = columns;
        }
        
        /**
         * Creates an instance of the container that would be populated with the objects
         */
        public JComponent createLayout(int elements) {
            cmps = new JComponent[elements];
            properties = new PropertyContext[elements];
            offset = 0;
            JPanel p = new JPanel(new GridBagLayout());
            p.setOpaque(false);
            return p;
        }

        /**
         * Adds the given pair of components to the layout
         */
        protected void addImpl(JComponent layout, JComponent component, PropertyContext property) {
            cmps[offset] = component;
            properties[offset] = property;
            offset++;
        }

        /**
         * Builds the actual UI
         */
        public JComponent finishLayout(JComponent layout) {
            // this is the height to which a standard component should aspire
            int height = new JLabel("X").getPreferredSize().height;
            int rowCount = 0;
            for(JComponent cmp : cmps) {
                rowCount += Math.min(5, cmp.getPreferredSize().height / height);
            }

            GridBagConstraints constraints = new GridBagConstraints();
            constraints.fill = GridBagConstraints.BOTH;
            
            offset = 0;
            for(int iter = 0 ; iter < cmps.length ; iter++) {
                int rows = Math.min(5, cmps[iter].getPreferredSize().height / height);
                if(rows == 1) {
                    constraints.anchor = GridBagConstraints.LINE_START;
                } else {
                    constraints.anchor = GridBagConstraints.PAGE_START;
                }
                constraints.gridx = offset / (rowCount / columns) * 2;
                constraints.gridy = offset % (rowCount / columns);
                constraints.insets = labelInsets;
                constraints.weightx = 0;
                constraints.gridheight = 1;
                JComponent label = createLabel(cmps[iter], properties[iter]);
                if(label != null) {
                    constraints.gridwidth = 1;
                    layout.add(label, constraints);
                    constraints.gridx++;
                } else {
                    constraints.gridwidth = 2;
                }
                constraints.anchor = GridBagConstraints.CENTER;
                constraints.gridheight = rows;
                if(cmps[iter] instanceof JScrollPane) {
                    constraints.weighty = 0.5;
                } else {
                    constraints.weighty = 0;
                }
                constraints.insets = componentInsets;
                constraints.weightx = 0.5;
                layout.add(cmps[iter], constraints);
                offset += rows;
            }
            
            return layout;
        }
    }

    /**
     * This is a layout based on a custom layout manager
     */
    static class CustomColumns extends SwingFactory {
        private int columns;
        private boolean horizontal;
        public CustomColumns(int columns, boolean horizontal) {
            this.columns = columns;
            this.horizontal = horizontal;
        }
        
        protected void addImpl(JComponent layout, JComponent component, PropertyContext property) {
            JComponent label = createLabel(component, property);
            if(label == null) {
                layout.add(new JLabel(""));
            } else {
                layout.add(label);
            }
            layout.add(component);
        }

        public JComponent createLayout(int elements) {
            JPanel p = new JPanel(new net.java.dev.properties.binding.swing.ColumnLayout(columns, horizontal));
            p.setOpaque(false);
            return p;
        }
    }
    
    /**
     * This class implements a border layout based layout placing the target component
     * in the center
     */
    static class CenterLayout extends SwingFactory {
        protected void addImpl(JComponent layout, JComponent component, PropertyContext property) {
            layout.add(component, BorderLayout.CENTER);
        }

        public JComponent createLayout(int elements) {
            JPanel p = new JPanel(new BorderLayout());
            p.setOpaque(false);
            return p;
        }
    }
}
