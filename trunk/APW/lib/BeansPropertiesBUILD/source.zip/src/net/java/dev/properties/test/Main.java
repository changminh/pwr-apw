/*
 * Main.java
 *
 * Created on February 20, 2007, 9:49 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import java.awt.Color;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.constraints.ConstraintFailedException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.PropertyListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.SwingUtilities;
import net.java.dev.properties.events.VetoListener;

/**
 * A simple demo of using the legacy, and new bean.
 *
 * @author Shai Almog
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // prevents a race condition between the main thread and property events
        SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
                legacy();
                newBeans();
                compatibility();
                advanced();
            }
        });
        testSerialization();
        testPersistance();
    }
    
    private static void legacy() {
        LegacyBean legacy = new LegacyBean();
        legacy.setX(1);
        System.out.println("Legacy x is: " + legacy.getX());
        PropertyChangeListener l = new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent ev) {
               System.out.println("Legacy " + ev.getPropertyName() + " was changed " + ev.getNewValue());
            }
        };
        legacy.addPropertyChangeListener(l);
        legacy.setX(2);
        legacy.removePropertyChangeListener(l);
        legacy.addPropertyChangeListener("x", l);
        legacy.setX(3);
    }

    private static void newBeans() {
        NewBean bean = new NewBean();
        bean.x.set(1);
        System.out.println("New bean x is: " + bean.x.get());
        PropertyListener l = new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
               System.out.println("New bean " + prop.getContext().getName() + " was changed " + newValue);
            }
        };
        BeanContainer.get().addListener(bean, l);
        bean.x.set(2);
        BeanContainer.get().removeListener(bean, l);
        BeanContainer.get().addListener(bean.x, l);
        bean.x.set(3);
    }

    private static void compatibility() {
        CompatibilityBean compat = new CompatibilityBean();
        compat.setX(1);
        System.out.println("Compatibility x is: " + compat.getX());
        PropertyChangeListener l = new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent ev) {
               System.out.println("Compatibility " + ev.getPropertyName() + " was changed " + ev.getNewValue());
            }
        };
        compat.addPropertyChangeListener(l);
        compat.setX(2);
        compat.removePropertyChangeListener(l);
        compat.addPropertyChangeListener("x", l);
        compat.setX(3);
    }
    
    private static void advanced() {
        AdvancedFeatures adv = new AdvancedFeatures();
        adv.attr.set(5);
        try {
            adv.attr.set(null);
        } catch(ConstraintFailedException err) {
            System.out.println("Exception thrown when trying to assign null to attribute");
        }
        System.out.println(adv.attr);
        
        System.out.println(adv.lightColor);
        adv.lightColor.set(Color.WHITE);
        System.out.println(adv.lightColor);
        adv.lightColor.set(Color.BLACK);
        System.out.println(adv.lightColor);
        

        System.out.println(adv.indexed);
        adv.indexed.add(0, "New");
        System.out.println(adv.indexed);
        adv.indexed.remove(1);
        System.out.println(adv.indexed);
        
        System.out.println(adv.vetoable);
        BeanContainer.get().addVetoListener(adv.vetoable, new VetoListener() {
            public boolean propertyChangeCheck(BaseProperty prop, Object oldValue, Object newValue, int index) {
                // disallow a number larger from 11
                return ((Number)newValue).intValue() < 11;
            }
        });
        adv.vetoable.set(50);
        System.out.println(adv.vetoable);
        adv.vetoable.set(10);
        System.out.println(adv.vetoable);        
    }
 
    /**
     * Used internally for serialization and persistence checks
     */
    private static Object createBean() {
        AdvancedFeatures advanced = new AdvancedFeatures();
        advanced.attr.set(17);
        advanced.indexed.add("Hi World");
        advanced.lightColor.set(Color.YELLOW);
        return advanced;
    }
    
    private static void testSerialization() throws Exception {
        Object bean = createBean();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ObjectOutputStream objectOut = new ObjectOutputStream(out);
        objectOut.writeObject(bean);
        objectOut.close();
        byte[] data = out.toByteArray();
        ObjectInputStream input = new ObjectInputStream(new ByteArrayInputStream(data));
        System.out.println("Serialization bean is: " + BeanContainer.get().toString(input.readObject()));
        input.close();
    }

    /**
     * Tries to serialize the given object to LTP and returns it
     */
    private static Object testLTP(Object bean) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        XMLEncoder encoder = new XMLEncoder(out);
        encoder.writeObject(bean);
        encoder.close();
        byte[] data = out.toByteArray();
        System.out.println("LTP Encoded data is: " + new String(data));
        XMLDecoder decoder = new XMLDecoder(new ByteArrayInputStream(data));
        return decoder.readObject();
    }
    
    
    private static void testPersistance() throws Exception {
        System.out.println("LTP For advanced bean is: " + 
            BeanContainer.get().toString(testLTP(createBean())));
        CompatibilityBean b = new CompatibilityBean();
        b.x.set(67);
        System.out.println("LTP For compatibility bean is: " + 
            BeanContainer.get().toString(testLTP(b)));
    }
}