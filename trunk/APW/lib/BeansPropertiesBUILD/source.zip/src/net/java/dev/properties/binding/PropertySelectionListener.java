/*
 * PropertySelectionListener.java
 *
 * Created on March 11, 2007, 12:13 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding;

import net.java.dev.properties.IndexedProperty;

/**
 * Allows a developer to track selection within the UI of a bound indexed property
 *
 * @author Shai Almog
 */
public interface PropertySelectionListener {
    /**
     * Invoked whenever the selection of property changes with the given selection
     * null or an empty array can be sent for an empty selection
     */
    public void selectionChanged(IndexedProperty property, int[] selection);
}
