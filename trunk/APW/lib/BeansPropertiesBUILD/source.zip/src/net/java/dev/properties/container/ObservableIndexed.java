/*
 * ObservableIndexed.java
 *
 * Created on February 22, 2007, 8:48 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import net.java.dev.properties.events.OnGetListener;
import java.util.Collection;
import java.util.List;
import net.java.dev.properties.*;
import net.java.dev.properties.events.OnGet;
import net.java.dev.properties.events.PropertyListener;

/**
 * Observable version of the indexed property that sends events on changes to the index
 *
 * @author Shai Almog
 */
public class ObservableIndexed<T> extends IndexedPropertyImpl<T> implements ObservableInterface, OnGetListener {    
    private final ObservableDelegate<PropertyListener> delegate = new ObservableDelegate<PropertyListener>();
    private OnGet onGet;

    public ObservableIndexed() {
    }

    public ObservableIndexed(Collection<T> l) {
        super(l);
    }

    public ObservableIndexed(T... arr) {
        super(arr);
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> ObservableIndexed<K> create() {
        return new ObservableIndexed<K>();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> ObservableIndexed<K> create(Collection<K> l) {
        return new ObservableIndexed<K>(l);
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> ObservableIndexed<K> create(K... arr) {
        return new ObservableIndexed<K>(arr);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void set(int index, T t) {
        T old = t;
        super.set(index, t);
        getContext().onChange(this, getParent(), old, t, index);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void add(int index, T t) {
        getModifiable().add(index, t);
        getContext().onInsert(this, getParent(), t, index);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void add(T t) {
        getModifiable().add(t);
        getContext().onInsert(this, getParent(), t, getModifiable().size() - 1);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void remove(T t) {
    	int indexOf = getModifiable().indexOf(t); 
    	if ( indexOf != -1 ) {
    		remove(indexOf);
    	}
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void remove(int index) {
        getContext().onRemove(this, getParent(), getModifiable().remove(index), index);
    }    

    /**
     * @inheritDoc
     */
    @Override
    public void set(List<T> t) {
        List<T> old = super.get();
        super.set(t);
        getContext().onChange(this, getParent(), old, t, -1);
    }

    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<PropertyListener> getDelegate() {
        return delegate;
    }

    /**
     * @inheritDoc
     */
    @Override
    public void setOnGet(OnGet onGet) {
        this.onGet = onGet;
    }

    /**
     * @inheritDoc
     */
    @Override
    public List<T> get() {
        if(onGet != null) {
            onGet.onGet(this);
        }
        return super.get();
    }    

    /**
     * @inheritDoc
     */
    @Override
    public int size() {
        return getModifiable().size();
    }

    /**
     * @inheritDoc
     */
    @Override
    protected List<T> getModifiable() {
        if(onGet != null) {
            onGet.onGet(this);
        }
        return super.getModifiable();
    }
}
