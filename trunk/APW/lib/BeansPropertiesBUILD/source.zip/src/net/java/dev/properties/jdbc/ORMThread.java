package net.java.dev.properties.jdbc;

import net.java.dev.properties.container.thread.SimpleThreadManager;
import net.java.dev.properties.events.BindListener;
import net.java.dev.properties.events.IndexedPropertyListener;
import net.java.dev.properties.events.OnGetListener;

/**
 * This class represents the thread on which most of the ORM releate code should
 * execute. It is a ThreadManager that allows us to assign the listeners to a
 * separate thread from the EDT thus prevent database operations from executing
 * on the EDT.
 *
 * @author Shai Almog
 */
public class ORMThread extends SimpleThreadManager {
    static {
        new ORMThread();
    }
    
    /**
     * Used to trigger the static initialized only once...
     */
    static void init() {}
    
    /**
     * Identifies listeners that should run on the ORM thread based on the inner
     * marker interfaces.
     */
    protected boolean isRightManager(Object listener) {
        return listener instanceof Marker || super.isRightManager(listener);
    }
    
    /**
     * Every listener interface marked with this marker should run on the ORM thread
     */
    public static interface Marker {
    }
    
    /**
     * Convenince version of the property listener that is already marked for ORM execution
     */
    public static interface PropertyListener extends net.java.dev.properties.events.PropertyListener, Marker {
    }

    /**
     * Convenince version of the bind listener that is already marked for ORM execution
     */
    public static interface BindListener extends net.java.dev.properties.events.BindListener, Marker {
    }

    /**
     * Convenince version of the Indexed Property listener that is already marked for ORM execution
     */
    public static interface IndexedPropertyListener extends net.java.dev.properties.events.IndexedPropertyListener, Marker {
    }

    /**
     * Convenince version of the Map Property listener that is already marked for ORM execution
     */
    public static interface MapPropertyListener extends net.java.dev.properties.events.MapPropertyListener, Marker {
    }
}
