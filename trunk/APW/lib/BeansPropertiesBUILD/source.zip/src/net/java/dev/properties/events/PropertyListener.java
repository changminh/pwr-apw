/*
 * PropertyListener.java
 *
 * Created on February 21, 2007, 1:28 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.events;

import net.java.dev.properties.BaseProperty;

/**
 * A simplified and more appropriate for this api property change listener 
 * interface
 * 
 * @author Shai Almog
 */
public interface PropertyListener extends java.io.Serializable {
    /**
     * Invoked for property change event, index would normally be -1 for anything that
     * is not an indexed property otherwise it will indicate the index ofset that has
     * changed within the indexed property.
     */
    public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index);
}
