/*
 * StudioBean.java
 *
 * Created on March 7, 2007, 11:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.mirror;

import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.annotations.Bean;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;

/**
 * Main class of which there is one instance containing all the students and classes
 * in the studio
 *
 * @author Shai Almog
 */
public class StudioBean implements java.io.Serializable {
    private StudentBean[] students;
    private YogaClassBean[] classes;
    private AttendanceBean[] attendance;

    public StudentBean[] getStudents() {
        return students;
    }

    public void setStudents(StudentBean[] students) {
        this.students = students;
    }

    public YogaClassBean[] getClasses() {
        return classes;
    }

    public void setClasses(YogaClassBean[] classes) {
        this.classes = classes;
    }

    public AttendanceBean[] getAttendance() {
        return attendance;
    }

    public void setAttendance(AttendanceBean[] attendance) {
        this.attendance = attendance;
    }
}
