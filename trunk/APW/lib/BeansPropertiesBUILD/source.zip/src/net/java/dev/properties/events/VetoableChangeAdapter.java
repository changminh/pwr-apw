/*
 * PropertyChangeAdapter.java
 *
 * Created on February 21, 2007, 1:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.events;

import net.java.dev.properties.container.PropertyContext;
import java.beans.*;
import net.java.dev.properties.BaseProperty;

/**
 * A small tool to simplify the conversion of existing property veto code
 * to the new properties approach for veto events
 *
 * @author Shai Almog
 */
public class VetoableChangeAdapter implements VetoListener {
    private VetoableChangeListener listener;
    
    /** Creates a new instance of PropertyChangeAdapter */
    public VetoableChangeAdapter(VetoableChangeListener listener) {
        this.listener = listener;
    }

    public VetoableChangeListener getListener() {
        return listener;
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean propertyChangeCheck(BaseProperty prop, Object oldValue, Object newValue, int index) {
        try {
            PropertyContext context = prop.getContext();
            if(index > -1) {
                listener.vetoableChange(new IndexedPropertyChangeEvent(prop.getParent(), context.getName(), oldValue, newValue, index));
            } else {
                listener.vetoableChange(new PropertyChangeEvent(prop.getParent(), context.getName(), oldValue, newValue));
            }
        } catch (PropertyVetoException ex) {
            return false;
        }
        return true;
    }    
}
