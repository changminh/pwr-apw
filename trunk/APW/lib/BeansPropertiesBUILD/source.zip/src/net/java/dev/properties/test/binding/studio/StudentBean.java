/*
 * StudentBean.java
 *
 * Created on March 7, 2007, 10:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.studio;

import java.util.Date;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Bean;
import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.annotations.Length;
import net.java.dev.properties.annotations.Regex;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;

/**
 * A bean representing a student in the yoga studio demo application
 *
 * @author Shai Almog
 */
@Bean(resourceBundle="net.java.dev.properties.test.binding.studio.resources", localize=true)
public class StudentBean implements java.io.Serializable {
    @Length(min=2, max=20)
    @Regex(exp="[a-zA-Z]*")
    public final Property<String> firstName = ObservableProperty.create();

    @Length(min=2, max=20)
    @Regex(exp="[a-zA-Z]*")
    public final Property<String> surname = ObservableProperty.create();

    public final Property<Boolean> male = ObservableProperty.create();
    
    public final Property<String> street = ObservableProperty.create();
    
    public final Property<String> streetNumber = ObservableProperty.create();
    public final Property<String> city = ObservableProperty.create();
    public final Property<String> phone = ObservableProperty.create();
    public final Property<String> mobile = ObservableProperty.create();
    public final Property<String> eMail = ObservableProperty.create();
    
    public final Property<Date> birthDay = ObservableProperty.create();
    public final Property<String> comment = ObservableProperty.create();
    public final Property<Boolean> active = ObservableProperty.create(true);
    
    /** Creates a new instance of StudentBean */
    public StudentBean() {
        BeanContainer.bind(this);
    }

    /** Creates a new instance of StudentBean */
    public StudentBean(String name, String surname) {
        this();
        firstName.set(name);
        this.surname.set(surname);
    }
    
    public String toString() {
        return firstName.get() + " " + surname.get();
    }
}
