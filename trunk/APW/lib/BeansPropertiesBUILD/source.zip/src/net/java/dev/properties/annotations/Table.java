package net.java.dev.properties.annotations;

import static java.lang.annotation.ElementType.TYPE;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Used by the ORM code allows us to specify the table name/prefix for a bean
 * which might differ from the bean name. Notice that by default the table
 * name would map to the bean name.
 *
 * @author Glen Marchesani
 */

@Target(TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface Table {
    /**
     * Name for the table
     */
    String name() default "";

    /**
     * Database prefix for the table
     */
    String prefix() default "";
}
