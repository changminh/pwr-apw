/*
 * BeanContainer.java
 *
 * Created on February 21, 2007, 1:49 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyChangeListener;
import java.beans.VetoableChangeListener;
import java.lang.annotation.*;
import java.lang.reflect.*;
import java.security.AccessControlException;
import java.util.*;
import javax.swing.*;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.annotations.*;
import net.java.dev.properties.constraints.*;
import net.java.dev.properties.container.thread.ThreadManager;
import net.java.dev.properties.events.*;
import net.java.dev.properties.MapProperty;
import net.java.dev.properties.util.Utils;

/**
 * The container is the heart of bean management, rather than invoking 
 * listener code on the beans/properties they are indirected via this class
 * to allow the code for event handling to exist in one place. This simplifies
 * both the development of beans and the development of custom property handling
 * code that does not derive from a single base class. This also allows comple
 * bean initialization and annotation support with greater ease. This class 
 * is a singleton.
 * <p>This allows things such as threading behavior and Java EE compatibility to
 * be layered on top of the BeanContainer without a single line of code being
 * changed in the bean implementations.
 * <p>The bean container is far more important than just an event proxy, it is
 * the central area where everything occurs, bean instances are intialized here.
 * Proxy objects are injected to newly created bean instances annotations are
 * parsed and used to build said proxy objects etc... 
 * <p>This class also serves as a general utility method for bean related feature,
 * it is not quite a singleton (although it does have a static get() method). It is
 * a pluggable singleton in the sense that it can (and is) replaced when we need
 * additional functionality.
 *
 * @author Shai Almog
 */
public class BeanContainer {
    private static BeanContainer instance = new BeanContainer();
    
    /**
     * This map indicates the context for the given bean class, yes context is
     * never cleared but since this is per bean class and not per bean instance
     * this might not be so terrible at least for client side applications.
     */
    private Map<Class, BeanContext> contextMap = new HashMap<Class, BeanContext>();

    /**
     * The constraint factories used for converting the annotations to instance 
     * objects
     */
    private List<ConstraintFactory> constraints = new ArrayList<ConstraintFactory>();
    
    /** Creates a new instance of BeanContainer */
    protected BeanContainer() {
        constraints.add(new ConstraintFactory() {
            @Override
            public void createConstraint(Field field, PropertyContext context, final ResourceFetch messages) 
                throws InstantiationException, IllegalAccessException {
                if(field.isAnnotationPresent(Validation.class)) {
                    Validation v = field.getAnnotation(Validation.class);
                    context.setOnConstraintFail(v.onFail());
                    if(v.constraint() != EmptyConstraint.class) {
                        context.addConstraint((Constraint)v.constraint().newInstance(), 
                            messages.getValue(context, "Validation", v.messageL(), v.message()));
                    }
                }
            }
        });
        constraints.add(new ConstraintFactory() {
            @Override
            public void createConstraint(Field field, PropertyContext context, final ResourceFetch messages) {
                if(field.isAnnotationPresent(NotNull.class)) {
                    NotNull v = field.getAnnotation(NotNull.class);
                    context.addConstraint(new NotNullConstraint(), 
                        messages.getValue(context, "NotNull", v.messageL(), v.message()));
                }
            }
        });
        constraints.add(new ConstraintFactory() {
            @Override
            public void createConstraint(Field field, PropertyContext context, final ResourceFetch messages) {
                if(field.isAnnotationPresent(Range.class)) {
                    Range r = field.getAnnotation(Range.class);
                    context.addConstraint(new RangeConstraint(r.min(), r.max()), 
                        messages.getValue(context, "Range", r.messageL(), r.message()));
                }
            }
        });
        constraints.add(new ConstraintFactory() {
            @Override
            public void createConstraint(Field field, PropertyContext context, final ResourceFetch messages) {
                if(field.isAnnotationPresent(Length.class)) {
                    Length r = field.getAnnotation(Length.class);
                    context.addConstraint(new LengthConstraint(r.min(), r.max()), 
                        messages.getValue(context, "Length", r.messageL(), r.message()));
                }
            }
        });
        constraints.add(new ConstraintFactory() {
            @Override
            public void createConstraint(Field field, PropertyContext context, final ResourceFetch messages) {
                if(field.isAnnotationPresent(Regex.class)) {
                    Regex r = field.getAnnotation(Regex.class);
                    context.addConstraint(new RegexConstraint(r.exp()), 
                        messages.getValue(context, "Regex", r.messageL(), r.message()));
                }
            }
        });
    }
    
    public static BeanContainer get() {
        return instance;
    }

    /**
     * Allows the user to define additional annotations
     */
    public void registerConstraint(ConstraintFactory factory) {
        constraints.add(factory);
    }
    
    /**
     * Allows developers to replace the instance of the bean container with their own.
     * Notice that it is CRITICAL to invoke this method before any bean is bound otherwise
     * an illegal state exception will be thrown...
     */
    public static void set(BeanContainer newInstance) {
        if(instance.contextMap.size() > 0) {
            throw new IllegalStateException("Beans were already bound to this container! See: " + instance.contextMap.keySet());
        }
        instance = newInstance;
    }
    
    /**
     * Allows subclasses to store the bean context in an arbitrary location
     */
    protected void putBeanContext(Class<?> cls, BeanContext context) {
        contextMap.put(cls, context);
    }
    
    /**
     * Allows subclasses to store the bean context in an arbitrary location
     */
    protected BeanContext getBeanContext(Class<?> cls) {
        return contextMap.get(cls);
    }

    /**
     * Allows subclasses to store the bean context in an arbitrary location
     */
    protected boolean isRegistered(Class<?> cls) {
        return contextMap.containsKey(cls);
    }
    
    /**
     * Allows subclasses to store the bean context in an arbitrary location
     */
    protected Iterator<Map.Entry<Class, BeanContext>> iterateBeans() {
        return contextMap.entrySet().iterator();
    }
    
    /**
     * Refreshes the resource bundle code defined in the beans if such a resource
     * bundle is defined to match a given locale.
     */
    public void refreshLocale(Locale l) {
        Iterator<Map.Entry<Class, BeanContext>> iter = iterateBeans();
        while(iter.hasNext()) {
            Map.Entry<Class, BeanContext> entry = iter.next();
            Class<?> c = entry.getKey();
            if(c.isAnnotationPresent(Bean.class)) {
                Bean b = (Bean)c.getAnnotation(Bean.class);
                if(b.localize()) {
                    ResourceBundle bundle = ResourceBundle.getBundle(b.resourceBundle(), l);
                    entry.getValue().updateBundle(bundle);
                }
            }
        }
    }
    
    /**
     * Updates the bean context with either default information or the content
     * of the annotation.
     */
    protected ResourceFetch initBeanAnnotation(Object bean, BeanContext context) {
        ResourceFetch fetch;
        String name = bean.getClass().getSimpleName();
        context.setName(name);
        if(bean.getClass().isAnnotationPresent(Bean.class)) {
            Bean b = bean.getClass().getAnnotation(Bean.class);
            ResourceBundle bundle = null;
            if(b.resourceBundle().length() > 0) {
                bundle = ResourceBundle.getBundle(b.resourceBundle());
                context.setBundle(bundle);
            }
            if(b.name().length() > 0) {
                context.setName(b.name());
            }
            if(b.localize()) {
                fetch = new LocalizedResourceFetch(bundle, name);
            } else {
                fetch = new ResourceFetch(bundle, name);
            }
            context.setDisplayName(fetch.getValue("displayName", b.displayNameL(), b.displayName(), Utils.prettyName(name)));
            context.setIcon(fetch.getValue("icon", b.iconL(), b.icon()));
            context.setSvgIcon(fetch.getValue("svgIcon", b.svgIconL(), b.svgIcon()));
            context.setDescription(fetch.getValue("description", b.descriptionL(), b.description()));
            context.setTypeHandler(b.typeHandler());
        } else {
            context.setDisplayName(Utils.prettyName(name));
            fetch = new ResourceFetch(null, name);
        }
        Table table = bean.getClass().getAnnotation(Table.class);
        if(table == null) {
            context.setTableName(context.getName());
            context.setTablePrefix("");
        } else {
            context.setTableName(table.name());
            context.setTablePrefix(table.prefix());
        }
        return fetch;
    }

    
    /**
     * Allows binding all the declared constraints to the given field
     */
    protected PropertyContext createPropertyContext(Field field, Object bean, BeanContext beanContext, ResourceFetch fetch) {
        try {
            PropertyContext context;
            
            // let the context factory handle the creation of the property context
            // for additional meta-data
            if(PropertyContextFactory.class.isAssignableFrom(field.getType())) {
                context = ((PropertyContextFactory)field.get(bean)).createContext(field);
            } else {
                context = new PropertyContext();
            }
            context.setField(field);
            context.setName(field.getName());
            if(field.isAnnotationPresent(Attributes.class)) {
                Attributes attr = field.getAnnotation(Attributes.class);
                if(attr.name().length() > 0) {
                    context.setName(attr.name());
                } 
                context.setDisplayName(fetch.getValue(context, "displayName", attr.displayNameL(), attr.displayName(), Utils.prettyName(field.getName())));
                context.setDescription(fetch.getValue(context, "description", attr.descriptionL(), attr.description()));
            } else {
                context.setDisplayName(fetch.getValue(context, "displayName", null, Utils.prettyName(field.getName())));
                context.setDescription(fetch.getValue(context, "description", null, ""));
            }
            
            for(ConstraintFactory factory : constraints) {
                factory.createConstraint(field, context, fetch);
            }
            
            context.setTransient(Modifier.isTransient(field.getModifiers()));
            Column column = field.getAnnotation(Column.class);
            if(column != null) {
                if(column.name().length() > 0) {
                    context.setColumnName(column.name());
                } else {
                    context.setColumnName(context.getName());
                }
                context.setKeyColumn(column.key());
                context.setColumnSuffix(column.suffix());
                context.setCompositeKeySequence(column.compositeKeySequence());
                context.setTypeHandler(column.typeHandler());
                context.setRelationName(column.relationName());
            } else {
                context.setColumnName(context.getName());
            }
            Bidirectional bidi = field.getAnnotation(Bidirectional.class);
            if(bidi != null) {
                context.setBidirectional(true);
                context.setAllowsBidirectionalDuplicates(bidi.allowDuplicates());
                if(bidi.value() != null && bidi.value().length() > 0) {
                    context.setRelationName(bidi.value());
                }
            }
            
            return context;
        } catch(InstantiationException iErr) {
            throw new BeanBindException(iErr);
        } catch(IllegalAccessException iaErr) {
            iaErr.printStackTrace();
            throw new BeanBindException("Can't access member of class or inner class, please verify that all attributes are public and where inner classes are involved static as well.");
        }
    }
    
    /**
     * Returns true if the given beans property values are all valid.
     */
    public boolean isValid(Object bean) {
        for(PropertyContext context : getContext(bean).getPropertiesArray()) {
            BaseProperty b = context.getValue(bean);
            if(b instanceof RProperty) {
                boolean passed = context.validate(b, ((RProperty)b).get());
                if(!passed) {
                    return false;
                }
            }
        }
        return true;
    }
    
    /**
     * Binds the given mirror to the container, there isn't much work to do here
     * since unlike a standard bean a mirror does most of the work for the contiainer.
     */
    public void bindMirror(Class beanClass, PropertyContext[] properties) {
        BeanContext context = new BeanContext();
        context.setFields(properties);
        context.setDisplayName(Utils.prettyName(beanClass.getSimpleName()));
        context.setName(beanClass.getSimpleName());
        putBeanContext(beanClass, context);
    }
    
    /**
     * This method must be invoked for every bean, it essentially bootstraps
     * a bean by setting its BeanContext and PropertyContext objects into place.
     */
    public void bindBean(Object bean) {
        try {
            BeanContext context = getBeanContext(bean.getClass());
            if(context == null) {
                context = new BeanContext();
                ResourceFetch fetch = initBeanAnnotation(bean, context);
                Field[] fields = bean.getClass().getFields();
                List<PropertyContext> fieldList = new ArrayList<PropertyContext>();
                for(Field field : fields) {
                    if(isProperty(field)) {
                        fieldList.add(createPropertyContext(field, bean, context, fetch));
                    } 
                }

                if(fieldList.size() == 0) {
                    // this might be a valid situation where a base class shared between
                    // many beans and non-beans invokes bind
                    return;
                    //throw new NoPropertyFoundException();
                }

                PropertyContext[] array = new PropertyContext[fieldList.size()];
                fieldList.toArray(array);
                context.setFields(array);
                putBeanContext(bean.getClass(), context);
            }

            for(PropertyContext pContext : context.getFields()) {
                if(!(pContext instanceof VirtualPropertyContext)) {
                    Field field = pContext.getField();
                    BaseProperty property = (BaseProperty)field.get(bean);

                    // this might occur if bind is invoked from a superclass
                    if(property == null) {
                        continue;
                    }
                    property.setContext(pContext);
                    property.setParent(bean);
                }
            }
            context.fireBindEvent(bean);
        } catch(AccessControlException err) {
            // thrown when running under a Java 5 security manager which is just broken
            // we need to notify the user
            JOptionPane.showMessageDialog(null, "Due to a bug in Java 5 bean properties " +
                    "cannot work\nproperly at this time in an untrusted environment.\n" +
                    "You can either upgrade to Java 6 or download the application\n" +
                    "and run it locally", "Error", JOptionPane.ERROR_MESSAGE);
            throw new BeanBindException(err);
        } catch(IllegalAccessException illegalErr) {
            // this might happen if the bean class is not public
            illegalErr.printStackTrace();
            throw new BeanBindException("Illegal access exception occured, make sure that your bean class is public");
        }
    }

    private void fillListProperties(Object bean, List properties, Class<?> pClass) {
        for(PropertyContext property : getContext(bean).getFields()) {
            BaseProperty value = property.getValue(bean);
            if(pClass.isAssignableFrom(value.getClass())) {
                properties.add(value);
            }
        }
    }
    
    /**
     * Converts the given bean to a map of key/value properties where the key is
     * the property name and the value is the object content. If a property
     * points at another bean this bean is placed as is.
     */
    public Map<String, Object> createMap(Object bean) {
        Map<String, Object> beanMap = new HashMap<String, Object>();
        for(PropertyContext context : getContext(bean).getPropertiesArray()) {
            BaseProperty prop = context.getValue(bean);
            if(prop instanceof RProperty) {
                Object value = ((RProperty)prop).get();
                if(value != null) {
                    beanMap.put(context.getName(), value);
                }
            }
        }
        
        return beanMap;
    }
    
    /**
     * Converts the given bean to a map of key/value properties where the key is
     * the property name and the value is the object content. If a property
     * points at another bean this bean is converted to a map recursively.
     */
    public Map<String, Object> createMapRecursive(Object bean) {
        Map<String, Object> beanMap = new HashMap<String, Object>();
        for(PropertyContext context : getContext(bean).getPropertiesArray()) {
            BaseProperty prop = context.getValue(bean);
            if(prop instanceof RProperty) {
                Object value = ((RProperty)prop).get();
                if(value != null) {
                    if(isRegistered(value.getClass())) {
                        beanMap.put(context.getName(), createMapRecursive(value));
                    } else {
                        beanMap.put(context.getName(), value);
                    }
                }
            }
        }
        
        return beanMap;
    }

    /**
     * This method allows us to begin tracking changes to the given observable bean.
     * When the following releaseMergePoint() method is invoked we will recive the
     * modified properties.
     */
    public MergePoint initMergePoint(Object bean) {
        return new StandardMergePoint(bean);
    }

    /**
     * Similar to a regular merge point but would produce a change result only if the 
     * value has actually changed... E.g. if value was "X" then changed to "Y" and back
     * to "X" then it wasn't modified according to a strict merge.
     * A strict merge point also allows a "rollback" feature that returns the bean
     * to its original state.
     */
    public StrictMergePoint strictMergePoint(Object bean) {
        return new StrictMergePoint(bean);
    }
    
    /**
     * Returns the modified properties since the initialization of the merge point
     */
    public List<Property> releaseMergePoint(MergePoint mergePoint) {
        List<Property> p = mergePoint.getProperties();
        mergePoint.dispose();
        return p;
    }

    /**
     * Used internally by equals
     */
    private boolean compareBeanProperties(Object bean1, Object bean2) {
        for(PropertyContext context : getContext(bean1).getPropertiesArray()) {
            Object v1 = context.getInternalValue(bean1);
            Object v2 = context.getInternalValue(bean2);
            if(v1 != v2 && v1 != null && v2 != null && (!v1.equals(v2))) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Compares two beans, this is an equals method that can be invoked directly
     * from a beans equals method.
     */
    public boolean equals(Object bean1, Object bean2) {
        return bean1 == bean2 || (bean1 != null && bean2 != null && 
            bean1.getClass() == bean2.getClass() && compareBeanProperties(bean1, bean2));
    }
    
    /**
     * This method is currently disabled since it fucks up the hashmap...
     * Returns a hashcode appropriate for the given bean.
     */
    public int hashCode(Object bean) {
        /*int value = 0;
        for(PropertyContext context : getContext(bean).getPropertiesArray()) {
            Object v = context.getInternalValue(bean);
            if(v != null) {
                value += v.hashCode();
            }
        }*/
        
        return getContext(bean).hashCode();
    }

    /**
     * Clones a new instance of the given bean, notice that only read/write 
     * properties can be cloned. Any property that is write only or read only
     * would be ignored.
     * @param bean The bean to clone
     * @return a new cloned instance
     */
    public <Y> Y clone(Y bean) {
        try {
            Y y = (Y)bean.getClass().newInstance();
            clone(bean, y);
            return y;
        } catch (InstantiationException ex) {
            throw new BeanBindException(ex);
        } catch (IllegalAccessException ex) {
            throw new BeanBindException(ex);
        }
    }

    /**
     * Clones the source bean into a destination bean
     */
    public <Y> void clone(Y source, Y dest) {
        for(PropertyContext context : getContext(source).getPropertiesArray()) {
            BaseProperty p1 = context.getValue(source);
            if(p1 instanceof RProperty && p1 instanceof WProperty) {
                BaseProperty p2 = context.getValue(dest);
                ((WProperty)p2).set(((RProperty)p1).get());
            } else {
                if(p1 instanceof MapProperty) {
                    MapProperty m1 = (MapProperty)p1;
                    MapProperty m2 = (MapProperty)context.getValue(dest);
                    Iterator i = m2.keyIterator();
                    while(i.hasNext()) {
                        m2.remove(i.next());
                        i = m2.keyIterator();
                    }
                    i = m1.keyIterator();
                    while(i.hasNext()) {
                        Object key = i.next();
                        m2.set(key, m1.get(key));
                    }
                }
            }
        }        
    }
    
    /**
     * Returns all the properties that allow reading their value on the given
     * bean
     */
    public List<RProperty<Object>> getReadProperties(Object bean) {
        List<RProperty<Object>> properties = new ArrayList<RProperty<Object>>();
        fillListProperties(bean, properties, RProperty.class);
        return properties;
    }
    
    /**
     * Returns all the properties that allow writing their value on the given
     * bean
     */
    public List<WProperty<Object>> getWriteProperties(Object bean) {
        List<WProperty<Object>> properties = new ArrayList<WProperty<Object>>();
        fillListProperties(bean, properties, WProperty.class);
        return properties;
    }

    /**
     * Implements a generic to string method that returns the properties of the 
     * beans and their toString values.
     */
    public String toString(Object bean) {
        StringBuilder s = new StringBuilder();
        BeanContext context = getContext(bean);
        s.append(context.getName());
        s.append(" {\n");
        for(RProperty<Object> p : getReadProperties(bean)) {
            s.append(p.toString());
            s.append('\n');
        }
        s.append("}\n");
        return s.toString();
    }
    
    /**
     * Returns true if the given object is considered to be one of the new
     * JavaBeans API or whether it falls under the old API. This will only
     * work for bound beans and thus the API is very efficient. 
     */
    public boolean isNewBean(Class<?> beanClass) {
        return isRegistered(beanClass) || Mirror.class.isAssignableFrom(beanClass);
    }
    
    /**
     * This method will return a bean info both for one of the new JavaBeans
     * and a legacy JavaBean simply by using the introspector API. 
     */
    public BeanInfo introspect(Class<?> beanClass) 
        throws IntrospectionException {
        if(isNewBean(beanClass)) {
            return new BeanInfoImpl(getBeanContext(beanClass), beanClass);
        } 
        return Introspector.getBeanInfo(beanClass);
    }
    
    /**
     * Helper method essentially identical to BeanContainer.get().bindBean(o)
     */
    public static void bind(Object o) {
        get().bindBean(o);
    }
    
    /**
     * Returns the context object matching the given bean, notice that this will
     * fail for mirror objects unless the actual POJO bean is used!
     */
    public BeanContext getContext(Class bean) {
        BeanContext b = getBeanContext(bean);
        if(b == null) {
            try {
                bean.newInstance();
            } catch(Exception err) {
                throw new BeanBindException(err);
            }
        }
        return getBeanContext(bean);
    }
    
    /**
     * Returns the context of the given bean, this is the preferred method for
     * getting the context since it works with mirror objects as well...
     */
    public BeanContext getContext(Object bean) {
        Class c;
        if(bean instanceof Mirror) {
            return ((Mirror)bean).getContext();
        } else {
            c = bean.getClass();
        }
        BeanContext context = getBeanContext(c);
        if(context == null) {
            bindBean(bean);
            return getBeanContext(c);
        }
        return context;
    }
    
    /**
     * Adds a listener that will be invoked whenever the given property of the bean
     * changes... This method will affect all the instances of the property
     * in all the beans.
     */
    public <T> void addListener(final PropertyContext property, final PropertyListener listener) {
        // property listeners should be added on the swing thread to prevent a race
        // condition where fire is still waiting for the swing thread and a new listener
        // is already registered
        ThreadManager m = ThreadManager.getManager(listener);
        if(!m.isRightThread()) {
            m.invokeAndWait(new Runnable() {
                public void run() {
                    addListener(property, listener);
                }
            });
            return;
        }
        ((ObservableInterface)property).getDelegate().addListener(listener);
    }
    
    /**
     * Removes the listener that would have been invoked whenever the given property of the bean
     * changes...
     */
    public <T> void removeListener(PropertyContext property, PropertyListener listener) {
        ((ObservableInterface)property).getDelegate().removeListener(listener);
    }

    /**
     * Adds a listener that will be invoked whenever the given property of the bean
     * changes...
     */
    public <T> void addListener(final BaseProperty<T> property, final PropertyListener listener) {
        // property listeners should be added on the swing thread to prevent a race
        // condition where fire is still waiting for the swing thread and a new listener
        // is already registered
        ThreadManager m = ThreadManager.getManager(listener);
        if(!m.isRightThread()) {
            m.invokeAndWait(new Runnable() {
                public void run() {
                    addListener(property, listener);
                }
            });
            return;
        }
        if(property instanceof ObservableInterface) {
            ((ObservableInterface)property).getDelegate().addListener(listener);
            return;
        } 
        throw new IllegalArgumentException("Property must be an instance of an ObservableInterface: " + property);
    }
    
    /**
     * Removes the listener that would have been invoked whenever the given property of the bean
     * changes...
     */
    public <T> void removeListener(BaseProperty<T> property, PropertyListener listener) {
        if(property instanceof ObservableInterface) {
            ((ObservableInterface)property).getDelegate().removeListener(listener);
            return;
        } 
        throw new IllegalArgumentException("Property must be an instance of an ObservableInterface: " + property);
    }
    
    /**
     * Adds a listener that will be invoked whenever any property of the bean
     * changes...
     */
    public void addListener(final Object bean, final PropertyListener listener) {
        // property listeners should be added on the swing thread to prevent a race
        // condition where fire is still waiting for the swing thread and a new listener
        // is already registered
        ThreadManager m = ThreadManager.getManager(listener);
        if(!m.isRightThread()) {
            m.invokeAndWait(new Runnable() {
                public void run() {
                    addListener(bean, listener);
                }
            });
            return;
        }
        ObservableDelegate<PropertyListener> delegate;
        if(bean instanceof ObservableInterface) {
            delegate = ((ObservableInterface)bean).getDelegate();
        } else {
            BeanContext bc = getContext(bean);
            for(PropertyContext p : bc.getPropertiesArray()) {
                BaseProperty v = p.getValue(bean);
                if(v instanceof ObservableInterface) {
                    ((ObservableInterface)v).getDelegate().addListener(listener);
                }
            }
            return;
        }
        delegate.addListener(listener);
    }

    /**
     * Removes the listener that would have been invoked whenever any property 
     * of the bean changes...
     */
    public void removeListener(Object bean, PropertyListener listener) {
        ObservableDelegate<PropertyListener> delegate;
        if(bean instanceof ObservableInterface) {
            delegate = ((ObservableInterface)bean).getDelegate();
            delegate.removeListener(listener);
        } else {
            BeanContext bc = getContext(bean);
            for(PropertyContext p : bc.getPropertiesArray()) {
                BaseProperty v = p.getValue(bean);
                if(v instanceof ObservableInterface) {
                    ((ObservableInterface)v).getDelegate().removeListener(listener);
                }
            }
        }
    }
    
    /**
     * Adds a listener that will be invoked whenever any property of the bean
     * changes in every bean instance!
     */
    public void addContextListener(final Object bean, final PropertyListener listener) {
        addListener(getContext(bean), listener);
    }

    /**
     * Removes the listener that would have been invoked whenever any property 
     * of the bean changes...
     */
    public void removeContextListener(Object bean, PropertyListener listener) {
        removeListener(getContext(bean), listener);
    }

    /**
     * Adds a listener that will be invoked whenever any property of the bean
     * changes in every bean instance!
     */
    public void addListener(final BeanContext bean, final PropertyListener listener) {
        // property listeners should be added on the swing thread to prevent a race
        // condition where fire is still waiting for the swing thread and a new listener
        // is already registered
        ThreadManager m = ThreadManager.getManager(listener);
        if(!m.isRightThread()) {
            m.invokeAndWait(new Runnable() {
                public void run() {
                    addListener(bean, listener);
                }
            });
            return;
        }
        bean.delegate.addListener(listener);
    }

    /**
     * Removes the listener that would have been invoked whenever any property 
     * of the bean changes...
     */
    public void removeListener(BeanContext bean, PropertyListener listener) {
        bean.delegate.removeListener(listener);
    }
    
    /**
     * Returns true if this field is a property
     */
    private boolean isProperty(Field f) {
        int mod = f.getModifiers();
        if(BaseProperty.class.isAssignableFrom(f.getType())) {
            if(!(Modifier.isPublic(mod) && Modifier.isFinal(mod))) {
                throw new BeanBindException("Properties MUST be declared public final! Make sure to fix " + f.getName() + " from: " + f.getDeclaringClass().getName());
            }
            return !Modifier.isStatic(mod);
        }
        return false;
    }

    /**
     * Fires the remove event
     */
    void fireOnRemove(MapProperty property, PropertyContext context,
        Object bean, Object key) {
        fireMapEvent(property, context, bean, key, null, new MapEventHandler() {
            public void fireEvent(final MapPropertyListener listener, final MapProperty prop, final Object key, Object value) {
                listener.propertyRemoved(prop, key);
            }
        });
    }
    
    /**
     * Fires the insert event
     */
    void fireOnInsert(MapProperty property, PropertyContext context,
        Object bean, Object key, Object value) {
        fireMapEvent(property, context, bean, key, value, new MapEventHandler() {
            public void fireEvent(final MapPropertyListener listener, final MapProperty prop, final Object key, Object value) {
                listener.propertyInserted(prop, key, value);
            }
        });
    }
    
    private void fireMapEvent(final MapProperty property, final PropertyContext context,
        final Object bean, final Object key, final Object value, final MapEventHandler handler) {
        // if we are not on the swing thread then invoke this method on the swing thread...
        if(property instanceof ObservableInterface) {
            fireMapEvent(((ObservableInterface)property).getDelegate().getListeners(), property, key, value, handler);
        }
        fireMapEvent(context.delegate.getListeners(), property, key, value, handler);
        ObservableDelegate<PropertyListener> d = null;
        if(bean instanceof ObservableInterface) {
            d = ((ObservableInterface)bean).getDelegate();
        } 
        if(d != null) {
            fireMapEvent(d.getListeners(), property, key, value, handler);
        }
        fireMapEvent(getContext(bean).delegate.getListeners(), property, key, value, handler);
    }

    /**
     * Fires the property change event to all the listeners
     */
    private void fireMapEvent(List<PropertyListener> listeners, final MapProperty property, final Object key, final Object value, final MapEventHandler handler) {
        if(listeners != null) {
            for(PropertyListener listener : listeners) {
                ThreadManager m = ThreadManager.getManager(listener);
                if(!m.isRightThread()) {
                    final PropertyListener finalListener = listener;
                    m.invokeAndWait(new Runnable() {
                        public void run() {
                            if(finalListener instanceof MapPropertyListener) {
                                handler.fireEvent((MapPropertyListener)finalListener, property, key, value);
                            }
                        }
                    });
                    continue;
                }
                if(listener instanceof MapPropertyListener) {
                    handler.fireEvent((MapPropertyListener)listener, property, key, value);
                }
            }
        }
    }
    
    /**
     * Fires the remove event
     */
    void fireOnRemove(IndexedProperty property, PropertyContext context,
        Object bean, Object value, int index) {
        fireIndexEvent(property, context, bean, value, index, new IndexEventHandler() {
            public void fireEvent(final IndexedPropertyListener listener, IndexedProperty prop, Object value, int index) {
                listener.propertyRemoved(prop, value, index);
            }
        });
    }

    /**
     * Fires the add event
     */
    public void fireOnInsert(IndexedProperty property, PropertyContext context,
        Object bean, Object value, int index) {
        fireIndexEvent(property, context, bean, value, index, new IndexEventHandler() {
            public void fireEvent(IndexedPropertyListener listener, IndexedProperty prop, Object value, int index) {
                listener.propertyInserted(prop, value, index);
            }
        });
    }

    private void fireIndexEvent(final IndexedProperty property, final PropertyContext context,
        final Object bean, final Object value, final int index, final IndexEventHandler handler) {
        // if we are not on the swing thread then invoke this method on the swing thread...
        if(property instanceof ObservableInterface) {
            fireIndexEvent(((ObservableInterface)property).getDelegate().getListeners(), property, value, index, handler);
        }
        fireIndexEvent(context.delegate.getListeners(), property, value, index, handler);
        ObservableDelegate<PropertyListener> d = null;
        if(bean instanceof ObservableInterface) {
            d = ((ObservableInterface)bean).getDelegate();
        } 
        if(d != null) {
            fireIndexEvent(d.getListeners(), property, value, index, handler);
        }
        fireIndexEvent(getContext(bean).delegate.getListeners(), property, value, index, handler);
    }

    /**
     * Returns true if the given listener is bound to the appropriate object. The object
     * is assumed to be a property/context if not it is assumed to be a bean.
     */
    public boolean isListening(Object o, PropertyListener listener) {
        ObservableDelegate<PropertyListener> delegate = null;
        if(o instanceof ObservableInterface) {
            delegate = ((ObservableInterface)o).getDelegate();
        } else {
            if(o instanceof BeanContext) {
                delegate = ((BeanContext)o).delegate;
            }
        }
        if(delegate == null) {
            return false;
        }
        List<PropertyListener> listeners = delegate.getListeners();
        return listeners != null && listeners.contains(listener);
    }
    
    /**
     * Fires the property change event to all the listeners
     */
    private void fireIndexEvent(List<PropertyListener> listeners, final IndexedProperty property, final Object value, final int index, final IndexEventHandler handler) {
        if(listeners != null) {
            for(PropertyListener listener : listeners) {
                ThreadManager m = ThreadManager.getManager(listener);
                if(!m.isRightThread()) {
                    final PropertyListener finalListener = listener;
                    m.invokeAndWait(new Runnable() {
                        public void run() {
                            if(finalListener instanceof IndexedPropertyListener) {
                                handler.fireEvent((IndexedPropertyListener)finalListener, property, value, index);
                            }
                        }
                    });
                    continue;
                }
                if(listener instanceof IndexedPropertyListener) {
                    handler.fireEvent((IndexedPropertyListener)listener, property, value, index);
                }
            }
        }
    }

    /**
     * Fires a property change event from the given bean, this method is threadsafe even
     * though most of the rest of the code isn't
     */
    void firePropertyChanged(final BaseProperty property, final PropertyContext context, 
        final Object bean, final Object oldValue, final Object newValue, final int index) {
        if(property instanceof ObservableInterface) {
            firePropertyChanged(((ObservableInterface)property).getDelegate().getListeners(), property, oldValue, newValue, index);
        }
        firePropertyChanged(context.delegate.getListeners(), property, oldValue, newValue, index);
        ObservableDelegate<PropertyListener> d = null;
        if(bean instanceof ObservableInterface) {
            d = ((ObservableInterface)bean).getDelegate();
        }
        if(d != null) {
            firePropertyChanged(d.getListeners(), property, oldValue, newValue, index);
        }
        firePropertyChanged(getContext(bean).delegate.getListeners(), property, oldValue, newValue, index);
    }

    /**
     * Fires the property change event to all the listeners
     */
    private void firePropertyChanged(List<PropertyListener> listeners, final BaseProperty property, final Object oldValue, final Object newValue, final int index) {
        if(listeners != null) {
            for(PropertyListener listener : listeners) {
                ThreadManager m = ThreadManager.getManager(listener);
                if(!m.isRightThread()) {
                    final PropertyListener finalListener = listener;
                    m.invokeAndWait(new Runnable() {
                        public void run() {
                            finalListener.propertyChanged(property, oldValue, newValue, index);
                        }
                    });
                    continue;
                }
                
                listener.propertyChanged(property, oldValue, newValue, index);
            }
        }
    }
    
    /**
     * Adds a listener that allows vetoing a property change
     */
    public void addVetoListener(final BaseProperty prop, final VetoListener listener) {
        // property listeners should be added on the swing thread to prevent a race
        // condition where fire is still waiting for the swing thread and a new listener
        // is already registered
        ThreadManager m = ThreadManager.getManager(listener);
        if(!m.isRightThread()) {
            m.invokeAndWait(new Runnable() {
                public void run() {
                    addVetoListener(prop, listener);
                }
            });
            return;
        }
        ((VetoInterface)prop).getVetoDelegate().addListener(listener);
    }

    /**
     * Removes a listener that allows vetoing a property change
     */
    public void removeVetoListener(final BaseProperty prop, final VetoListener listener) {
        // property listeners should be added on the swing thread to prevent a race
        // condition where fire is still waiting for the swing thread and a new listener
        // is already registered
        ThreadManager m = ThreadManager.getManager(listener);
        if(!m.isRightThread()) {
            m.invokeAndWait(new Runnable() {
                public void run() {
                    removeVetoListener(prop, listener);
                }
            });
            return;
        }
        ((VetoInterface)prop).getVetoDelegate().removeListener(listener);
    }
    
    /**
     * Adds a listener that allows vetoing a property change
     */
    public void addVetoListener(final PropertyContext prop, final VetoListener listener) {
        // property listeners should be added on the swing thread to prevent a race
        // condition where fire is still waiting for the swing thread and a new listener
        // is already registered
        ThreadManager m = ThreadManager.getManager(listener);
        if(!m.isRightThread()) {
            m.invokeAndWait(new Runnable() {
                public void run() {
                    addVetoListener(prop, listener);
                }
            });
            return;
        }
        ((VetoInterface)prop).getVetoDelegate().addListener(listener);
    }

    /**
     * Removes a listener that allows vetoing a property change
     */
    public void removeVetoListener(final PropertyContext prop, final VetoListener listener) {
        // property listeners should be added on the swing thread to prevent a race
        // condition where fire is still waiting for the swing thread and a new listener
        // is already registered
        ThreadManager m = ThreadManager.getManager(listener);
        if(!m.isRightThread()) {
            m.invokeAndWait(new Runnable() {
                public void run() {
                    removeVetoListener(prop, listener);
                }
            });
            return;
        }
        ((VetoInterface)prop).getVetoDelegate().removeListener(listener);
    }
    
    // TODO: This method might need to run on the event thread!
    boolean checkVeto(final BaseProperty property, final Object oldValue, final Object newValue, final int index) {
        // we might need to invoke this method on the event thread???
        
        if(property instanceof VetoInterface) {
            for(VetoListener listener : ((VetoInterface)property).getVetoDelegate().getListeners()) {
                if(!listener.propertyChangeCheck(property, oldValue, newValue, index)) {
                    return false;
                }
            }
        }
        
        PropertyContext context = property.getContext();

        List<VetoListener> list = ((VetoInterface)context).getVetoDelegate().getListeners();
        if(list != null) {
            for(VetoListener listener : list) {
                if(!listener.propertyChangeCheck(property, oldValue, newValue, index)) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    // 
    // Following are compatibility related methods for observing legacy
    // property fields
    //
    
    /**
     * Compatibility method to allow a bean to track veto change events
     */
    public void addVetoableChangeListener(final Object bean, final String property, final VetoableChangeListener l) {
        PropertyContext p = getContext(bean).getContext(property);
        // fail silently for compatibility
        if(p != null) {
            ((VetoInterface)p.getValue(bean)).getVetoDelegate().addListener(new VetoableChangeAdapter(l));
        }
    }

    /**
     * Compatibility method to allow a bean to track veto change events
     */
    public void removeVetoableChangeListener(final Object bean, final String property, final VetoableChangeListener l) {
        PropertyContext p = getContext(bean).getContext(property);
        // fail silently for compatibility
        if(p != null) {
            ((VetoInterface)p.getValue(bean)).getVetoDelegate().removeListener(l);
        }
    }
    
    /**
     * Compatibility method to allow a bean to track property change events
     */
    public void addPropertyChangeListener(final Object bean, final PropertyChangeListener l) {
        addListener(bean, new PropertyChangeAdapter(l));
    }

    /**
     * Compatibility method to allow a bean to track property change events
     */
    public void addPropertyChangeListener(Object bean, String n, PropertyChangeListener l) {
        PropertyContext p = getContext(bean).getContext(n);
        // fail silently for compatibility
        if(p != null) {
            ((ObservableInterface)p.getValue(bean)).getDelegate().addListener(new PropertyChangeAdapter(l));
        }
    }
    
    /**
     * Compatibility method to allow a bean to track property change events
     */
    public void removePropertyChangeListener(Object bean, PropertyChangeListener l) {
        getContext(bean).delegate.removeListener(l);
    }

    /**
     * Compatibility method to allow a bean to track property change events
     */
    public void removePropertyChangeListener(Object bean, String n, PropertyChangeListener l) {
        PropertyContext c = getContext(bean).getContext(n);
        // fail silently for compatibility
        if(c != null) {
            ((ObservableInterface)c.getValue(bean)).getDelegate().removeListener(l);
        }
    }    
    
    /**
     * Used to generalize the functionality of lifecycle event handling
     */
    private static interface IndexEventHandler {
        public void fireEvent(IndexedPropertyListener listener, IndexedProperty prop, Object value, int index);
    }

    /**
     * Used to generalize the functionality of lifecycle event handling
     */
    private static interface MapEventHandler {
        public void fireEvent(MapPropertyListener listener, MapProperty prop, Object key, Object value);
    }
    
    /**
     * This interface allows the binding engine to dynamically add additional constraint 
     * annotations
     */
    public static interface ConstraintFactory {
        /**
         * Returns the constraint from the given field or null if the constraint is
         * not present. Fills up the messages list with the message strings for
         * the constraint. Returns null if the annotation isn't defined in the field.
         */
        public void createConstraint(Field field, PropertyContext context, final ResourceFetch messages) 
        throws InstantiationException, IllegalAccessException;
    }
    
    /**
     * A simple class that can load resources either from the bundle or return them directly
     */
    public static class ResourceFetch {
        private ResourceBundle bundle;
        private String beanName;
        ResourceFetch(ResourceBundle bundle, String beanName) {
            this.bundle = bundle;
            this.beanName = beanName;
        }

        public String getValue(PropertyContext property, String postfix, String localized, String... args) {
            return getValue(property.getName() + "." + postfix, localized, args);
        }
        
        public String getValue(String postfix, String localized, String... args) {
            if(localized != null && localized.length() > 0) {
                return bundle.getString(localized);
            }
            for(String s : args) {
                if(s.length() > 0) {
                    return s;
                }
            }
            return "";
        }

        protected ResourceBundle getBundle() {
            return bundle;
        }

        protected String getBeanName() {
            return beanName;
        }
    }
    
    private static class LocalizedResourceFetch extends ResourceFetch {
        private List<String> keys;
        LocalizedResourceFetch(ResourceBundle bundle, String beanName) {
            super(bundle, beanName);
            keys = Collections.list(getBundle().getKeys());
        }

        public String getValue(String postfix, String localized, String... args) {
            String val = getBeanName() + "." + postfix;
            if(keys.contains(val)) {
                return getBundle().getString(val);
            }
            return super.getValue(postfix, localized, args);
        }
    }
    
    /**
     * A mergepoint allows us to track changes to a bean and its properties and then
     * roll them back to their initial values.
     * 
     * @see BeanContainer#initMergePoint
     * @see BeanContainer#strictMergePoint
     */
    public abstract static class MergePoint implements PropertyListener {
        private Object bean;
        MergePoint(Object bean) {
            this.bean = bean;
            BeanContainer.get().addListener(bean, this);
        }

        /**
         * Should return the modified properties
         */
        abstract List<Property> getProperties();

        /**
         * Inidicates whether the bean was modified at some point
         */
        public boolean isModified() {
            return !getProperties().isEmpty();
        }
        
        /**
         * Removes the property tracking and essentially eliminates this merge point
         */
        public void dispose() {
            BeanContainer.get().removeListener(bean, this);
        }
        
        /**
         * Merges the changes only into the given bean of the same type
         */
        public void mergeInto(Object bean) {
            Iterator<Property> iter = getProperties().iterator();
            while(iter.hasNext()) {
                Property p = iter.next();
                ((WProperty)p.getContext().getValue(bean)).set(p.get());
            }
        }
    }

    /**
     * A mergepoint allows us to track changes to a bean and its properties and then
     * roll them back to their initial values.
     * 
     * @see BeanContainer#strictMergePoint
     * @see BeanContainer#initMergePoint
     */
    private static class StandardMergePoint extends MergePoint {
        private List<Property> properties = new ArrayList<Property>();
        StandardMergePoint(Object bean) {
            super(bean);
        }
        
        /**
         * @inheritDoc
         */
        @Override
        List<Property> getProperties() {
            return properties;
        }
        
        /**
         * @inheritDoc
         */
        @Override
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
            if(!properties.contains(prop)) {
                properties.add((Property)prop);
            }
        }
    }

    /**
     * A mergepoint allows us to track changes to a bean and its properties and then
     * roll them back to their initial values.
     * 
     * @see BeanContainer#strictMergePoint
     * @see BeanContainer#initMergePoint
     */
    public static class StrictMergePoint extends MergePoint {
        private Map<Property, Object> properties = new HashMap<Property, Object>();
        StrictMergePoint(Object bean) {
            super(bean);
        }
        
        /**
         * @inheritDoc
         */
        @Override
        List<Property> getProperties() {
            return new ArrayList<Property>(properties.keySet());
        }
        
        /**
         * @inheritDoc
         */
        @Override
        public boolean isModified() {
            return !properties.isEmpty();
        }

        /**
         * Rolls back the component to its original state, notice events will be fired as expected
         */
        public void rollback() {
            while(properties.size() > 0) {
                Property prop = properties.keySet().iterator().next();
                prop.set(properties.get(prop));
            }
        }
        
        /**
         * @inheritDoc
         */
        @Override
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
            Object val = properties.get(prop);
            if(val == null) {
                properties.put((Property)prop, oldValue);
                return;
            }
            if(val == newValue || val.equals(newValue)) {
                properties.remove(prop);
            }
        }
    }
}
