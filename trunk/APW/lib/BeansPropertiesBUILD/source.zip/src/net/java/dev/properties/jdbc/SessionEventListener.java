package net.java.dev.properties.jdbc;

public interface SessionEventListener {

	void preUpdate(Object o);
	void postUpdate(Object o);

	void preInsert(Object o);
	void postInsert(Object o);

	void preDelete(Object o);
	void postDelete(Object o);

	void onLoad(Object o);
	
}
