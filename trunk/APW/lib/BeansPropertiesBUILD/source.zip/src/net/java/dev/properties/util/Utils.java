/*
 * Utils.java
 *
 * Created on March 11, 2007, 12:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.util;

import java.lang.reflect.Array;
import java.util.Collection;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import net.java.dev.properties.IndexedProperty;

/**
 * General static utility methods
 *
 * @author Shai Almog
 */
public class Utils {
    
    private Utils() {
    }

    /**
     * Used when a property must be set to zero since null can't be accepted
     */
    public static Number createZero(Class numberClass) {
        if(Double.class.isAssignableFrom(numberClass)) {
            return Double.valueOf(0);
        }
        if(Float.class.isAssignableFrom(numberClass)) {
            return Float.valueOf(0);
        }
        if(Integer.class.isAssignableFrom(numberClass)) {
            return Integer.valueOf(0);
        }
        if(Long.class.isAssignableFrom(numberClass)) {
            return Long.valueOf(0);
        }
        if(Byte.class.isAssignableFrom(numberClass)) {
            return Byte.valueOf((byte)0);
        }
        if(Short.class.isAssignableFrom(numberClass)) {
            return Short.valueOf((short)0);
        }
        if(BigDecimal.class.isAssignableFrom(numberClass)) {
            return BigDecimal.valueOf(0);
        }
        if(BigInteger.class.isAssignableFrom(numberClass)) {
            return BigInteger.valueOf(0);
        }
        throw new IllegalArgumentException("Unknown number subclass: " + numberClass.getName());
    }
    
    /**
     * Fucking generics gets fucked when an integer is sent by the view and
     * we need to guard against that. This method makes sure the given number is
     * of the right primitive wrapper type...
     */
    public static Number normalizeType(Number n, Class numberClass) {
        if(n.getClass() == numberClass) {
            return n;
        }
        if(Double.class.isAssignableFrom(numberClass)) {
            return Double.valueOf(n.doubleValue());
        }
        if(Float.class.isAssignableFrom(numberClass)) {
            return Float.valueOf(n.floatValue());
        }
        if(Integer.class.isAssignableFrom(numberClass)) {
            return Integer.valueOf(n.intValue());
        }
        if(Long.class.isAssignableFrom(numberClass)) {
            return Long.valueOf(n.longValue());
        }
        if(Byte.class.isAssignableFrom(numberClass)) {
            return Byte.valueOf(n.byteValue());
        }
        if(Short.class.isAssignableFrom(numberClass)) {
            return Short.valueOf(n.shortValue());
        }
        if(BigDecimal.class.isAssignableFrom(numberClass)) {
            return BigDecimal.valueOf(n.doubleValue());
        }
        if(BigInteger.class.isAssignableFrom(numberClass)) {
            return BigInteger.valueOf(n.longValue());
        }
        throw new IllegalArgumentException("Unknown number subclass: " + numberClass.getName());
    }

    /**
     * For a class instance that is primiteve return the non primitive version
     */
    public static Class getNonPrimitive(Class numberClass) {
        if(double.class == numberClass) {
            return Double.class;
        }
        if(float.class == numberClass) {
            return Float.class;
        }
        if(int.class == numberClass) {
            return Integer.class;
        }
        if(long.class == numberClass) {
            return Long.class;
        }
        if(byte.class == numberClass) {
            return Byte.class;
        }
        if(short.class == numberClass) {
            return Short.class;
        }
        if(char.class == numberClass) {
            return Character.class;
        }
        if(boolean.class == numberClass) {
            return Boolean.class;
        }
        throw new IllegalArgumentException("The submitted class is not a primitive type class: " + numberClass);
    }
    
    /**
     * For a class instance that is not primiteve return the primitive version
     */
    public static Class getPrimitive(Class numberClass) {
        if(Double.class == numberClass) {
            return double.class;
        }
        if(Float.class == numberClass) {
            return float.class;
        }
        if(Integer.class == numberClass) {
            return int.class;
        }
        if(Long.class == numberClass) {
            return long.class;
        }
        if(Byte.class == numberClass) {
            return byte.class;
        }
        if(Short.class == numberClass) {
            return short.class;
        }
        if(Character.class == numberClass) {
            return char.class;
        }
        if(Boolean.class == numberClass) {
            return boolean.class;
        }
        throw new IllegalArgumentException("The submitted class is a primitive type class: " + numberClass);
    }
    
    /**
     * Utility method to make the default display name "prettier"... It does this
     * by capitalizing the first letter and subsequently inserting a space before every 
     * other capital letter.
     */
    public static String prettyName(String name) {
        if(name.length() == 0) {
            return name;
        }
        StringBuilder b = new StringBuilder();
        b.append(Character.toUpperCase(name.charAt(0)));
        for(int iter = 1 ; iter < name.length() ; iter++) {
            char current = name.charAt(iter);
            if(Character.isUpperCase(current)) {
                b.append(" ");
            }
            b.append(current);
        }
        return b.toString();
    }

    /**
     * Takes an array that might be a primitive array and converts it to the
     * given collection. This works better than Arrays.asList() since that
     * tool doesn't work properly with primitives. Returns the variable passed in
     * col for convenience
     */
    public static <T> Collection<T> addToCollection(Object array, Collection<T> col) {
        int size = Array.getLength(array);
        for(int iter = 0 ; iter < size ; iter++) {
            col.add((T)Array.get(array, iter));
        }
        return col;
    }

    /**
     * Accepts a collection which is then copied into the property
     */
    public static <T> void updateIndexedProperty(IndexedProperty<T> prop, Collection<T> c) {
        int position = 0;
        
        // shrink the indexed property if its too big
        while(prop.size() > c.size()) {
            prop.remove(prop.size() - 1);
        }
        
        // insert/update the properties
        for(T current : c) {
            if(prop.size() <= position) {
                prop.add(current);
            } else {
                T t = prop.get(position);
                if(t != current && t != null && (!t.equals(current))) {
                    prop.set(position, t);
                }
            }
        }
    }

    /**
     * Converts the given property to an array copy
     */
    public static <T> Object[] asArray(IndexedProperty<T> prop) {
        return (Object[])asArray(prop, Object.class);
    }

    /**
     * Converts the given property to an array copy
     */
    public static <T> Object asArray(IndexedProperty<T> prop, Class type) {
        int size = prop.size();
        Object a = Array.newInstance(type, size);
        if(a.getClass().getComponentType().isPrimitive()) {
            for(int iter = 0 ; iter < size ; iter++) {
                Array.set(a, iter, prop.get(iter));
            }
        } else {
            Object[] array = (Object[])a;
            for(int iter = 0 ; iter < size ; iter++) {
                array[iter] = prop.get(iter);
            }
        }
        return a;
    }


    /**
     * Wrapps the given property as a java.util.list
     */
    public static <T> List<T> asList(final IndexedProperty<T> property) {
        return new List<T>() {
            public Object[] toArray() {
                Object[] arr = new Object[size()];
                toArrayImpl(arr);
                return arr;
            }

            public List<T> subList(int fromIndex, int toIndex) {
                List<T> a = new ArrayList<T>();
                for(int iter = fromIndex ; iter <= toIndex ; iter++) {
                    a.add(get(iter));
                }
                return a;
            }

            public int size() {
                return property.size();
            }

            public void clear() {
                while(property.size() > 0) {
                    property.remove(property.size() - 1);
                }
            }

            public boolean isEmpty() {
                return property.size() == 0;
            }

            public Iterator<T> iterator() {
                return property.iterator();
            }

            public ListIterator<T> listIterator() {
                return listIterator(0);
            }

            public boolean remove(Object o) {
                property.remove((T)o);
                
                // not correct but it will do.
                return true;
            }

            public boolean contains(Object o) {
                for(int iter = 0 ; iter < property.size() ; iter++) {
                    if(property.get(iter).equals(o)) {
                        return true;
                    }
                }
                return false;
            }

            public int indexOf(Object o) {
                for(int iter = 0 ; iter < property.size() ; iter++) {
                    if(property.get(iter).equals(o)) {
                        return iter;
                    }
                }
                return -1;
            }

            public int lastIndexOf(Object o) {
                for(int iter = property.size() - 1 ; iter >= 0 ; iter--) {
                    if(property.get(iter).equals(o)) {
                        return iter;
                    }
                }
                return -1;
            }

            public <U> U[] toArray(U[] a) {
                toArrayImpl(a);
                return a;
            }

            public void toArrayImpl(Object[] a) {
                for(int iter = 0 ; iter < property.size() ; iter++) {
                    a[iter] = property.get(iter);
                }
            }

            public T remove(int index) {
                T t = property.get(index);
                property.remove(index);
                return t;
            }

            public ListIterator<T> listIterator(final int index) {
                return new ListIterator<T>() {
                    private int offset = index;
                    public void remove() {
                        property.remove(offset);
                    }

                    public int previousIndex() {
                        return offset - 1;
                    }

                    public T previous() {
                        offset--;
                        return property.get(offset);
                    }

                    public int nextIndex() {
                        return offset + 1;
                    }

                    public T next() {
                        offset++;
                        return property.get(offset);
                    }

                    public boolean hasPrevious() {
                        return offset > index;
                    }

                    public boolean hasNext() {
                        return offset + 1 < property.size();
                    }

                    public void set(T e) {
                        property.set(offset, e);
                    }

                    public void add(T e) {
                        property.add(offset, e);
                    }
                };
            }

            public T get(int index) {
                return property.get(index);
            }

            public boolean retainAll(Collection<?> c) {
                throw new UnsupportedOperationException("Retain all unsupported in list compatibility");
            }

            public boolean removeAll(Collection<?> c) {
                for(Object current : c) {
                    property.remove((T)current);
                }
                return c.size() > 0;
            }

            public boolean add(T e) {
                property.add(e);
                return true;
            }

            public boolean containsAll(Collection<?> c) {
                for(Object current : c) {
                    if(!contains(current)) {
                        return false;
                    }
                }
                return true;
            }

            public boolean addAll(int index, Collection<? extends T> c) {
                for(T current : c) {
                    property.add(index, current);
                    index++;
                }
                return c.size() > 0;
            }

            public boolean addAll(Collection<? extends T> c) {
                for(T current : c) {
                    property.add(current);
                }
                return c.size() > 0;
            }

            public T set(int index, T element) {
                T old = property.get(index);
                property.set(index, element);
                return old;
            }

            public void add(int index, T element) {
                property.add(index, element);
            }            
        };
    }
}
