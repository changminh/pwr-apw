package net.java.dev.properties.jdbc.handlers;


/**
 * 
 * If a type handler is needed it is usually constructed by the TypeHandlerFactory
 * by calling new instance on the type handler's class.  There are some types that
 * will not be constructed properly using this method.  For example EntityHandler's
 * These will get cloned from the copy the TypeHandlerFactory has.
 * 
 * @author Glen Marchesani
 */
public interface CloneableTypeHandler<T> extends TypeHandler<T> {
	CloneableTypeHandler<T> clone();
}
