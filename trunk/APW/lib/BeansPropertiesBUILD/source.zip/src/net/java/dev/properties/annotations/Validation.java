/*
 * Attributes.java
 *
 * Created on February 21, 2007, 6:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.annotations;

import java.lang.annotation.*;
import net.java.dev.properties.constraints.*;

/**
 * A custom constraint allows us to define a constraint for a given bean which
 * will prevent setting a bad value. Rather than adding a constraint manually to
 * a property we can just specify the constrint class using this annotation. 
 * Furthermore, we can customize the behavior of constraint failure using this annotation
 * so a constraint failure could trigger an exception etc...
 *
 * @author Shai Almog
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Validation {
    /**
     * The class of the constraint that can optionally be installed onto the property
     */
    Class<? extends Constraint> constraint() default EmptyConstraint.class;
    
    /**
     * Behavior of the property when a constraint fails this can be one of:
     * CHANGE_AS_USUAL (default), DO_NOTHING or THROW_EXCEPTION.
     * 
     * @see net.java.dev.properties.constraints.Failed
     */
    Failed onFail() default Failed.CHANGE_AS_USUAL;

    /**
     * The validation messae passed into the constraint object
     */
    String message() default "Validation failed";

    /**
     * The localizable validation messae passed into the constraint object
     */
    String messageL() default "";
}
