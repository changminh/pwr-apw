/*
 * Constraint.java
 *
 * Created on February 22, 2007, 9:40 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

import net.java.dev.properties.BaseProperty;

/**
 * Defines a constraint interface that allows us to place limitations on property
 * states thus preventing certain operations on a property. A constraint failure
 * can have many implications defined within the property context.
 * <p>Constraints can be added/traversed programmatically through the {@link net.java.dev.properties.container.PropertyContext}
 * API or they can be added decleratively via the annotations package API.
 *
 * @author Shai Almog
 */
public interface Constraint<T> extends java.io.Serializable {
    /**
     * Returns true if the constraint passes validation on the given property 
     * for the given value or false otherwise. Notice that the value argument
     * MUST be used for validation and not prop.get() since the property value
     * would still match the old value of the constraint.
     */
    public boolean validate(BaseProperty<T> prop, T value);
}
