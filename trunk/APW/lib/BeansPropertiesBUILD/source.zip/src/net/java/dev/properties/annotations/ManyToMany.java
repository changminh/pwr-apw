package net.java.dev.properties.annotations;

import static java.lang.annotation.ElementType.FIELD;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Used by the ORM code allows us to specify a many to many relation between properties
 *
 * @author Glen Marchesani
 */

@Target(FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ManyToMany {

    /**
     * Name of the table connecting the two properties
     */
    String tableName() default "";

    /**
     * Name of the key column on the local database table
     */
    String localKeyColumns() default "";

    /**
     * Name of the foreign key column on the foreign database table
     */
    String foreignKeyColumns() default "";

    /**
     * In a bidirectional many to many only one side can be used for updating the
     * DB.  Set transientSide=true for the side you don't want used for updating/synchronizing
     * with the DB.
     */
    boolean transientSide() default false;
	
}
