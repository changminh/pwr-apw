/*
 * NotNullConstraint.java
 *
 * Created on February 22, 2007, 9:45 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

import net.java.dev.properties.BaseProperty;

/**
 * Simple implementation defining a not null constraint for a given value
 *
 * @see net.java.dev.properties.annotations.NotNull
 * @author Shai Almog
 */
public class NotNullConstraint implements Constraint {
    /**
     * @inheritDoc
     */
    @Override
    public boolean validate(BaseProperty prop, Object value) {
        return value != null;
    }
}
