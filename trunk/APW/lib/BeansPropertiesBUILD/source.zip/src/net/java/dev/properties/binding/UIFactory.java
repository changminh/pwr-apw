/*
 * UIFactory.java
 *
 * Created on March 6, 2007, 6:25 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.IndexedPropertyImpl;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.constraints.ValidationManager;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;

/**
 * The UI factory is a tool that automatically creates a form UI to match a given
 * bean. It uses the properties of the given bean to create fields and entries
 * appropriately and can accept simple hints when needed, all properties are
 * bound and validated transparently. This is mostly useful for form based 
 * applications where the requirements include a great deal of uniform data entry.
 *
 * @author Shai Almog
 */
public abstract class UIFactory<C> {
    /**
     * The component factory is responsible for creating/binding individual components
     * to the properties
     */
    public final Property<ComponentFactory<C>> componentFactory = PropertyImpl.create();
    
    /**
     * Contains the default placement for labels
     */
    public final Property<LabelPlacement<C>> defaultLabelPlacement = PropertyImpl.create(getLabelPalcementBeside());
    
    /**
     * Properties within this index would be ignored by the factory code
     */
    public final IndexedProperty<PropertyContext> ignoreProperties = IndexedPropertyImpl.create();
    
    /**
     * Allows us to lookup selection objects, this map indicates which property contexts
     * representing selection apply to which property contexts representing data.
     */
    private Map<PropertyContext, PropertyContext> selectionFor = new HashMap<PropertyContext, PropertyContext>();
    
    /**
     * Indicates where the UI expects a label to be created
     */
    private Map<PropertyContext, LabelPlacement<C>> labelPolicy = new HashMap<PropertyContext, LabelPlacement<C>>();
    
    /** Creates a new instance of UIFactory */
    protected UIFactory(ComponentFactory<C> factory) {
        BeanContainer.bind(this);
        componentFactory.set(factory);
    }
    
    /**
     * Creates the UI for the given bean
     */
    public C createBeanUI(Object bean) {
        C ui = createPropertiesUI(
            getPropertiesArray(BeanContainer.get().getContext(bean)));
        bindUI(bean, ui);
        return ui;
    }
    
    /**
     * Inidicates that the given property in an upcoming list combo etc... represents
     * the selection and should not cause an object creation
     */
    public void setSelectionFor(PropertyContext group, PropertyContext selection) {
        selectionFor.put(group, selection);
    }

    /**
     * Hints to the UI regarding whether or where a label should be placed on the component
     */
    public void setLabelPolicy(PropertyContext property, LabelPlacement<C> placement) {
        labelPolicy.put(property, placement);
    }

    /**
     * Binds the component to changes in selection within the given property
     * bound component.
     */
    public abstract void addPropertySelectionListener(PropertySelectionListener listener, IndexedProperty property, C component);
    
    /**
     * Returns the label placement rule for the component
     */
    public LabelPlacement<C> getPlacement(PropertyContext property) {
        LabelPlacement<C> p = labelPolicy.get(property);
        if(p == null) {
            return defaultLabelPlacement.get();
        }
        return p;
    }
    
    /**
     * Searches the for selection map values for the context and retrieves the selection
     * then searches the bean properties and retreaves the right instance.
     */
    private BaseProperty findSelection(PropertyContext context, BaseProperty[] properties) {
        for(Map.Entry<PropertyContext, PropertyContext> current : selectionFor.entrySet()) {
            if(current.getValue() == context) {
                context = current.getKey();
                for(BaseProperty p : properties) {
                    if(p.getContext() == context) {
                        return p;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Creates the UI for the given bean
     */
    public C createBeanUI(BeanContext bean) {
        return createPropertiesUI(getPropertiesArray(bean));
    }
    
    /**
     * Returns the properties for the bean that should be mapped without
     * ignored properties
     */
    public PropertyContext[] getPropertiesArray(BeanContext bean) {
        List<PropertyContext> result = new ArrayList<PropertyContext>();
        Iterator<PropertyContext> iter = bean.getProperties();
        List<PropertyContext> ignoreList = ignoreProperties.get();
        while(iter.hasNext()) {
            PropertyContext property = iter.next();
            if(!ignoreList.contains(property)) {
                result.add(property);
            }
        }
        PropertyContext[] arr = new PropertyContext[result.size()];
        result.toArray(arr);
        return arr;
    }
    
    /**
     * Creates the UI hierarchy with mapping to the given properties, this allows
     * the UI to be created once and bound to multiple bean instances later...
     */
    public C createPropertiesUI(PropertyContext[] properties) {
        Map<PropertyContext, PropertyContext> propertiesMap = new HashMap<PropertyContext, PropertyContext>();
        for(PropertyContext property : properties) {
            if(selectionFor.containsKey(property)) {
                propertiesMap.put(property, selectionFor.get(property));
            } else {
                if(!propertiesMap.containsKey(property)) {
                    propertiesMap.put(property, null);
                }
            }
        }
        
        C layout = createLayout(propertiesMap.size());        
        
        // when iterating go over the original array to preserve its order...
            for(PropertyContext property : properties) {
            if(!propertiesMap.containsKey(property)) {
                continue;
            }
            PropertyContext selection = propertiesMap.get(property);
            C component = componentFactory.get().createComponent(property, selection);
            add(layout, component, property);

        }
        layout = finishLayout(layout);
        return layout;
    }

    /**
     * This method receives a UI created by createPropertiesUI and binds it to
     * a bean instance
     */
    public void bindUI(Object bean, C layout) {
        componentFactory.get().bindComponentTree(this, bean, layout);
        getValidation().trackValidity(bean, layout);
    }
    
    /**
     * Creates a master-detail UI featuring a table and a means of editing it on
     * the fly.
     */
    public C createMasterDetail(IndexedProperty property, UIFactory<C> masterFactory) {
        return createMasterDetail(property, BeanContainer.get().getContext(property.getContext().getType()), masterFactory);
    }
    
    /**
     * Creates a master-detail UI featuring a table and a means of editing it on
     * the fly.
     */
    public C createMasterDetail(IndexedProperty property, BeanContext detail, UIFactory<C> masterFactory) {
        C master = masterFactory.createPropertiesUI(new PropertyContext[]{ property.getContext() });
        C detailView = createBeanUI(detail);
        bindMasterDetail(master, detailView, property);
        return combineMasterDetail(master, detailView);
    }
    
    /**
     * Binds the given UI as a master detail set, a master-detail 
     */
    protected abstract void bindMasterDetail(C master, C detail, IndexedProperty property);
    
    /**
     * Returns a single layout containing the master detail elements
     */
    protected abstract C combineMasterDetail(C master, C detail);
    
    /**
     * Returns the validation manager to use
     */
    protected abstract ValidationManager<C> getValidation();
    
    /**
     * Creates an instance of the container that would be populated with the objects
     */
    public abstract C createLayout(int elements);
    
    /**
     * Optional operation allowing layouts to be performed in the final stage
     */
    public C finishLayout(C layout) {
        return layout;
    }
    
    /**
     * Adds the given pair of components to the layout
     */
    public abstract void add(C layout, C component, PropertyContext property);

    /**
     * Returns an empty label placement policy
     */
    public abstract LabelPlacement<C> getLabelPalcementNone();

    /**
     * Returns a label placement policy for placing the label besides the component
     */
    public abstract LabelPlacement<C> getLabelPalcementBeside();

    /**
     * Returns a label placement policy for placing the label above the component
     */
    public abstract LabelPlacement<C> getLabelPalcementAbove();

    /**
     * Returns a label placement policy for placing the label as a border to the component
     */
    public abstract LabelPlacement<C> getLabelPalcementAsBorder();
    
    /**
     * Indicates the placement of the labels for a property context, this is a class
     * rather than an enum since an enum can't be generic (so we cannot adapt them for subclasses of this 
     * class)...
     * 
     * <p>The types are "None, Beside, Above and As border" which you get
     * by invoking the appropriate method. The right subclass in the appropriate
     * kit creates the appropriate instances.
     *
     * @author Shai Almog
     */
    public static class LabelPlacement<C> {
        /**
         * This method might return a physical label that needs to be layed out
         * or it might just annotate the component or do nothing.
         */
        public C createLabel(C component, PropertyContext context) {
            return null;
        }
    }
}
