/*
 * IndexedPropertyImpl.java
 *
 * Created on February 22, 2007, 8:43 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Basic implementation of the indexed property that does not support observability
 *
 * @author Shai Almog
 */
public class IndexedPropertyImpl<T> extends BasePropertyImpl<List<T>> implements IndexedProperty<T> {
    
    /** 
     * Creates a new instance of the object see the create method
     * 
     * @see #create
     */
    public IndexedPropertyImpl() {
        super.set(new ArrayList<T>());
    }

    /** 
     * Creates a new instance of the object see the create method
     * 
     * @see #create(Collection)
     */
    public IndexedPropertyImpl(Collection<T> l) {
        super.set(new ArrayList<T>(l));
    }

    /** 
     * Creates a new instance of the object see the create method
     */
    public IndexedPropertyImpl(T... arr) {
        super.set(new ArrayList<T>(Arrays.asList(arr)));
    }
    
    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> IndexedPropertyImpl<K> create() {
        return new IndexedPropertyImpl<K>();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> IndexedPropertyImpl<K> create(Collection<K> l) {
        return new IndexedPropertyImpl<K>(l);
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> IndexedPropertyImpl<K> create(K... arr) {
        return new IndexedPropertyImpl<K>(arr);
    }
    
    /**
     * @inheritDoc
     */
    public T get(int index) {
        return super.get().get(index);
    }
    
    /**
     * @inheritDoc
     */
    public void set(int index, T t) {
        super.get().set(index, t);
    }
    
    /**
     * Returns an iterator that does not enable removal
     */
    public Iterator<T> iterator() {
        return Collections.unmodifiableList(super.get()).iterator();
    }
    
    /**
     * @inheritDoc
     */
    public void add(int index, T t) {
        super.get().add(index, t);
    }
    
    /**
     * @inheritDoc
     */
    public void add(T t) {
        super.get().add(t);
    }
    
    /**
     * @inheritDoc
     */
    public void remove(T t) {
        super.get().remove(t);
    }
    
    /**
     * @inheritDoc
     */
    public void remove(int index) {
        super.get().remove(index);
    }

    /**
     * @inheritDoc
     */
    public int size() {
        return super.get().size();
    }
    
    /**
     * Returns an unmodifiable list to prevent external implementations from
     * bypassing the event handling
     */
    public List<T> get() {
        return Collections.unmodifiableList(super.get());
    }

    /**
     * @inheritDoc
     */
    public void set(List<T> t) {
        super.set(new ArrayList<T>(t));
    }
    
    /**
     * Used internally since the get() method returns an unmodifiable list
     */
    protected List<T> getModifiable() {
        return super.get();
    }
}
