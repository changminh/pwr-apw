/*
 * DemoInterface.java
 *
 * Created on April 14, 2007, 10:41 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 * An interface that can be implemented by demos 
 *
 * @author shai
 */
public interface DemoInterface {
    public String demoName();
    public String demoDescription();
    public String[] fileNames();
    public JComponent execute();
    public void cleanup();
    
    /**
     * Allows console demos to run within the demo framework
     */
    public static abstract class ConsoleDemo implements DemoInterface, Runnable {
        private JTextArea output;
        private PrintStream out;

        public PrintStream getOutput() {
            if(out == null) {
                out = new PrintStream(new ByteArrayOutputStream() {
                    public void write(byte[] b, int off, int len) {
                        super.write(b, off, len);
                        update(this);
                    }

                    public void write(byte[] b) throws IOException {
                        super.write(b);
                        update(this);
                    }

                    public void write(int b) {
                        super.write(b);
                        update(this);
                    }
                });
            }
            return out;
        }
        
        public void cleanup() {
            if(output != null) {
                output.setText("");
                out.close();
                out = null;
            }
        }

        private void update(ByteArrayOutputStream o) {
            try {
                o.flush();
                output.setText(new String(o.toByteArray()));
            } catch (IOException ex) {
                // this is just stupid
                ex.printStackTrace();
            }
        }

        public JComponent execute() {
            output = new JTextArea();
            output.setWrapStyleWord(true);
            output.setLineWrap(true);
            SwingUtilities.invokeLater(this);
            return new JScrollPane(output);
        }
    }

    public static abstract class DefaultConsoleDemo extends ConsoleDemo {
        private String[] fileNames;
        private String demoName;
        private String demoDescription;
        
        public DefaultConsoleDemo(String demoName, String demoDescription, Class[] classes) {
            this(demoName, demoDescription, DemoGUI.demoFiles(classes));
        }

        public DefaultConsoleDemo(String demoName, String demoDescription, String[] fileNames) {
            this.fileNames = fileNames;
            this.demoName = demoName;
            this.demoDescription = demoDescription;
        }
        
        public String[] fileNames() {
            return fileNames;
        }

        public String demoName() {
            return demoName;
        }

        public String demoDescription() {
            return demoDescription;
        }
    }
}
