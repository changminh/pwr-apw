package net.java.dev.properties.test.demos;

import java.util.Date;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;

/**
 * The wrap bean demonstrates how properties in the bean can be wrapped to produce
 * a totally different property, this is highlighted in the WrapDemo class.
 *
 * @author Shai Almog
 */
public class WrapBean {
    public final Property<String> firstName = new ObservableProperty<String>("");
    public final Property<String> surname = new ObservableProperty<String>("");
    public final Property<Date> dateOfBirth = new ObservableProperty<Date>(new Date());
    public final Property<Integer> value1 = new ObservableProperty<Integer>(3);
    public final Property<Integer> value2 = new ObservableProperty<Integer>(8);
    public final Property<Integer> value3 = new ObservableProperty<Integer>(17);
    
    public WrapBean() {
        BeanContainer.bind(this);
    }

}
