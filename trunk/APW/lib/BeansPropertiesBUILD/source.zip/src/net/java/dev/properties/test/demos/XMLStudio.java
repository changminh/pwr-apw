/*
 * XMLStudio.java
 *
 * Created on April 15, 2007, 11:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.demos;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.VirtualPropertyContext;
import net.java.dev.properties.test.DemoGUI;
import net.java.dev.properties.test.binding.studio.*;
import net.java.dev.properties.xml.DTD;
import net.java.dev.properties.xml.Serializer;
import org.xml.sax.SAXException;

/**
 * This version of the Yoga Studio Demo illustrates persisting the studio to and
 * From XML.
 *
 * @author shai
 */
public class XMLStudio extends Main {
    
    /** Creates a new instance of XMLDemo */
    protected StudioBeanInterface createStudio() {
        try {
            Class c = new StudioBean().getClass();
            BeanContext studentContext = BeanContainer.get().getContext(new StudentBean().getClass());
            VirtualPropertyContext id = new VirtualPropertyContext("id", Integer.class);
            studentContext.addVirtual(id);
            Serializer s = Serializer.createSerializer(BeanContainer.get().getContext(c));
            DTD dtd = new DTD(c);
            dtd.setIDProperty(id);
            StudioBean bean = (StudioBean) s.toBean(dtd, new InputStreamReader(getClass().getResourceAsStream("studio.xml")));
            studentContext.removeVirtualProperty(id);
            return bean;
        } catch(IOException ioErr) {
            // this should never occur since the file is being read from a resource
            ioErr.printStackTrace();
            return null;
        } catch (SAXException ex) {
            throw new BeanBindException(ex);
        }
    }
    
    public String[] fileNames() {
        return DemoGUI.demoFiles(new Class[]{ getClass(), Main.class, AttendanceBean.class, StudentBean.class, StudioBean.class, 
                YogaClassBean.class, getClass()});
    }

    public String demoName() {
        return "XML - Yoga Studio (Experimental)";
    }

    public String demoDescription() {
        return "<html><body><h1>XML Loaded Yoga Studio</h1>" +
                "This is an <b>experimental demo</b> highlighting the Yoga Studio loaded from an XML file. " +
                "Since XML bindings are in a relatively preliminary state this demo should be taken " +
                "as a proof of concept rather than as a tutorial. XML support is planned for milestone 2 " +
                "at the moment and the API is subject to change. However, the idea of transpaently mapping " +
                "properties to XML nodes and propogating changes back and forth would be in the final solution. " +
                "We plan to make properties <b>MUCH easier to use than JAXB</b> or any similar alternative.";
    }

    public JComponent execute() {
        try {
            JTextArea text = new JTextArea();
            text.setWrapStyleWord(true);
            text.setLineWrap(true);
            text.setEditable(false);
            Reader r = new InputStreamReader(getClass().getResourceAsStream("studio.xml"));
            char[] buffer = new char[65536];
            int size = r.read(buffer);
            while(size > 0) {
                text.append(new String(buffer, 0, size));
                size = r.read(buffer);
            }
            r.close();
            JSplitPane pane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, 
                    super.execute(), new JScrollPane(text));
            pane.setResizeWeight(0.6);
            return pane;
        } catch(IOException ioErr) {
            // this should never occur since the file is being read from a resource
            ioErr.printStackTrace();
            return null;
        } 
    }
}
