package net.java.dev.properties;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.java.dev.properties.BasePropertyImpl;

/**
 * A simple non-observable implementation of the map property
 *
 * @author Shai Almog
 */
public class MapPropertyImpl<K, T> extends BasePropertyImpl<Map<K, T>> implements MapProperty<K, T> {
    
    /** 
     * Creates a new instance of IndexedPropertyImpl 
     */
    public MapPropertyImpl() {
        super.set(new HashMap<K, T>());
    }

    public MapPropertyImpl(Map<K, T> l) {
        super.set(new HashMap<K, T>(l));
    }
    
    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K, T> MapPropertyImpl<K, T> create() {
        return new MapPropertyImpl<K, T>();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K, T> MapPropertyImpl<K, T> create(Map<K, T> l) {
        return new MapPropertyImpl<K, T>(l);
    }

    /**
     * @inheritDoc
     */
    public T get(K key) {
        return super.get().get(key);
    }
    
    /**
     * @inheritDoc
     */
    public void set(K key, T t) {
        super.get().put(key, t);
    }
    
    /**
     * Returns an iterator for the keys that does not enable removal
     */
    public Iterator<K> keyIterator() {
        return Collections.unmodifiableSet(get().keySet()).iterator();
    }
        
    /**
     * @inheritDoc
     */
    public void remove(K key) {
        get().remove(key);
    }
    
    /**
     * @inheritDoc
     */
    public int size() {
        return get().size();
    }    
}
