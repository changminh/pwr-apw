package net.java.dev.properties;

import java.util.Iterator;
import java.util.Map;

/**
 * An implementation of a property wrapper for a map property. For more details 
 * about property wrappers see the PropertyWrapper class.
 *
 * @see PropertyWrapper
 * @author Shai Almog
 */
public class MapPropertyWrapper<K, T> extends PropertyWrapper.ReadWrite<Map<K, T>> implements MapProperty<K, T> {
    public MapPropertyWrapper(MapProperty<K, T> property) {
        super(property);
    }

    /**
     * @inheritDoc
     */
    public MapProperty<K, T> getProperty() {
        return ((MapProperty<K, T>)super.getProperty());
    }
    
    /**
     * @inheritDoc
     */
    public T get(K key) {
        return getProperty().get(key);
    }
    
    /**
     * @inheritDoc
     */
    public void set(K key, T t) {
        getProperty().set(key, t);
    }
    
    /**
     * @inheritDoc
     */
    public Iterator<K> keyIterator() {
        return getProperty().keyIterator();
    }
    
    /**
     * @inheritDoc
     */
    public void remove(K key) {
        getProperty().remove(key);
    }
    
    /**
     * @inheritDoc
     */
    public int size() {
        return getProperty().size();
    }    
}