package net.java.dev.properties.jdbc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.jdbc.handlers.SingleEntityHandler;
import net.java.dev.properties.jdbc.handlers.TableGeneration;
import net.java.dev.properties.jdbc.handlers.TypeHandlerFactory;


/**
 * Contains all the configuration infomration needed for persisting classes to the DB
 * 
 * This is a singleton.
 * 
 * @author Glen Marchesani
 *
 */
public class SessionConfiguration {

    private static SessionConfiguration _instance;

    public static void setInstance(SessionConfiguration instance) {
		_instance = instance;
	}
    
    public static SessionConfiguration getInstance() {
    	if ( _instance == null ) {
    		_instance = new SessionConfiguration();
    	}
   		return _instance;
    }

    public final Property<TypeHandlerFactory> typeHandlerFactory = ObservableProperty.create(new TypeHandlerFactory());
    public final Property<ConnectionFactory> connectionFactory = ObservableProperty.create();

    private Map<Class, EntityPersister<?>> _persistersMap = new LinkedHashMap<Class, EntityPersister<?>>();

    // just in case they are needed later
    private Map<Class<?>, Object> _instances = new HashMap<Class<?>, Object>();
    
    private List<SessionEventListener> _listeners = new ArrayList<SessionEventListener>();

    private SessionConfiguration() {
    	BeanContainer.bind(this);
    }

    public <T> EntityPersister<T> addClass(Class<T> clazz) {
        return addClass(clazz, null);
    }

    public <T> EntityPersister<T> addClass(Class<T> clazz, T bean) {

        EntityPersister<T> entityPersister = getPersister(clazz);
        if (entityPersister != null) {
            return entityPersister;
        }

        if (bean == null) {
            try {
                bean = clazz.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        BeanContext beanContext = BeanContainer.get().getContext(clazz);
        
        // listen to binding of new instances that should be mapped to the ORM
        beanContext.addBindListener(new ORMThread.BindListener() {
            public void beanBound(Object bean, BeanContext context) {
                // iterate over all the properties and bind to the ORM every
                // non-transient field
                for(PropertyContext prop : context.getPropertiesArray()) {
                    if(!prop.isTransient()) {
                        // if this is a bidirectional relation we need
                        // to associate a foreign key 
                        if(prop.isBidirectional() || BeanContainer.get().isNewBean(prop.getType())) {
                            Association.bind(prop, bean);
                        }
                    }
                }
            }
        });

        entityPersister = new EntityPersister(clazz, beanContext, this);

        _persistersMap.put(clazz, entityPersister);
        _instances.put(clazz, bean);

        typeHandlerFactory.get().add(new SingleEntityHandler(entityPersister));

        entityPersister.setTableName(beanContext.getTableName());

        return entityPersister;
    }

    public Collection<EntityPersister<?>> getPersisters() {
        return _persistersMap.values();
    }

    public <T> EntityPersister<T> getPersister(Class<T> clazz) {
        return (EntityPersister<T>) _persistersMap.get(clazz);
    }


    public List<PropertyContext> getPrimaryKeyContexts(EntityPersister persister) {
        // search for the primary keys
        List<PropertyContext> primaryKeys = new ArrayList<PropertyContext>();
        for (PropertyContext prop : persister.getBeanContext().getPropertiesArray()) {
            if (prop.isKeyColumn()) {
                primaryKeys.add(prop);
            }
        }
        Collections.sort(primaryKeys, new Comparator<PropertyContext>() {

            public int compare(PropertyContext o1, PropertyContext o2) {
                return o1.getCompositeKeySequence() - o2.getCompositeKeySequence();
            }
        });

        return primaryKeys;
    }
    
    public List<SessionEventListener> getListeners() {
		return _listeners;
	}

    
    
    /**
     * Adds the given classes and makes sure to create all the tables with the given
     * arguments
     */
    public void addClassesAndCreateTables(boolean silentFaile, boolean dropTables, Class<?>... classes) {
        SessionConfiguration configuration = SessionConfiguration.getInstance();
        EntityPersister<?>[] persisters = new EntityPersister<?>[classes.length];
        for(int iter = 0 ; iter < classes.length ; iter++) {
            // we build the classes one by one and only then create the tables
            // this allows the relationships to form correctly when invoking
            // create table.
            persisters[iter] = configuration.addClass(classes[iter]);
        }
        
        for(EntityPersister<?> e : persisters) {
            e.createTable(silentFaile, dropTables);
        }
    }
    

    private List<TableGeneration> getTableGenerators() {
    	List<TableGeneration> tableGenerators = new ArrayList<TableGeneration>();
    	for( EntityPersister persister : getPersisters() ) {
    		tableGenerators.add(persister);
    	}
    	for( EntityPersister persister : getPersisters() ) {
    		for ( int i = 0 ; i<persister.getTypeHandlers().size(); i++ ) {
    			if ( persister.getTypeHandlers().get(i) instanceof TableGeneration ) {
    	    		tableGenerators.add((TableGeneration)persister.getTypeHandlers().get(i));    				
    			}
    		}
    	}
    	return tableGenerators;
    }

    public void createDatabaseTables() {
    	for( TableGeneration tableGenerator : getTableGenerators() ) {
    		tableGenerator.prepareForCreate();
    	}
        
    	for( TableGeneration tableGenerator : getTableGenerators() ) {
    		tableGenerator.createTable();
    	}    	
    }
    
    public void clearDatabaseTables() {
    	for( TableGeneration tableGenerator : getTableGenerators() ) {
            try {
                tableGenerator.clearTable();
            } catch(Exception err) {}
    	}    	
    }
    
    public void dropDatabaseTables() {
    	for( TableGeneration tableGenerator : getTableGenerators() ) {
    		tableGenerator.dropTable();
    	}
    }
    
}
