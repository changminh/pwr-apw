package net.java.dev.properties.test.demos;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.PropertyListener;
import net.java.dev.properties.test.DemoInterface;
import net.java.dev.properties.test.NewBean;

/**
 * A demo of using a new bean that matches the functionality of the legacy bean
 *
 * @author shai
 */
public class NewBeanDemo extends DemoInterface.DefaultConsoleDemo {
    public NewBeanDemo() {
        super("Hello World New Bean", "<html><body><h1>Hello World Bean-Properties</h1>" +
                "Demonstrates a hello world new bean, notice that unlike the legacy bean demo above " +
                "type safty is maintained and there is no need for the bean to implement features such as " +
                "listeners etc. they are all handled transparently. No strings are involved in the creation " +
                "of beans or their observability features.",
                new Class[] {NewBean.class, NewBeanDemo.class});
    }

    public void run() {
        NewBean bean = new NewBean();
        bean.x.set(1);
        getOutput().println("New bean x is: " + bean.x.get());
        PropertyListener l = new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
               getOutput().println("New bean " + prop.getContext().getName() + " was changed " + newValue);
            }
        };
        BeanContainer.get().addListener(bean, l);
        bean.x.set(2);
        BeanContainer.get().removeListener(bean, l);
        BeanContainer.get().addListener(bean.x, l);
        bean.x.set(3);
    }
}
