/*
 * ObservableIndexedWrapper.java
 *
 * Created on April 9, 2007, 1:41 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.IndexedPropertyWrapper;
import net.java.dev.properties.events.PropertyListener;

/**
 * Wrapper property that allows an indexed property to be wrapped yet observed
 *
 * @author Shai Almog
 */
public class ObservableIndexedWrapper<T> extends IndexedPropertyWrapper<T> implements ObservableInterface {
    
    /** Creates a new instance of ObservableIndexedWrapper */
    public ObservableIndexedWrapper(IndexedProperty<T> prop) {
        super(prop);
    }

    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<PropertyListener> getDelegate() {
        if(getProperty() instanceof ObservableInterface) {
            return ((ObservableInterface)getProperty()).getDelegate();
        }
        return null;
    }
}
