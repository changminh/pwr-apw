package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Types;

import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.PropertyContext;

/**
 * @author Glen Marchesani
 */
public class JavaDotSqlDotTimeHandler extends AbstractTypeHandler<Time> {

	public boolean canHandleType(Class<?> type) {
		return Time.class.equals(type);
	}
	
	@Override
	protected void initColumns() {
            PropertyContext pc = getPropertyContext();
            setColumn(ColumnContext.createSingleColumn(pc.getColumnName(),Types.DATE,pc.getMaxLength(255), pc.isNullable(), pc.getReadOnlyColumns()));
	}

	public void loadPreparedStatment(Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
		preparedStatement.setTime(preparedStatementOffset, (Time) columnValues[columnValuesOffset]);
	}

	public void loadProperty(WProperty<Time> property, ResultSet resultSet, int offset) throws SQLException {
		Time time = resultSet.getTime(offset);
		property.set(time);
	}
	
	public boolean doesEagerFetching() {
		return true;
	}

}
