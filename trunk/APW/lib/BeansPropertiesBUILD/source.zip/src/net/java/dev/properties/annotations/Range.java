/*
 * Attributes.java
 *
 * Created on February 21, 2007, 6:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.annotations;

import java.lang.annotation.*;

/**
 * Constraint for minimum/maximum value that automatically installs an instance of the 
 * class {@link net.java.dev.properties.constraints.RangeConstraint} onto the given
 * property.
 *
 * @author Shai Almog
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Range {
    /**
     * Minimum numeric value for the range of values
     */
    double min();

    /**
     * Maximum numeric value for the range of values
     */
    double max();

    /**
     * The validation messae passed into the constraint object
     */
    String message() default "Validation failed";

    /**
     * The localizable validation messae passed into the constraint object
     */
    String messageL() default "";
}
