package net.java.dev.properties.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * A helper class for queries that return a long.  Used by the IdGeneratorHandler code and 
 * because it is something often done I figured to make it a subclass.
 * 
 * @author Glen Marchesani
 *
 */
public class LongQueryExecutor extends QueryExecutor<Long> {

	
    public LongQueryExecutor(String query) {
        super(query,null,true);
    }
    
    public LongQueryExecutor(String query,Connection connection) {
        super(query,connection,true);
    }
    

	@Override
	protected Long processRow(ResultSet row) throws SQLException {
		return row.getLong(1);
	}
	
	

}
