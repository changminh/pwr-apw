/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters.impl;

import net.java.dev.properties.binding.swing.adapters.*;
import java.text.DateFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Date;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.constraints.swing.SwingValidation;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.util.Utils;

/**
 * Text component adapter is the only public adapter because it is essentially a 
 * bean that allows us to toggle its format. 
 *
 * @deprecated this class is an implementation detail and should not be used directly
 * @author Shai Almog
 */
public class TextComponentFormatAdapter extends SwingAdapter<Object, JTextComponent> implements DocumentListener {
    public final Property<Format> format = new PropertyImpl<Format>();

    public TextComponentFormatAdapter() {
        BeanContainer.bind(this);
    }
    
    protected void bindListener(BaseProperty<Object> property, JTextComponent cmp) {
        cmp.getDocument().addDocumentListener(this);
    }

    protected void unbindListener(BaseProperty<Object> property, JTextComponent cmp) {
        cmp.getDocument().removeDocumentListener(this);
    }

    
    protected void initFromProperty(BaseProperty<Object> property) {
        Class type = property.getContext().getType();
        if(Date.class.isAssignableFrom(type)) {
            format.set(DateFormat.getDateInstance(DateFormat.SHORT));
        } else {
            if(Number.class.isAssignableFrom(type)) {
                format.set(NumberFormat.getInstance());
            } 
        }
        super.initFromProperty(property);
    }
    
    protected void updateUI(Object newValue) {
        getComponent().setText(format.get().format(newValue));
    }            

    private void uiChanged() {
        try {
            String text = getComponent().getText();
            Class type = getProperty().getContext().getType();
            if(Number.class.isAssignableFrom(type)) {
                callWhenUIChanged(Utils.normalizeType((Number)format.get().parseObject(text), type));
            } else {
                callWhenUIChanged(format.get().parseObject(text));
            }
            SwingValidation.getInstance().setComponentValidity(getProperty(), getComponent(), true);
        } catch (ParseException ex) {
            // this exception should occur when some illegal input occured, it
            // should update the validity state of the object to false but
            // right now this is not so simple...
            SwingValidation.getInstance().setComponentValidity(getProperty(), getComponent(), false);
        }
    }
    
    public void removeUpdate(DocumentEvent e) {
        uiChanged();
    }

    public void insertUpdate(DocumentEvent e) {
        uiChanged();
    }

    public void changedUpdate(DocumentEvent e) {
        uiChanged();
    }

    protected Class getType() {
        return Object.class;
    }

    protected Class getComponentType() {
        return JTextComponent.class;
    }

    protected void setEmptyValue() {
        getComponent().setText("");
    }
}