/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.util.Utils;

/**
 * Implements list support for propagating UI changes, this class is made
 * public for subclasses in SwingX it is not intended for general use
 *
 *
 * @author Shai Almog
 */
public class TableIndicesAdapter extends SwingAdapter<List<Integer>, JTable> implements ListSelectionListener {
    protected void bindListener(BaseProperty<List<Integer>> property, JTable cmp) {
        cmp.getSelectionModel().addListSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<List<Integer>> property, JTable cmp) {
        cmp.getSelectionModel().removeListSelectionListener(this);
    }

    protected void updateUI(List<Integer> newValue) {
        getComponent().clearSelection();
        ListSelectionModel model = getComponent().getSelectionModel();
        for(Integer i : newValue) {
            model.addSelectionInterval(i, i);
        }
    }            

    public void valueChanged(ListSelectionEvent e) {
        callWhenUIChanged((List<Integer>)
        Utils.addToCollection(getComponent().getSelectedRows(), new ArrayList<Integer>()));
    }

    protected Class getType() {
        return List.class;
    }

    protected Class getComponentType() {
        return JTable.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}