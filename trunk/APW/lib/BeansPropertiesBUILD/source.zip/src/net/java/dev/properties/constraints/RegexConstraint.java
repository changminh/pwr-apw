package net.java.dev.properties.constraints;

import java.util.regex.Pattern;
import net.java.dev.properties.BaseProperty;

/**
 * A constraint for matching a given regular expression from start to finish
 *
 * @see net.java.dev.properties.annotations.Regex
 * @author Shai Almog
 */
public class RegexConstraint implements Constraint {
    private Pattern regex;
    
    public RegexConstraint(String regex) {
        this.regex = Pattern.compile(regex);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public boolean validate(BaseProperty prop, Object value) {
        return value != null && regex.matcher(value.toString()).matches();
    }
}
