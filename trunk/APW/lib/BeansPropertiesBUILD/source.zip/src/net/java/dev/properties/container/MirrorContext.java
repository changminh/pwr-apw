/*
 * MirrorContext.java
 *
 * Created on April 8, 2007, 11:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.beans.BeanInfo;
import java.beans.IndexedPropertyDescriptor;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.events.PropertyListener;
import net.java.dev.properties.util.Utils;

/**
 * A context object for the mirror object which allows us to obtain mirror instances
 * and track mirror state.
 *
 * @author shai
 */
public class MirrorContext {
    private static Map<Class, MirrorContext> contextMap = new HashMap<Class, MirrorContext>();
    private Mirror.MirrorVirtualPropertyContext[] contexts;
    private boolean reflectOnChange;
    private boolean trackBean;

    private MirrorContext(Class cls, boolean includeReadonly, boolean includeWriteOnly) {
        try {
            BeanInfo info = Introspector.getBeanInfo(cls);
            PropertyDescriptor[] descriptors = info.getPropertyDescriptors();
            List<Mirror.MirrorVirtualPropertyContext> list = new ArrayList<Mirror.MirrorVirtualPropertyContext>();
            int offset = 0;
            for(int iter = 0 ; iter < descriptors.length ; iter++) {
                String name = descriptors[iter].getName();
                boolean indexed = descriptors[iter] instanceof IndexedPropertyDescriptor ||
                        descriptors[iter].getPropertyType().isArray() ||
                        Collection.class.isAssignableFrom(descriptors[iter].getPropertyType());
                Class<?> type;
                Method read = descriptors[iter].getReadMethod();
                Method write = descriptors[iter].getWriteMethod();
                if((read == null && (!includeReadonly)) || (write == null && (!includeWriteOnly))) {
                    continue;
                }
                if(descriptors[iter] instanceof IndexedPropertyDescriptor) {
                    type = ((IndexedPropertyDescriptor)descriptors[iter]).getIndexedPropertyType();
                } else {
                    if(indexed) {
                        // we decided the property is indexed on our own without the
                        // java beans API... Ugh
                        if(descriptors[iter].getPropertyType().isArray()) {
                            type = descriptors[iter].getPropertyType().getComponentType();
                        } else {
                            // this is a collection, TODO: extract the generic type if
                            // such a type exists...
                            type = Object.class;
                        }
                    } else {
                        type = descriptors[iter].getPropertyType();
                    }
                }

                // primitive types for properties propogate bugs since bindings
                // such as Boolean in the JTable (or any other API) won't work
                // for Boolean.TYPE (the primitive type) and this is HELL to debug...
                // To avoid this pain the type is normallized to a typical wrapper type...
                if(type.isPrimitive()) {
                    type = normalize(type);
                }

                Mirror.MirrorVirtualPropertyContext vp = new Mirror.MirrorVirtualPropertyContext(name, indexed, type, offset, read, write);
                list.add(vp);
                vp.setDisplayName(Utils.prettyName(descriptors[iter].getDisplayName()));
                offset++;
            }
            contexts = new Mirror.MirrorVirtualPropertyContext[list.size()];
            list.toArray(contexts);
        } catch(IntrospectionException err) {
            throw new BeanBindException(err);
        }
    }
    
    private Mirror.MirrorVirtualPropertyContext getByName(String name) {
        for(Mirror.MirrorVirtualPropertyContext c : contexts) {
            if(c.getName().equals(name)) {
                return c;
            }
        }
        throw new IllegalArgumentException("Unknown property: " + name);
    }
    
    /**
     * Creates a context object that can be used to build mirrors
     *
     * @param reflectOnChange indicates whether the mirror should update the bean
     * whenever a value changes. If not the relflection can occur when the reflect()
     * method is invoked.
     * @param trackBean indicates that the mirror should bind itself to the add/remove
     * property change listener methods on the bean if they exist thus removing the
     * need for the update method. Notice that removePropertyChangeListener will
     * never be called but that doesn't make a difference if both the bean and the
     * mirror are GC'd!
     */
    public static MirrorContext create(Class bean, boolean reflectOnChange, boolean trackBean, boolean includeReadonly, boolean includeWriteOnly) {
        if(contextMap.containsKey(bean)) {
            throw new IllegalStateException("A mirror context for " + bean.getName() + 
                    " was already built... There can be only one mirror context per class type");
        }
        MirrorContext mc = new MirrorContext(bean, includeReadonly, includeWriteOnly);
        contextMap.put(bean, mc);
        BeanContainer.get().bindMirror(bean, mc.contexts);
        mc.reflectOnChange = reflectOnChange;
        mc.trackBean = trackBean;
        return mc;
    }

    /**
     * A default create method with sensible defaults for POJO's
     */
    public static MirrorContext create(Class bean) {
        return create(bean, true, false, false, false);
    }
    
    /**
     * This method will implicitly create a context if one doesn't exist using default values...
     */
    public static Mirror createStatic(Object bean) {
        MirrorContext c = contextMap.get(bean.getClass());
        if(c == null) {
            c = create(bean.getClass());
        }
        return c.create(bean);
    }
    
    /**
     * Creates a mirror for the given object
     */
    public Mirror create(Object bean) {
        return create(bean, reflectOnChange, trackBean);
    }


    /**
     * primitive types for properties propogate bugs since bindings
     * such as Boolean in the JTable (or any other API) won't work
     * for Boolean.TYPE (the primitive type) and this is HELL to debug...
     * To avoid this pain the type is normallized to a typical wrapper type...
     */
    private Class normalize(Class type) {
        if(type == Boolean.TYPE) return Boolean.class;
        if(type == Integer.TYPE) return Integer.class;
        if(type == Long.TYPE) return Long.class;
        if(type == Short.TYPE) return Short.class;
        if(type == Double.TYPE) return Double.class;
        if(type == Float.TYPE) return Float.class;
        if(type == Character.TYPE) return Character.class;
        if(type == Byte.TYPE) return Byte.class;
        throw new IllegalArgumentException("Unsupported type: " + type.getName());
    }

    private Mirror create(Object bean, boolean reflectOnChange, boolean trackBean) {
        final Mirror mirror = new Mirror.MirrorImpl(bean);
        BaseProperty[] properties = new BaseProperty[contexts.length];
        for(int iter = 0 ; iter < contexts.length ; iter++) {
            properties[iter] = contexts[iter].create(mirror);

            if(reflectOnChange && contexts[iter].isWriteable() && 
                    properties[iter] instanceof ObservableInterface) {
                BeanContainer.get().addListener(properties[iter], new PropertyListener() {
                    public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                        if(oldValue != newValue) {
                            ((Mirror.MirrorVirtualPropertyContext)prop.getContext()).reflect((RProperty)prop);
                        }
                    }
                });
            }
        }
        mirror.setProperties(properties);

        if(trackBean) {
            Mirror.invoke("addPropertyChangeListener", bean, new Object[] {new PropertyChangeListener() {
                public void propertyChange(PropertyChangeEvent evt) {
                    BaseProperty p = mirror.getProperty(evt.getPropertyName());
                    if(p != null && p instanceof WProperty) {
                        ((WProperty)p).set(evt.getNewValue());
                    }
                }
            }});
        }

        return mirror;
    }
}
