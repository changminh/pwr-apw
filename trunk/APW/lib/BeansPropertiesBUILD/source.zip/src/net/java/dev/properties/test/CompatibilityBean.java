/*
 * CompatibilityBean.java
 *
 * Created on February 21, 2007, 3:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import net.java.dev.properties.container.ObservableProperty;
import java.beans.*;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;

/**
 * This is new bean that provides a compatibility layer to appear like the legacy
 * bean.
 *
 * @author Shai Almog
 */
public class CompatibilityBean {
    public final Property<Integer> x = ObservableProperty.create();
    
    /** Creates a new instance of NewBean */
    public CompatibilityBean() {
        BeanContainer.bind(this);
    }
    
    public Integer getX() {
        return x.get();
    }

    public void setX(Integer x) {
        this.x.set(x);
    }
    
    public void addPropertyChangeListener(PropertyChangeListener l) {
        BeanContainer.get().addPropertyChangeListener(this, l);
    }

    public void addPropertyChangeListener(String n, PropertyChangeListener l) {
        BeanContainer.get().addPropertyChangeListener(this, n, l);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener l) {
        BeanContainer.get().removePropertyChangeListener(this, l);
    }

    public void removePropertyChangeListener(String n, PropertyChangeListener l) {
        BeanContainer.get().removePropertyChangeListener(this, n, l);
    }    
}
