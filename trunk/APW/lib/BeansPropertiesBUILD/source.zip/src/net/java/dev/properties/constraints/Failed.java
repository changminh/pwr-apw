/*
 * Failed.java
 *
 * Created on February 22, 2007, 10:13 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

/**
 * Indicates what should be done when a constraint failed. This enum allows
 * for a constraint to be performed despite the error that might occure for special
 * cases of "warnings" where a constraint can be violated but the user should be notified.
 * Futheremore, there are cases when constraints between values of two properties must
 * be temporarily violated in order to complete the operation. 
 * <p>There are three types of behaviors:
 * <ol>
 * <li>{@code DO_NOTHING} - do not change the value of the underlying property if the value is illegal
 * <li>{@code THROW_EXCEPTION} - Throw a {@link ConstraintFailedException} from the set method
 * <li>{@code CHANGE_AS_USUAL} - change the value even if it is illegal (the default).
 * </ol>
 *
 * @author Shai Almog
 */
public enum Failed {
    DO_NOTHING,
    THROW_EXCEPTION,
    CHANGE_AS_USUAL
}
