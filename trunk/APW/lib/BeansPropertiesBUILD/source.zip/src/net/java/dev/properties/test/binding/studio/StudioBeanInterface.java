package net.java.dev.properties.test.binding.studio;

import net.java.dev.properties.IndexedProperty;

/**
 * Allows the studio bean to be both a hardcoded implementation for simple beans
 * and database mapped for the ORM demo. This file also demonstrates how to use
 * inheritance and polymorphism with properties.
 *
 * @author Shai Almog
 */
public interface StudioBeanInterface {
    public IndexedProperty<StudentBean> students();
    public IndexedProperty<YogaClassBean> classes();
    public IndexedProperty<AttendanceBean> attendance();
}
