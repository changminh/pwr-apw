/*
 * Mirror.java
 *
 * Created on April 7, 2007, 10:33 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.IndexedPropertyWrapper;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.RPropertyImpl;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.WPropertyImpl;
import net.java.dev.properties.util.Utils;

/**
 * A mirror is a bean that appears to the world as a "new bean" but it serves
 * as a mirror to a POJO legacy bean in order to provide all the benefits of 
 * bean properties to old code. When creating a mirror from an old bean all the data
 * from the properties of the old bean is copied into the mirror, the mirror can
 * reflect the changes back to the original object from which it was created
 * or turn into a different object. 
 * <p>Notice that there are still several differences between working with Mirror
 * objects and standard beans. Since a mirror object is always of the same class
 * BeanContainer.get().getContext(mirrorClass) doesn't make sense, this applies
 * to several different aspects of working with mirror objects. The class which is
 * registered in the context is not the mirror class but rather the class of the 
 * legacy POJO bean which is mirrored!
 *
 * @author shai
 */
public class Mirror {
    private Object bean;
    private BaseProperty[] properties;
   
    /** Creates a new instance of Mirror */
    protected Mirror(Object bean) {
        this.bean = bean;
    }
    
    /**
     * Same as invoking BeanContainer.get().getContext(mirroredPojoBean)
     */
    public BeanContext getContext() {
        return BeanContainer.get().getContext(bean.getClass());
    }
    
    /**
     * Returns the beans toString() value for convenience
     */
    public String toString() {
        return bean.toString();
    }
    
    /**
     * Returns the mirrored internal POJO bean
     */
    public Object getBean() {
        return bean;
    }
   
    /**
     * Helper method that is identical to ((WProperty)getProperty(name)).set(o)
     */
    public void set(String name, Object o) {
        ((WProperty)getProperty(name)).set(o);
    }
    
    /**
     * Helper method that is identical to ((RProperty)getProperty(name)).get()
     */
    public Object get(String name) {
        return ((RProperty)getProperty(name)).get();
    }
    
    /**
     * Returns the property object matching the given name
     */
    public BaseProperty getProperty(String name) {
        for(BaseProperty p : properties) {
            if(p.getContext().getName().equals(name)) {
                return p;
            }
        }
        return null;
    }
    
    /**
     * Updates the mirror with the current content of the bean.
     */
    public void update() {
        for(BaseProperty p : properties) {
            MirrorVirtualPropertyContext context = (MirrorVirtualPropertyContext)p.getContext();
            if(p instanceof WProperty) {
                ((WProperty)p).set(context.getValueImpl(bean));
            }
        }
    }
    
    /**
     * Updates the bean with the values from within the mirror this method is
     * worthless for a dynamic mirror.
     */
    public void reflect() {
        for(BaseProperty p : properties) {
            MirrorVirtualPropertyContext context = (MirrorVirtualPropertyContext)p.getContext();
            if(p instanceof RProperty) {
                context.reflect((RProperty)p);
            }
        }
    }
    
    /**
     * Sets the underlying bean to a new value and invokes update()
     */
    public void update(Object newBean) {
        if(bean.getClass() != newBean.getClass()) {
            throw new IllegalArgumentException("When replacing the internal bean the value must be of the exact same class!");
        }
        bean = newBean;
        update();
    }
    
    /**
     * Sets the underlying bean to a new value and invokes reflect()
     */
    public void reflect(Object newBean) {
        if(bean.getClass() != newBean.getClass()) {
            throw new IllegalArgumentException("When replacing the internal bean the value must be of the exact same class!");
        }
        bean = newBean;
        reflect();
    }
    
    static Object invoke(String name, Object bean, Object[] values) {
        try {
            Class[] params = null;
            if(values != null) {
                params = new Class[values.length];
                for(int iter = 0 ; iter < values.length ; iter++) {
                    params[iter] = values[iter].getClass();
                }
            } 
            Method mtd = bean.getClass().getMethod(name, params);
            return mtd.invoke(bean, values);
        } catch (Exception ex) {
            throw new BeanBindException(ex);
        } 
    }

    static Object invoke(Method mtd, Object bean, Object[] values) {
        try {
            return mtd.invoke(bean, values);
        } catch (Exception ex) {
            throw new BeanBindException(ex);
        } 
    }

    static class MirrorImpl extends Mirror {
        public MirrorImpl() {
            super(null);
        }
        
        public MirrorImpl(Object bean) {
            super(bean);
        }
    }
    
    /**
     * A more efficient virtual property that relies on the knowledge that property
     * state is within a Mirror object.
     */
    static class MirrorVirtualPropertyContext extends VirtualPropertyContext {
        private int offset;
        private Method read;
        private Method write;
        
        public MirrorVirtualPropertyContext(String name, boolean indexed, Class<?> type, 
                int offset, Method read, Method write) {
            super(name, indexed, type);
            this.offset = offset;
            this.read = read;
            this.write = write;
        }
        
        /**
         * In a case of an index containing mirror objects we can wrap it in
         * a class that extracts the inner POJO's.
         */
        private IndexedProperty wrapIndex(IndexedProperty index) {
            if(index.get(0) instanceof Mirror) {
                return new IndexedPropertyWrapper(index) {
                    public Object get(int index) {
                        return ((Mirror)super.get(index)).getBean();
                    }
                };
            }
            return index;
        }
        
        /**
         * Updates from the current property value
         */
        public void reflect(RProperty prop) {
            Object bean = ((Mirror)prop.getParent()).bean;
            if(prop instanceof IndexedProperty) {
                // an indexed property will need special treatment in order to be reflected back
                // into the bean there are several problems involved:
                // 1. Indexed property maps to array or legacy property of such type
                // 2. special mapping into collection to simplify coding.
                
                Object destinationValue;
                Class type = write.getParameterTypes()[0];
                IndexedProperty indexed = (IndexedProperty)prop;
                if(type.isArray()) {
                    if(indexed.size() == 0) {
                        invoke(write, bean, new Object[] { Utils.asArray(indexed, type) });
                    }
                    
                    // 3. Wrapping of indexed property elements in mirrors of their own...
                    // we know the index is bigger than 0 so we can detect its element types.
                    indexed = wrapIndex(indexed);
                    
                    destinationValue = Utils.asArray(indexed, type);
                } else {
                    if(indexed.size() == 0) {
                        invoke(write, bean, new Object[] { Collections.EMPTY_LIST });
                    }
                    
                    // 3. Wrapping of indexed property elements in mirrors of their own...
                    // we know the index is bigger than 0 so we can detect its element types.
                    indexed = wrapIndex(indexed);
                    
                    destinationValue = Utils.asList(indexed);
                }
                            
                invoke(write, bean, new Object[] { destinationValue });
                return;
            }
            invoke(write, bean, new Object[] { prop.get() });
        }
        
        public boolean isWriteable() {
            return write != null;
        }
        
        private BaseProperty createImpl(Object bean) {
            if(isIndexedProperty()) {
                Object arr = getValueImpl(bean); 
                Collection c = new ArrayList();
                if(arr != null) {
                    if(arr.getClass().isArray()) {
                        Utils.addToCollection(arr, c);
                    } else {
                        c.addAll((Collection)arr);
                    }
                }
                return new ObservableIndexed(c);
            } else {
                if(read == null) {
                    return new WPropertyImpl();
                }
                    
                    
                if(write == null) {
                    return new RPropertyImpl(getValueImpl(bean));
                } 
                    
                return new ObservableProperty(getValueImpl(bean));
            }
        }
        
        /**
         * Creates the property instance for the first time
         */
        public BaseProperty create(Mirror m) {
            BaseProperty p = createImpl(m.getBean());
            p.setContext(this);
            p.setParent(m);
            return p;
        }
        
        Object getValueImpl(Object bean) {
            if(read != null) {
                return invoke(read, bean, null);
            }
            return null;
        }
        
        public BaseProperty getValue(Object bean) {
            return ((Mirror)bean).properties[offset];
        }

        void setOffset(int offset) {
            this.offset = offset;
        }
    }

    BaseProperty[] getProperties() {
        return properties;
    }

    void setProperties(BaseProperty[] properties) {
        this.properties = properties;
    }
}
