/*
 * Main.java
 *
 * Created on March 27, 2007, 3:33 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.xml;

import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.VirtualPropertyContext;
import net.java.dev.properties.test.binding.studio.StudentBean;
import net.java.dev.properties.test.binding.studio.StudioBean;
import net.java.dev.properties.xml.DTD;
import net.java.dev.properties.xml.Serializer;

/**
 *
 * @author Shai Almog
 */
public class Main {
    public static void main(String[] argv) throws Exception {
        Class c = new StudioBean().getClass();
        BeanContext studentContext = BeanContainer.get().getContext(new StudentBean().getClass());
        VirtualPropertyContext id = new VirtualPropertyContext("id", Integer.class);
        studentContext.addVirtual(id);
        Serializer s = Serializer.createSerializer(BeanContainer.get().getContext(c));
        DTD dtd = new DTD(c);
        dtd.setIDProperty(id);
        Object b = s.toBean(dtd, new InputStreamReader(Main.class.getResourceAsStream("studio.xml")));
        System.out.println(BeanContainer.get().toString(b));
        System.out.println("----------------------------------");
        s.toXML(dtd, b, new OutputStreamWriter(System.out));
    }
}
