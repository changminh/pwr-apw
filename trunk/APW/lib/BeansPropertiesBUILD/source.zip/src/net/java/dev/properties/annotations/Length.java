/*
 * Attributes.java
 *
 * Created on February 21, 2007, 6:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.annotations;

import java.lang.annotation.*;

/**
 * Constraint for length support that automatically installs an instance of the 
 * class {@link net.java.dev.properties.constraints.LengthConstraint} onto the given
 * property.
 * <p>Notice that the ORM takes the value of the length constraints maximum length
 * into consideration when creating tables.
 *
 * @author Shai Almog
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Length {
    /**
     * Minimum length for the constraint
     */
    int min() default 0;

    /**
     * Maximum length for the constraint
     */
    int max() default 0;
    
    /**
     * The validation messae passed into the constraint object
     */
    String message() default "Validation failed";

    /**
     * The localizable validation messae passed into the constraint object
     */
    String messageL() default "";
}
