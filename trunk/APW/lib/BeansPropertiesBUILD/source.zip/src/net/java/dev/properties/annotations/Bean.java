/*
 * Attributes.java
 *
 * Created on February 21, 2007, 6:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.annotations;

import java.lang.annotation.*;

import net.java.dev.properties.jdbc.handlers.TypeHandler;

/**
 * Allows us to define attributes for a the bean itself such as
 * its name, description, icon etc... Properties pointing at elements such as
 * the icon or svg icon should store the data within an absolute resource path
 * so Class.getResource(icon) would return the icon and it will be loaded by
 * the appropriate tool. Icon resolution is not specified and it would be scaled
 * based on the needs of the tools. 
 * <p>A bean that is marked as "localize=true" it must have a resource bundle associated
 * with it. For every property within the bean a lookup will occur (once per bean class not instance!) 
 * in the resource bundle to check if a property with the given name exists in the bundle e.g. For a bean named
 * com.vprise.MyBean that has a property named "property" with a validation of type Length 
 * a lookup would occur like: MyBean.displayName, MyBean.description,
 * MyBean.svgIcon, MyBean.icon, MyBean.property.displayName, MyBean.property.Length.message 
 * etc...
 *
 * @author Shai Almog
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Bean {
    /**
     * The name of the bean, this defaults to the name of the class without the package
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.ObservableContext#getName
     * @see net.java.dev.properties.container.ObservableContext#setName
     */
    String name() default "";

    /**
     * The display name of the bean, this can be automatically extracted from
     * a resource bundle. This defaults to the name of the bean.
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.ObservableContext#getDisplayName
     * @see net.java.dev.properties.container.ObservableContext#setDisplayName
     */
    String displayName() default "";

    /**
     * Description for the bean used by GUI tools for elements such as tooltips,
     * this is a localized attribute.
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.ObservableContext#getDescription
     * @see net.java.dev.properties.container.ObservableContext#setDescription
     */
    String description() default "";

    /**
     * A reference to an icon representing the bean, this icon needs to reside within
     * the JAR at an absolute location.
     * This is a localized attribute.
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.BeanContext#getIcon
     * @see net.java.dev.properties.container.BeanContext#setIcon
     */
    String icon() default "";

    /**
     * A reference to an SVG icon that can be used by tools that support SVG
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.BeanContext#getSvgIcon
     * @see net.java.dev.properties.container.BeanContext#setSvgIcon
     */
    String svgIcon() default "";
    
    /**
     * Resource bundle used to localize the bean automatically or explicitly.
     * This attribute defaults to the name of the bean when localize is true and
     * no name is mentioned.
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.BeanContext#updateBundle
     */
    String resourceBundle() default "";
    
    /**
     * Allows manually defining resource bundle keys for display name
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.ObservableContext#getDisplayName
     * @see net.java.dev.properties.container.ObservableContext#setDisplayName
     */
    String displayNameL() default "";

    /**
     * Allows manually defining resource bundle keys for description
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.ObservableContext#getDescription
     * @see net.java.dev.properties.container.ObservableContext#setDescription
     */
    String descriptionL() default "";

    /**
     * Allows manually defining resource bundle keys for icon
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.BeanContext#getIcon
     * @see net.java.dev.properties.container.BeanContext#setIcon
     */
    String iconL() default "";

    /**
     * Allows manually defining resource bundle keys for svg icon
     * 
     * @see net.java.dev.properties.container.BeanContext
     * @see net.java.dev.properties.container.BeanContext#getSvgIcon
     * @see net.java.dev.properties.container.BeanContext#setSvgIcon
     */
    String svgIconL() default "";

    /**
     * Indicates whether automatic localization should occur, if this flag is set to
     * true (it defaults to false) the resource bundle specified by resouceBundle
     * would be loaded (see the class declaration for further details).
     */
    boolean localize() default false;
    
    /**
     * Type handlers are used by the ORM to define custom persistance logic for a
     * specific type
     */
    Class<? extends TypeHandler> typeHandler() default TypeHandler.class;
    
}
