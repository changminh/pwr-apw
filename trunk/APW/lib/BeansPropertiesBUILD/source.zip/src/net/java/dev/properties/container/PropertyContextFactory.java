/*
 * PropertyContextFactory.java
 *
 * Created on March 2, 2007, 6:29 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.lang.reflect.Field;

/**
 * Some property types might choose to implement a property context factory of
 * their own and thus provide their own property context with additiona information.
 * To use this functionality a property class must implement this interface.
 *
 * @author Shai Almog
 */
public interface PropertyContextFactory {
    /**
     * This method will be invoked once to create a property context instance
     */
    public PropertyContext createContext(Field f);
}
