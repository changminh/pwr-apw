/*
 * Main.java
 * 
 * Created on Sep 29, 2007, 9:55:37 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.java.dev.properties.test.recipe;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.binding.PropertySelectionListener;
import net.java.dev.properties.binding.swing.SwingFactory;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.SessionConfiguration;
import net.java.dev.properties.jdbc.handlers.IdGeneratorHandler;

/**
 * A demo similar to the RoR recipe demo available here:
 * http://www.onlamp.com/pub/a/onlamp/2005/01/20/rails.html?page=1
 * 
 * @author Shai Almog
 */
public class CookBook implements Runnable {
    @Column(key=true, typeHandler=IdGeneratorHandler.class) 
    public final Property<Long> id = ObservableProperty.create();
    public final IndexedProperty<Recipe> recipes = ObservableIndexed.create();
    
    public CookBook() {
        BeanContainer.bind(this);
    }
    
    private class AddAction extends AbstractAction {
        public AddAction() {
            putValue(NAME, "Add");
        }
        
        public void actionPerformed(ActionEvent e) {
            Recipe r = new Recipe("Title");
            CurrentSession.get().insert(r);
            recipes.add(r);
        }        
    }

    private class RemoveAction extends AbstractAction implements PropertySelectionListener {
        private int[] selection;
        public RemoveAction() {
            putValue(NAME, "Remove");
            setEnabled(false);
        }
        
        public void actionPerformed(ActionEvent e) {
            for(int iter = selection.length - 1 ; iter > -1 ; iter--) {
                Recipe r = recipes.get(selection[iter]);
                recipes.remove(selection[iter]);
                CurrentSession.get().delete(r);
            }
        }

        public void selectionChanged(IndexedProperty property, int[] selection) {
            this.selection = selection;
            setEnabled(selection != null && selection.length > 0);
        }
    }
    
    public class SaveAction extends AbstractAction {
        public SaveAction() {
            putValue(NAME, "Save");
        }
        
        public void actionPerformed(ActionEvent e) {
            CurrentSession.get().flushAndCommit();
        }
    }
    
    private JToolBar createCrud(SwingFactory factory, JComponent masterDetail) {
        JToolBar crud = new JToolBar();
        crud.add(new AddAction());
        RemoveAction remove = new RemoveAction();
        factory.addPropertySelectionListener(remove, recipes, masterDetail);
        crud.add(remove);
        crud.add(new SaveAction());
        return crud;
    }
    
    public static CookBook initCookBookDB() {
        ConnectionFactory.initSimpleDriver("org.hsqldb.jdbcDriver", "jdbc:hsqldb:file:myDb", "sa", "");
        SessionConfiguration configuration = SessionConfiguration.getInstance();
        configuration.connectionFactory.get().verbose.set(true);
        configuration.addClass(Recipe.class);
        configuration.addClass(CookBook.class);
        configuration.createDatabaseTables();

        CookBook m = CurrentSession.get().fetchOne(CookBook.class, null);
        if (m == null) {
            m = new CookBook();
            CurrentSession.get().insert(m);
            CurrentSession.get().flushAndCommit();
        }
        return m;
    }
    
    public void run() {
        SwingFactory factory = SwingFactory.customColumnLayoutFactory(1);
        Recipe recipe = new Recipe();
        factory.ignoreProperties.add(recipe.id.getContext());
        factory.componentFactory.get().overrideCreate.set(recipe.instructions.getContext(), JTextArea.class);

        CookBook m = initCookBookDB();
        
        JFrame frm = new JFrame("Recipes");

        JComponent masterDetail = factory.createMasterDetail(m.recipes, factory);
        frm.add(masterDetail, BorderLayout.CENTER);
        frm.add(m.createCrud(factory, masterDetail), BorderLayout.SOUTH);
        
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        frm.pack();
        frm.setVisible(true);
    }
    
    public static void main(String[] argv) throws Exception {        
        SwingUtilities.invokeLater(new CookBook());
    }
}
