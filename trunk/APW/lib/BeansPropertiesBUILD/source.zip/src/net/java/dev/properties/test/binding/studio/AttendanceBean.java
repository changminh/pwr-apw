/*
 * AttendanceBean.java
 *
 * Created on March 7, 2007, 11:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.studio;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import net.java.dev.properties.BaseBean;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Bean;
import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.annotations.NotNull;
import net.java.dev.properties.annotations.Validation;
import net.java.dev.properties.constraints.Constraint;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;

/**
 * Indicates which students attended a particular class on a given date
 *
 * @author Shai Almog
 */
@Bean(resourceBundle="net.java.dev.properties.test.binding.studio.resources", localize=true)
public class AttendanceBean implements java.io.Serializable {
    @Validation(constraint=ValidateWhen.class)
    public final Property<YogaClassBean> type = ObservableProperty.create();
    
    @NotNull
    @Validation(constraint=ValidateWhen.class)
    @Column(name="WHEN_COLUMN")
    public final Property<Date> when = ObservableProperty.create(new Date());
    
    public final IndexedProperty<StudentBean> who = ObservableIndexed.create();

    /** Creates a new instance of AttendanceBean */
    public AttendanceBean() {
        BeanContainer.bind(this);
    }    

    public String toString() {
        return who.toString();
    }
    
    /**
     * Validates that the day of the week defined in the type matches the date defined
     * by the when property
     */
    public static class ValidateWhen implements Constraint {
        public boolean validate(BaseProperty prop, Object value) {
            AttendanceBean bean = (AttendanceBean)prop.getParent();
            Date date = bean.when.get();
            YogaClassBean type = bean.type.get();
            if(date != null && type != null && type.dayOfWeek.get() != null) {
                Calendar c = new GregorianCalendar();
                c.setTime(date);
                return type.dayOfWeek.get().byteValue() == c.get(Calendar.DAY_OF_WEEK);
            }
            return false;
        }
    }
}
