package net.java.dev.properties.container;

import net.java.dev.properties.events.VetoListener;

/**
 * A property that supports a veto event can implement this interface
 *
 * @author Shai Almog
 */
public interface VetoInterface {
    /**
     * Allows firing veto change events which can be rejected causing the chnge to fail
     */
    public ObservableDelegate<VetoListener> getVetoDelegate();
}
