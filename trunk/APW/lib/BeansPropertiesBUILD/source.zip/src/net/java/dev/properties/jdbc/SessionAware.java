package net.java.dev.properties.jdbc;

public interface SessionAware {
	void processDeletes();
	void processUpdates();
	void processInserts();
}
