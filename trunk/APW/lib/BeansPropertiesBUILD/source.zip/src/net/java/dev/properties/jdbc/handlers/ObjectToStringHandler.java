package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.PropertyContext;

/**
 * 
 * A base class for creating custom types that are stored in the DB as strings
 * but used in the domain model as something other than a string... 
 * 
 * @author Glen Marchesani
 */
public abstract class ObjectToStringHandler<T> extends AbstractTypeHandler<T> {

	
	public abstract T convertStringToObject(String valueAsString);
	public abstract String convertObjectToString(T value);
	

	@Override
	protected void initColumns() {
            PropertyContext pc = getPropertyContext();
            setColumn(ColumnContext.createSingleColumn(pc.getColumnName(), Types.VARCHAR, pc.getMaxLength(255), pc.isNullable(), pc.getReadOnlyColumns() ));
	}
	
	public void loadPreparedStatment(Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
		String valueAsString = convertObjectToString( (T) columnValues[columnValuesOffset] );
		preparedStatement.setString(preparedStatementOffset, valueAsString);
	}

	public void loadProperty(WProperty<T> property, ResultSet resultSet, int offset) throws SQLException {
		String valueAsString = resultSet.getString(offset);
		T value = convertStringToObject(valueAsString);
		property.set(value);
	}

	public boolean doesEagerFetching() {
		return true;
	}
}
