/*
 * PropertyWrapper.java
 *
 * Created on April 5, 2007, 8:53 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.beans.PropertyChangeListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyWrapper;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.events.PropertyListener;

/**
 * This class is practically identical to the PropertyWrapper class with the
 * added exposing of observability
 *
 * @param T The type of the wrapper, the internal type of the property
 * @author Shai Almog
 */
public class ObservableWrapper<T> extends PropertyWrapper<T> implements ObservableInterface {
    private ObservableDelegate<PropertyListener> delegate;
    
    /** 
     * Creates a new instance of PropertyWrapper 
     * 
     * @param properties being wrapped, the first property gets elements delegated
     *  to it. The others are only useful for internal implementation purposes.
     */
    public ObservableWrapper(BaseProperty... properties) {
        super(properties);
        if(properties.length== 1) {
            delegate = ((ObservableInterface)getProperty()).getDelegate();
        } else {
            delegate = new ObservableDelegate<PropertyListener>() {
                @Override
                public void removeListener(final PropertyListener listener) {
                    for(BaseProperty p : getProperties()) {
                        ((ObservableInterface)p).getDelegate().removeListener(listener);
                    }
                }

                @Override
                public void addListener(final PropertyListener listener) {
                    for(BaseProperty p : getProperties()) {
                        ((ObservableInterface)p).getDelegate().addListener(listener);
                    }
                }

                @Override
                public void removeListener(final PropertyChangeListener listener) {
                    for(BaseProperty p : getProperties()) {
                        ((ObservableInterface)p).getDelegate().removeListener(listener);
                    }
                }
            };
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<PropertyListener> getDelegate() {
        return delegate;
    }

    /**
     * Read only version of the observable wrapper
     */
    public static class Read<T> extends ObservableWrapper<T> implements RProperty<T> {
        public Read(BaseProperty... property) {
            super(property);
        }
        
        /**
         * @inheritDoc
         */
        @Override
        public T get() {
            return ((RProperty<T>)getProperty()).get();
        }

        public String toString() {
            return getContext().getName() + " = " + get();
        }
    }

    /**
     * Write only version of the observable wrapper
     */
    public static class Write<T> extends ObservableWrapper<T> implements WProperty<T> {
        public Write(BaseProperty... property) {
            super(property);
        }

        /**
         * @inheritDoc
         */
        @Override
        public void set(T t) {
            ((WProperty<T>)getProperty()).set(t);
        }
    }

    /**
     * Read/Write version of the observable wrapper
     */
    public static class ReadWrite<T> extends Read<T> implements Property<T> {
        public ReadWrite(BaseProperty... property) {
            super(property);
        }

        /**
         * @inheritDoc
         */
        @Override
        public void set(T t) {
            ((WProperty<T>)getProperty()).set(t);
        }
    }
}
