/*
 * Main.java
 *
 * Created on March 7, 2007, 11:07 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.mirror;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.ResourceBundle;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.binding.PropertySelectionListener;
import net.java.dev.properties.binding.swing.SwingComponentFactory;
import net.java.dev.properties.binding.swing.SwingFactory;
import net.java.dev.properties.binding.swing.adapters.SwingBind;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.Mirror;
import net.java.dev.properties.container.MirrorContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.test.DemoGUI;
import net.java.dev.properties.test.DemoInterface;

/**
 * Handles the glue code between the bean and the UI code
 *
 * @author Shai Almog
 */
public class Main implements DemoInterface {
    private SwingFactory factory;
    private SwingFactory masterFactory;
    private StudioBean studio;
    private Mirror studioMirror;
    private PropertyContext whoContext;
    private PropertyContext typeContext;
    private PropertyContext regularsContext;
    private MirrorContext attendanceMirrorContext;
    private MirrorContext studentMirrorContext;
    private MirrorContext studioMirrorContext;
    private MirrorContext yogaClassMirrorContext;
    private BeanContext studioContext;
    private JTabbedPane pane = new JTabbedPane();
    
    /** Creates a new instance of Main */
    public Main() {
        attendanceMirrorContext = MirrorContext.create(AttendanceBean.class);
        BeanContext attendanceBeanContext = BeanContainer.get().getContext(AttendanceBean.class);
        attendanceBeanContext.arrange(new String[] {"type", "when", "who"});
        studentMirrorContext = MirrorContext.create(StudentBean.class);
        BeanContext studentBeanContext = BeanContainer.get().getContext(StudentBean.class);
        studentBeanContext.arrange(new String[]{"firstName", "surname", "male",
                            "street", "streetNumber", "city", "phone", "mobile",
                            "EMail", "birthDay", "comment", "active"});
        studioMirrorContext = MirrorContext.create(StudioBean.class);
        studioContext = BeanContainer.get().getContext(StudioBean.class);
        yogaClassMirrorContext = MirrorContext.create(YogaClassBean.class);
        BeanContext yogaClassContext = BeanContainer.get().getContext(YogaClassBean.class);
        yogaClassContext.arrange(new String[] {"regulars", "dayOfWeek", 
                                "time", "active"});
        Mirror attendanceMirror = attendanceMirrorContext.create(new AttendanceBean());
        
        ResourceBundle bundle = ResourceBundle.getBundle("net.java.dev.properties.test.binding.studio.resources");
        attendanceBeanContext.updateBundle(bundle);
        studentBeanContext.updateBundle(bundle);
        studioContext.updateBundle(bundle);
        yogaClassContext.updateBundle(bundle);
        
        YogaClassBean yogaClass = new YogaClassBean();
        Mirror yogaClassMirror = yogaClassMirrorContext.create(yogaClass);
        whoContext = attendanceMirror.getProperty("who").getContext();
        typeContext = attendanceMirror.getProperty("type").getContext();
        regularsContext = yogaClassMirror.getProperty("regulars").getContext();
        
        factory = SwingFactory.customColumnLayoutFactory(2);
        masterFactory = SwingFactory.centerLayoutFactory();
        masterFactory.componentFactory.set(new OverrideComponentFactory());
        
        factory.componentFactory.get().registerBinding(regularsContext, new StudentBinding());
        
        studio = new StudioBean();
        studioMirror = studioMirrorContext.create(studio);
        IndexedProperty students = (IndexedProperty)studioMirror.getProperty("students");
        for(char iter = 'A' ; iter <= 'Z' ; iter++) {
            students.add(studentMirrorContext.create(new StudentBean("First" + iter, "Surname" + iter)));
        }
        for(char iter = 'a' ; iter <= 'z' ; iter++) {
            students.add(studentMirrorContext.create(new StudentBean("More" + iter, "Additional" + iter)));
        }

        addTab(pane, students, studentBeanContext);

        factory.componentFactory.get().registerBinding(yogaClassMirror.getProperty("time").getContext(), 
            new SwingComponentFactory.CustomPropertyBinding() {
                public JComponent createComponent(PropertyContext prop) {
                    return new TimeComponent();
                }
                public void bind(Object bean, PropertyContext property, PropertyContext selection, JComponent comp) {
                    ((TimeComponent)comp).bind(bean, property);
                }
            });
        addTab(pane, (IndexedProperty)studioMirror.getProperty("classes"), yogaClassContext);

        factory = SwingFactory.customColumnLayoutFactory(1);
        factory.componentFactory.get().registerBinding(whoContext, new StudentBinding());
        factory.componentFactory.get().registerBinding(typeContext, 
            new SwingComponentFactory.CustomPropertyBinding() {
                public JComponent createComponent(PropertyContext prop) {
                    return new JComboBox();
                }
                public void bind(Object bean, PropertyContext property, PropertyContext selection, JComponent comp) {
                    SwingBind.get().bindContent((IndexedProperty<?>)studioMirror.getProperty("classes"), 
                            (JComboBox)comp);
                    SwingBind.get().bindItem(typeContext.getValue(bean), (JComboBox)comp);
                }
            });
        addTab(pane, (IndexedProperty)studioMirror.getProperty("attendance"), attendanceBeanContext);
    }
    
    /**
     * Adds the component to the tabbed pane and adds the appropriate add/remove
     * operations etc.
     */
    private void addTab(JTabbedPane pane, final IndexedProperty property, BeanContext context) {
        class AddAction extends AbstractAction {
            public AddAction() {
                putValue(NAME, "Add");
            }
            
            public void actionPerformed(ActionEvent ev) {
                try {
                    property.add(MirrorContext.createStatic(property.getContext().getType().newInstance()));
                } catch(Exception err) {
                    err.printStackTrace();
                }
            }
        }

        class RemoveAction extends AbstractAction implements PropertySelectionListener {
            private int[] selection;
            public RemoveAction(JComponent cmp) {
                putValue(NAME, "Remove");
                setEnabled(false);
                factory.addPropertySelectionListener(this, property, cmp);
            }
            
            public void actionPerformed(ActionEvent ev) {
                for(int iter = selection.length - 1 ; iter > -1 ; iter--) {
                    property.remove(selection[iter]);
                }
            }

            public void selectionChanged(IndexedProperty property, int[] selection) {
                this.selection = selection;
                setEnabled(selection != null && selection.length > 0);
            }
        }
        
        JPanel panel = new JPanel(new BorderLayout());
        JComponent cmp = factory.createMasterDetail(property, context, masterFactory);
        panel.add(cmp, BorderLayout.CENTER);
        JPanel buttonPane = new JPanel();
        JButton addButton = new JButton(new AddAction());
        JButton removeButton = new JButton(new RemoveAction(cmp));
        buttonPane.add(addButton);
        buttonPane.add(removeButton);
        panel.add(buttonPane, BorderLayout.SOUTH);
        pane.addTab(context.getDisplayName(), panel);
    }
    
    class StudentBinding implements SwingComponentFactory.CustomPropertyBinding {
        private PropertyContext prop;
        public JComponent createComponent(PropertyContext prop) {
            this.prop = prop;
            return new JList();
        }

        public void bind(Object bean, PropertyContext property, PropertyContext selection, JComponent comp) {
            SwingBind.get().bindContent((IndexedProperty<?>)studioMirror.getProperty("students"), (JList)comp);
            SwingBind.get().bindSelectionItems((IndexedProperty<Object>)prop.getValue(bean), (JList)comp);
        }
    }
     
    /**
     * Simple override to allow the creation of a JTable that can properly render
     * hours, lists of people, days of week etc..
     */
    class OverrideComponentFactory extends SwingComponentFactory {
        public JComponent createComponent(PropertyContext propertyContext, PropertyContext selection) {
            JComponent retValue = super.createComponent(propertyContext, selection);
            if(propertyContext == studioMirror.getProperty("classes").getContext()) {
                JTable table = (JTable)retValue;
                table.setDefaultRenderer(Byte.class, new DefaultTableCellRenderer() {
                    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                        return super.getTableCellRendererComponent(table, YogaClassBean.getDOW(value), 
                            isSelected, hasFocus, row, column);
                    }
                });
                table.setDefaultRenderer(Integer.class, new DefaultTableCellRenderer() {
                    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                        return super.getTableCellRendererComponent(table, 
                            YogaClassBean.getTime(value), isSelected, 
                            hasFocus, row, column);
                    }
                });
            }
            return retValue;
        }
    }

    
    public static void main(String[] argv) throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        Main m = new Main();
        JFrame frm = new JFrame(m.studioContext.getDisplayName());
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        frm.add(m.pane, BorderLayout.CENTER);
        frm.pack();
        frm.setLocationByPlatform(true);
        frm.setVisible(true);
    }

    public String[] fileNames() {
        return DemoGUI.demoFiles(new Class[]{ AttendanceBean.class, StudentBean.class, StudioBean.class, 
                YogaClassBean.class, getClass(), TimeComponent.class});
    }

    public JComponent execute() {
        return pane;
    }

    public String demoName() {
        return "Mirror - Yoga Studio";
    }

    public String demoDescription() {
        return "<html><body><h1>Mirror Yoga Studio</h1>This demo is almost a one to one port of the Yoga Studio demo " +
                "with the exception of using " +
                "mirror objects (POJO's bound to bean-properties) rather than new beans. It shows how all the features " +
                "of the Yoga Studio demo can be reached. Note that validations are not yet implemented in the demo due to lack of time" +
                "they are possible with mirror objects. Notice how much code must be written in order to implement both " +
                "the getters and setters as well as ordering, i18n etc... (validation not included). Furthermore, notice that " +
                "\"true\" POJO's were used and they do not need observability!";
    }

    public void cleanup() {
    }
}
