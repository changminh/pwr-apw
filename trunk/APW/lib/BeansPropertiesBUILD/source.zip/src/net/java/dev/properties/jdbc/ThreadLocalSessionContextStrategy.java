package net.java.dev.properties.jdbc;

class ThreadLocalSessionContextStrategy implements SessionContextStrategy {

	private ThreadLocal<Session> _sessionThreadLocal = new ThreadLocal<Session>();	

	public Session currentSession() {
		if ( _sessionThreadLocal.get() == null ) {
			_sessionThreadLocal.set(new SessionImpl(this,SessionConfiguration.getInstance()));
		}
		return _sessionThreadLocal.get();
	}
	
	public void close(Session session) {
		if ( _sessionThreadLocal.get() == session ) {
			_sessionThreadLocal.set(null);
		}
	}
	
}
