/*
 * GUIBean.java
 *
 * Created on February 27, 2007, 7:17 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import net.java.dev.properties.LegacyDelegateProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;

/**
 * A simplified bean utilizing GUI features and deriving from the JPanel class 
 * rather that being concrete.
 *
 * @author Shai Almog
 */
public class NewGUIBean extends JPanel {
    private JLabel content = new JLabel("Test Color");
    
    public final LegacyDelegateProperty<Color> foreground = new LegacyDelegateProperty<Color>(content);

    public final LegacyDelegateProperty<Color> background = new LegacyDelegateProperty<Color>(content);
    
    /** Creates a new instance of GUIBean */
    public NewGUIBean() {
        BeanContainer.bind(this);
        setLayout(new BorderLayout());
        content.setOpaque(true);
        add(content, BorderLayout.CENTER);
        JPanel buttons = new JPanel();
        buttons.add(createButton("Foreground", foreground));
        buttons.add(createButton("Background", background));
        add(buttons, BorderLayout.SOUTH);
    }
    
    /**
     * Notice that because we have a property object we can generalize the code for
     * the background and foreground...
     */
    public JButton createButton(final String label, final Property<Color> color) {
        JButton btn = new JButton(label);
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                color.set(JColorChooser.showDialog(NewGUIBean.this, label, color.get()));
            }
        });
        return btn;
    }
    
    public static void main(String[] argv) {
        JFrame frm = new JFrame("Test GUIBean");
        NewGUIBean bean = new NewGUIBean();
        frm.getContentPane().add(bean, BorderLayout.CENTER);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.pack();
        frm.setVisible(true);
    }
}
