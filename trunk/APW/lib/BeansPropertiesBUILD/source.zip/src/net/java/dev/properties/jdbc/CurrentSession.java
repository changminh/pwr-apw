package net.java.dev.properties.jdbc;

/**
 * A helper class to track a session per thread
 * 
 * @author Glen Marchesani
 */
public class CurrentSession {

	private static SessionContextStrategy _sessionContextStrategy = new ThreadLocalSessionContextStrategy();

	public static Session get() {
		return _sessionContextStrategy.currentSession();
	}
	
	public static SessionContextStrategy getSessionContextStrategy() {
		return _sessionContextStrategy;
	}

	public static void setSessionContextStrategy( SessionContextStrategy sessionContextStrategy ) {
		_sessionContextStrategy = sessionContextStrategy;
	}

}
