package net.java.dev.properties.jdbc.handlers;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.PropertyContext;

/**
 * 
 * Sorry about the name I always get confused if something is for java.util.Date or java.sql.Date
 * this makes it clear.
 * 
 * TODO make this class work with both java.util and java.sql dates
 * 
 * @author Glen Marchesani
 */
public class JavaDotSqlDotDateHandler extends AbstractTypeHandler<Date> {

	public boolean canHandleType(Class<?> type) {
		return Date.class.equals(type) || java.util.Date.class.equals(type);
	}

	@Override
	protected void initColumns() {
            PropertyContext pc = getPropertyContext();
            setColumn(ColumnContext.createSingleColumn(pc.getColumnName(),Types.DATE, pc.getMaxLength(255), pc.isNullable(), pc.getReadOnlyColumns()));
	}

	public void loadPreparedStatment(Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
            if(columnValues[columnValuesOffset] == null || columnValues[columnValuesOffset] instanceof Date)
            {
		preparedStatement.setDate(preparedStatementOffset, (Date)columnValues[columnValuesOffset]);
            }
            else
            {
                long time = ((java.util.Date)columnValues[columnValuesOffset]).getTime();
		preparedStatement.setDate(preparedStatementOffset, new Date(time));
            }
	}

	public void loadProperty(WProperty<Date> property, ResultSet resultSet, int offset) throws SQLException {
		Date date = resultSet.getDate(offset);
		property.set(date);
	}
	
	public boolean doesEagerFetching() {
		return true;
	}

}
