package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author Glen Marchesani
 */
public class CharacterHandler extends PrimitiveTypeHandler<Character> {

	public CharacterHandler() {
		super(Character.class, Types.CHAR);
	}

	public Character get( ResultSet resultSet, int offset) throws SQLException {
		return resultSet.getString(offset).charAt(0);
	}

	public void initPreparedStatmentImpl(Character value, PreparedStatement preparedStatement, int offset) throws SQLException {
		preparedStatement.setString(offset, String.valueOf(value));		
	}

}
