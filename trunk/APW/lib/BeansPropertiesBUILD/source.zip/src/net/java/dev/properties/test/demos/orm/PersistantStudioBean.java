package net.java.dev.properties.test.demos.orm;

import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Bean;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.test.binding.studio.AttendanceBean;
import net.java.dev.properties.test.binding.studio.StudentBean;
import net.java.dev.properties.test.binding.studio.StudioBean;
import net.java.dev.properties.test.binding.studio.StudioBeanInterface;
import net.java.dev.properties.test.binding.studio.YogaClassBean;

/**
 * Version of the studio bean that allows the indexed properties to persist into
 * the database.
 *
 * @author Shai Almog
 */
@Bean(resourceBundle="net.java.dev.properties.test.binding.studio.resources", localize=true)
public class PersistantStudioBean extends StudioBean implements java.io.Serializable, StudioBeanInterface, PersistentId {
    @Column(key=true)
    public final Property<Integer> id = ObservableProperty.create();
    
    /** Creates a new instance of StudioBean */
    public PersistantStudioBean() {
        BeanContainer.bind(this);
    }    

    public IndexedProperty<StudentBean> students() {
        return students;
    }
    
    public IndexedProperty<YogaClassBean> classes() {
        return classes;
    }
    
    public IndexedProperty<AttendanceBean> attendance() {
        return attendance;
    }

    public Property<Integer> id() {
        return id;
    }
}
