package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.OnGet;
import net.java.dev.properties.events.OnGetListener;
import net.java.dev.properties.jdbc.Association;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.EntityPersister;
import net.java.dev.properties.jdbc.SessionConfiguration;

/**
 * @author Glen Marchesani
 */
public class SingleEntityHandler<T> extends AbstractTypeHandler<T> implements CloneableTypeHandler<T> {

	private EntityPersister<T> _entityPersister;
	
	public SingleEntityHandler(EntityPersister<T> entityPersister) {
		_entityPersister = entityPersister;
	}
	
	public boolean canHandleType(Class<?> type) {
		return _entityPersister.getBeanClass().equals(type);
	}

    /**
     * Unlike canHandleType this is a fallback method that will be called if
     * no other type handler can handle the type. This may be useful for a generic
     * handler that can handle a base class of an entity.
     */
    public boolean canHandleTypeFallback( Class<?> type ) {
        return type.isAssignableFrom(_entityPersister.getBeanClass());
    }

	@Override
	public void activated() {
		super.activated();
		if ( _entityPersister == null ) {
			_entityPersister = (EntityPersister<T>)SessionConfiguration.getInstance().getPersister(getPropertyContext().getType());
		}
		
	}
	
	@Override
	protected void initColumns() {
		setColumns(new ArrayList<ColumnContext>());
		List<TypeHandler<Object>> primaryKeyHandlers = getPersister().getPrimaryKeyHandlers();
		if( primaryKeyHandlers.size() == 1 && primaryKeyHandlers.get(0).getColumns().size() == 1 ) {
                    PropertyContext pc = getPropertyContext();
                    ColumnContext columnContext = ColumnContext.createSingleColumn( pc.getColumnName(), primaryKeyHandlers.get(0).getColumns().get(0).getSqlType(), pc.getMaxLength(255), pc.isNullable(), pc.getReadOnlyColumns() );
                    getColumns().add(columnContext);
		} else {
			String baseName = getPropertyContext().getName();
	    	for( TypeHandler<Object> keyHandler : getPersister().getPrimaryKeyHandlers()) {
	    		for( ColumnContext foreignKeyHandler : keyHandler.getColumns() ) {
                            PropertyContext pc = getPropertyContext();
                            ColumnContext columnContext = ColumnContext.createSingleColumn( baseName + "_" + foreignKeyHandler.getName(),foreignKeyHandler.getSqlType(), pc.getMaxLength(255), foreignKeyHandler.isNullable(), pc.getReadOnlyColumns() );
                            getColumns().add( columnContext );
	    		}
	    	}
		}
	}

	public void loadColumnValues( RProperty<T> property, Object[] array, int offset ) {
		T value = property.get();
    	for( TypeHandler keyHandler : getPersister().getPrimaryKeyHandlers()) {
    		RProperty keyProperty;
    		if ( value == null ) {
    			keyProperty = null;
    		} else {
    			keyProperty = ((RProperty<Object>) keyHandler.getPropertyContext().getValue(value));
    		}
    		keyHandler.loadColumnValues(keyProperty, array, offset);
    		offset += keyHandler.getColumns().size();
    	}		
	}

	EntityPersister<T> getPersister() {
		return _entityPersister;
	}
	
	public void loadPreparedStatment(Object[] array, int arrayOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
    	for( TypeHandler keyHandler : getPersister().getPrimaryKeyHandlers()) {
    		keyHandler.loadPreparedStatment(array, arrayOffset, preparedStatement, preparedStatementOffset);
    		preparedStatementOffset += keyHandler.getColumns().size();
    		arrayOffset += keyHandler.getColumns().size();
    	}
    }
	
    
    public void loadProperty(WProperty<T> property, ResultSet resultSet, int offset) throws SQLException {
    	int index=0;
    	SimpleProperty tempProperty = new SimpleProperty();
    	List<Object> primaryKeyValues = new ArrayList<Object>();
    	for( TypeHandler keyHandler : getPersister().getPrimaryKeyHandlers()) {
    		keyHandler.loadProperty(tempProperty, resultSet, offset+index);
			Object value = tempProperty.get(); 
    		if ( value == null && tempProperty.getPrimaryKeyValues() != null ) {
    			primaryKeyValues.addAll(Arrays.asList(tempProperty.getPrimaryKeyValues()));
    		} else {
    			primaryKeyValues.add(value);
    		}
    		index+=keyHandler.getColumns().size();
    	}
        if(property instanceof SimpleProperty) {
            ((SimpleProperty) property).setPrimaryKeyValues(primaryKeyValues.toArray());
        } else if ( property.getContext() != null ) {
	        Association relation = property.getContext().getRelationalAssociation(property.getParent());
	        if(relation != null) {
	            relation.setPrimaryKeyValues(primaryKeyValues.toArray());
	        } else if ( property instanceof OnGetListener ) {
	        	final OnGetListener onGetListener = (OnGetListener) property;
	        	final Object[] primaryKeyColumnValues = primaryKeyValues.toArray();
	        	onGetListener.setOnGet(new OnGet() {
	        		public void onGet(RProperty<?> p) {
	        			onGetListener.setOnGet(null);
	                    ((WProperty)p).set(CurrentSession.get().fetchByPK(p.getContext().getType(), primaryKeyColumnValues));
	        		}
	        	});
	        }
        }
    }
    
    
    @Override
    public SingleEntityHandler<T> clone() {
    	return new SingleEntityHandler<T>(getPersister());
    }

    static class SimpleProperty implements WProperty<Object>, RProperty<Object> {
    	
    	Object value;
    	Object[] primaryKeyValues;
    	
		public void set(Object t) {
			value = t;
		}

		public Object get() {
			return value;
		}

		public PropertyContext getContext() {
			return null;
		}

		public Object getParent() {
			return null;
		}

		public void setContext(PropertyContext context) {
		}

		public void setParent(Object parent) {
		}
		
		public void setPrimaryKeyValues(Object... primaryKeyValues) {
			this.primaryKeyValues = primaryKeyValues;
		}
		
		public Object[] getPrimaryKeyValues() {
			return primaryKeyValues;
		}
		
    }
    
	public boolean doesEagerFetching() {
		return false;
	}

}
