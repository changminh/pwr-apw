/*
 * RPropertyImpl.java
 *
 * Created on February 20, 2007, 10:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

/**
 * Simple implementation of a read only property that only allows subclasses or
 * the constructor to modify it.
 * 
 * @author Shai Almog
 */
public class RPropertyImpl<T> extends BasePropertyImpl<T> implements RProperty<T> {
    
    /** 
     * Creates a new instance of RPropertyImpl 
     * @see #create
     */
    public RPropertyImpl() {
    }
    
    /** 
     * Creates a new instance of RPropertyImpl 
     * @see #create
     */
    public RPropertyImpl(T t) {
        super(t);
    }

    /**
     * @inheritDoc
     */
    @Override
    public T get() {
        return super.get();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> RPropertyImpl<K> create() {
        return new RPropertyImpl<K>();
    }
}
