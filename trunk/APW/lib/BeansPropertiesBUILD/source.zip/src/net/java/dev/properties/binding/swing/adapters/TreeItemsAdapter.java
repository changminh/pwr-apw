/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements table support for propagating selection UI changes
 *
 * @author Shai Almog
 */
class TreeItemsAdapter extends SwingAdapter<List<Object>, JTree> implements TreeSelectionListener {
    protected void bindListener(BaseProperty<List<Object>> property, JTree cmp) {
        cmp.getSelectionModel().addTreeSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<List<Object>> property, JTree cmp) {
        cmp.getSelectionModel().removeTreeSelectionListener(this);
    }
        
    /**
     * Recursively searches the tree for the given node
     */
    private void findNodes(TreePath path, List nodes, List<TreePath> result) {
        Object lastPath = path.getLastPathComponent();
        if(nodes.contains(lastPath)) {
            result.add(path);
        }
        TreeModel model = getComponent().getModel();
        int count = model.getChildCount(lastPath);
        for(int iter = 0 ; iter < count ; iter++) {
            Object child = model.getChild(lastPath, iter);
            findNodes(path.pathByAddingChild(child), nodes, result);
        }
    }

    protected void updateUI(List<Object> newValue) {
        if(newValue != null && newValue.size() > 0) {
            TreePath root = new TreePath(getComponent().getModel().getRoot());
            List<TreePath> result = new ArrayList<TreePath>();
            findNodes(root, newValue, result);
            TreePath[] paths = new TreePath[result.size()];
            result.toArray(paths);
            getComponent().setSelectionPaths(paths);
        } else {
            getComponent().clearSelection();
        }
    }            

    public void valueChanged(TreeSelectionEvent e) {
        TreePath[] paths = getComponent().getSelectionPaths();
        List data = new ArrayList();
        for(int iter = 0 ; iter < paths.length ; iter++) {
            data.add(paths[iter].getLastPathComponent());
        }
        callWhenUIChanged(data);
    }


    protected Class getType() {
        return List.class;
    }

    protected Class getComponentType() {
        return JTree.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}