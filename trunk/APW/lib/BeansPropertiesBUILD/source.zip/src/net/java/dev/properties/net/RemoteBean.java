/*
 * RemoteBean.java
 * 
 * Created on Jul 21, 2007, 11:20:54 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.java.dev.properties.net;

import net.java.dev.properties.container.BeanContext;

/**
 * This class implements an abstraction to a remote bean object, it is similar
 * to a mirror object however it provides location transparency and can do so
 * both for mirrors and for new beans transparently.
 *
 * @author Shai Almog
 */
class RemoteBean {
    private BeanContext target;
    private RemoteServer server;
    
    public RemoteBean(RemoteServer server, BeanContext target) {
        this.target = target;
        this.server = server;
    }

    public void fetch() {
    }
    
}
