package net.java.dev.properties.jdbc.handlers;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.jdbc.BatchUpdateExecutor;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.JdbcException;
import net.java.dev.properties.jdbc.LongQueryExecutor;
import net.java.dev.properties.jdbc.SQLExecutor;
import net.java.dev.properties.jdbc.QueryExecutor;
import net.java.dev.properties.jdbc.UpdateQueryExecutor;

/**
 * A TypeHandler that if the property is null will generate an id.
 * 
 * @author Glen Marchesani
 * 
 */
public class IdGeneratorHandler<T> extends AbstractTypeHandler<T> {

	private String _autoIncrementTableName = "auto_increment_table";
	private String _tableColumn = "table_name";
	private String _idColumn = "last_id_used";
	private long _initialValue;
	
	private ThreadLocal<Connection> _connectionThreadLocal = new ThreadLocal<Connection>();

	@Override
	protected void initColumns() {
            PropertyContext pc = getPropertyContext();
            setColumn(ColumnContext.createSingleColumn(pc.getColumnName(),Types.BIGINT, pc.getMaxLength(255), pc.isNullable(), pc.getReadOnlyColumns()));
	}

	public boolean canHandleType(Class<?> type) {
		return false;
	}
	
	@Override
	public void loadColumnValues(RProperty<T> property, Object[] columnValues, int columnValuesOffset) {
		if ( property.get() == null ) {
			Long nextIdValue = getNextIdValue();
			((WProperty<Long>) property).set(nextIdValue);
			columnValues[columnValuesOffset] = nextIdValue;
		} else {
			columnValues[columnValuesOffset] = property.get();			
		}
	}

	public void loadPreparedStatment(Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
		try {
			preparedStatement.setLong(preparedStatementOffset, (Long) columnValues[columnValuesOffset]);
		} catch ( NullPointerException e ) {
			throw e;
		}
	}

	public void createTable() {
		String sql = "CREATE TABLE " + _autoIncrementTableName + " ( " + _tableColumn + " VARCHAR(255), " + _idColumn + " BIGINT, PRIMARY KEY( " + _tableColumn + " ) )";
		new UpdateQueryExecutor(sql);
	}

	public long getNextIdValue() {
		
		try {
                        Connection oldConnection = _connectionThreadLocal.get();
			Connection connection = getParentEntityPersister().getSessionConfiguration().connectionFactory.get().newConnection();
			_connectionThreadLocal.set(connection);
			
			long nextValue;
			
			try {
				while( true ) {

					long currentValue = getCurrentIdValue();
					nextValue = currentValue + 1;

					if ( updateIdValue(currentValue, nextValue) ) {
						break;
					}

				}
			} finally {
				_connectionThreadLocal.set(oldConnection);
				connection.close();
			}

			return nextValue;
	
		} catch ( SQLException e ) {
			throw new JdbcException(e);
		} 
				
	}

        private long getCurrentIdValueImpl() {
		String sql = "select " + _idColumn + " from " + _autoIncrementTableName + " where " + _tableColumn + " = ?";

                LongQueryExecutor selectQuery = new LongQueryExecutor(sql,_connectionThreadLocal.get()) {
                        @Override
                        protected void prepareQuery() throws SQLException {
                                getStatement().setString(1,getBeanContext().getTableName());
                        }
                };

                Long currentId = selectQuery.getResult();
                if ( currentId == null ) {
                        insertInitialValue(0);
                        return 0;
                } else {
                        return currentId;
                }
        }
	
	public long getCurrentIdValue() {
            // if the table was not yet created just create it lazily and move along
            try {
                return getCurrentIdValueImpl();
            } catch(Exception err) {
                createTable();
                CurrentSession.get().commit();
                return getCurrentIdValueImpl();
            }
	}

	public void insertInitialValue( final long value ) {
		
		String sql = "insert into " + _autoIncrementTableName + " ( " + _tableColumn + ", " + _idColumn + " ) VALUES( ?, ? )";

		List list = new ArrayList();
		list.add(new Object());
		
		new UpdateQueryExecutor(sql) {
			@Override
			protected void prepareQuery() throws SQLException {
				getStatement().setString(1, getBeanContext().getTableName());
				getStatement().setLong(2, value);
			}
		};
                CurrentSession.get().commit();
	}
	
	/**
	 * Returns true if the update is successful...
	 */
	public boolean updateIdValue( final long currentValue, final long newValue ) throws SQLException {
		String sql = "update " + _autoIncrementTableName + " set " + _idColumn + " = ? where " + _tableColumn + " = ? and " + _idColumn + " = ?";

		UpdateQueryExecutor updateQuery = new UpdateQueryExecutor(sql,_connectionThreadLocal.get()) {
			@Override
			protected void prepareQuery() throws SQLException {
				getStatement().setLong(1, newValue);
				getStatement().setString(2, getBeanContext().getTableName());
				getStatement().setLong(3, currentValue);
			}

		};
		
                int rows = updateQuery.getNumberOfRowsUpdated();
		_connectionThreadLocal.get().commit();
		
		if ( rows  == 0 ) {
			return false;
		} else {
			return true;
		}
	}

	
	public void loadProperty(WProperty<T> property, ResultSet resultSet, int resultSetOffset) throws SQLException {
		((WProperty) property).set( resultSet.getLong(resultSetOffset) ); 
	}

	public String getIdColumn() {
		return _idColumn;
	}

	public void setIdColumn(String idColumn) {
		_idColumn = idColumn;
	}

	public long getInitialValue() {
		return _initialValue;
	}

	public void setInitialValue(long initialValue) {
		_initialValue = initialValue;
	}

	public String getTableColumn() {
		return _tableColumn;
	}

	public void setTableColumn(String tableColumn) {
		_tableColumn = tableColumn;
	}
	
	public boolean doesEagerFetching() {
		return true;
	}
	
}
