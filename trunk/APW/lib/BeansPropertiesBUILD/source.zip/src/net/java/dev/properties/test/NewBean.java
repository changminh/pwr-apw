/*
 * NewBean.java
 *
 * Created on February 21, 2007, 3:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.container.BeanContainer;

/**
 * This is a clean new bean that implements the same feature set as the legacy
 * bean
 *
 * @author Shai Almog
 */
public class NewBean {
    public final ObservableProperty<Integer> x = ObservableProperty.create();
    
    /** Creates a new instance of NewBean */
    public NewBean() {
        BeanContainer.bind(this);
    }
}
