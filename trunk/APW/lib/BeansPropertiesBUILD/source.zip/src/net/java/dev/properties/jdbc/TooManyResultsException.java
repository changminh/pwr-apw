package net.java.dev.properties.jdbc;

public class TooManyResultsException extends JdbcException {

	public TooManyResultsException(String err) {
		super(err);
	}
	
}
