package net.java.dev.properties.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.jdbc.handlers.ColumnContext;
import net.java.dev.properties.jdbc.handlers.ManyEntityHandler;
import net.java.dev.properties.jdbc.handlers.ManyToManyHandler;
import net.java.dev.properties.jdbc.handlers.TableGeneration;
import net.java.dev.properties.jdbc.handlers.TypeHandler;

/**
 * The mapping class connects a table from the schema package to a bean and maps
 * its column objects to bean properties. 
 *
 * @author Shai Almog
 * @author Glen Marchesani
 */
public class EntityPersister<T> implements TableGeneration {
	
	//private final Log logger = LogHelper.getInstanceLog(this);

	private SessionConfiguration _sessionConfiguration;

	private String tableName;
	private BeanContext beanContext;
    private Class<T> beanClass;
    private Map<PropertyContext, TypeHandler<Object>> _propertyContextToHandlerMap;
    private List<TypeHandler<Object>> _typeHandlers;

    private Integer _primaryKeyColumnCount;
    private Integer _typeHandlersColumnCount;
    
    private String insertQuery;
    private String deleteQuery;
    private String updateQuery;

    private String selectPkQuery;
    private String selectQuery;
    private String selectCountQuery;
    
    private List<ManyToManyHandler<Object>> _manyToManyHandlers;
    private List<TypeHandler<Object>> _primaryKeyHandlers;
    
    private List<PropertyContext> _propertyContexts;
    
    public EntityPersister(Class<T> beanClass, BeanContext beanContext,SessionConfiguration sessionConfiguration) {
    	this.beanClass = beanClass;
    	this.beanContext = beanContext;
    	tableName = beanContext.getTableName();
    	_sessionConfiguration = sessionConfiguration;
    }

    public TypeHandler getTypeHandler( PropertyContext propertyContext ) {
    	TypeHandler typeHandler = (TypeHandler) getPropertyMapping().get(propertyContext);
    	if ( typeHandler == null ) {
            // this could be a valid case due to recursion in initialization where
            // _propertyContextToHandlerMap has not finished its creation
            typeHandler = createHandlerForPropertyContext(propertyContext);            
            if(typeHandler == null) {
                throw new RuntimeException( "unable to find typeHandler for " + propertyContext.getName() );
            }
            _propertyContextToHandlerMap.put(propertyContext, typeHandler);
    	}
    	return typeHandler;
    }

    Map<PropertyContext, TypeHandler<Object>> getPropertyMapping() {
        initPropertyContextToHandlerMap();    		
        return _propertyContextToHandlerMap;
    }

    private void initPropertyContextToHandlerMap() {
        if ( _propertyContextToHandlerMap == null ) {
            _propertyContextToHandlerMap = new HashMap<PropertyContext, TypeHandler<Object>>();
            _typeHandlers = new ArrayList<TypeHandler<Object>>();
            for( PropertyContext propertyContext : beanContext.getPropertiesArray() ) {
            	if ( !propertyContext.isTransient() && propertyContext.getColumnName() != null ) {
	                TypeHandler<Object> typeHandler = createHandlerForPropertyContext(propertyContext);
	                _propertyContextToHandlerMap.put(propertyContext, typeHandler);
	                _typeHandlers.add(typeHandler);
            	}
            }
        }
    }
    
    public void setTableName(String tableName) {
		this.tableName = tableName;
	}

    public List<TypeHandler<Object>> getPrimaryKeyHandlers() {
    	if ( _primaryKeyHandlers == null ) {
            List<TypeHandler<Object>> primaryKeyHandlers = new ArrayList<TypeHandler<Object>>();
            for ( PropertyContext propertyContext : getPrimaryKeyContexts() ) {
            	TypeHandler<Object> handler = getTypeHandler(propertyContext);
            	primaryKeyHandlers.add( handler );
            }
            _primaryKeyHandlers = primaryKeyHandlers;
    	}
        return _primaryKeyHandlers;
    }
                
    TypeHandler<Object> createHandlerForPropertyContext(PropertyContext context) {
    	TypeHandler<Object> typeHandler = _sessionConfiguration.typeHandlerFactory.get().createHandlerForPropertyContext(this,beanClass,context);
    	return typeHandler;
    }

    private void updatePropertyMapping(TypeHandler<Object>[] props, PropertyContext context, int offset) {
        props[offset] = createHandlerForPropertyContext(context);
    }

    /**
     * Lazily creates an insert query string 
     */
    private String getInsertQuery() {
        if(insertQuery == null) {
        	QueryBuilder queryBuilder = new QueryBuilder();
        	queryBuilder.append("insert into ");
        	queryBuilder.append(tableName);
        	queryBuilder.append(" (");
            queryBuilder.appendHandlerColumns( getTypeHandlers(), ", ", false );

            queryBuilder.append(" ) values ( ");

            String seperator = "";
            for(int i=0 ; i<queryBuilder.getColumnCount(); i++) {
            	queryBuilder.append(seperator);
            	queryBuilder.append("?");
                seperator = ", ";
            }

            queryBuilder.append(" )");

            insertQuery = queryBuilder.getSql();
        }
        return insertQuery;
    }

    /**
     * Performs the setting of parameters for the insert query
     */
    private void insertQuery(PreparedStatement stmt, Object bean) throws SQLException {        
    	processPreparedStatementHandlers(bean, stmt, getTypeHandlers(), getTypeHandlersColumnCount() );
    }

    /**
     * Appends the where statement for the pk
     */
    private void appendWherePK(QueryBuilder builder) {
        builder.append(" where ");
        
        String separator = "";
       	builder.appendHandlerColumns(getPrimaryKeyHandlers(), "= ?", " and ", true);
    }
    
    /**
     * Lazily creates an delete query string 
     */
    private String getDeleteQuery() {
        if(deleteQuery == null) {
        	QueryBuilder queryBuilder = new QueryBuilder();
        	queryBuilder.append("delete from ");
        	queryBuilder.append(tableName);
        	queryBuilder.append(" ");
            appendWherePK(queryBuilder);
            deleteQuery = queryBuilder.getSql();
        }
        return deleteQuery;
    }

    /**
     * Performs the setting of parameters for the delete query
     */
    private void deleteQuery(PreparedStatement stmt, Object bean) throws SQLException {
    	processPreparedStatementHandlers(bean, stmt, getPrimaryKeyHandlers(), getPrimaryKeyColumnCount());
    }

    public static Object[] processPreparedStatementHandlers(Object bean, PreparedStatement preparedStatement, List<TypeHandler<Object>> handlers, int columnCount) throws SQLException {
    	return processPreparedStatementHandlers(bean, preparedStatement, handlers, columnCount, null, 0);
    }

    public static Object[] processPreparedStatementHandlers(Object bean, PreparedStatement preparedStatement, List<TypeHandler<Object>> handlers, int columnCount, Object[] columnValues, int columnOffset) throws SQLException {
    	if ( columnValues == null ) {
    		columnValues = new Object[columnCount];
    	}
        for(TypeHandler<Object> handler : handlers) {
        	int handlerColumnCount = handler.getColumns().size();
        	if ( handlerColumnCount > 0 ) { 
	        	handler.loadColumnValues((RProperty<Object>)handler.getPropertyContext().getValue(bean), columnValues, columnOffset);
	        	handler.loadPreparedStatment(columnValues, columnOffset, preparedStatement, columnOffset+1);
	        	columnOffset += handlerColumnCount;
        	}
        }
        return columnValues;
    }

    /**
     * Lazily creates an update query string 
     */
    private String getUpdateQuery() {
        if(updateQuery == null) {
        	QueryBuilder queryBuilder = new QueryBuilder();
        	queryBuilder.append("update ");
        	queryBuilder.append(tableName);            
        	queryBuilder.append(" set ");

        	queryBuilder.appendHandlerColumns(getTypeHandlers(), " = ? ", ", ", false);

        	appendWherePK(queryBuilder);
        	
            updateQuery = queryBuilder.getSql();
        }
        return updateQuery;
    }
    

    private boolean isPrimaryKey(PropertyContext p) {
        for(TypeHandler<Object> current : getPrimaryKeyHandlers()) {
            if(current.getPropertyContext() == p) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Performs the setting of parameters for the update query
     */
    private void updateQuery(PreparedStatement stmt, Object bean) throws SQLException {
    	int columnCount = getTypeHandlersColumnCount()+getPrimaryKeyColumnCount();
    	Object[] columnValues = processPreparedStatementHandlers(bean, stmt, getTypeHandlers(), columnCount );
    	processPreparedStatementHandlers(bean, stmt, getPrimaryKeyHandlers(), getPrimaryKeyColumnCount(), columnValues, getTypeHandlersColumnCount() );
    }

    /**
     * Inserts the given bean into the database 
     */
    void insertBatch(List<T> t) {
        if(t.size() == 0) return;
        new BatchUpdateExecutor<T>(getInsertQuery(), t) {
        	@Override
        	protected void addBeanToBatchStatement(T bean) throws SQLException {
                insertQuery(getStatement(), bean);
            }
        };
    }

    /**
     * Deletes the given bean in the database 
     */
    void deleteBatch(List<T> t) {
        if(t.size() == 0) return;
        new BatchUpdateExecutor<T>(getDeleteQuery(), t) {
        	@Override
        	protected void addBeanToBatchStatement(T bean) throws SQLException {
                deleteQuery(getStatement(), bean);
            }
        };
    }

    /**
     * Updates the given bean in the database 
     */
    void updateBatch(List<T> t) {
        if(t.size() == 0) return;
        new BatchUpdateExecutor<T>(getUpdateQuery(), t) {
        	protected void addBeanToBatchStatement(T bean) throws SQLException {
                updateQuery(getStatement(), bean);
            }
        };
    }
          
    public void dropTable() {
        new UpdateQueryExecutor("drop table if exists " + tableName);    	
    }
    
    /**
     * Adds foreign keys to other tables for unidirectional relations
     */
    public void prepareForCreate() {
        for( PropertyContext propertyContext : beanContext.getPropertiesArray() ) {
            TypeHandler<Object> typeHandler = getTypeHandler(propertyContext);
            
            // if this is a relationship and it is unidirectional then we need to
            // update the foregin side of this relation
            if(typeHandler instanceof ManyEntityHandler && (!propertyContext.isBidirectional())) {
                EntityPersister<?> foreignPersister = ((ManyEntityHandler)typeHandler).getManyEntityPersister();
                if(foreignPersister.foreignColumns == null) {
                    foreignPersister.foreignColumns = new ArrayList<ColumnContext>();
                }
                String relationName = propertyContext.getRelationName();
                for(TypeHandler<Object> pkHandler : getPrimaryKeyHandlers()) {
                    for(ColumnContext column : pkHandler.getColumns()) {
                        foreignPersister.foreignColumns.add(ColumnContext.createSingleColumn(relationName + column.getName(), column.getSqlType(), column.getSize(), true, null));
                    }
                }
                if(foreignPersister.foreignColumns.size() == 1) {
                    foreignPersister.foreignColumns.get(0).setName(relationName);
                }
            }
        }
    }
    
    /**
     * Foreign keys that should be added to the table
     */
    private List<ColumnContext> foreignColumns;
    
    /**
     * This method creates the table matching the current mapping, it drops the 
     * old table if dropOld is true. Exceptions will be swallowed if this method
     * fails.
     */
    public void createTable() {
    	createTable(true,false);
        CurrentSession.get().commit();
    }
    
    
    public void clearTable() {

    	new UpdateQueryExecutor( "delete from " + getTableName() );
        
        for( ManyToManyHandler<?> manyToManyHandler : getManyToManyHandlers() ) {
        	new UpdateQueryExecutor( "delete from " + manyToManyHandler.getTableName() );
        }

    }
    
    public void createTable(boolean silentFail, boolean dropOld) {
        if(dropOld) {
        	dropTable();
        }
        
        try {
            
            for( ManyToManyHandler<?> manyToManyHandler : getManyToManyHandlers() ) {
                try {
                    if(dropOld) {
                        manyToManyHandler.dropTable();
                    }
                    manyToManyHandler.createTable();
                } catch(Exception failed) {
                    if(silentFail) {
                        continue;
                     } else {
                        throw failed;
                     }
                }
            }
        
        	
        	//logger.debug( "creating create table sql for " + tableName );
        	
            StringBuilder b = new StringBuilder("create table ");
            b.append(tableName);
            b.append(" (");
            
            StringBuilder primaryKeys = new StringBuilder();
            String primaryKeySeparator = "";
            String separator = "";
            for( PropertyContext propertyContext : beanContext.getPropertiesArray() ) {
            	TypeHandler<Object> typeHandler = getTypeHandler(propertyContext);
            	//logger.debug( "adding columns for property " + propertyContext.getName() );
                for(ColumnContext column : typeHandler.getColumns()) {
                    b.append(separator);
                	//logger.debug( "adding column " + column.getName() );
                	b.append(column.getName());
                    b.append(" ");                    
                    b.append(SQLExecutor.getSqlTypeName(column.getSqlType(), column.getSize()));
                    separator = ", ";
                    if ( isPrimaryKey(propertyContext)) {
                    	primaryKeys.append(primaryKeySeparator);
                    	primaryKeys.append(column.getName());
                    	primaryKeySeparator = ", ";
                    }
                }
            }
            
            if(foreignColumns != null) {
                for(ColumnContext column : foreignColumns) {
                    b.append(separator);
                    b.append(column.getName());
                    b.append(" ");                    
                    b.append(SQLExecutor.getSqlTypeName(column.getSqlType(), column.getSize()));
                    separator = ", ";
                }
            }
            
            b.append( ", PRIMARY KEY(" );
            b.append(primaryKeys);
            b.append(")");
            
            b.append(")");
            new UpdateQueryExecutor(b.toString());
        } catch(Exception failed) {
            if(silentFail) {
                return;
            }
            if(SessionConfiguration.getInstance().connectionFactory.get().verbose.get()) {
                SessionConfiguration.getInstance().connectionFactory.get().log(failed.getMessage());
            }
            failed.printStackTrace();
            throw new RuntimeException(failed);
        }
    }

    public String[] getPrimaryKeyColumnNames() {
    	String[] primaryKeyColumnNames = new String[getPrimaryKeyColumnCount()];
    	int offset = 0;
    	for( TypeHandler<Object> handler : getPrimaryKeyHandlers() ) {
    		for( ColumnContext columnContext : handler.getColumns() ) {
    			primaryKeyColumnNames[offset] = columnContext.getName();
    			offset++;
    		}
    	}
    	return primaryKeyColumnNames;
    }

    /**
     * Returns an object representing the primary key of the given object
     */
    public Object[] getPrimaryKeyColumnValues(T t) {
    	Object[] primaryKeyColumnValues = new Object[getPrimaryKeyColumnCount()];
    	int offset = 0;
    	for( TypeHandler<Object> handler : getPrimaryKeyHandlers() ) {
    		handler.loadColumnValues((RProperty<Object>) handler.getPropertyContext().getValue(t), primaryKeyColumnValues, offset);
    		handler.getPropertyContext().getInternalValue(t);
    		offset += handler.getColumns().size();
    	}
    	return primaryKeyColumnValues;
    }

    
    /**
     * Lazily creates a select query string 
     */
    private String getSelectPkQuery() {
        if(selectPkQuery == null) {
            QueryBuilder queryBuilder = new QueryBuilder();
            queryBuilder.append(getSelectQuery());
            appendWherePK(queryBuilder);
            selectPkQuery = queryBuilder.getSql();
        }
        return selectPkQuery;
    }
    
    /**
     * Lazily creates a select query string 
     */
    public String getSelectQuery() {
        if(selectQuery == null) {
            StringBuilder builder = new StringBuilder("select ");
            String seperator = "";
            for ( TypeHandler<Object> typeHandler : getTypeHandlers() ) {
                for ( ColumnContext column : typeHandler.getColumns() ) {
                    builder.append(seperator);
                	builder.append(column.getName());
                	seperator = ", ";
                }
            }
            builder.append(" from ");
            builder.append(tableName);
            selectQuery = builder.toString();
        }
        return selectQuery;
    }

    /**
     * Lazily creates a select count query string 
     */
    private String getSelectCountQuery() {
        if(selectCountQuery == null) {
            StringBuilder builder = new StringBuilder("select count(*) from ");
            builder.append(tableName);
            selectCountQuery = builder.toString();
        }
        return selectCountQuery;
    }
    
    public List<T> createListFromResultSet(ResultSet result) throws SQLException {
    	return createListFromResultSet(result,0,Integer.MAX_VALUE);
    }
    /**
     * Creates a bean object out of the resultset
     */
    public List<T> createListFromResultSet(ResultSet result, int offset, int length) throws SQLException {
        List<T> l = new ArrayList<T>();
        while(offset > 0) {
            result.next();
            offset--;
        }
        while(result.next() && length > 0) { 
            l.add(createFromResultSet(result));
            length--;
        }
        return l;
    }

    /**
     * Creates a bean object out of the resultset
     */
    public T createFromResultSet(ResultSet result) throws SQLException {
        try {
            T t = (T) beanClass.newInstance();
            int offset = 1;
            for( TypeHandler<Object> handler : getTypeHandlers() ) {
                WProperty w = (WProperty)handler.getPropertyContext().getValue(t);
                handler.loadProperty(w, result, offset);
                offset+=handler.getColumns().size();
            }

            CurrentSession.get().merge(t,true,false);

            for( SessionEventListener listener : SessionConfiguration.getInstance().getListeners() ) {
            	listener.onLoad(t);
            }
            
            CurrentSession.get().addToCache(t);

            return t;
        } catch (IllegalAccessException ex) {
            throw new BeanBindException(ex);
        } catch (InstantiationException ex) {
            throw new BeanBindException(ex);
        }
    }
    
        
    /**
     * Accepts the primary key for a compound key value
     */
    public T findByPK(final Object... primaryKeyColumnValues) {
        return new QueryExecutor<T>(getSelectPkQuery()) {
        	@Override
        	protected void prepareQuery() throws SQLException {
            	int offset = 0;
                for(TypeHandler<Object> handler : getPrimaryKeyHandlers() ) {
                	handler.loadPreparedStatment(primaryKeyColumnValues, offset, getStatement(), offset+1);
                	offset += handler.getColumns().size();
                }
            }
        	
        	@Override
        	protected T processRow(ResultSet row) throws SQLException {
               	return createFromResultSet(row);
            }
        	
        }.getResult();
    }

    /**
     * Selects a set of beans based on the given SQL where statement. This version
     * will select up to the first 1000 elements and is the equivalent of calling
     * select(where, args, 0, 1000).
     */
    public T fetch(Where where, final Object... args) {
        List<T> oneOrZero = select(where, 0, 1000, args);

        if ( oneOrZero.size() == 0 ) {
        	return null;
        	
        } else if ( oneOrZero.size() == 1 ) {
        	return oneOrZero.get(0);

        } else {
        	throw new TooManyResultsException( where + " returned " + oneOrZero.size() + " records" );
        } 
    }
    
    public List<T> select(String whereClause, final Object...args) {
        return new QueryExecutor<T>(getSelectQuery() + whereClause) {
    		@Override
    		protected void prepareQuery() throws SQLException {
                if(args != null) {
                    for(int iter = 0 ; iter < args.length ; iter++) {
                    	getStatement().setObject(iter + 1, args[iter]);
                    }
                }
            }

    		@Override
        	protected T processRow(ResultSet row) throws SQLException {
                return createFromResultSet(row);
            }
    		
        }.getResults();
    }

    /**
     * Selects a set of beans based on the given SQL where statement. This version
     * will select up to the first 1000 elements and is the equivalent of calling
     * select(where, args, 0, 1000).
     */
    public List<T> select(Where where, final Object... args) {
        return select(where, 0, 1000, args);
    }
    
    /**
     * Selects a set of beans based on the given SQL where statement
     */
    public List<T> select(Where where, final int offset, final int length, final Object... args) {
        if(where == null) {
            where = new Where(this, null);
        }
        return new QueryExecutor<T>(getSelectQuery() + where.getWhere()) {
    		@Override
    		protected void prepareQuery() throws SQLException {
                if(args != null) {
                    for(int iter = 0 ; iter < args.length ; iter++) {
                    	getStatement().setObject(iter + 1, args[iter]);
                    }
                }
            }

    		@Override
        	protected T processRow(ResultSet row) throws SQLException {
                return createFromResultSet(row);
            }
    		
        }.getResults();
    }

    /**
     * Creates a native SQL where statement
     */
    public Where createWhere(String sql) {
        return new Where(this, sql);
    }
    
    /**
     * Allows you to assmeble a where condition
     */
    public Where createWhere(PropertyContext c, SQLOperators operator) {
        return new Where(this, c, operator);
    }
    
    /**
     * This class represents the "where" statement for an SQL query it can just represent a 
     * String based SQL code or it can be constructed dynamically.
     */
    public static class Where {
    	
        private String sql;
        private EntityPersister _entityPersister;
        
        Where(EntityPersister entityPersister, String sql) {
            this.sql = sql;
            _entityPersister = entityPersister;
        }
        
        Where(EntityPersister entityPersister, PropertyContext context, SQLOperators operator) {
            _entityPersister = entityPersister;
            sql = "(" + operator.apply(getPropertyMapping().get(context).getColumns().get(0).getName()) + ")";
        }
        
        Map<PropertyContext, TypeHandler<Object>> getPropertyMapping() {
        	return _entityPersister.getPropertyMapping();
        }
        
        String getWhere() {
            if(sql != null && sql.length() > 0) {
                return " where " + sql;
            } else {
                return "";
            }
        }
        
        /**
         * Adds the given conditional parameter to the where statement
         */       
        public Where and(PropertyContext context, SQLOperators operator) {
            sql += " AND (" + operator.apply(getPropertyMapping().get(context).getColumns().get(0).getName()) + ")";
            return this;
        }

        /**
         * Adds the given conditional parameter to the where statement
         */       
        public Where or(PropertyContext context, SQLOperators operator) {
            sql += " OR (" + operator.apply(getPropertyMapping().get(context).getColumns().get(0).getName()) + ")";
            return this;
        }

        /**
         * Adds the given conditional parameter to the where statement
         */       
        public Where andNot(PropertyContext context, SQLOperators operator) {
            sql += " AND NOT (" + operator.apply(getPropertyMapping().get(context).getColumns().get(0).getName()) + ")";
            return this;
        }
        
        /**
         * Limits the current set of operations until end group, this essentially opens
         * a bracket in the SQL
         */       
        public Where beginGroup() {
            sql += " (";
            return this;
        }
        
        public Where endGroup() {
            sql += ") ";
            return this;
        }
    }
    
    
    public BeanContext getBeanContext() {
		return beanContext;
	}
    
    public Class<T> getBeanClass() {
		return beanClass;
	}
    
    public List<PropertyContext> getPrimaryKeyContexts() {
    	if ( _propertyContexts == null ) {
    		_propertyContexts = _sessionConfiguration.getPrimaryKeyContexts(this);
    	}
		return _propertyContexts;
	}

    public List<TypeHandler<Object>> getTypeHandlers() {
    	if ( _typeHandlers == null ) {
    		initPropertyContextToHandlerMap();
    	}
		return _typeHandlers;
	}

    public int getTypeHandlersColumnCount() {
    	if ( _typeHandlersColumnCount == null ) {
    		int columnCount=0;
        	for( TypeHandler<Object> handler : getTypeHandlers() ) {
        		columnCount += handler.getColumns().size();
        	}
        	_typeHandlersColumnCount = columnCount;
    	}
		return _typeHandlersColumnCount;    	
    }

    public int getPrimaryKeyColumnCount() {
    	if ( _primaryKeyColumnCount == null ) {
    		int columnCount=0;
        	for( TypeHandler<Object> handler : getPrimaryKeyHandlers() ) {
        		columnCount += handler.getColumns().size();
        	}
    		_primaryKeyColumnCount = columnCount;
    	}
		return _primaryKeyColumnCount;
	}
    
    public SessionConfiguration getSessionConfiguration() {
		return _sessionConfiguration;
	}

    public String getTableName() {
		return tableName;
	}
    
    public List<ManyToManyHandler<Object>> getManyToManyHandlers() {
    	if ( _manyToManyHandlers == null ) {
    		_manyToManyHandlers = new ArrayList<ManyToManyHandler<Object>>();
    		for( TypeHandler handler : getTypeHandlers() ) {
    			if ( handler instanceof ManyToManyHandler ) {
    				_manyToManyHandlers.add((ManyToManyHandler<Object>)handler);
    			}
    		}
    	}
		return _manyToManyHandlers;
	}
    
    public void merge(Session session,T bean, boolean mergeEagerProperties, boolean mergeNonEagerProperties, ORMThread.PropertyListener propertyListener) {
    	final int typeHandlerCount = getTypeHandlersColumnCount();
    	List<TypeHandler<Object>> handlers = getTypeHandlers();
    	for (TypeHandler<Object> handler : handlers) {
    		if ( 
    				(handler.doesEagerFetching() && mergeEagerProperties)
    				|| (!handler.doesEagerFetching() && mergeNonEagerProperties)
    		) {
	        	PropertyContext propertyContext = handler.getPropertyContext();
	        	BaseProperty property = propertyContext.getValue(bean);
	            BeanContainer.get().addListener(property, propertyListener);
    		}
        }
    	if ( mergeNonEagerProperties ) {
    		mergeManyToManyProperties(session,bean);
    	} 
        
        for( TypeHandler handler : getTypeHandlers() ) {
            if ( handler instanceof ManyEntityHandler ) {
                ((ManyEntityHandler)handler).merge(session, (IndexedProperty)handler.getPropertyContext().getValue(bean));
            }
        }
    }
    
    private void mergeManyToManyProperties(Session session, T bean) {
		for( ManyToManyHandler<Object> manyToManyHandler : getManyToManyHandlers() ) {
			IndexedProperty<Object> indexedProperty = (IndexedProperty<Object>) manyToManyHandler.getPropertyContext().getValue(bean);
			manyToManyHandler.merge(session, indexedProperty, (List<Object>) null);
		}    	
    }
    
}
