package net.java.dev.properties.jdbc.handlers;


/**
 * a class representing a single column in an sql table
 * 
 * @author Glen Marchesani
 */
public class ColumnContext {

	private String _name;
	private int _sqlType;
	private boolean _nullable = true;
	private boolean _readOnly;
        private int size;
	
	private ColumnContext(String name, int sqlType, int size, boolean nullable, boolean readOnly) {
		setName(name);
		_sqlType = sqlType;
		_nullable = nullable;
		_readOnly = readOnly;
                this.size = size;
	}
	
	public String getName() {
		return _name;
	}
	
	public void setName(String name) {
		_name = name;
	}
	
	public int getSqlType() {
		return _sqlType;
	}
	
	public boolean isNullable() {
		return _nullable;
	}

	public boolean getReadOnly() {
		return _readOnly;
	}
	public void setReadOnly(boolean readOnly) {
		_readOnly = readOnly;
	}
        
        public int getSize() {
            return size;
        }

	public static ColumnContext createSingleColumn(String name, int sqlType, int size, boolean nullable, String[] transientColumns) {
		boolean transien = false;
                if(transientColumns != null) {
                    for ( int i=0; i<transientColumns.length; i++ ) {
                            if ( transientColumns[i].equalsIgnoreCase(name)) {
                                    transien = true;
                            }
                    }
                }
		return new ColumnContext(name,sqlType,size, nullable,transien);
	}
	
}
