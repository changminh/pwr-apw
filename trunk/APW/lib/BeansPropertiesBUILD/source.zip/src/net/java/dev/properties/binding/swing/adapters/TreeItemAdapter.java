/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements table support for propagating selection UI changes
 *
 * @author Shai Almog
 */
class TreeItemAdapter extends SwingAdapter<Object, JTree> implements TreeSelectionListener {
    protected void bindListener(BaseProperty<Object> property, JTree cmp) {
        cmp.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        cmp.getSelectionModel().addTreeSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<Object> property, JTree cmp) {
        cmp.getSelectionModel().removeTreeSelectionListener(this);
    }
        
    /**
     * Recursively searches the tree for the given node
     */
    private TreePath findNode(TreePath path, Object node) {
        Object lastPath = path.getLastPathComponent();
        if(lastPath == node) {
            return path;
        }
        TreeModel model = getComponent().getModel();
        int count = model.getChildCount(lastPath);
        for(int iter = 0 ; iter < count ; iter++) {
            Object child = model.getChild(lastPath, iter);
            TreePath result = findNode(path.pathByAddingChild(child), node);
            if(result != null) {
                return result;
            }
        }
        return null;
    }

    protected void updateUI(Object newValue) {
        if(newValue != null) {
            TreePath root = new TreePath(getComponent().getModel().getRoot());
            TreePath path = findNode(root, newValue);
            if(path != null) {
                getComponent().setSelectionPath(path);
            }
        } else {
            getComponent().clearSelection();
        }
    }            

    public void valueChanged(TreeSelectionEvent e) {
        callWhenUIChanged(getComponent().getSelectionPath().getLastPathComponent());
    }

    protected Class getType() {
        return Object.class;
    }

    protected Class getComponentType() {
        return JTree.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}