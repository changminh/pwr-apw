package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author Glen Marchesani
 */
public class IntegerHandler extends PrimitiveTypeHandler<Integer> {

	public IntegerHandler() {
		super(Integer.class,Types.INTEGER);		
	}

	public Integer get( ResultSet resultSet, int offset) throws SQLException {
		return resultSet.getInt(offset);
	}

	public void initPreparedStatmentImpl(Integer value, PreparedStatement preparedStatement, int offset) throws SQLException {
		preparedStatement.setInt(offset, value);		
	}

}
