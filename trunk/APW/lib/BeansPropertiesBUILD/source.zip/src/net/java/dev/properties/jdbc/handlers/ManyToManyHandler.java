package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.annotations.ManyToMany;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.OnGet;
import net.java.dev.properties.events.OnGetListener;
import net.java.dev.properties.jdbc.BatchUpdateExecutor;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.EntityPersister;
import net.java.dev.properties.jdbc.ORMThread;
import net.java.dev.properties.jdbc.QueryBuilder;
import net.java.dev.properties.jdbc.QueryExecutor;
import net.java.dev.properties.jdbc.SQLExecutor;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionAware;
import net.java.dev.properties.jdbc.SessionConfiguration;
import net.java.dev.properties.jdbc.UpdateQueryExecutor;


/**
 * 
 * DONEgm implement bidi many to many associations
 * TODOgm remove the need to have ManyToMany.transietSide()
 * TODOgm similarly have createTable() be called for only one side of a bidi many to many 
 * 
 * @author Glen Marchesani
 */
public class ManyToManyHandler<T> extends AbstractTypeHandler<T> {

	private String _insertQuery;
	private String _deleteQuery;
	
	private String _tableName;
	private String[] _localKeyColumnNames;
	private String[] _foreignKeyColumnNames;
	
	private EntityPersister<T> _foreignEntityPersister;

	private boolean _transientSide;

    public ManyToManyHandler() {
    }

    public boolean canHandleType(Class<?> type) {
        return false;
    }

    @Override
    protected void initColumns() {
        setColumns(new ArrayList<ColumnContext>());
    }

    public void loadPreparedStatment(Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
    }

	public void loadColumnValues(RProperty<T> property, Object[] columnValues, int columnValuesOffset) {		
	}

    public void loadProperty(WProperty<T> property, ResultSet resultSet, int offset) throws SQLException {

    	if ( property instanceof OnGetListener ) {

    		final OnGetListener onGetListener = (OnGetListener) property;

			onGetListener.setOnGet( new OnGet() {
				public void onGet(RProperty<?> p) {
					WProperty wProperty = (WProperty) p;
					List<T> originalCollection = getManyEntities((Property)p);
					wProperty.set(originalCollection);

					final IndexedProperty<T> indexedProperty = (IndexedProperty<T>) p;

					// we are initialized so this listener can remove itself
					onGetListener.setOnGet(null);

					merge(CurrentSession.get(), indexedProperty, originalCollection);
				}
			});

			BeanContainer.get().addListener(property, new ORMThread.PropertyListener() {
				public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
					
				}
			});

    	} else {
    		throw new RuntimeException( "properties must support an OnGetListener" );
    	}
    }
    
    List<T> getManyEntities( Property property ) {
    	    	
		StringBuilder queryStringBuilder = new StringBuilder();

		queryStringBuilder.append( "select " );

		String separator = "";
		for( String localColumnName : getLocalKeyColumnNames() ) {
			queryStringBuilder.append(separator);
			queryStringBuilder.append( localColumnName );
			separator = ", ";
		}
		for( String foreignColumnName : getForeignKeyColumnNames() ) {
			queryStringBuilder.append(separator);
			queryStringBuilder.append( foreignColumnName );
			separator = ", ";
		}

		queryStringBuilder.append( " from " );

		queryStringBuilder.append( getTableName() );

		queryStringBuilder.append( " where " );

		separator = "";
		for ( String columnName : _localKeyColumnNames ) {
			queryStringBuilder.append(separator);
			queryStringBuilder.append( columnName );
			queryStringBuilder.append( " = ?" );
			separator = " and ";
		}

		List<T> response = new SelectManyQuery( queryStringBuilder.toString(), property.getParent() ).getResults();

		return response;
    }

    public EntityPersister<T> getForeignEntityPersister() {
		if ( _foreignEntityPersister == null ) {
			_foreignEntityPersister = (EntityPersister) ((Object) SessionConfiguration.getInstance().getPersister(getForeignEntityType())); 
		}
		return _foreignEntityPersister;
    }
    
    public String getTableName() {
    	if ( _tableName == null ) {
    		String table1 = getParentEntityPersister().getTableName();
    		String table2 = getForeignEntityPersister().getTableName();
    		if ( table1.compareTo(table2) > 0 ) {
    			String hold = table2;
    			table2 = table1;
    			table1 = hold;
    		}
    		_tableName = table1 + "_" + table2;
    	}
		return _tableName;
	}

    public void setTableName(String tableName) {
		_tableName = tableName;
	}

    public void setLocalKeyColumnNames(String[] localKeyColumnNames) {
		_localKeyColumnNames = localKeyColumnNames;
	}

    public void setForeignKeyColumnNames(String[] foreignKeyColumnNames) {
		_foreignKeyColumnNames = foreignKeyColumnNames;
	}

	public Class<Set<T>> getForeignEntityType() {
		return (Class<Set<T>>) getPropertyContext().getType();
	}


	class SelectManyQuery extends QueryExecutor<T> {
		
		private Object _bean;
		
		SelectManyQuery(String sql,Object bean) {
			super(sql,false);
			_bean = bean;
			execute();
		}

		@Override
		protected void prepareQuery() throws SQLException {
        	Object[] columnValues = ((EntityPersister<Object>)getParentEntityPersister()).getPrimaryKeyColumnValues(_bean);

        	EntityPersister.processPreparedStatementHandlers(
        			_bean, 
        			getStatement(), 
        			getParentEntityPersister().getPrimaryKeyHandlers(), 
        			columnValues.length, 
        			columnValues, 
        			0
        	);
        	
        }
		
		@Override
		protected T processRow(ResultSet row) throws SQLException {
            return getForeignEntityPersister().createFromResultSet(row);
        }
		
	}
	
	public String[] getLocalKeyColumnNames() {
		if ( _localKeyColumnNames == null ) {
			_localKeyColumnNames = getParentEntityPersister().getPrimaryKeyColumnNames();			
			for (int i = 0; i < _localKeyColumnNames.length; i++) {
				_localKeyColumnNames[i] = getParentEntityPersister().getTableName() + "_" + _localKeyColumnNames[i];
			}
		}
		return _localKeyColumnNames;
	}
	
	public String[] getForeignKeyColumnNames() {
		if ( _foreignKeyColumnNames == null ) {
			_foreignKeyColumnNames = getForeignEntityPersister().getPrimaryKeyColumnNames();
			for (int i = 0; i < _foreignKeyColumnNames.length; i++) {
				_foreignKeyColumnNames[i] = getForeignEntityPersister().getTableName() + "_" + _foreignKeyColumnNames[i];
			}
		}
		return _foreignKeyColumnNames;
	}
	
	@Override
	public void activated() {
		super.activated();
		
		ManyToMany manyToMany = getPropertyContext().getField().getAnnotation( ManyToMany.class );
		if ( manyToMany != null ) {
			if ( manyToMany.foreignKeyColumns().length() > 0 ) {
				setForeignKeyColumnNames(manyToMany.foreignKeyColumns().split(","));
			}
			if ( manyToMany.localKeyColumns().length() > 0 ) {
				setLocalKeyColumnNames(manyToMany.localKeyColumns().split(","));
			}
			if ( manyToMany.tableName().length() > 0 ) {
				setTableName(manyToMany.tableName());
			}
			setTransientSide(manyToMany.transientSide());
		}

	}

	public void dropTable() {
            new UpdateQueryExecutor("drop table " + getTableName() + " if exists" );		
	}
	
	public void createTable() {
        StringBuilder b = new StringBuilder("create table ");
        b.append(getTableName());
        b.append(" (");

        StringBuilder primaryKeys = new StringBuilder();
        String primaryKeySeparator = "";
        String separator = "";
        int columnIndex = 0;
        for( TypeHandler<Object> typeHandler : getParentEntityPersister().getPrimaryKeyHandlers() ) {
            for(ColumnContext column : typeHandler.getColumns()) {
            	String columnName = getLocalKeyColumnNames()[columnIndex];
                b.append(separator);
            	b.append(columnName);
                b.append(" ");                    
                b.append(SQLExecutor.getSqlTypeName(column.getSqlType(), column.getSize()));
                separator = ", ";
            	primaryKeys.append(primaryKeySeparator);
            	primaryKeys.append(columnName);
            	primaryKeySeparator = ", ";
                columnIndex++;
            }
        }
        columnIndex = 0;
        for( TypeHandler<Object> typeHandler : getForeignEntityPersister().getPrimaryKeyHandlers() ) {
            for(ColumnContext column : typeHandler.getColumns()) {
            	String columnName = getForeignKeyColumnNames()[columnIndex];
                b.append(separator);
            	b.append(columnName);
                b.append(" ");                    
                b.append(SQLExecutor.getSqlTypeName(column.getSqlType(), column.getSize()));
                separator = ", ";
            	primaryKeys.append(primaryKeySeparator);
            	primaryKeys.append(columnName);
            	primaryKeySeparator = ", ";
                columnIndex++;
            }
        }
        
        b.append( ", PRIMARY KEY(" );
        b.append(primaryKeys);
        b.append(")");
        
        b.append(")");
        
        new UpdateQueryExecutor(b.toString());

	}
	
	public class ManyToManyRecord {
		
		private Object _localEntity;
		private Object _foreignEntity;
		
		private Object[] _localKeyValues;
		private Object[] _foreignKeyValues;
		
		@Override
		public int hashCode() {
			final int PRIME = 31;
			int result = 1;
			result = PRIME * result + Arrays.hashCode(getForeignKeyValues());
			result = PRIME * result + Arrays.hashCode(getLocalKeyValues());
			return result;
		}
		
		Object[] getLocalKeyValues() {
			if ( _localKeyValues == null ) {
				_localKeyValues = getParentEntityPersister().getPrimaryKeyColumnValues(_localEntity);
			}
			return _localKeyValues;
		}
		
		Object[] getForeignKeyValues() {
			if ( _foreignKeyValues == null ) {
				_foreignKeyValues = getForeignEntityPersister().getPrimaryKeyColumnValues((T)_foreignEntity);
			}
			return _foreignKeyValues;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final ManyToManyRecord other = (ManyToManyRecord) obj;
			if (!Arrays.equals(getForeignKeyValues(), other.getForeignKeyValues()))
				return false;
			if (!Arrays.equals(getLocalKeyValues(), other.getLocalKeyValues()))
				return false;
			return true;
		}
		
	}
	
	class ManyToManyCollectionProxy implements ORMThread.PropertyListener {
		private Collection<T> _collection;
		
		public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
			
		}
		
	}
	
	public boolean doesEagerFetching() {
		return false;
	}

	public class CollectionProxy implements SessionAware {

		private IndexedProperty<T> _indexedProperty;
		private List<T> _originalCollection;

		private CollectionProxy(IndexedProperty<T> indexedProperty, List<T> originalCollection) {
			super();
			_indexedProperty = indexedProperty;
			_originalCollection = originalCollection;
		}

		public void processDeletes() {
			List<?> newList = _indexedProperty.get();
			// all elementes in the new list not in the old one are inserted as new records
			List<Object> deletes = new ArrayList<Object>();
			for( Object o : _originalCollection ) {
				if ( !newList.contains( o ) ) { 
					deletes.add(o);
				}
			}
			processBeanQueries(getDeleteQuery(), deletes );
		}

		public void processInserts() {
			List<?> newList = _indexedProperty.get();
			// insert all elementes in the new list not in the old one
			List<Object> inserts = new ArrayList<Object>();
			for( Object o : newList ) {
				if ( !_originalCollection.contains( o ) ) { 
					inserts.add(o);
				}
			}
			processBeanQueries(getInsertQuery(), inserts );
		}
		
		@SuppressWarnings("unchecked")
		void processBeanQueries( String sql, List<Object> beans ) {
            new BatchUpdateExecutor<Object>(sql, beans) {
            	@Override
            	protected void addBeanToBatchStatement(Object bean) throws SQLException {
            		Object[] columnValues = new Object[getColumnCount()];
            		EntityPersister.processPreparedStatementHandlers(bean, getStatement(), getForeignEntityPersister().getPrimaryKeyHandlers(), _foreignKeyColumnNames.length, columnValues, 0);
            		EntityPersister.processPreparedStatementHandlers(_indexedProperty.getParent(), getStatement(), getParentEntityPersister().getPrimaryKeyHandlers(), _localKeyColumnNames.length, columnValues, _foreignKeyColumnNames.length);
                }
            };
		}
		
		public void processUpdates() {
		}

		@Override
		public int hashCode() {
			final int PRIME = 31;
			int result = 1;
			result = PRIME * result + ((_indexedProperty == null) ? 0 : _indexedProperty.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final CollectionProxy other = (CollectionProxy) obj;
			if (_indexedProperty == null) {
				if (other._indexedProperty != null)
					return false;
			} else if (!_indexedProperty.equals(other._indexedProperty))
				return false;
			return true;
		}
	}
	
	int getColumnCount() {
		return _foreignKeyColumnNames.length + _localKeyColumnNames.length;
	}

	private List<String> getForeignAndLocalColumns() {
		List<String> columns = new ArrayList<String>();
		Collections.addAll(columns, _foreignKeyColumnNames);
		Collections.addAll(columns, _localKeyColumnNames);
		return columns;
	}
	
    /**
     * Lazily creates an insert query string 
     */
    private String getInsertQuery() {
        if(_insertQuery == null) {
        	QueryBuilder queryBuilder = new QueryBuilder();
        	queryBuilder.append("insert into ");
        	queryBuilder.append(getTableName());
        	queryBuilder.append(" (");
        	
        	List<String> columns = getForeignAndLocalColumns();
        	String seperator = "";
        	for( String columnName : columns ) {
            	queryBuilder.append(seperator);
            	queryBuilder.append(columnName);
            	seperator = ", "; 
        	}

            queryBuilder.append(" ) values ( ");

            seperator = "";
            for(int i=0 ; i<columns.size(); i++) {
            	queryBuilder.append(seperator);
            	queryBuilder.append("?");
                seperator = ", ";
            }
            
        	queryBuilder.append(" )");
        	
        	_insertQuery = queryBuilder.toString();

        }
        
        return _insertQuery;
    }
    
    
    /**
     * Lazily creates an delete query string 
     */
    private String getDeleteQuery() {
        if(_deleteQuery == null) {
        	QueryBuilder queryBuilder = new QueryBuilder();
        	queryBuilder.append("delete from ");
        	queryBuilder.append(getTableName());
        	queryBuilder.append(" where ");

        	String seperator = "";
        	for( String columnName : getForeignAndLocalColumns() ) {
        		queryBuilder.append( seperator );
        		queryBuilder.append( columnName );
        		queryBuilder.append( " = ? " );
        		seperator = " and ";
        	}

            _deleteQuery = queryBuilder.getSql();
        }
        return _deleteQuery;
    }
    
    public void merge( final Session session, final IndexedProperty<T> indexedProperty, List<T> originalCollection ) {
		if ( !_transientSide ) {
	    	if ( originalCollection == null ) {
	    		originalCollection = indexedProperty.get();
	    	}
			final List<T> finalOriginalCollection = new ArrayList<T>(originalCollection);

			BeanContainer.get().addListener(indexedProperty, new ORMThread.IndexedPropertyListener() {
				public void propertyInserted(IndexedProperty prop, Object value, int index) {
					session.insert(new CollectionProxy(indexedProperty,finalOriginalCollection));
				}
				public void propertyRemoved(IndexedProperty prop, Object value, int index) {
					session.delete(new CollectionProxy(indexedProperty,finalOriginalCollection));
				}
				public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
					session.insert(new CollectionProxy(indexedProperty,finalOriginalCollection));
				}
			});
		}

    }

    public void setTransientSide(boolean transientSide) {
		_transientSide = transientSide;
	}

}
