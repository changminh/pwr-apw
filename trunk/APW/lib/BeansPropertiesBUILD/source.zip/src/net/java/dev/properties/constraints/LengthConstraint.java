/*
 * LengthConstraint.java
 *
 * Created on March 6, 2007, 2:37 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

import java.text.NumberFormat;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;

/**
 * Allows us to define a minimum/maximum length constraint, this differs from
 * range by working on the number of characters. When applied to indexed properties
 * this indicates the number of entries rather than their values.
 *
 * @see net.java.dev.properties.annotations.Length
 * @author Shai Almog
 */
public class LengthConstraint implements Constraint {
    private int min;
    private int max;
    
    public LengthConstraint(int min, int max) {
        this.min = min;
        this.max = max;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public boolean validate(BaseProperty prop, Object value) {
        if(value == null) {
            return false;
        }
        int length;
        if(prop instanceof IndexedProperty) {
            length = ((IndexedProperty)prop).size();
        } else {
            if(value instanceof Number) {
                length = NumberFormat.getInstance().format(value).length();
            } else {
                length = value.toString().length();
            }
        }
        return getMin() <= length && length <= getMax();
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }
}
