package net.java.dev.properties.test.demos;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.VirtualPropertyContext;
import net.java.dev.properties.events.PropertyListener;
import net.java.dev.properties.test.DemoInterface;
import net.java.dev.properties.test.NewBean;

/**
 * A demo of using a new bean that matches the functionality of the legacy bean
 *
 * @author shai
 */
public class VirtualPropertyDemo extends DemoInterface.DefaultConsoleDemo {
    public VirtualPropertyDemo() {
        super("Virtual Properties", "<html><body><h1>Virtual Properties</h1>" +
                "Virtual properties allow us to add new properties in runtime to a " +
                "preexisting bean, this properties will not be visible in code but will be visible to the API. " +
                "Thus when adding a virtual property it could be manipulated by the bindings to XML/GUI/Database etc... " +
                "There are several use cases for such a feature such as the ability to keep the domain object clean " +
                "or the ability to provide custom fields for a particular deployment.<br>" +
                "Virtual properties allow features such as Ruby type scaffolding used by tools such as RoR to import " +
                "the columns of a table directly into an object. While this feature is not currently supported " +
                "by bean-properties (and we don't think its a good feature) we are thinking about adding it for the " +
                "sake of completeness.",
                new Class[] {VirtualPropertyDemo.class, NewBean.class});
    }

    public void run() {
        NewBean bean = new NewBean();
        bean.x.set(1);
        
        getOutput().println("Bean before virtual property: " + BeanContainer.get().toString(bean));
        
        BeanContext context = BeanContainer.get().getContext(bean);
        context.addVirtual(new VirtualPropertyContext("y", Integer.class));
        
        getOutput().println("Bean after adding virtual property: " + BeanContainer.get().toString(bean));
        
        PropertyListener l = new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
               getOutput().println("New bean " + prop.getContext().getName() + " was changed " + newValue);
            }
        };
        
        BeanContainer.get().addListener(bean, l);
        Property yProperty = (Property)context.getByName("y").getValue(bean);
        yProperty.set(2);
        BeanContainer.get().removeListener(bean, l);
        BeanContainer.get().addListener(yProperty, l);
        yProperty.set(3);
    }
}
