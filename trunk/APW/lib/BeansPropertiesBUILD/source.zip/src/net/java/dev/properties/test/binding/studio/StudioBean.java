/*
 * StudioBean.java
 *
 * Created on March 7, 2007, 11:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.studio;

import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.annotations.Bean;
import net.java.dev.properties.annotations.Bidirectional;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableIndexed;

/**
 * Main class of which there is one instance containing all the students and classes
 * in the studio
 *
 * @author Shai Almog
 */
@Bean(resourceBundle="net.java.dev.properties.test.binding.studio.resources", localize=true)
public class StudioBean implements java.io.Serializable, StudioBeanInterface {
    public final IndexedProperty<StudentBean> students = ObservableIndexed.create();

    public final IndexedProperty<YogaClassBean> classes = ObservableIndexed.create();

    public final IndexedProperty<AttendanceBean> attendance = ObservableIndexed.create();
    
    /** Creates a new instance of StudioBean */
    public StudioBean() {
        BeanContainer.bind(this);
    }    

    public IndexedProperty<StudentBean> students() {
        return students;
    }
    
    public IndexedProperty<YogaClassBean> classes() {
        return classes;
    }
    
    public IndexedProperty<AttendanceBean> attendance() {
        return attendance;
    }
}
