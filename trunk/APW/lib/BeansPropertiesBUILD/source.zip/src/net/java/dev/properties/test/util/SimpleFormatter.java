package net.java.dev.properties.test.util;


import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.MessageFormat;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;

/**
 * 
 * A JDK logging formatter for use in unit tests and other "development" environments. 
 * The idea is to have as little information as possible.  In other words minimal info
 * is given for each log message 
 * 
 *   logger name
 *   logger level
 *   message
 *   throwable (if there is one atached to the message)
 * 
 * The logger name and logger level are padded so the message always appears on the same column.
 * This should make it easier to quickly eye through a large set of messages.  Note on multi-line 
 * messages the second line is not indented.
 * 
 * @author Glen Marchesani
 */

public class SimpleFormatter extends Formatter {

	private Date date = new Date();

	private final static String format = "{0,time}";

	private MessageFormat formatter;

	private String fieldSeparator = " | ";
	private String lineSeparator = "\n";

	/**
	 * Format the given LogRecord.
	 * 
	 * @param record
	 *            the log record to be formatted.
	 * @return a formatted log record
	 */
	@Override
	public synchronized String format(LogRecord record) {
		StringBuilder sb = new StringBuilder();
		
		// Minimize memory allocations here.
		date.setTime(record.getMillis());
		
		StringBuffer text = new StringBuffer();
		if (formatter == null) {
			formatter = new MessageFormat(format);
		}
		
//		// DATE and TIME
//		formatter.format(new Object[] { date }, text, null);
//		sb.append(text);
//		sb.append(fieldSeparator);
//
//		// THREAD NAME
//		sb.append(fieldSeparator);
//		sb.append(Thread.currentThread().getName());		

		// LOGGER NAME
		String loggerName = record.getLoggerName();
		if ( loggerName.startsWith( "gov.sensornet.isp" ) ) {
			loggerName = loggerName.substring( "gov.sensornet.isp".length() );
		}
		sb.append( loggerName );
		
		while( sb.length() < 20 ) {
			sb.append(" ");
		}
		sb.append(fieldSeparator);

		// LEVEL
		String level = record.getLevel().getLocalizedName();
		sb.append(level);		
		while( sb.length() < 30 ) {
			sb.append(" ");
		}
		sb.append(fieldSeparator);

		
		// MESSAGE
		String message = formatMessage(record);
		sb.append(message);
		sb.append(lineSeparator);
		if (record.getThrown() != null) {
			try {
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				pw.print( "   " );
				record.getThrown().printStackTrace(pw);
				pw.close();
				sb.append(sw.toString());
			} catch (Exception ex) {
			}
		}
		return sb.toString();
	}
}
