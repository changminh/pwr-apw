/*
 * DemoGUI.java
 *
 * Created on April 13, 2007, 11:50 PM
 */

package net.java.dev.properties.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.WeakHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.swing.AbstractAction;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;
import javax.swing.tree.*;
import net.java.dev.properties.test.binding.BindingDemoGUI;
import net.java.dev.properties.test.binding.TreeBindingTest;
import net.java.dev.properties.test.binding.ValidationTest;
import net.java.dev.properties.test.demos.AdvancedFeaturesDemo;
import net.java.dev.properties.test.demos.CompatibilityBeanDemo;
import net.java.dev.properties.test.demos.I18nDemo;
import net.java.dev.properties.test.demos.LegacyDemo;
import net.java.dev.properties.test.demos.MirrorBeanDemo;
import net.java.dev.properties.test.demos.NewBeanDemo;
import net.java.dev.properties.test.demos.VirtualPropertyDemo;
import net.java.dev.properties.test.demos.WrapDemo;
import net.java.dev.properties.test.demos.XMLStudio;
import net.java.dev.properties.test.demos.orm.ORMDemo;
import net.java.dev.properties.test.demos.orm.ORMStudioDemo;

/**
 * This class represents the GUI for the demo that allows us to select the specific
 * demo and also view the appropriate sources. The demo expects a source.zip file
 * in the distribution root.
 *
 * @author  shai
 */
public class DemoGUI extends javax.swing.JPanel {
    private static final Pattern[] keywords = new Pattern[] {
        Pattern.compile("\\babstract\\b"),
        Pattern.compile("\\bcontinue\\b"),
        Pattern.compile("\\bfor\\b"),
        Pattern.compile("\\bnew\\b"),
        Pattern.compile("\\bswitch\\b"),
        Pattern.compile("\\bassert\\b"),
        Pattern.compile("\\bdefault\\b"),
        Pattern.compile("\\bgoto\\b"),
        Pattern.compile("\\bpackage\\b"),
        Pattern.compile("\\bsynchronized\\b"),
        Pattern.compile("\\bboolean\\b"),
        Pattern.compile("\\bdo\\b"),
        Pattern.compile("\\bif\\b"),
        Pattern.compile("\\bprivate\\b"),
        Pattern.compile("\\bthis\\b"),
        Pattern.compile("\\bbreak\\b"),
        Pattern.compile("\\bdouble\\b"),
        Pattern.compile("\\bimplements\\b"),
        Pattern.compile("\\bprotected\\b"),
        Pattern.compile("\\bthrow\\b"),
        Pattern.compile("\\bbyte\\b"),
        Pattern.compile("\\belse\\b"),
        Pattern.compile("\\bimport\\b"),
        Pattern.compile("\\bpublic\\b"),
        Pattern.compile("\\bthrows\\b"),
        Pattern.compile("\\bcase\\b"),
        Pattern.compile("\\benum\\b"),
        Pattern.compile("\\binstanceof\\b"),
        Pattern.compile("\\breturn\\b"),
        Pattern.compile("\\btransient\\b"),
        Pattern.compile("\\bcatch\\b"),
        Pattern.compile("\\bextends\\b"),
        Pattern.compile("\\bint\\b"),
        Pattern.compile("\\bshort\\b"),
        Pattern.compile("\\btry\\b"),
        Pattern.compile("\\bchar\\b"),
        Pattern.compile("\\bfinal\\b"),
        Pattern.compile("\\binterface\\b"),
        Pattern.compile("\\bstatic\\b"),
        Pattern.compile("\\bvoid\\b"),
        Pattern.compile("\\bclass\\b"),
        Pattern.compile("\\bfinally\\b"),
        Pattern.compile("\\blong\\b"),
        Pattern.compile("\\bstrictfp\\b"),
        Pattern.compile("\\bvolatile\\b"),
        Pattern.compile("\\bconst\\b"),
        Pattern.compile("\\bfloat\\b"),
        Pattern.compile("\\bnative\\b"),
        Pattern.compile("\\bsuper\\b"),
        Pattern.compile("\\bwhile\\b")};
    
    private final DemoInterface[] demos = new DemoInterface[] {
        new LegacyDemo(),
        new NewBeanDemo(),
        new CompatibilityBeanDemo(),
        new AdvancedFeaturesDemo(),
        new MirrorBeanDemo(),
        new VirtualPropertyDemo(),
        new WrapDemo(),
        new BindingDemoGUI(),
        new TreeBindingTest(),
        new ValidationTest(),
        new net.java.dev.properties.test.binding.studio.Main(),
        new I18nDemo(),
        new net.java.dev.properties.test.binding.mirror.Main(),
        new XMLStudio(),
        new ORMDemo()/*,
        new ORMStudioDemo()*/
    };
    
    private static final Tutorial[] tutorials = new Tutorial[] {
        new Tutorial("Basics", "https://bean-properties.dev.java.net/tutorial.html"),
        new Tutorial("Advanced", "https://bean-properties.dev.java.net/tutorial2.html"),
        new Tutorial("Binding", "https://bean-properties.dev.java.net/tutorial3.html"),
        new Tutorial("Factories", "https://bean-properties.dev.java.net/quickstart.html"),
        new Tutorial("Mirror Objects", "https://bean-properties.dev.java.net/mirrors.html"),
        new Tutorial("Echo2 Integration", "https://bean-properties.dev.java.net/echo2.html"),
        new Tutorial("SwingX Integration", "https://bean-properties.dev.java.net/swingx.html"),
        new Tutorial("ORM", "https://bean-properties.dev.java.net/orm.html")
    };
        
    private DemoInterface currentDemo;
    private DemoInterface previousDemo;
    
    /** Creates new form DemoGUI */
    public DemoGUI() {
        initComponents();
        
        for(Tutorial t : tutorials) {
            tutorialsCombo.addItem(t);
        }
        
        currentTutorial.addHyperlinkListener(new HyperlinkListener() { 
            public void hyperlinkUpdate(HyperlinkEvent e) {
                if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                    if (e instanceof HTMLFrameHyperlinkEvent) {
                        HTMLFrameHyperlinkEvent  evt = (HTMLFrameHyperlinkEvent)e;
                        HTMLDocument doc = (HTMLDocument)currentTutorial.getDocument();
                        doc.processHTMLFrameHyperlinkEvent(evt);
                    } else {
                        setPage(e.getURL().toExternalForm());
                    }
                }
            }
        });
        
        tutorialsCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Tutorial t = (Tutorial)tutorialsCombo.getSelectedItem();
                if(t != null) {
                    setPage(t.getURL());
                }
            }
        });
        
        demoList.setListData(demos);
        demoList.setCellRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                return super.getListCellRendererComponent(list, ((DemoInterface)value).demoName(), index, isSelected, cellHasFocus);
            }
        });
        sourceTree.addTreeSelectionListener(new TreeSelectionListener() {
            private Map<TreePath, JScrollPane> cache = new WeakHashMap<TreePath, JScrollPane>();
            private JScrollPane getEditor(TreePath path, String selection) {
                JScrollPane pane = cache.get(path);
                if(pane == null) {
                    Directory dir = (Directory)path.getParentPath().getLastPathComponent();
                    pane = new JScrollPane(new SyntaxHighlightPane(dir.getFileContent((String)selection)));
                    cache.put(path, pane);
                }
                return pane;
            }
            
            public void valueChanged(TreeSelectionEvent e) {
                while(sourcePane.getTabCount() > 0) {
                    // probably more efficient than sourcePane.removeTabAt(0);
                    sourcePane.removeTabAt(sourcePane.getTabCount() - 1);
                }
                TreePath[] paths = sourceTree.getSelectionPaths();
                if(paths != null) {
                    for(TreePath path : paths) {
                        Object selection = path.getLastPathComponent();
                        if(selection instanceof String) {
                            Directory dir = (Directory)path.getParentPath().getLastPathComponent();
                            sourcePane.addTab((String)selection, getEditor(path, (String)selection));
                        }
                    }
                }
            }
        });
        
        sourceTree.setCellRenderer(new DefaultTreeCellRenderer() {
            public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
                super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
                if(currentDemo != null && value instanceof String) {
                    for(String name : currentDemo.fileNames()) {
                        if(name.endsWith((String)value)) {
                            setForeground(Color.RED);
                            return this;
                        }
                    }
                }
                return this;
            }
        });
        
        // will set itself into the tree once it completes loading
        new ZipContentTreeModel();
    }
    
    /**
     * A version of set page from the editor pane that handles the IOException
     */
    private void setPage(String url) {
        try {
            currentTutorial.setPage(url);
        } catch(IOException err) {
            err.printStackTrace();
            JOptionPane.showMessageDialog(this, "Could not open the URL for the tutorial", "Network Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabs = new javax.swing.JTabbedPane();
        selection = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        demoList = new javax.swing.JList();
        runDemo = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        description = new javax.swing.JEditorPane();
        demo = new javax.swing.JPanel();
        runDemoButtonPanel = new javax.swing.JPanel();
        demoNameLabel = new javax.swing.JLabel();
        reRunDemoButton = new javax.swing.JButton();
        sourceSplit = new javax.swing.JSplitPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        sourceTree = new JTree(new Object[] {"Loading..."});
        sourcePane = new javax.swing.JTabbedPane();
        tutorialPanel = new javax.swing.JPanel();
        tutorialsCombo = new javax.swing.JComboBox();
        jScrollPane3 = new javax.swing.JScrollPane();
        currentTutorial = new javax.swing.JEditorPane();

        FormListener formListener = new FormListener();

        jLabel1.setText("<html><body>Select the appropriate demo from the demo list, run it in the demo tab,<br> review it in the source tab and learn about it in the tutorial tab");

        demoList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        demoList.addListSelectionListener(formListener);
        jScrollPane1.setViewportView(demoList);

        runDemo.setText("Run Demo");
        runDemo.addActionListener(formListener);

        jScrollPane4.setViewportView(description);

        org.jdesktop.layout.GroupLayout selectionLayout = new org.jdesktop.layout.GroupLayout(selection);
        selection.setLayout(selectionLayout);
        selectionLayout.setHorizontalGroup(
            selectionLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, selectionLayout.createSequentialGroup()
                .addContainerGap()
                .add(selectionLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 676, Short.MAX_VALUE)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 676, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, runDemo)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel1))
                .addContainerGap())
        );
        selectionLayout.setVerticalGroup(
            selectionLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(selectionLayout.createSequentialGroup()
                .add(26, 26, 26)
                .add(jLabel1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(runDemo)
                .addContainerGap())
        );

        tabs.addTab("Selection", selection);

        demo.setOpaque(false);
        demo.setLayout(new java.awt.BorderLayout());

        runDemoButtonPanel.setOpaque(false);
        runDemoButtonPanel.add(demoNameLabel);

        reRunDemoButton.setText("Run Demo");
        reRunDemoButton.setEnabled(false);
        reRunDemoButton.setOpaque(false);
        reRunDemoButton.addActionListener(formListener);
        runDemoButtonPanel.add(reRunDemoButton);

        demo.add(runDemoButtonPanel, java.awt.BorderLayout.NORTH);

        tabs.addTab("Demo", demo);

        sourceSplit.setResizeWeight(0.3);
        sourceSplit.setContinuousLayout(true);

        sourceTree.setRootVisible(false);
        jScrollPane2.setViewportView(sourceTree);

        sourceSplit.setLeftComponent(jScrollPane2);

        sourcePane.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);
        sourceSplit.setRightComponent(sourcePane);

        tabs.addTab("Source", sourceSplit);

        tutorialPanel.setOpaque(false);

        currentTutorial.setEditable(false);
        jScrollPane3.setViewportView(currentTutorial);

        org.jdesktop.layout.GroupLayout tutorialPanelLayout = new org.jdesktop.layout.GroupLayout(tutorialPanel);
        tutorialPanel.setLayout(tutorialPanelLayout);
        tutorialPanelLayout.setHorizontalGroup(
            tutorialPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, tutorialPanelLayout.createSequentialGroup()
                .addContainerGap()
                .add(tutorialPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 676, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, tutorialsCombo, 0, 676, Short.MAX_VALUE))
                .addContainerGap())
        );
        tutorialPanelLayout.setVerticalGroup(
            tutorialPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(tutorialPanelLayout.createSequentialGroup()
                .add(tutorialsCombo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabs.addTab("Tutorial", tutorialPanel);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, tabs, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 737, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, tabs, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 389, Short.MAX_VALUE)
        );
    }

    // Code for dispatching events from components to event handlers.

    private class FormListener implements java.awt.event.ActionListener, javax.swing.event.ListSelectionListener {
        FormListener() {}
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            if (evt.getSource() == runDemo) {
                DemoGUI.this.runDemoActionPerformed(evt);
            }
            else if (evt.getSource() == reRunDemoButton) {
                DemoGUI.this.reRunDemoButtonActionPerformed(evt);
            }
        }

        public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
            if (evt.getSource() == demoList) {
                DemoGUI.this.demoListValueChanged(evt);
            }
        }
    }// </editor-fold>//GEN-END:initComponents
    
    private void reRunDemoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reRunDemoButtonActionPerformed
        runDemoActionPerformed(evt);
    }//GEN-LAST:event_reRunDemoButtonActionPerformed
    
    private void demoListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_demoListValueChanged
        currentDemo = (DemoInterface)demoList.getSelectedValue();
        boolean demoSelected = currentDemo != null;
        if(demoSelected) {
            String desc = currentDemo.demoDescription();
            if(desc.startsWith("<html>")) {
                description.setContentType("text/html");
            } else {
                description.setContentType("text/plain");
            }
            description.setText(desc);
            if(!(sourceTree.getModel() instanceof ZipContentTreeModel)) {
                return;
            }
            String[] files = currentDemo.fileNames();
            TreePath[] paths = new TreePath[files.length];
            //sourceTree.collapsePath(new TreePath(sourceTree.getModel().getRoot()));
            for(int iter = 0 ; iter < paths.length ; iter++) {
                paths[iter] = createPath(files[iter]);
                //sourceTree.expandPath(paths[iter]);
            }
            sourceTree.setSelectionPaths(paths);
            demoNameLabel.setText(currentDemo.demoName());
        } else {
            description.setText("");
            demoNameLabel.setText("No Demo Selected");
        }
        runDemo.setEnabled(demoSelected);
        reRunDemoButton.setEnabled(demoSelected);
    }//GEN-LAST:event_demoListValueChanged
    
    private void runDemoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runDemoActionPerformed
        tabs.setSelectedIndex(1);
        if(previousDemo != null) {
            previousDemo.cleanup();
        }
        previousDemo = currentDemo;
        demo.removeAll();
        demo.add(runDemoButtonPanel, BorderLayout.NORTH);
        demo.add(currentDemo.execute(), BorderLayout.CENTER);
        revalidate();
    }//GEN-LAST:event_runDemoActionPerformed
    
    /**
     * Creates a path for the given file name
     */
    private TreePath createPath(String fileName) {
        return ((ZipContentTreeModel)sourceTree.getModel()).getPath(fileName);
    }
    
    /**
     * Returns the Java source file paths corresponding to the given classes.
     */
    public static String[] demoFiles(Class[] classes) {
        String[] files = new String[classes.length];
        for(int iter = 0; iter < classes.length ; iter++) {
            files[iter] = "/src/" + classes[iter].getName().replace('.', '/') + ".java";
        }
        return files;
    }
    
    private static class Directory {
        private Map<String, Object> nameMap = new HashMap<String, Object>();
        private String name;
        private Object[] array;
        
        public Directory(String name) {
            this.name = name;
        }
        
        public String toString() {
            return name;
        }
        
        public Directory getDirectory(String name) {
            Directory dir = (Directory)nameMap.get(name);
            if(dir == null) {
                dir = new Directory(name);
                nameMap.put(name, dir);
            }
            return dir;
        }
        
        public void putFile(String name, String content) {
            nameMap.put(name, content);
        }
        
        public String getFileContent(String name) {
            return (String)nameMap.get(name);
        }
        
        public int getChildCount() {
            return nameMap.size();
        }
        
        private void initArray() {
            if(array == null) {
                array = new Object[nameMap.size()];
                Iterator<Map.Entry<String, Object>> entryIter = nameMap.entrySet().iterator();
                for(int iter = 0 ; iter < array.length ; iter++) {
                    Map.Entry<String, Object> entry = entryIter.next();
                    array[iter] = entry.getValue();
                    if(array[iter] instanceof String) {
                        array[iter] = entry.getKey();
                    }
                }
            }
        }
        
        public Object get(int offset) {
            initArray();
            return array[offset];
        }
        
        public int getIndex(Object child) {
            initArray();
            for(int iter = 0 ; iter < array.length ; iter++) {
                if(array[iter] == child) {
                    return iter;
                }
            }
            return -1;
        }
    }
    
    /**
     * A tree model pointing at the zip file root
     */
    private class ZipContentTreeModel implements TreeModel {
        private Directory root = new Directory("/");
        
        public ZipContentTreeModel() {
            new Thread() {
                public void run() {
                    // build the tree structure on a separate thread...
                    buildTree();
                    
                    // now that we built the structure we can just switch this
                    // model into place instead of the default model.
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            sourceTree.setModel(ZipContentTreeModel.this);
                        }
                    });
                }
            }.start();
        }
        
        /**
         * Builds the content of the tree in memory
         */
        private void buildTree() {
            try {
                InputStream stream = getClass().getResourceAsStream("/source.zip");
                ZipInputStream zipFile = new ZipInputStream(stream);
                ZipEntry entry;
                entry = zipFile.getNextEntry();
                byte[] buffer = new byte[65536];
                while(entry != null) {
                    String entryName = entry.getName();
                    if(entryName.endsWith(".java")) {
                        addFile(entryName, zipFile, buffer);
                    }
                    zipFile.closeEntry();
                    entry = zipFile.getNextEntry();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        
        /**
         * Adds the given file to the hierarchy
         */
        private void addFile(String name, ZipInputStream zip, byte[] buffer) throws IOException {
            Directory d = getDirectory(name);
            d.putFile(name.substring(name.lastIndexOf('/') + 1), loadFile(zip, buffer));
        }
        
        private String loadFile(ZipInputStream zip, byte[] buffer) throws IOException {
            String response = "";
            int length = zip.read(buffer);
            while(length > -1) {
                response += new String(buffer, 0, length);
                length = zip.read(buffer);
            }
            return response;
        }
        
        /**
         * Returns the tree path for the given file
         */
        public TreePath getPath(String name) {
            // remove the file name
            String fileName = name.substring(name.lastIndexOf('/') + 1);
            name = name.substring(0, name.lastIndexOf('/'));
            List path = new ArrayList();
            StringTokenizer tokenize = new StringTokenizer(name, "/");
            Directory dir = root;
            path.add(dir);
            while(tokenize.hasMoreTokens()) {
                String token = tokenize.nextToken();
                dir = dir.getDirectory(token);
                path.add(dir);
            }
            path.add(fileName);
            return new TreePath(path.toArray());
        }
        
        /**
         * Returns the directory for the given file name, if no such directory exists
         * then a new hierarchy is built.
         */
        private Directory getDirectory(String name) {
            // remove the file name
            name = name.substring(0, name.lastIndexOf('/'));
            StringTokenizer tokenize = new StringTokenizer(name, "/");
            Directory dir = root;
            while(tokenize.hasMoreTokens()) {
                String token = tokenize.nextToken();
                dir = dir.getDirectory(token);
            }
            return dir;
        }
        
        public boolean isLeaf(Object node) {
            return node instanceof String;
        }
        
        public int getChildCount(Object parent) {
            return ((Directory)parent).getChildCount();
        }
        
        public void valueForPathChanged(TreePath path, Object newValue) {
            // do nothing, tree is immutable
        }
        
        public void removeTreeModelListener(TreeModelListener l) {
            // do nothing, tree is immutable
        }
        
        public void addTreeModelListener(TreeModelListener l) {
            // do nothing, tree is immutable
        }
        
        public Object getChild(Object parent, int index) {
            return ((Directory)parent).get(index);
        }
        
        public Object getRoot() {
            return root;
        }
        
        public int getIndexOfChild(Object parent, Object child) {
            return ((Directory)parent).getIndex(child);
        }
        
    }
    
    /**
     * A simple utility class that presents code in a syntax highlighting editor
     */
    private static class SyntaxHighlightPane extends JTextPane {
        private Pattern numbers = Pattern.compile("\\d");
        private Pattern strings = Pattern.compile("\".*\"");
        private Pattern commentA = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        private Pattern commentB = Pattern.compile("//.*");
        private MutableAttributeSet keywordAttr = new SimpleAttributeSet();
        private MutableAttributeSet numberAttr = new SimpleAttributeSet();
        private MutableAttributeSet stringAttr = new SimpleAttributeSet();
        private MutableAttributeSet standardAttr = new SimpleAttributeSet();
        private MutableAttributeSet commentAttr = new SimpleAttributeSet();
        
        public SyntaxHighlightPane(String text) {
            setText(text);
            StyleConstants.setBold(keywordAttr, true);
            StyleConstants.setForeground(keywordAttr, Color.BLUE);
            StyleConstants.setForeground(numberAttr, Color.PINK);
            StyleConstants.setForeground(stringAttr, Color.RED);
            StyleConstants.setForeground(commentAttr, Color.GRAY);
            StyleConstants.setItalic(stringAttr, true);
            ((AbstractDocument)getStyledDocument()).setDocumentFilter(new DocumentFilter() {
                public void insertString(DocumentFilter.FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                    fb.insertString(offset, string, attr);
                    update();
                }
                public void remove(DocumentFilter.FilterBypass fb, int offset, int length) throws BadLocationException {
                    fb.remove(offset, length);
                    update();
                }
                public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                    fb.replace(offset, length, text, attrs);
                    update();
                }
            });
            update();
        }
        
        private void update() {
            try {
                StyledDocument doc = getStyledDocument();
                doc.setCharacterAttributes(0, doc.getLength(), standardAttr, true);
                String text = doc.getText(0, doc.getLength());
                for(int iter = 0 ; iter < keywords.length ; iter++) {
                    Matcher m = keywords[iter].matcher(text);
                    while(m.find()) {
                        int start = m.start();
                        doc.setCharacterAttributes(start, m.end() - start, keywordAttr, true);
                    }
                }
                annotate(doc, numbers, text, numberAttr);
                annotate(doc, strings, text, stringAttr);
                annotate(doc, commentA, text, commentAttr);
                annotate(doc, commentB, text, commentAttr);
            } catch(BadLocationException err) {
                err.printStackTrace();
            }
        }
        
        private void annotate(StyledDocument doc, Pattern p, String text, AttributeSet attr) {
            Matcher m = p.matcher(text);
            while(m.find()) {
                int start = m.start();
                doc.setCharacterAttributes(start, m.end() - start, attr, true);
            }
        }
    }
    
    public static void main(String[] argv) throws Exception {
        System.setProperty("apple.laf.useScreenMenuBar", "true");        
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        final JFrame frm = new JFrame("Bean Properties Demo");
        JMenuBar menuBar = new JMenuBar();
        frm.setJMenuBar(menuBar);
        JMenu fileMenu = new JMenu("File");
        JMenu appearanceMenu = new JMenu("Appearance");
        menuBar.add(fileMenu);
        menuBar.add(appearanceMenu);
        fileMenu.add(new AbstractAction("Exit") {
            public void actionPerformed(ActionEvent e) {
                if(JOptionPane.showConfirmDialog(frm, "Are you sure?", "Exit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) ==
                        JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
        final DemoGUI gui = new DemoGUI();
        appearanceMenu.add(new AbstractAction("Zoom In") {
            public void actionPerformed(ActionEvent e) {
                gui.zoom(3);
            }
        });
        appearanceMenu.add(new AbstractAction("Zoom Out") {
            public void actionPerformed(ActionEvent e) {
                gui.zoom(-3);
            }
        });
        

        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.add(gui, BorderLayout.CENTER);
        frm.pack();
        if(frm.getSize().width < 800) {
            frm.setSize(800, 700);
            frm.validate();
        }
        frm.setLocationByPlatform(true);
        frm.setVisible(true);
    }

    private static final String[] LF_COMPONENTS = new String[] {
            "Button", "Label", "Table", "TextField", "ScrollPane",
            "ComboBox", "CheckBox", "TitledBorder", "RadioButton", 
            "ToolTip", "TextPane", "TextArea", "Tree", "List",
            "MenuBar", "Menu", "MenuItem",  "TableHeader", "TabbedPane",
            "PasswordField", "FormattedTextField", "ToggleButton"};
    
    private void zoom(int direction) {
        for(int iter = 0 ; iter < LF_COMPONENTS.length ; iter++) {
            Font font = UIManager.getFont(LF_COMPONENTS[iter] + ".font");
            if(font != null) {
                font = font.deriveFont(font.getSize2D() + direction);
                UIManager.put(LF_COMPONENTS[iter] + ".font", new FontUIResource(font));
            }
        }
        SwingUtilities.updateComponentTreeUI(this);
        for(DemoInterface demo : demos) {
            if(demo != currentDemo) {
                SwingUtilities.updateComponentTreeUI(demo.execute());
            }
        }
    }
    
    /**
     * Simple class representing a tutorial to be placed in the combo box
     */
    private static class Tutorial {
        private String name;
        private String url;
        
        public Tutorial(String name, String url) {
            this.name = name;
            this.url = url;
        }
        
        public String getURL() {
            return url;
        }
        
        public String toString() {
            return name;
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane currentTutorial;
    private javax.swing.JPanel demo;
    private javax.swing.JList demoList;
    private javax.swing.JLabel demoNameLabel;
    private javax.swing.JEditorPane description;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JButton reRunDemoButton;
    private javax.swing.JButton runDemo;
    private javax.swing.JPanel runDemoButtonPanel;
    private javax.swing.JPanel selection;
    private javax.swing.JTabbedPane sourcePane;
    private javax.swing.JSplitPane sourceSplit;
    private javax.swing.JTree sourceTree;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JPanel tutorialPanel;
    private javax.swing.JComboBox tutorialsCombo;
    // End of variables declaration//GEN-END:variables
    
}
