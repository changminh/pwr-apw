/*
 * NotNullConstraint.java
 *
 * Created on February 22, 2007, 9:45 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

import net.java.dev.properties.BaseProperty;

/**
 * A constraint defining a numeric range for a given value
 *
 * @see net.java.dev.properties.annotations.Range
 * @author Shai Almog
 */
public class RangeConstraint implements Constraint {
    private double min;
    private double max;
    
    public RangeConstraint(double min, double max) {
        this.min = min;
        this.max = max;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public boolean validate(BaseProperty prop, Object value) {
        if(value == null) {
            return false;
        }
        double d = ((Number)value).doubleValue();
        return d >= min && d <= max;
    }
}
