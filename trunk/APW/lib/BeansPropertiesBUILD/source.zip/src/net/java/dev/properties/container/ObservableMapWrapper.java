package net.java.dev.properties.container;

import net.java.dev.properties.MapPropertyWrapper;
import net.java.dev.properties.MapProperty;
import net.java.dev.properties.events.PropertyListener;

/**
 * Wrapper property that allows a map property to be wrapped yet observed
 *
 * @author shai
 */
public class ObservableMapWrapper<K, T> extends MapPropertyWrapper<K, T> implements ObservableInterface {
    
    /** Creates a new instance of ObservableIndexedWrapper */
    public ObservableMapWrapper(MapProperty<K, T> prop) {
        super(prop);
    }

    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<PropertyListener> getDelegate() {
        if(getProperty() instanceof ObservableInterface) {
            return ((ObservableInterface)getProperty()).getDelegate();
        }
        return null;
    }
}
