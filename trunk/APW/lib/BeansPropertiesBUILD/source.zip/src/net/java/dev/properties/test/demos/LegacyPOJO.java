/*
 * LegacyPOJO.java
 *
 * Created on April 15, 2007, 5:48 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.demos;

/**
 * This is a true POJO used by the mirror demo, unlike the LegacyBean used in
 * other demos it does not contain the add/removePropertyChangeListener methods.
 *
 * @author shai
 */
public class LegacyPOJO {
    private int x;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }    
}
