/*
 * VetoListener.java
 *
 * Created on April 23, 2007, 9:38 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.events;

import net.java.dev.properties.BaseProperty;

/**
 * This interface allows the listener to veto an event change
 *
 * @author Shai Almog
 */
public interface VetoListener {
    /**
     * Invoked for property change allowing a listener to veto the change by returning
     * false from this method, index would normally be -1 for anything that
     * is not an indexed property otherwise it will indicate the index ofset that has
     * changed within the indexed property.
     */
    public boolean propertyChangeCheck(BaseProperty prop, Object oldValue, Object newValue, int index);    
}
