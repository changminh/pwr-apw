package net.java.dev.properties.test.demos.orm;

import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.test.binding.studio.YogaClassBean;

/**
 * Adds support for an ID property.
 *
 * @author Shai Almog
 */
public class PersistantYogaClass extends YogaClassBean implements PersistentId {
    @Column(key=true)
    public final Property<Integer> id = ObservableProperty.create();
    
    public PersistantYogaClass() {
        BeanContainer.bind(this);
    }
    
    public Property<Integer> id() {
        return id;
    }
}
