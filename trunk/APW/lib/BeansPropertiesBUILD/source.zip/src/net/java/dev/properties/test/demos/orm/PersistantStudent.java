/*
 * PeristantStudent.java
 *
 * Created on April 26, 2007, 5:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.demos.orm;

import net.java.dev.properties.Property;
import net.java.dev.properties.annotations.Column;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.test.binding.studio.StudentBean;

/**
 * Adds support for an ID property.
 *
 * @author Shai Almog
 */
public class PersistantStudent extends StudentBean implements PersistentId {
    @Column(key=true)
    public final Property<Integer> id = ObservableProperty.create();
    
    /** Creates a new instance of PeristantStudent */
    public PersistantStudent() {
        BeanContainer.bind(this);
    }
    
    public Property<Integer> id() {
        return id;
    }
}
