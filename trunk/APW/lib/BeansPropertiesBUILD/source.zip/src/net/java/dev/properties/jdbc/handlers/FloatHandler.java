package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author Glen Marchesani
 */
public class FloatHandler extends PrimitiveTypeHandler<Float> {

	public FloatHandler() {
		super(Float.class,Types.FLOAT);		
	}

	public Float get( ResultSet resultSet, int offset) throws SQLException {
		return resultSet.getFloat(offset);
	}

	public void initPreparedStatmentImpl(Float value, PreparedStatement preparedStatement, int offset) throws SQLException {
		preparedStatement.setFloat(offset, value);		
	}

}
