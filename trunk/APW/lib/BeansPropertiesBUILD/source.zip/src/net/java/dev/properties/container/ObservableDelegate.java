/*
 * ObservableDelegate.java
 *
 * Created on February 21, 2007, 4:04 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.beans.VetoableChangeListener;
import java.util.concurrent.CopyOnWriteArrayList;
import net.java.dev.properties.events.PropertyChangeAdapter;
import java.beans.PropertyChangeListener;
import java.util.List;
import net.java.dev.properties.events.VetoableChangeAdapter;

/**
 * This class is exposed via the observable portions and allows the container
 * to extract listeners it allows us to easily plugin observability into any
 * bean/property type.
 *
 * @author Shai Almog
 */
public class ObservableDelegate<T> implements java.io.Serializable {
    /**
     * The listeners for either the property only, or the listeners for all the 
     * properties
     */
    private List<T> listeners;
    
    /** Creates a new instance of ObservableDelegate */
    public ObservableDelegate() {
    }
    
    /**
     * Package protected method to prevent illegal maniputation
     */
    List<T> getListeners() {
        return listeners;
    }
    
    synchronized void addListener(final T listener) {
        if(listeners == null) {
            listeners = new CopyOnWriteArrayList<T>();
            listeners.add(listener);
            return;
        } 
        if(!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }
    
    synchronized void removeListener(final T listener) {
        if(listeners != null) {
            listeners.remove(listener);
            if(listeners.size() == 0) {
                listeners = null;
            }
        }
    }
    
    /**
     * Allows us to remove a legacy listener from this delegate
     */
    void removeListener(final PropertyChangeListener listener) {
        if(listeners != null) {
            for(T l : listeners) {
                if(l instanceof PropertyChangeAdapter) {
                    if(((PropertyChangeAdapter)l).getListener() == listener) {
                        listeners.remove(l);
                        return;
                    }
                }
            }
        }
    }
    
    /**
     * Allows us to remove a legacy listener from this delegate
     */
    void removeListener(final VetoableChangeListener listener) {
        if(listeners != null) {
            for(T l : listeners) {
                if(l instanceof VetoableChangeAdapter) {
                    if(((VetoableChangeAdapter)l).getListener() == listener) {
                        listeners.remove(l);
                        return;
                    }
                }
            }
        }
    }
}
