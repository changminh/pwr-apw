/*
 * GeneratorTask.java
 *
 * Created on February 25, 2007, 4:52 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.generator;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.taskdefs.MatchingTask;
import org.apache.tools.ant.types.FileSet;

/**
 * A simple ant task that allows us to instrument bytecode in order to support
 * automatic set/get creation. This task assumes the code was previously compiled
 * and does nothing if the code was already instrumented (this is verified
 * by a check of the listener interface).
 *
 * @author Shai Almog
 */
public class GeneratorTask extends MatchingTask {
    private List<FileSet> files = new ArrayList<FileSet>();
    private File baseDir;
    
    public void execute() throws BuildException {
        try {
            if(files.size() == 0 && baseDir == null) {
                throw new BuildException("At least one file set must be given or a basedir must be defined");
            }

            if(baseDir != null) {
                FileSet fs = (FileSet) getImplicitFileSet().clone();
                fs.setDir(baseDir);
                files.add(fs);
            }

            Generator g = new Generator();
            for(FileSet set : files) {
                DirectoryScanner scanner = set.getDirectoryScanner(getProject());
                String[] fileNames = scanner.getIncludedFiles();
                File dir = scanner.getBasedir();
                for(String currentName : fileNames) {
                    g.instrument(new File(dir, currentName));
                }
            }
        } catch(IOException ioErr) {
            throw new BuildException(ioErr);
        }
    }

    public void addFileset(FileSet set) {
        files.add(set);
    }

    public void setBaseDir(File baseDir) {
        this.baseDir = baseDir;
    }
}
