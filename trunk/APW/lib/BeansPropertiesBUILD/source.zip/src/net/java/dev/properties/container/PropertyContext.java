/*
 * PropertyContext.java
 *
 * Created on February 21, 2007, 1:32 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.*;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.constraints.Constraint;
import net.java.dev.properties.constraints.ConstraintChain;
import net.java.dev.properties.constraints.Failed;
import net.java.dev.properties.constraints.LengthConstraint;
import net.java.dev.properties.constraints.NotNullConstraint;
import net.java.dev.properties.events.PropertyListener;
import net.java.dev.properties.events.VetoListener;
import net.java.dev.properties.MapProperty;
import net.java.dev.properties.jdbc.Association;
import net.java.dev.properties.jdbc.handlers.TypeHandler;

/**
 * A context contains information regarding a particular property, the 
 * relationship between a property and its context is similar to the 
 * relationship between an Object and its Class. A context is set during
 * the bind process to the container.
 *
 * @author Shai Almog
 */
public class PropertyContext extends ObservableContext implements VetoInterface {
    private Failed onConstrainFail = Failed.CHANGE_AS_USUAL;
    private ConstraintChain constraint = new ConstraintChain(); 
    private Field field;    
    private ObservableDelegate<VetoListener> veto = new ObservableDelegate<VetoListener>();
        
    private String columnName;
    private String relationName;
    private String[] readOnlyColumns;
    private boolean isPK;
    private int compositeKeySequence = 10000;
    private Class<? extends TypeHandler> typeHandler;
    private String columnSuffix = "";
    private boolean isTransient;
    private boolean bidirectional;
    private boolean bidirectionalDuplicates;
    
    public PropertyContext() {    	
    }
    
    /**
     * If a property supports observability it must invoke this method after 
     * mutability occured in order to fire the appropriate events. Normally 
     * this is handled internally by the set(T) method implementation.
     */
    public void onChange(BaseProperty property, Object bean, Object oldValue, Object newValue, int index) {
        BeanContainer.get().firePropertyChanged(property, this, bean, oldValue, newValue, index);
    }

    /**
     * Fires the insert event for the given property
     */
    public void onInsert(IndexedProperty property, Object bean, Object value, int index) {
        BeanContainer.get().fireOnInsert(property, this, bean, value, index);
    }

    /**
     * Fires the remove event for the given property
     */
    public void onRemove(IndexedProperty property, Object bean, Object value, int index) {
        BeanContainer.get().fireOnRemove(property, this, bean, value, index);
    }

    /**
     * Fires the insert event for the given property
     */
    public void onInsert(MapProperty property, Object bean, Object key, Object value) {
        BeanContainer.get().fireOnInsert(property, this, bean, key, value);
    }

    /**
     * Fires the remove event for the given property
     */
    public void onRemove(MapProperty property, Object bean, Object key) {
        BeanContainer.get().fireOnRemove(property, this, bean, key);
    }

    /**
     * This method can be invoked by a property that supports vetoable observability,
     * a veto observable can fail to accept the change in which case it won't be applied.
     * This method MUST be invoked before the change is applied thus property.get() == oldValue at
     * this stage.
     */
    public boolean onVetoCheck(BaseProperty property, Object oldValue, Object newValue, int index) {
        return BeanContainer.get().checkVeto(property, oldValue, newValue, index);
    }
    
    /**
     * Indicates the behavior of the property when validation constraints fail
     */
    public Failed getOnConstraintFail() {
        return onConstrainFail;
    }

    /**
     * Indicates the behavior of the property when validation constraints fail
     */
    public void setOnConstraintFail(Failed onConstrainFail) {
        this.onConstrainFail = onConstrainFail;
    }

    /**
     * Adds a constraint to the bean that can be validated
     */
    public void addConstraint(Constraint c, String message) {
        constraint.addConstraint(c, message);
    }


    /**
     * Returns the error message corresponding to the given data
     */
    public String getValidationMessage(BaseProperty prop) {
        if(prop instanceof RProperty) {
            return constraint.getFailedMessage(prop, ((RProperty)prop).get());
        }
        return "";
    }
    
    /**
     * Returns the error message corresponding to the given data
     */
    public String getValidationMessage(BaseProperty prop, Object o) {
        return constraint.getFailedMessage(prop, o);
    }
        
    /**
     * Validates the object setting on the constraint chain returns true if the
     * property is indeed valid.
     * 
     * @return True if the given object passes validation
     */ 
    public boolean validate(BaseProperty prop, Object o) {
        return constraint.validate(prop, o);
    }

    /**
     * Returns true if the field pointed at by this context is indexed
     * @return True if this is an indexed property
     */
    public boolean isIndexedProperty() {
        return IndexedProperty.class.isAssignableFrom(field.getType());
    }
    
    /**
     * Returns the internal property type e.g. {@code Property<Integer>} would return
     * Integer.class rather than Property.class.
     * 
     * @return The type of a property
     */
    public Class<?> getType() {
        Class c = (Class)((ParameterizedType)field.getGenericType()).getActualTypeArguments()[0];
        return c;
    }

    /**
     * Returns the property type for the value side if this is a map property
     * 
     * @return The type for the second argument in case of a map property
     */
    public Class<?> getMapValueType() {
        Class c = (Class)((ParameterizedType)field.getGenericType()).getActualTypeArguments()[1];
        return c;
    }
    
    /**
     * The field object matching this property useful for some operations
     */
    void setField(Field field) {
        this.field = field;
    }
    
    /**
     * Returns true if the value of this property is identical between both beans
     * will also return true if both beans are write only...
     */
    public boolean equals(Object bean1, Object bean2) {
        BaseProperty p1 = getValue(bean1);
        if(p1 instanceof RProperty) {
            RProperty p2 = (RProperty)getValue(bean2);
            Object v1 = ((RProperty)p1).get();
            Object v2 = p2.get();
            return (v1 == v2) || (v1 != null && v2 != null && v1.equals(v2)); 
        }
        return true;
    }
    
    /**
     * Returns the value of the hashcode for this field within the given bean
     * returns 0 for write only fields
     */
    public int hashCode(Object bean) {
        Object o = getInternalValue(bean);
        if(o != null) {
            return o.hashCode();
        }
        return 0;
    }

    /**
     * Returns the value within the property if this bean is not write only
     * otherwise returns null
     */
    public Object getInternalValue(Object bean) {
        Object v = getValue(bean);
        if(v instanceof RProperty) {
            return ((RProperty)v).get();
        }
        return null;
    }
    
    /**
     * Sets the value within the property of the bean if the property is writable
     * otherwise do nothing
     */
    public void setInternalValue(Object bean, Object propertyValue) {
        if(getValue(bean) instanceof WProperty) {
            ((WProperty<Object>)getValue(bean)).set(propertyValue);
        }
    }
    
    /**
     * Returns the value of this property on the given bean (using reflection)
     */
    public BaseProperty getValue(Object bean) {
        try {
            return (BaseProperty)field.get(bean);
        } catch(IllegalAccessException i) {
            // should never happen since properties must always be public
            throw new BeanBindException(i);
        } catch(IllegalArgumentException e) {
            throw new BeanBindException("Trying to access a property of a bean on an instance of a bean of a different type field: " + 
                field.getName() + " on bean of: " + bean.getClass().getName());
        }
    }

    /**
     * Returns the field underlying this property
     * @deprecated this will be removed in the near future
     */
    public Field getField() {
        return field;
    }

    /**
     * Returns the instance of the constraint
     */
    public <TC extends Constraint> TC getConstraintInstance(Class<TC> constraint) {
        return (TC)this.constraint.getInstance(constraint);
    }

    /**
     * Returns whether the NotNull constraint is defined
     */
    public boolean isNullable() {
        return getConstraintInstance(NotNullConstraint.class) != null;
    }
    
    /**
     * Returns the length defined by the Length constraint that can be set using
     * the length annotation. This is used by the ORM layer
     */
    public int getMaxLength(int defaultVal) {
        LengthConstraint c = getConstraintInstance(LengthConstraint.class);
        if(c != null) {
            return c.getMax();
        }
        return defaultVal;
    }
    
    /**
     * Allows the container access to the veto listener
     */
    public ObservableDelegate<VetoListener> getVetoDelegate() {
        return veto;
    }
    
    /**
     * Indicate whether this property is tagged as a bidirectional property mostly
     * used for bidi ORM relations
     */
    public boolean isBidirectional() {
        return bidirectional;
    }
    
    /**
     * Indicate whether this property is tagged as a bidirectional property mostly
     * used for bidi ORM relations
     */
    public void setBidirectional(boolean bidirectional) {
        this.bidirectional = bidirectional;
    }
    
    /**
     * A bidirectional property may or may not allow duplicate entries
     */
    public boolean isAllowsBidirectionalDuplicates() {
        return bidirectionalDuplicates;
    }
    
    /**
     * A bidirectional property may or may not allow duplicate entries
     */
    public void setAllowsBidirectionalDuplicates(boolean bidirectionalDuplicates) {
        this.bidirectionalDuplicates = bidirectionalDuplicates;
    }

    /**
     * If this property represents a relation (possibly in the ORM) this indicates
     * the name of the relation for persistence purposes. This defaults to tableName_foreignTableName
     */
    public void setRelationName(String relationName) {
        this.relationName = relationName;
    }
    
    /**
     * If this property represents a relation (possibly in the ORM) this indicates
     * the name of the relation for persistence purposes. This defaults to columnName_foreignTableName
     */
    public String getRelationName() {
        if(relationName == null || relationName.length() == 0) {
            BeanContext foreign = BeanContainer.get().getContext(getType());
            return getColumnName() + "_" + foreign.getTableName();
        }
        return relationName;
    }
    
    /**
     * Returns the ORM column name matching this property by default the name
     * attribute
     */
    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }
    
    /**
     * Used by ORM to determine if this property is a part of a PK
     */
    public boolean isKeyColumn() {
        return isPK;
    }

    public void setKeyColumn(boolean isPK) {
        this.isPK = isPK;
    }
    
    /**
     * Returns the ORM column suffix if defined or a blank string
     */
    public String getColumnSuffix() {
        return columnSuffix;
    }
    
    /**
     * The ORM column suffix if defined or a blank string
     */
    public void setColumnSuffix(String columnSuffix) {
        this.columnSuffix = columnSuffix;
    }
    
    /**
     * Indicates the order in which key fields are layed out in the ORM
     * mapping. By default they will be sequenced by their order in the bean
     * but in cases such as inheritance this feature can be used via the Column
     * annotation. 
     */
    public int getCompositeKeySequence() {
        return compositeKeySequence;
    }
    
    /**
     * Indicates the order in which key fields are layed out in the ORM
     * mapping. By default they will be sequenced by their order in the bean
     * but in cases such as inheritance this feature can be used via the Column
     * annotation. 
     */
    public void setCompositeKeySequence(int compositeKeySequence) {
        this.compositeKeySequence = compositeKeySequence;
    }
    
    /**
     * Returns true if the property is transient and shouldn't be persisted
     * or serialized.
     */
    public boolean isTransient() {
        return isTransient;
    }
    
    /**
     * True if the property is transient and shouldn't be persisted
     * or serialized.
     */
    public void setTransient(boolean isTransient) {
        this.isTransient = isTransient;
    }

    /**
     * Allows us to customize the way in which this particular Java type is persisted
     * to the ORM
     */ 
    public Class<? extends TypeHandler> getTypeHandler() {
        return typeHandler;
    }
    
    /**
     * Allows us to customize the way in which this particular Java type is persisted
     * to the ORM
     */ 
    public void setTypeHandler(Class<? extends TypeHandler> typeHandler) {
    	if ( !typeHandler.equals(TypeHandler.class)) {
    		this.typeHandler = typeHandler;
    	}
    }
    
    /**
     * Returns an association bound to this bean instance
     */
    public Association getRelationalAssociation(Object bean) {
        Object value = getValue(bean);
        if (value instanceof ObservableInterface) {
            ObservableDelegate<PropertyListener> delegate = ((ObservableInterface) value).getDelegate();
            // check to see whether we already have an association bound with this
            // property...
            if(delegate.getListeners() != null) {
                for (PropertyListener l : delegate.getListeners()) {
                    if (l instanceof Association) {
                        return (Association)l;
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Returns read only database columns for ORM usage
     */
    public String[] getReadOnlyColumns() {
    	if ( readOnlyColumns == null ) {
    		readOnlyColumns = new String[0];
    	}
        return readOnlyColumns;
    }
    
    /**
     * Returns read only database columns for ORM usage
     */
    public void setReadOnlyColumns(String readOnlyColumns) {    	
        this.readOnlyColumns = readOnlyColumns.split(",");
        for (int i = 0; i < this.readOnlyColumns .length; i++) {
                this.readOnlyColumns[i] = this.readOnlyColumns[i].trim(); 
        }
    }

}
