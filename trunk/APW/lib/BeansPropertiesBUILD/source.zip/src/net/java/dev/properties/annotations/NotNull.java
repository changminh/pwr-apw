/*
 * Attributes.java
 *
 * Created on February 21, 2007, 6:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.annotations;

import java.lang.annotation.*;

/**
 * Constraint for not null that automatically installs an instance of the 
 * class {@link net.java.dev.properties.constraints.NotNullConstraint} onto the given
 * property.
 * <p>Notice that the ORM checks whether this constraint is set when creating tables.
 *
 * @author Shai Almog
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface NotNull {
    /**
     * The validation messae passed into the constraint object
     */
    String message() default "Validation failed";

    /**
     * The localizable validation messae passed into the constraint object
     */
    String messageL() default "";
}
