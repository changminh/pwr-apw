/*
 * TestDynamicBinding.java
 *
 * Created on March 7, 2007, 5:08 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding;

import javax.swing.JFrame;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.swing.SwingFactory;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.PropertyListener;

/**
 * Tests the ability to dynamically bind a bean to a UI created on the fly...
 *
 * @author Shai Almog
 */
public class TestDynamicBinding {
    
    public static void main(String[] argv) {
        JFrame frm = new JFrame("Dynamic Binding");
        SwingFactory factory = SwingFactory.balancedColumnLayoutFactory(2);
        ValidationBean v = new ValidationBean();
        BeanContainer.get().addListener(v, new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                System.out.println(prop);
            }
        });
        factory.setSelectionFor(v.values.getContext(), v.selection.getContext());
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.add("Center", factory.createBeanUI(v));
        frm.pack();
        frm.setVisible(true);
    }
}
