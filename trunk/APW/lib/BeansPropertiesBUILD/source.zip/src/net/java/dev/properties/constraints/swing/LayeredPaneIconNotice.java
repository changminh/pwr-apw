package net.java.dev.properties.constraints.swing;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Component;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.util.HashMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPopupMenu;
import javax.swing.JRootPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.binding.swing.adapters.TableAdapterModel;
import net.java.dev.properties.constraints.ValidationNotice;

/**
 * An implementation of validation notice that places an icon on the invalid component
 * (right hand or left hand based on orientation). This implementation relies on adding
 * itself to the layered pane for the parent window...
 *
 * @author Shai Almog
 */
public class LayeredPaneIconNotice extends JComponent implements ValidationNotice<JComponent> {
    private Map<JComponent, String> invalid = new HashMap<JComponent, String>();
    private static final Icon ERROR_ICON = new ImageIcon(
        LayeredPaneIconNotice.class.getResource("/net/java/dev/properties/constraints/swing/exclamation.png"));

    /**
     * The icon that is displayed next to fields with errors
     */
    public final Property<Icon> icon = PropertyImpl.create(ERROR_ICON);

    /**
     * The layer to which this notice is posted
     */
    public final Property<Integer> layer = PropertyImpl.create(JLayeredPane.DEFAULT_LAYER + 50);
    private final JLabel errorMessage = new JLabel();
    private boolean showError = false;
    
    /**
     * Indicates whether this is Java 5 where some JTable functionality isn't supported yet...
     */
    private static final boolean JAVA_5 = Double.parseDouble(System.getProperty("java.class.version")) < 50;
    
    /** Creates a new instance of ChangeBackgroundNotice */
    public LayeredPaneIconNotice() {
        errorMessage.setOpaque(true);
        errorMessage.setBackground(new Color(128, 128, 255));
        errorMessage.setBorder(BorderFactory.createEtchedBorder());
        add(errorMessage);
        //JPopupMenu.setDefaultLightWeightPopupEnabled(false);
    }

    public LayeredPaneIconNotice(Icon icon) {
        this();
        this.icon.set(icon);
    }

    /**
     * @inheritDoc
     */
    @Override
    public void updateValidationStatus(BaseProperty property, JComponent component, boolean valid, String message) {
        if(valid) {
            invalid.remove(component);
            if(invalid.size() == 0) {
                setOpaque(false);
                setVisible(false);
            }
            JRootPane root = component.getRootPane();
            if(root != null) {
                MouseMotionListener listener = (MouseMotionListener) root.getClientProperty("MouseListenerBound");
                if(listener != null) {
                    component.removeMouseMotionListener(listener);
                    Component parent = component.getParent();
                    if(parent != null) {
                        parent.removeMouseMotionListener(listener);
                    }
                }
            }
        } else {
            invalid.put(component, message);
            install(component);
        }
        JRootPane root = component.getRootPane();
        if(root != null) {
            root.repaint();
        }
    }
    
    /**
     * Layout manager that is installed on the root pane allowing us to properly position
     * the layered pane icon notice
     */
    private class RootPaneLayout implements LayoutManager {
        private LayoutManager old;
        public RootPaneLayout(LayoutManager old) {
            this.old = old;
        }
        
        public void addLayoutComponent(String name, Component comp) {
                old.addLayoutComponent(name, comp);
        }

        public void layoutContainer(Container parent) {
                old.layoutContainer(parent);
                setBounds(getRootPane().getContentPane().getBounds());
        }

        public Dimension minimumLayoutSize(Container parent) {
                return old.minimumLayoutSize(parent);
        }

        public Dimension preferredLayoutSize(Container parent) {
                return old.preferredLayoutSize(parent);
        }

        public void removeLayoutComponent(Component comp) {
                old.removeLayoutComponent(comp);
        }
    }
        
    private void install(final JComponent cmp) {
        JRootPane root = cmp.getRootPane();
        if(root != null) {
            JLayeredPane layers = root.getLayeredPane();
            if(!(root.getLayout() instanceof RootPaneLayout)) {
                root.setLayout(new RootPaneLayout(root.getLayout()));
            }
            if(layers.getComponentCountInLayer(layer.get()) == 0) {
                layers.add(this, (Object)layer.get());
                layers.setLayer(this, layer.get());
                root.revalidate();
            }
            setVisible(true);
            setOpaque(false);
            MouseMotionListener listener = (MouseMotionListener) root.getClientProperty("MouseListenerBound");
            if(listener == null) {
                listener = new MouseMotionAdapter() {
                    public void mouseMoved(MouseEvent e) {
                        Point p = SwingUtilities.convertPoint((JComponent)e.getSource(), e.getPoint(), LayeredPaneIconNotice.this);
                        String message = messageFor(p);
                        if(message != null && message.length() > 0) {
                            showError = true;
                            errorMessage.setText(message);
                            errorMessage.setLocation(p);
                            errorMessage.setSize(errorMessage.getPreferredSize());
                            repaint();
                        } else {
                            if(showError) {
                                showError = false;
                                repaint();
                            } else {
                                showError = false;
                            }
                        }
                    }
                };
                root.putClientProperty("MouseListenerBound", listener);
            }
            root.addMouseMotionListener(listener);
            cmp.addMouseMotionListener(listener);
            Component parent = cmp.getParent();
            if(parent != null) {
                parent.addMouseMotionListener(listener);
            }
        } else {
            // we need to wait for an ansestor change and try again
            cmp.addHierarchyListener(new HierarchyListener() {
                public void hierarchyChanged(HierarchyEvent e) {
                    cmp.removeHierarchyListener(this);
                    install(cmp);
                }
            });
        }
    }
    
    /**
     * Returns the message that should appear when the mouse is in this position...
     */
    private String messageFor(Point p) {
        for(Map.Entry<JComponent, String> entry : invalid.entrySet()) {
            Point position = invalidPosition(entry.getKey());
            Rectangle r = new Rectangle(position.x, position.y, icon.get().getIconWidth(), icon.get().getIconHeight());
            if(r.contains(p) && isVisible(entry.getKey())) {
                return entry.getValue();
            }
        }
        return null;
    }
    
    private Point invalidPosition(JComponent component) {
        int space = icon.get().getIconHeight() / 2 + 2;
        if(component.getParent() instanceof JViewport) {
            component = (JComponent)component.getParent().getParent();
        }
        Point p = SwingUtilities.convertPoint(component.getParent(), component.getLocation(), this);
        p.y += component.getHeight() - space;
        if(component.getComponentOrientation().isLeftToRight()) {
            p.x += component.getWidth() - icon.get().getIconWidth();
        }
        return p;
    }

    /**
     * With complex components such as JTable (only one supported right now) internal
     * portions might be invalid and we might want to outline them
     */
    private void paintInvalidDetails(JComponent cmp, Graphics2D g2d) {
        if(cmp instanceof JTable) {
            Map<BaseProperty, Integer> invalids = (Map<BaseProperty, Integer>)cmp.getClientProperty("InvalidMap");
            JTable table = (JTable)cmp;
            if(invalids != null && invalids.size() > 0) {
                for(Map.Entry<BaseProperty, Integer> entry : invalids.entrySet()) {
                    TableAdapterModel model = (TableAdapterModel)table.getModel();
                    int column = table.convertColumnIndexToView(model.getColumn(entry.getKey().getContext()));
                    int row;
                    if(JAVA_5) {
                        row = entry.getValue();
                    } else {
                        row = table.convertRowIndexToView(entry.getValue());
                    }
                    Rectangle rect = table.getCellRect(row, column, true);
                    Rectangle viewRect = ((JViewport)table.getParent()).getViewRect();                    
                    if(viewRect.intersects(rect)) {
                        //rect = rect.createIntersection(viewRect);
                        rect = SwingUtilities.convertRectangle(table, rect, this);
                        g2d.setColor(Color.PINK);
                        g2d.fill(rect);
                    }                    
                }
            }
        }
    }
    
    /**
     * This recursive method returns true if all parent components
     * are visible. This is especially useful for tab components where the
     * isVisible method of components residing on another tab will return
     * true while physically they are not visible.
     */
    private boolean isVisible(java.awt.Container container) {
        java.awt.Container parent = container.getParent();
        if(parent == null) {
            return container.isVisible() && container instanceof RootPaneContainer;
        }
        return container.isVisible() && isVisible(parent);
    }

    /**
     * Paints over the invalid components
     */
    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D)g.create();
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.8f));
        for(JComponent component : invalid.keySet()) {
            if(isVisible(component)) {
                Point p = invalidPosition(component);
                icon.get().paintIcon(this, g2d, p.x, p.y);
                paintInvalidDetails(component, g2d);
            }
        }
        if(showError) {
            Rectangle r = errorMessage.getBounds();
            if(r.x + r.width > getWidth()) {
                r.x = getWidth() - r.width;
            }
            if(r.y + r.height > getHeight()) {
                r.y = getHeight() - r.height;
            }
            SwingUtilities.paintComponent(g2d, errorMessage, this, r);
        }
    }
}
