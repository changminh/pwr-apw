package net.java.dev.properties.binding.swing.adapters;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.binding.Adapter;
import net.java.dev.properties.container.BeanContainer;

/**
 * Implements table support for propagating selection UI changes, this class is made
 * public for subclasses in SwingX it is not intended for general use
 *
 * @author Shai Almog
 */
public class TableItemAdapter extends SwingAdapter<Object, JTable> implements ListSelectionListener {
    public final Property<Integer> column = new PropertyImpl<Integer>();

    public TableItemAdapter() {
        this(0);
    }

    public TableItemAdapter(int col) {
        BeanContainer.bind(this);
        column.set(col);
    }
    
    protected void bindListener(BaseProperty<Object> property, JTable cmp) {
        cmp.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cmp.getSelectionModel().addListSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<Object> property, JTable cmp) {
        cmp.getSelectionModel().removeListSelectionListener(this);
    }

    protected void updateUI(Object newValue) {
        if(newValue == null) {
            getComponent().clearSelection();
        } else {
            for(int iter = 0 ; iter < getComponent().getRowCount() ; iter++) {
                Object value = getComponent().getValueAt(iter, column.get());
                if(value == newValue || ((value != null) && value.equals(newValue))) {
                    getComponent().setRowSelectionInterval(iter, iter);
                    return;
                }
            }
        }
    }            

    public void valueChanged(ListSelectionEvent e) {
        callWhenUIChanged(getComponent().getValueAt(getComponent().getSelectedRow(), column.get()));
    }

    protected Class getType() {
        return Object.class;
    }

    protected Class getComponentType() {
        return JTable.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}