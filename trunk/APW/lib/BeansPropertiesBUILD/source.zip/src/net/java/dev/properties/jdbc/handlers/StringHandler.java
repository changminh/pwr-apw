package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.PropertyContext;

/**
 * @author Glen Marchesani
 */
public class StringHandler extends AbstractTypeHandler<String> {
	
	public StringHandler() {
	}
	
	@Override
	public void setPropertyContext(PropertyContext context) {
		super.setPropertyContext(context);
		setColumn(ColumnContext.createSingleColumn(context.getColumnName(),Types.VARCHAR,context.getMaxLength(255), 
                        context.isNullable(), getPropertyContext().getReadOnlyColumns()));
	}

	public boolean canHandleType(Class<?> type) {
		return type.equals(String.class);
	}

	public void loadPreparedStatment(Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
		preparedStatement.setString(preparedStatementOffset, (String)columnValues[columnValuesOffset]);
	}

	public void loadProperty(WProperty<String> property, ResultSet resultSet, int offset) throws SQLException {
		property.set(resultSet.getString(offset));
	}
	
	public boolean doesEagerFetching() {
		return true;
	}
}
