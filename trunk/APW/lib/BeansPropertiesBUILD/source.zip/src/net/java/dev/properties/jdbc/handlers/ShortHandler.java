package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author Glen Marchesani
 */
public class ShortHandler extends PrimitiveTypeHandler<Short> {

	public ShortHandler() {
		super(Short.class, Types.SMALLINT);
	}

	public Short get( ResultSet resultSet, int offset) throws SQLException {
		return resultSet.getShort(offset);
	}

	public void initPreparedStatmentImpl(Short value, PreparedStatement preparedStatement, int offset) throws SQLException {
		preparedStatement.setShort(offset, value);		
	}

}
