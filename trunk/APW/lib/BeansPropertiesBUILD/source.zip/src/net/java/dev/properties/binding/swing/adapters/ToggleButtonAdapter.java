/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JToggleButton;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements toggle button support for the state change/ui
 *
 * @author Shai Almog
 */
class ToggleButtonAdapter extends SwingAdapter<Boolean, JToggleButton> implements ItemListener {
    protected void bindListener(BaseProperty<Boolean> property, JToggleButton button) {
        button.addItemListener(this);
    }

    protected void unbindListener(BaseProperty<Boolean> property, JToggleButton button) {
        button.removeItemListener(this);
    }

    public void itemStateChanged(ItemEvent e) {
        callWhenUIChanged(getComponent().isSelected());
    }

    protected void updateUI(Boolean newValue) {
        getComponent().setSelected(newValue);
    }            

    protected Class getType() {
        return Boolean.class;
    }

    protected Class getComponentType() {
        return JToggleButton.class;
    }

    protected void setEmptyValue() {
        getComponent().setSelected(false);
    }
}