/*
 * ConstraintFailedException.java
 *
 * Created on February 22, 2007, 10:22 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

import net.java.dev.properties.Property;

/**
 * An exception indicating the a constraint has failed which is thrown only in the
 * case of Failed being set to throw exception
 *
 * @author Shai Almog
 */
public class ConstraintFailedException extends RuntimeException {
    private Property property;
    private Object value;
    
    /** Creates a new instance of ConstraintFailedException */
    public ConstraintFailedException(Property property, Object value) {
        this.property = property;
        this.value = value;
    }

    public Property getProperty() {
        return property;
    }

    public Object getValue() {
        return value;
    }
    
}
