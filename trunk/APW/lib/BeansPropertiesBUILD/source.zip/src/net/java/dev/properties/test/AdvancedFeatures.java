/*
 * AdvancedFeatures.java
 *
 * Created on February 22, 2007, 2:59 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import java.awt.Color;
import net.java.dev.properties.*;
import net.java.dev.properties.annotations.*;
import net.java.dev.properties.container.*;
import net.java.dev.properties.constraints.*;
import net.java.dev.properties.container.veto.VetoProperty;

/**
 * This bean demonstrates the advanced features of the new JavaBeans API
 *
 * @author Shai Almog
 */
@Bean(name="FeaturesDemo", 
    description="A bean that demonstrates the more elaborate aspects of this API",
    icon="/coffee.png",
    svgIcon="/coffee.svg")
public class AdvancedFeatures implements java.io.Serializable {
    /**
     * Demonstrates the usage of not null validation and failure by throwing an
     * exception rather than the default of just doing nothing.
     * Also demonstrates that naming and description of the bean can be defined
     * in code. Also demonstrates that despite the "NotNull" annotation the value
     * is essentially initialized to null, but it can't be "set back" from null.
     */
    @NotNull
    @Validation(onFail=Failed.THROW_EXCEPTION)
    @Attributes(name="y", description="Stuff")
    public final ObservableProperty<Integer> attr = ObservableProperty.create();

    /**
     * Complex constraints for colors possible even with a property that is not 
     * observable. Demonstrates an annotation that prevents a darker color from
     * being set to the light color.
     */
    @Validation(onFail=Failed.DO_NOTHING, constraint=LightColor.class)
    public final Property<Color> lightColor = PropertyImpl.create(Color.GRAY);
    
    /**
     * Indexed properties allow us to access an element and within the property
     * and modify said elements. This is essentially an array or really more
     * like a list.
     */
    public final IndexedProperty<String> indexed = ObservableIndexed.create("A", "B", "C");
    
    /**
     * Demonstrates the ability to add veto listeners to a property and accept/reject a change
     * completely externally.
     */
    public final Property<Integer> vetoable = VetoProperty.create(5);
    
    /** Creates a new instance of AdvancedFeatures */
    public AdvancedFeatures() {
        BeanContainer.bind(this);
    }
    
    public static class LightColor implements Constraint {
        public boolean validate(BaseProperty p, Object value) {
            Color c = (Color)value;
            return (c.getRed() + c.getGreen() + c.getBlue()) / 3 > 127;
        }
    }
}
