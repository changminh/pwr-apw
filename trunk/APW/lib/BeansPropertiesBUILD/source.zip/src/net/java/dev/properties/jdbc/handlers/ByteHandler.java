package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author Glen Marchesani
 */
public class ByteHandler extends PrimitiveTypeHandler<Byte> {

	public ByteHandler() {
		super(Byte.class, Types.TINYINT);
	}

	public Byte get( ResultSet resultSet, int offset) throws SQLException {
		return resultSet.getByte(offset);
	}

	public void initPreparedStatmentImpl(Byte value, PreparedStatement preparedStatement, int offset) throws SQLException {
		preparedStatement.setByte(offset, value);		
	}

}
