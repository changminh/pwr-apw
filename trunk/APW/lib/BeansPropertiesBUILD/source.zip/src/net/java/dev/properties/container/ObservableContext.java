/*
 * ObservableContext.java
 *
 * Created on February 21, 2007, 2:47 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.io.Serializable;
import java.util.*;
import net.java.dev.properties.events.PropertyListener;

/**
 * This is a base class for both the bean and the property context it allows them
 * both to hold their own set of observers and some common state such as names
 * and descriptions.
 *
 * @author Shai Almog
 */
public class ObservableContext implements Serializable {
    /**
     * For internal use by the container, this member is package protected
     */
    final ObservableDelegate<PropertyListener> delegate = new ObservableDelegate<PropertyListener>();
    
    private String name;
    private String displayName;
    private String description;
    
    /** Creates a new instance of ObservableContext */
    public ObservableContext() {
    }

    /**
     * The name for the context
     */
    public String getName() {
        return name;
    }

    /**
     * The name for the context
     */
    public void setName(String name) {
        this.name = name;
    }    

    /**
     * The display name for the context
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * The display name for the context
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * The description for the context
     */
    public String getDescription() {
        return description;
    }

    /**
     * The description for the context
     */
    public void setDescription(String description) {
        this.description = description;
    }    
}
