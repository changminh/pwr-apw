/*
 * Property.java
 *
 * Created on February 20, 2007, 9:57 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

/**
 * Write only property that can only be read by subclasses but can be modified by
 * anyone
 *
 * @author Shai Almog
 */
public interface WProperty<T> extends BaseProperty<T> {
    /**
     * Sets a new value to the property
     */
    public void set(T t);
}
