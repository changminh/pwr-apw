package net.java.dev.properties.test.util;

/* 
 * This will log WARN and more severa message to System.err and 
 * everything else to System.out  
 * 
 */

import java.util.logging.ErrorManager;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;

/**
 * This <tt>Handler</tt> publishes log records to <tt>System.err</tt>. By
 * default the <tt>SimpleFormatter</tt> is used to generate brief summaries.
 * <p>
 * <b>Configuration:</b> By default each <tt>ConsoleHandler</tt> is
 * initialized using the following <tt>LogManager</tt> configuration
 * properties. If properties are not defined (or have invalid values) then the
 * specified default values are used.
 * <ul>
 * <li> java.util.logging.ConsoleHandler.level specifies the default level for
 * the <tt>Handler</tt> (defaults to <tt>Level.INFO</tt>).
 * <li> java.util.logging.ConsoleHandler.filter specifies the name of a
 * <tt>Filter</tt> class to use (defaults to no <tt>Filter</tt>).
 * <li> java.util.logging.ConsoleHandler.formatter specifies the name of a
 * <tt>Formatter</tt> class to use (defaults to
 * <tt>java.util.logging.SimpleFormatter</tt>).
 * <li> java.util.logging.ConsoleHandler.encoding the name of the character set
 * encoding to use (defaults to the default platform encoding).
 * </ul>
 * <p>
 * 
 * @version 1.12, 12/19/03
 * @since 1.4
 */

public class SystemDotOutConsoleHandler extends Handler {

	/**
	 * Create a <tt>ConsoleHandler</tt> for <tt>System.err</tt>.
	 * <p>
	 * The <tt>ConsoleHandler</tt> is configured based on <tt>LogManager</tt>
	 * properties (or their default values).
	 * 
	 */
	public SystemDotOutConsoleHandler() {
		setLevel( Level.FINEST );
		setFilter( null );
		setFormatter( new ProductionFormatter() );
	}

	/**
	 * Publish a <tt>LogRecord</tt>.
	 * <p>
	 * The logging request was made initially to a <tt>Logger</tt> object,
	 * which initialized the <tt>LogRecord</tt> and forwarded it here.
	 * <p>
	 * 
	 * @param record
	 *            description of the log event. A null record is silently
	 *            ignored and is not published
	 */
	@Override
	public void publish(LogRecord record) {
    	if (!isLoggable(record)) {
    	    return;
    	}
    	String msg;
    	try {
     	    msg = getFormatter().format(record);
    	} catch (Exception ex) {
    	    // We don't want to throw an exception here, but we
    	    // report the exception to any registered ErrorManager.
    	    reportError(null, ex, ErrorManager.FORMAT_FAILURE);
    	    return;
    	}

    	try {
   			System.out.print(msg);    			
    	} catch (Exception ex) {
    	    // We don't want to throw an exception here, but we
    	    // report the exception to any registered ErrorManager.
    	    reportError(null, ex, ErrorManager.WRITE_FAILURE);
    	}
		flush();
	}
    	
	@Override
	public void flush() {
		System.out.flush();
	}
	
	/**
	 * Override <tt>StreamHandler.close</tt> to do a flush but not to close
	 * the output stream. That is, we do <b>not</b> close <tt>System.err</tt>.
	 */
	@Override
	public void close() {
		flush();
	}
}
