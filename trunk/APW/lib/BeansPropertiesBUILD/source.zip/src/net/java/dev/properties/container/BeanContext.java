/*
 * BeanContext.java
 *
 * Created on February 21, 2007, 1:54 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container;

import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import net.java.dev.properties.Property;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.events.BindListener;
import net.java.dev.properties.jdbc.handlers.TypeHandler;

/**
 * This class has a relationship to a bean instance similar to the one java.lang.Class has
 * to an Object instance. This is a one to many relationship that describes the beans
 * aspects, features and properties. This class carries bean specific meta-data that
 * is injected automatically by the container.
 * <p>Instances of this class are generally created and injected implicitly by
 * the bean container.
 *
 * @author Shai Almog
 */
public final class BeanContext extends ObservableContext {
    /**
     * This map maps the fields to their contexts
     */
    private PropertyContext[] fields;

    private String icon;
    private String svgIcon;
    
    /**
     * The resource bundle for the bean properties
     */
    private ResourceBundle bundle;
    
    private String tableName;
    private String tablePrefix;
    
    private List<VirtualPropertyBean> virtuals;
    
    /**
     * List of listeners to bean binding events
     */
    private List<BindListener> bindListeners;
    
    private Class<? extends TypeHandler> typeHandler;
    
    /** Creates a new instance of BeanContext */
    BeanContext() {
    }

    /**
     * Arranges the fields according to the given order, the status of the UI's/beans
     * created beforehand is undetermined.
     */
    public void arrange(PropertyContext[] fields) {
        this.fields = fields;
    }
    
    /**
     * Arranges the properties based on String names
     */
    public void arrange(String[] properties) {
        PropertyContext[] fields = new PropertyContext[properties.length];
        for(int iter = 0 ; iter < fields.length ; iter++) {
            fields[iter] = getByName(properties[iter]);
        }
        this.fields = fields;
    }
    
    /**
     * Allows us to extract a property based on its name, useful mostly for mirror objects
     */
    public PropertyContext getByName(String name) {
        for(PropertyContext p : fields) {
            if(p.getName().equals(name)) {
                return p;
            }
        }
        throw new IllegalArgumentException("Unknown property name: " + name);
    }
    
    
    PropertyContext[] getFields() {
        return fields;
    }

    void setFields(PropertyContext[] fields) {
        this.fields = fields;
    }
    
    /**
     * Returns an iterator for the property contexts 
     */
    public Iterator<PropertyContext> getProperties() {
        return Arrays.asList(fields).iterator();
    }
    
    /**
     * Returns an array of the properties, this array is a copy
     */
    public PropertyContext[] getPropertiesArray() {
        PropertyContext[] arr = new PropertyContext[fields.length];
        System.arraycopy(fields, 0, arr, 0, fields.length);
        return arr;
    }

    /**
     * Returns an array of the properties, this array is not a copy
     * 
     */
    // TODO: make this an unmodifiable list
    public PropertyContext[] getPropertiesArrayRaw() {
    	return fields;
    }

    /**
     * Returns an array of the property objects that are readable this array is a copy
     */
    public RProperty[] getRPropertiesArray(Object bean) {
        return (RProperty[])getPropertiesArray(bean, RProperty.class);
    }

    /**
     * Returns an array of the property objects that are writeable this array is a copy
     */
    public WProperty[] getWPropertiesArray(Object bean) {
        return (WProperty[])getPropertiesArray(bean, WProperty.class);
    }

    /**
     * Returns an array of the property objects that are read/write this array is a copy
     */
    public Property[] getPropertiesArray(Object bean) {
        return (Property[])getPropertiesArray(bean, Property.class);
    }

    /**
     * Returns an array of the property objects that are of the given type
     */
    private Object[] getPropertiesArray(Object bean, Class type) {
        try {
            List properties = new ArrayList();
            for(PropertyContext property : fields) {
                if(property.getField() != null && type.isAssignableFrom(property.getField().getType())) {
                    properties.add(property.getValue(bean));
                }
            }
            return properties.toArray((Object[])Array.newInstance(type, properties.size()));
        } catch (Exception ex) {
            throw new BeanBindException(ex);
        }
    }
    
    /**
     * Returns the context with the given name, this tool uses the actual property
     * name rather than the field name if that is applicable
     */
    public PropertyContext getContext(String name) {
        for(PropertyContext context : fields) {
            if(context.getName().equals(name)) {
                return context;
            }
        }
        return null;
    }

    /**
     * Returns the path to the icon resource that should represent this bean in GUI tools
     */
    public String getIcon() {
        return icon;
    }

    /**
     * Returns the path to the svg icon resource that should represent this bean in GUI tools
     */
    public String getSvgIcon() {
        return svgIcon;
    }

    /**
     * Sets the path to the icon resource that should represent this bean in GUI tools
     */
    void setIcon(String icon) {
        this.icon = icon;
    }

    /**
     * Sets the path to the svg icon resource that should represent this bean in GUI tools
     */
    void setSvgIcon(String svgIcon) {
        this.svgIcon = svgIcon;
    }
    
    private String getKey(List<String> keys, String key, String def) {
        key = getName() + "." + key;
        if(keys.contains(key)) {
            return bundle.getString(key);
        }
        return def;
    }
    
    /**
     * Replaces the resource bundle on the fly for the properties within this
     * bean.
     */
    public void updateBundle(ResourceBundle bundle) {
        setBundle(bundle);
        List<String> keys = Collections.list(bundle.getKeys());
        setDisplayName(getKey(keys, "displayName", getDisplayName()));
        setIcon(getKey(keys, "icon", getIcon()));
        setSvgIcon(getKey(keys, "svgIcon", getSvgIcon()));
        setDescription(getKey(keys, "description", getDescription()));
        for(PropertyContext p : fields) {
            p.setDisplayName(getKey(keys, p.getName() + ".displayName", p.getDisplayName()));
            p.setDescription(getKey(keys, p.getName() + ".description", p.getDescription()));
        }
    }

    ResourceBundle getBundle() {
        return bundle;
    }

    void setBundle(ResourceBundle bundle) {
        this.bundle = bundle;
    }
    
    /**
     * A virtual property is a property that is created and strapped in during runtime,
     * the class won't show it but all tools that work with the bean container API
     * would see it as if it were a standard property within the bean. The main use
     * case for such a property is as a field whose usefulness is limited to a given
     * set of tools or customizable in runtime e.g. an "id" property in a bean to match
     * the id field in the database, which is useful only for the persistance aspect but
     * not for the general programming.
     */
    public void addVirtual(VirtualPropertyContext property) {
        PropertyContext[] fields = new PropertyContext[this.fields.length + 1];
        System.arraycopy(this.fields, 0, fields, 0, this.fields.length);
        fields[this.fields.length] = property;
        this.fields = fields;
    }

    /**
     * Removes the given property from the bean.
     */ 
    public void removeVirtualProperty(VirtualPropertyContext property) {
        PropertyContext[] fields = new PropertyContext[this.fields.length - 1];
        int offset = 0;
        for(int iter = 0 ; iter < this.fields.length ; iter++) {
            if(this.fields[iter] != property) {
                fields[offset] = this.fields[iter];
                offset++;
            }
        }
        this.fields = fields;
    }
    
    /**
     * Finds the virtual bean instance matching the regular bean
     */
    VirtualPropertyBean getVirtualBean(Object bean) {
        if(virtuals != null) {
            for(VirtualPropertyBean current : virtuals) {
                if(current.getParentBean() == bean) {
                    return current;
                }
            }
        } else {
            virtuals = new ArrayList<VirtualPropertyBean>();
        }
        VirtualPropertyBean v = new VirtualPropertyBean(this, bean);
        virtuals.add(v);
        return v;
    }
    
    /**
     * Removes the beans virtual properties from memory once the weak reference is released
     */
    void removeVirtualBean(VirtualPropertyBean bean) {
        if(virtuals != null) {
            virtuals.remove(bean);
        }
    }

    /**
     * This method is used by the ORM and defaults to the bean name if no table
     * name is explicitly set
     */
    public String getTableName() {
        return tableName;
    }
    
    void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    /**
     * This method is used by the ORM 
     */
    public String getTablePrefix() {
        return tablePrefix;
    }
    
    void setTablePrefix(String tablePrefix) {
        this.tablePrefix = tablePrefix;
    }
    
    /**
     * A bind listener allows tools such as the ORM to "listen" to newly constructed beans
     * since a bean must be bound immeidiately on construction the ORM can perform
     * operations at that stage.
     */
    public void addBindListener(BindListener l) {
        if(bindListeners == null) {
            bindListeners = new CopyOnWriteArrayList<BindListener>();
        }
        bindListeners.add(l);
    }

    /**
     * A bind listener allows tools such as the ORM to "listen" to newly constructed beans
     * since a bean must be bound immeidiately on construction the ORM can perform
     * operations at that stage.
     */
    public void removeBindListener(BindListener l) {
        bindListeners.remove(l);
    }
    
    /**
     * Invoked by the container to indicate a new bean instance was bound
     */
    void fireBindEvent(Object bean) {
        // TODO: should we fire this on the right thread? 
        if(bindListeners != null) {
            for(BindListener l : bindListeners) {
                l.beanBound(bean, this);
            }
        }
    }
    
    /**
     * Handles ORM types, this method allows us to customize the loading/storing
     * of ORM properties
     */
    public Class<? extends TypeHandler> getTypeHandler() {
        return typeHandler;
    }
    
    /**
     * Handles ORM types, this method allows us to customize the loading/storing
     * of ORM properties
     */
    public void setTypeHandler(Class<? extends TypeHandler> typeHandler) {
    	// several places TypeHandler.class is used as a place holder (because of limitation in JDK 5 annotations).  This keeps that place hodler from actually getting set
    	if ( !typeHandler.equals(TypeHandler.class) ) {
            this.typeHandler = typeHandler;
    	}
    }    
}
