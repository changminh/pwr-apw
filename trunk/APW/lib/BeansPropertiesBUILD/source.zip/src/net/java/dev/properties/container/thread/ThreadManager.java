package net.java.dev.properties.container.thread;

import java.lang.reflect.InvocationTargetException;
import javax.swing.SwingUtilities;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.IndexedPropertyImpl;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;

/**
 * This class is used by the BeanContainer and manages merging the threads
 * into the container. The default implementation of this class works with the
 * Swing EDT.
 *
 * @author Shai Almog
 */
public class ThreadManager {
    /**
     * Indicates the default manager used in the application this allows developers
     * to independently install their own "main thread" for the application although
     * this might not be a "good idea" unless you know what you are doing...
     */
    public static final Property<ThreadManager> defaultInstance = PropertyImpl.create(new ThreadManager());
    
    /**
     * Contains all the threads that are supported by the manager, developers interested in multithreading
     * should add their ThreadManager into this list of managers
     */
    public static final IndexedProperty<ThreadManager> managers = IndexedPropertyImpl.create();
        
    public ThreadManager() {
        BeanContainer.bind(this);
    }
    
    /**
     * <p>Returns the thread manager to handle the given listener, a listener can be distinguished
     * by the appropriate subclass using marker interfaces, annotations etc...
     * <p>This method never returns null, it will return the default manager if none of th
     * installed managers fit the bill.
     */
    public static ThreadManager getManager(Object listener) {
        for(ThreadManager manager : managers) {
            if(manager.isRightManager(listener)) {
                return manager;
            }
        }
        return defaultInstance.get();
    }
    
    /**
     * This method should be overriden to indicate if this manager should be used for 
     * a particular listener instance. 
     */
    protected boolean isRightManager(Object listener) {
        return false;
    }
    
    /**
     * Invokes r on the thread represented by this manager and waits on the current thread for r to complete.
     * If the current thread is already the destination (isRightThread() returns true) the behavior of this
     * method is undefined and it might fail/block forever.
     */
    public void invokeAndWait(Runnable r) {
        try {
            SwingUtilities.invokeAndWait(r);
        } catch(InterruptedException i) {
            // not much to do
            i.printStackTrace();
            return;
        } catch(InvocationTargetException err) {
            Throwable e = err.getCause();
            if(e instanceof RuntimeException) {
                throw (RuntimeException)e;
            }
            throw new BeanBindException((Exception)e);
        }
    }
    
    /**
     * Returns true if the current thread is the "right thread" for this type of 
     * dispatch
     */
    public boolean isRightThread() {
        return SwingUtilities.isEventDispatchThread();
    }
}
