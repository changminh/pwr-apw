package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author Glen Marchesani
 */
public class DoubleHandler extends PrimitiveTypeHandler<Double> {

	public DoubleHandler() {
		super(Double.class,Types.DOUBLE);		
	}

	public Double get( ResultSet resultSet, int offset) throws SQLException {
		return resultSet.getDouble(offset);
	}

	public void initPreparedStatmentImpl(Double value, PreparedStatement preparedStatement, int offset) throws SQLException {
		preparedStatement.setDouble(offset, value);		
	}

}
