/*
 * TimeComponent.java
 *
 * Created on March 13, 2007, 3:31 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding.mirror;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.PropertyListener;

/**
 * A simple UI widget that implements a time selection control based on hours and
 * minutes using a spinner
 *
 * @author Shai Almog
 */
public class TimeComponent extends Box implements ChangeListener, PropertyListener {
    private JSpinner hours = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
    private JSpinner minutes = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
    private Object bean;
    private PropertyContext property;
    private boolean lock = false;
    TimeComponent() {
        super(BoxLayout.LINE_AXIS);
        add(hours);
        add(new JLabel(":"));
        add(minutes);
        hours.addChangeListener(this);
        minutes.addChangeListener(this);
    }

    public void bind(Object bean, PropertyContext property) {
        if(this.property != null) {
            BeanContainer.get().removeListener(this.property.getValue(bean), this);
        }
        this.bean = bean;
        this.property = property;
        updateValue((Number)property.getInternalValue(bean));
        BeanContainer.get().addListener(property.getValue(bean), this);
    }

    private void updateValue(Number val) {
        int value = 0;
        if(val != null) {
            value = val.intValue();
        }
        hours.setValue(new Integer(value / 60));
        minutes.setValue(new Integer(value % 60));
    }

    public void stateChanged(ChangeEvent e) {
        if(lock) return;
        lock = true;
        if(bean != null) {
            BaseProperty p = property.getValue(bean);
            if(p instanceof WProperty) {
                ((WProperty)p).set(((Number)hours.getValue()).intValue() * 60 + 
                    ((Number)minutes.getValue()).intValue());
            }
        }
        lock = false;
    }

    public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        if(lock) return;
        lock = true;
        updateValue((Number)property.getInternalValue(bean));
        lock = false;
    }
}
