/*
 * BaseBean.java
 *
 * Created on March 5, 2007, 7:35 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import java.beans.PropertyChangeListener;
import java.util.Map;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.ObservableDelegate;
import net.java.dev.properties.container.ObservableInterface;
import net.java.dev.properties.events.PropertyListener;

/**
 * An optional class to ease the process of creating beans, users who wish to
 * create beans that are functional can simply derive from this class which 
 * doesn't remove the need to invoke BeanContainer.bind() however it implements sensible
 * and powerful implementations of equals etc... Various methods from
 * the bean container are delegated here for even shorter syntax.
 * <p>Even if you don't intend to derive from this class it is a good starting
 * point for the proper way to implement some bean features.
 * <p>This class implements ObservableInterface which is not a required interface however, 
 * it can speed up performance for the use case of adding a listener directly to the bean.
 * <p>This class also includes property change support for compatibility with legacy
 * beans with no effort at all.
 *
 * @author Shai Almog
 */
public class BaseBean implements java.io.Serializable, ObservableInterface {
    private ObservableDelegate<PropertyListener> delegate;
    
    public BaseBean() {
        BeanContainer.bind(this);
    }
    
    public Map<String, Object> toMap() {
        return get().createMapRecursive(this);
    }

    public String toString() {
        return get().toString(this);
    }

    public boolean equals(Object obj) {
        return get().equals(this, obj);
    }

    public Object clone() {
        return get().clone(this);
    }

    protected static BeanContainer get() {
        return BeanContainer.get();
    }
    
    public BeanContext getContext() {
        return BeanContainer.get().getContext(getClass());
    }
    
    /**
     * Returns all the read/write properties objects in this bean
     */
    public Property[] getProperties() {
        return getContext().getPropertiesArray(this);
    }

    /**
     * Returns all the readable properties objects in this bean
     */
    public RProperty[] getRProperties() {
        return getContext().getRPropertiesArray(this);
    }

    /**
     * Returns all the writeable properties objects in this bean
     */
    public WProperty[] getWProperties() {
        return getContext().getWPropertiesArray(this);
    }
    
    public boolean isValid() {
        return BeanContainer.get().isValid(this);
    }
    
    public <T> void addListener(BaseProperty<T> property, PropertyListener listener) {
        BeanContainer.get().addListener(property, listener);
    }
    
    public <T> void removeListener(BaseProperty<T> property, PropertyListener listener) {
        BeanContainer.get().removeListener(property, listener);
    }

    public <T> void addListener(PropertyListener listener) {
        BeanContainer.get().addListener(this, listener);
    }
    
    public <T> void removeListener(PropertyListener listener) {
        BeanContainer.get().removeListener(this, listener);
    }
    
    public void addPropertyChangeListener(PropertyChangeListener l) {
        BeanContainer.get().addPropertyChangeListener(this, l);
    }

    public void addPropertyChangeListener(String n, PropertyChangeListener l) {
        BeanContainer.get().addPropertyChangeListener(this, n, l);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener l) {
        BeanContainer.get().removePropertyChangeListener(this, l);
    }

    public void removePropertyChangeListener(String n, PropertyChangeListener l) {
        BeanContainer.get().removePropertyChangeListener(this, n, l);
    }    

    public ObservableDelegate<PropertyListener> getDelegate() {
        if(delegate == null) {
            delegate = new ObservableDelegate<PropertyListener>();
        } 
        return delegate;
    }
}
