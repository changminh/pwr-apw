package net.java.dev.properties.jdbc;

import java.util.List;
import net.java.dev.properties.Property;

/**
 * The interface through which all orm objects should traverse.  Essentially
 * a Session will track all the objects that have been retrieved through it 
 * and offer transparent updates to any object retrieved through the session 
 * when flush() is called.
 * 
 *  A single session will return the same object if the key is the same.  To explain with code
 *  
 *  Session sess = ....;
 *  
 *  MyClass m1 = sess.fetch(MyClass.class, 1 );
 *  MyClass m2 = sess.fetch(MyClass.class, 1 );
 *  
 *  m1 == m2 will always be true assuming that there is a valid record in the MyClass table with a key vcalue of 1.
 * 
 * @author Glen Marchesani
 */
public interface Session {
	
	public <T> List<T> fetchAll( Class<T> clazz );
	public <T> List<T> fetchMany( Class<T> clazz, String whereClause );
	public <T> T fetchOne( Class<T> clazz, String whereClause );
	public <T> T fetchByPK( Class<T> clazz, Object...keyValues );
	
	public void clear();
	
	public void insert(Object o);
	public void delete(Object o);
	
	public void flush();
	public void commit();
	public void flushAndCommit();
	
	public void close();
	
	public <T> T fetchFromCache( Class<T> clazz, Object...keyValues );
	public void addToCache( Object object );
        
    /**
     * This property indicates whether changes made to properties in the session
     * will be tracked so they can be reverted in memory without going to the database.
     * This is very useful for applications that might fail in persisting but would
     * still want to try again without going to the database.
     */
    public Property<Boolean> trackClientChanges();
	
    /**
     * Reverts in memory state of the objects to the value before the last invocation
     * of clearMemoryState! This operation is only valid when trackClientChanges is true.
     */
    public void revertMemoryState();

    /**
     * Clears current memory state so we can no longer revert to older states.
     * This operation is only valid when trackClientChanges is true.
     */
    public void clearMemoryState();
    
    
    /**
     * Binds the given bean to the persistence layer so it will be batch updated
     * in the background until flush is invoked...
     * equivalent of merge(o,true);
     * 
     */
    public void merge(Object o);

    /**
     * Bind only to the eagerly loaded properties.  Should only be used internally.
     * 
     * The ORM internals for the lazy associations need a way to bind property change listeners
     * to only the properties that have been fulyl hydrated (i.e. eagerly loaded).
     * 
     */
    public void merge(Object o, boolean mergeEagerProperties, boolean mergeNonEagerProperties );

}
