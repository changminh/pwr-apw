/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters.impl;

import net.java.dev.properties.binding.swing.adapters.*;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.container.BeanContainer;

/**
 * Implements list support for propagating UI changes
 *
 * @deprecated do not use this class! It is an internal implementation class and undocumented!
 * @author Shai Almog
 */
public class ListItemAdapter extends SwingAdapter<Object, JList> implements ListSelectionListener {
    public final Property<Boolean> shouldScroll = new PropertyImpl<Boolean>(true);
    
    public ListItemAdapter() {
        BeanContainer.bind(this);
    }
    
    protected void bindListener(BaseProperty<Object> property, JList cmp) {
        cmp.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cmp.addListSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<Object> property, JList cmp) {
        cmp.removeListSelectionListener(this);
    }

    protected void updateUI(Object newValue) {
        getComponent().setSelectedValue(newValue, shouldScroll.get());
    }            

    public void valueChanged(ListSelectionEvent e) {
        callWhenUIChanged(getComponent().getSelectedValue());
    }

    protected Class getType() {
        return Object.class;
    }

    protected Class getComponentType() {
        return JList.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}