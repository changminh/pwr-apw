/*
 * VetoObservable.java
 *
 * Created on April 23, 2007, 11:37 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container.veto;

import net.java.dev.properties.container.ObservableDelegate;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.container.VetoInterface;
import net.java.dev.properties.events.VetoListener;

/**
 * An observable version of the vetoable property
 *
 * @author Shai Almog
 */
public class VetoObservable<T> extends ObservableProperty<T> implements VetoInterface {
    private ObservableDelegate<VetoListener> veto;
    
    public VetoObservable() {
    }
    
    public VetoObservable(T t) {
        super(t);
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> VetoObservable<K> create() {
        return new VetoObservable<K>();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> VetoObservable<K> create(K k) {
        return new VetoObservable<K>(k);
    }

    /**
     * @inheritDoc
     */
    @Override
    public void set(T t) {
        if(!getContext().onVetoCheck(this, get(), t, -1)) {
            return;
        }
        super.set(t);
    }

    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<VetoListener> getVetoDelegate() {
        if(veto == null) {
            veto = new ObservableDelegate<VetoListener>();
        }
        return veto;
    }    
}
