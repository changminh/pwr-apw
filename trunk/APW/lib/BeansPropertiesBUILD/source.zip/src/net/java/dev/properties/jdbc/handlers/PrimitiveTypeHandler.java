package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import net.java.dev.properties.WProperty;
//import net.model3.lang.ClassX;
import net.java.dev.properties.util.Utils;


/**
 * Base class for all primitive types
 * 
 * @author Glen Marchesani
 */
public abstract class PrimitiveTypeHandler<T> extends AbstractTypeHandler<T> {

	private Class _primitiveType;
	private Class _referenceType;
	private int _sqlType;

	protected PrimitiveTypeHandler( Class type, int sqlType ) {
		
                if(type.isPrimitive()) {
                    _primitiveType = type;
                    _referenceType = Utils.getNonPrimitive(type);
                } else {
                    _primitiveType = Utils.getPrimitive(type);
                    _referenceType = type;
                }
            
		
		_sqlType = sqlType;
		
	}
	
	public abstract T get(ResultSet resultSet, int offset) throws SQLException;
	
	public final void loadProperty(WProperty<T> property, ResultSet resultSet, int offset) throws SQLException {
		property.set(get(resultSet, offset));
	}
	
	public void loadPreparedStatment(Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
		T value = (T) columnValues[columnValuesOffset];
		if ( value == null ) {
			preparedStatement.setNull(preparedStatementOffset, _sqlType);
		} else {
			initPreparedStatmentImpl(value, preparedStatement, preparedStatementOffset);
		}
	}

	public abstract void initPreparedStatmentImpl(T value, PreparedStatement preparedStatement, int offset) throws SQLException;

	public boolean canHandleType(Class type) {
    	if ( type.equals(_primitiveType) || type.equals(_referenceType) ) {
    		return true;
    	} else {
    		return false;
    	}
	}
	
	@Override
	public void activated() {
		super.activated();
		setColumn(ColumnContext.createSingleColumn(getPropertyContext().getColumnName(), _sqlType, 0, getPropertyContext().isNullable(),getPropertyContext().getReadOnlyColumns() ));
	}
	
	public boolean doesEagerFetching() {
		return true;
	}
	
}
