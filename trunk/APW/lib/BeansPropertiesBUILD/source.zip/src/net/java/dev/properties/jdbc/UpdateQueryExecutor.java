package net.java.dev.properties.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * 
 * A Query executor specifically for doing updates that exposes the number of rows updated i.e. 
 * ResultSet.getUpdateCount().
 * 
 * @author Glen Marchesani
 */
public class UpdateQueryExecutor extends SQLExecutor {
	
	private int _numberOfRowsUpdated;
	
    public UpdateQueryExecutor(String query) {
        super(query,null,true);
    }
    
    public UpdateQueryExecutor(String query,Connection connection) {
        super(query,connection,true);
    }
    
    @Override
    protected void postQuery() throws SQLException {
    	_numberOfRowsUpdated = getStatement().getUpdateCount();
    }
    
    public int getNumberOfRowsUpdated() {
		return _numberOfRowsUpdated;
	}

}