package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;

import net.java.dev.properties.Property;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.OnGet;
import net.java.dev.properties.events.OnGetListener;
import net.java.dev.properties.jdbc.Association;
import net.java.dev.properties.jdbc.EntityPersister;
import net.java.dev.properties.jdbc.ORMThread;
import net.java.dev.properties.jdbc.QueryBuilder;
import net.java.dev.properties.jdbc.QueryExecutor;
import net.java.dev.properties.jdbc.SQLExecutor;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionAware;
import net.java.dev.properties.jdbc.SessionConfiguration;

/**
 * @author Glen Marchesani
 */
public class ManyEntityHandler<T> extends AbstractTypeHandler<T> {

	private SingleEntityHandler<Object> _foreignTypeHandler;
	private EntityPersister<Object> _foreignEntityPersister;
	private PropertyContext _foreignPropertyContext;
	
    public ManyEntityHandler() {
    }

    public boolean canHandleType(Class<?> type) {
        return false;
    }

    @Override
    protected void initColumns() {
        setColumns(new ArrayList<ColumnContext>());
    }

    public void loadPreparedStatment(Object[] columnValues, int columnValuesOffset, PreparedStatement preparedStatement, int preparedStatementOffset) throws SQLException {
    }
	
    public void loadProperty(WProperty<T> property, ResultSet resultSet, int offset) throws SQLException {
    	
    	if ( _foreignPropertyContext == null && property.getContext().isBidirectional() ) {
    		Association association = property.getContext().getRelationalAssociation(property.getParent());
    		_foreignPropertyContext = association.getForeignPropertyContext(property.getContext());
    	}
    	
    	if ( property instanceof OnGetListener ) {
    		
    		final OnGetListener onGetListener = (OnGetListener) property;
    		
			onGetListener.setOnGet( new OnGet() {
				public void onGet(RProperty<?> p) {
					WProperty wProperty = (WProperty) p;
					List manyEntitites = getManyEntities((Property) p);
					wProperty.set(manyEntitites);
                                        
					// we are initialized so this listener can remove itself
					onGetListener.setOnGet(null);
				}
			});

    	} else {
    		throw new RuntimeException( "properties must implement OnGetListener" );
    	}
    }
    
    List getManyEntities( Property property ) {
    	    	
		int index = 0;
		StringBuilder whereClause = new StringBuilder();
		String separator = "";
                
                if(property.getContext().isBidirectional()) {
                    for ( ColumnContext columnContext : getManyTypeHandler().getColumns() ) {
                            whereClause.append(separator);
                            whereClause.append( columnContext.getName() );
                            whereClause.append( " = ?" );
                            separator = " and ";
                    }
                } else {
                    whereClause.append(property.getContext().getRelationName());
                    whereClause.append( " = ?" );
                }
		
		String fullSql = getManyEntityPersister().getSelectQuery() + " where " + whereClause;

		List<T> response = new SelectManyQuery( fullSql, property.getParent() ).getResults();

		return response;
    }

	public SingleEntityHandler<Object> getManyTypeHandler() {
		if ( _foreignTypeHandler == null ) {
                    _foreignTypeHandler = (SingleEntityHandler<Object>) getManyEntityPersister().getTypeHandler(_foreignPropertyContext);
		}
		return _foreignTypeHandler;
	}

	
	public EntityPersister getManyEntityPersister() {
		if ( _foreignEntityPersister == null ) {
			_foreignEntityPersister = (EntityPersister) ((Object) SessionConfiguration.getInstance().getPersister(getManyEntityType())); 
		}
		return _foreignEntityPersister;
	}

	public Class<Set<T>> getManyEntityType() {
		return (Class<Set<T>>) getPropertyContext().getType();
	}


	class SelectManyQuery extends QueryExecutor<T> {
		
            private Object _bean;

            SelectManyQuery(String sql,Object bean) {
                super(sql,false);
                _bean = bean;
                execute();
            }

            @Override
            protected void prepareQuery() throws SQLException {
                Object[] columnValues;
                if(getPropertyContext().isBidirectional()) {
                    columnValues = new Object[getManyTypeHandler().getColumns().size()];
                    SimpleProperty simpleProperty = new SimpleProperty();
                    simpleProperty._value = _bean;
                    getManyTypeHandler().loadColumnValues(simpleProperty, columnValues, 0);
                    getManyTypeHandler().loadPreparedStatment(columnValues, 0, getStatement(), 1);
                } else {
                    int arrayOffset = 0;
                    int preparedStatementOffset = 1;
                    PreparedStatement preparedStatement = getStatement();
                    columnValues = getParentEntityPersister().getPrimaryKeyColumnValues(_bean);
                    for( TypeHandler keyHandler : getParentEntityPersister().getPrimaryKeyHandlers()) {
                            keyHandler.loadPreparedStatment(columnValues, arrayOffset, preparedStatement, preparedStatementOffset);
                            preparedStatementOffset += keyHandler.getColumns().size();
                            arrayOffset += keyHandler.getColumns().size();
                    }
                }
            }

            @Override
            protected T processRow(ResultSet row) throws SQLException {
                return (T) getManyEntityPersister().createFromResultSet(row);
            }
		
	}
	

    private class SimpleProperty implements RProperty<Object> {

		private Object _value;
		
		public Object get() {
			return _value;
		}

		public PropertyContext getContext() {
			return null;
		}

		public Object getParent() {
			return null;
		}

		public void setContext(PropertyContext context) {
		}

		public void setParent(Object parent) {
		}
		
	}
	
	public boolean doesEagerFetching() {
		return false;
	}
        
    public void merge(Session session, IndexedProperty<T> indexedProperty ) {
        // we need to manually update the foreign key since there is no
        // foreign property that would do that for us...
        if(!indexedProperty.getContext().isBidirectional()) {
            BeanContainer.get().addListener(indexedProperty, new UnidirectionalUpdater(session, indexedProperty));
        }
    }
        
        
    private class UnidirectionalUpdater implements SessionAware, ORMThread.IndexedPropertyListener {
        private List<Object> removed = new ArrayList<Object>();
        private List<Object> added = new ArrayList<Object>();
        private Session session;
        private boolean addedToSession = false;
        private IndexedProperty<T> indexedProperty;

        public UnidirectionalUpdater(Session session, IndexedProperty<T> indexedProperty) {
            this.session = session;
            this.indexedProperty = indexedProperty;
        }
        
        public void processDeletes() {
        }

        public void processUpdates() {
            final QueryBuilder queryBuilder = new QueryBuilder();
            queryBuilder.append("update ");
            queryBuilder.append(getManyEntityPersister().getTableName());            
            queryBuilder.append(" set ");

            queryBuilder.append(getPropertyContext().getRelationName());
            queryBuilder.append(" = ? ");
            
            queryBuilder.append(" where ");

            String separator = "";
            queryBuilder.appendHandlerColumns(getManyEntityPersister().getPrimaryKeyHandlers(), "= ?", " and ", true);
            
            new SQLExecutor(queryBuilder.getSql(),null,true) {    
                protected void runQuery() throws SQLException {
                    getStatement().executeBatch();
                }

                @Override
                protected void prepareQuery() throws SQLException {
                    Object[] vals = getParentEntityPersister().getPrimaryKeyColumnValues(indexedProperty.getParent());
                    PreparedStatement p = getStatement();
                    // we can't use loadPrepared Statement since we don't have handlers for the foreign side
                    for(int iter = 0 ; iter < vals.length ; iter++) {
                        p.setObject(1 + iter, null);
                    }
                    for(Object o : removed) {
                        p.addBatch();
                    }

                    for(int iter = 0 ; iter < vals.length ; iter++) {
                        p.setObject(1 + iter, vals[iter]);
                    }
                    for(Object o : added) {
                        Object[] foreignPKs = getManyEntityPersister().getPrimaryKeyColumnValues(o);
                        for(int iter = 0 ; iter < foreignPKs.length ; iter++) {
                            p.setObject(1 + vals.length + iter, foreignPKs[iter]);
                        }
                        getStatement().addBatch();
                    }
                }
            };
        }

        public void processInserts() {
        }

        private void init() {
            if(!addedToSession) {
                addedToSession = true;
                session.merge(this);
            }
        }
        
        public void propertyInserted(IndexedProperty prop, Object value, int index) {
            if(removed.contains(value)) {
                removed.remove(value);
            }
            added.add(value);
            init();
        }

        public void propertyRemoved(IndexedProperty prop, Object value, int index) {
            if(added.contains(value)) {
                added.remove(value);
            }
            removed.add(value);
            init();
        }

        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        }
    }

}
