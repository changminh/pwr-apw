package net.java.dev.properties.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Used by the ORM code but this attribute will be have affect in the future for
 * beans without persistance. It allows us to mark two properties as related and
 * any change to one property will automatically affect the other. This aspect
 * represents a bidirectional relation.
 *
 * @author Glen Marchesani
 */

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Bidirectional {
        /**
         * Value overrides the relation name as a "shorthand" to save us the need of a Column annotation...
         * This is a name for the bidirectional annotation that allows us to diffrentiate
         * the two sides of the relation from other properties with the same type
         */
	String value();
        
        /**
         * Some relations require a side that is eventually responsible for persisting
         * the relation state.
         */
	boolean parent() default false; 
	boolean allowDuplicates() default false;
}
