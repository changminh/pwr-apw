/*
 * ColumnLayout.java
 *
 * Created on March 10, 2007, 9:35 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;

/**
 * A simple layout manager that lays out label/component pairs in a column all
 * of which are identically sized and evenly spaced however pairs of component
 * and labels are aligned while component height can be independent. The layout
 * manager expects components to appear in the form of label+component. Unlike
 * many third party layout managers this layout manager properly supports bidi.
 *
 * @author Shai Almog
 */
public class ColumnLayout implements LayoutManager {
    private static final GetSize MINIMUM = 
        new GetSize() {
            public Dimension getSize(Component c) {
                return c.getMinimumSize();
            }
        };

    private static final GetSize PREFERRED = 
        new GetSize() {
            public Dimension getSize(Component c) {
                return c.getPreferredSize();
            }
        };
        
    private int columns;
    private boolean horizontal = true;
    
    /** Creates a new instance of ColumnLayout */
    public ColumnLayout(int columns) {
        this.columns = columns;
    }

    /** Creates a new instance of ColumnLayout */
    public ColumnLayout(int columns, boolean horizontal) {
        this(columns);
        this.horizontal = horizontal;
    }

    /**
     * Removes the specified component from the layout.
     * 
     * @param comp the component to be removed
     */
    public void removeLayoutComponent(Component comp) {
    }

    /**
     * If the layout manager uses a per-component string,
     * adds the component <code>comp</code> to the layout,
     * associating it with the string specified by <code>name</code>.
     * 
     * 
     * @param name the string to be associated with the component
     * @param comp the component to be added
     */
    public void addLayoutComponent(String name, Component comp) {
    }

    /**
     * Used internally by the preferred/maximum/minimum size methods
     */
    private Dimension calculateContainerSize(Container c, GetSize sizeEvaluation) {
        Component[] comps = c.getComponents();
        int maxComponent = 0;
        int maxLabel = 0;
        int totalHeight = 0;
        for(int iter = 0 ; iter < comps.length ; iter += 2) {
            Component label = comps[iter]; 
            Component comp = comps[iter + 1]; 
            Dimension labelSize = sizeEvaluation.getSize(label);
            Dimension componentSize = sizeEvaluation.getSize(comp);
            maxLabel = Math.max(maxLabel, labelSize.width);
            maxComponent = Math.max(maxComponent, componentSize.width);
            totalHeight += componentSize.height + 3;
        }
        return new Dimension((maxLabel + maxComponent + 6) * columns + 6, 
            totalHeight / columns + 6);
    }
    
    /**
     * Calculates the preferred size dimensions for the specified 
     * container, given the components it contains.
     * 
     * @param parent the container to be laid out
     * @see #minimumLayoutSize
     */
    public Dimension preferredLayoutSize(Container parent) {
        return calculateContainerSize(parent, PREFERRED);
    }

    /**
     * 
     * Calculates the minimum size dimensions for the specified 
     * container, given the components it contains.
     * 
     * @param parent the component to be laid out
     * @see #preferredLayoutSize
     */
    public Dimension minimumLayoutSize(Container parent) {
        return calculateContainerSize(parent, MINIMUM);
    }

    /**
     * Lays out the specified container.
     * 
     * @param parent the container to be laid out
     */
    public void layoutContainer(Container parent) {
        int columns = this.columns * 2;
        Component[] comps = parent.getComponents();
        int maxLabel = 0;
        for(int iter = 0 ; iter < comps.length ; iter += 2) {
            Component label = comps[iter]; 
            Dimension labelSize = label.getPreferredSize();
            maxLabel = Math.max(maxLabel, labelSize.width);
        }
        
        int parentHeight = parent.getHeight();
        int parentWidth = parent.getWidth();
        int componentWidth = parentWidth / this.columns - (6 * this.columns) - maxLabel;
        int[] columnStarts = new int[columns];
        columnStarts[0] = 3;
        for(int iter = 1 ; iter < columns ; iter++) {
            if(iter % 2 == 0) {
                columnStarts[iter] = columnStarts[iter - 1] + 5 + componentWidth;
            } else {
                columnStarts[iter] = columnStarts[iter - 1] + 3 + maxLabel;
            }
        }

        int currentComponent = 0;
        if(horizontal) {
            for(int iter = 0 ; iter < columns ; iter += 2) {
                int labelColumn = columnStarts[iter];
                int componentColumn = columnStarts[iter + 1];
                int height = 3;
                if(comps.length <= currentComponent + 1) {
                    break;
                }
                Component label = comps[currentComponent];
                Component comp = comps[currentComponent + 1];
                Dimension componentSize = comp.getPreferredSize();
                int componentHeight = Math.min(parentHeight - height - 3, componentSize.height);;
                do {
                    int labelHeight = label.getPreferredSize().height;
                    int baseLine = componentSize.height / 2 - labelHeight / 2;
                    if(baseLine > 6) { 
                        baseLine = 0;
                    }
                    if(parent.getComponentOrientation().isLeftToRight()) {
                        comp.setBounds(componentColumn, height, componentWidth, componentHeight);
                        label.setBounds(labelColumn, height + baseLine, maxLabel, label.getPreferredSize().height);
                    } else {
                        comp.setBounds(parentWidth - componentColumn - componentWidth, height, componentWidth, componentHeight);
                        label.setBounds(parentWidth - labelColumn - maxLabel, height + baseLine, maxLabel, label.getPreferredSize().height);
                    }
                    height += componentHeight + 3;
                    currentComponent += 2;
                    if(comps.length <= currentComponent + 1) {
                        break;
                    }
                    label = comps[currentComponent];
                    comp = comps[currentComponent + 1];
                    componentSize = comp.getPreferredSize();
                    componentHeight = Math.min(
                        Math.max(parentHeight - height - 3, comps[currentComponent].getMinimumSize().height), 
                        componentSize.height);
                } while(height + componentHeight < parentHeight);
            }
        } else {
            int componentHeight = 0;
            int height = 3;
            do {
                for(int iter = 0 ; iter < columns ; iter += 2) {
                    int labelColumn = columnStarts[iter];
                    int componentColumn = columnStarts[iter + 1];
                    if(comps.length <= currentComponent + 1) {
                        break;
                    }
                    Component label = comps[currentComponent];
                    Component comp = comps[currentComponent + 1];
                    Dimension componentSize = comp.getPreferredSize();
                    componentHeight = Math.min(parentHeight - height - 3, componentSize.height);;
                    int labelHeight = label.getPreferredSize().height;
                    int baseLine = componentSize.height / 2 - labelHeight / 2;
                    if(baseLine > 6) { 
                        baseLine = 0;
                    }
                    if(parent.getComponentOrientation().isLeftToRight()) {
                        comp.setBounds(componentColumn, height, componentWidth, componentHeight);
                        label.setBounds(labelColumn, height + baseLine, maxLabel, label.getPreferredSize().height);
                    } else {
                        comp.setBounds(parentWidth - componentColumn - componentWidth, height, componentWidth, componentHeight);
                        label.setBounds(parentWidth - labelColumn - maxLabel, height + baseLine, maxLabel, label.getPreferredSize().height);
                    }
                    currentComponent += 2;
                    if(comps.length <= currentComponent + 1) {
                        break;
                    }
                    label = comps[currentComponent];
                    comp = comps[currentComponent + 1];
                    componentSize = comp.getPreferredSize();
                    componentHeight = Math.min(
                        Math.max(parentHeight - height - 3, comps[currentComponent].getMinimumSize().height), 
                        componentSize.height);
                }
                height += componentHeight + 3;
            } while(height + componentHeight < parentHeight);
        }
    }
    
    private static interface GetSize {
        public Dimension getSize(Component c);
    }
}
