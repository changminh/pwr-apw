/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.math.BigDecimal;
import java.util.Date;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.binding.Adapter;
import net.java.dev.properties.util.Utils;

/**
 * Implements spinner support for the state change/ui
 *
 * @author Shai Almog
 */
class SliderAdapter extends SwingAdapter<Integer, JSlider> implements ChangeListener {
    protected void bindListener(BaseProperty<Integer> property, JSlider cmp) {
        cmp.addChangeListener(this);
    }

    protected void unbindListener(BaseProperty<Integer> property, JSlider component) {
        component.removeChangeListener(this);
    }

    protected void updateUI(Integer newValue) {
        if(newValue != null) {
            getComponent().setValue(newValue);
        } 
    }            

    public void stateChanged(ChangeEvent e) {
        callWhenUIChanged(getComponent().getValue());
    }    

    protected Class getType() {
        return Integer.class;
    }

    protected Class getComponentType() {
        return JSlider.class;
    }
}