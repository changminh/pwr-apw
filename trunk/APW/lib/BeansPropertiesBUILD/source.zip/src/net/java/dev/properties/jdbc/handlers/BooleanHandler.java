package net.java.dev.properties.jdbc.handlers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author Glen Marchesani
 */
public class BooleanHandler extends PrimitiveTypeHandler<Boolean> {

	public BooleanHandler() {
		super(Boolean.class, Types.BOOLEAN);
	}

	public Boolean get( ResultSet resultSet, int offset) throws SQLException {
		return resultSet.getBoolean(offset);
	}

	public void initPreparedStatmentImpl(Boolean value, PreparedStatement preparedStatement, int offset) throws SQLException {
		preparedStatement.setBoolean(offset, value);		
	}

}
