/*
 * IndexedPropertyListener.java
 *
 * Created on March 4, 2007, 9:01 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.events;

import net.java.dev.properties.IndexedProperty;

/**
 * Allows additional events unique only to indexed properties, instances of this 
 * interface can be bound just like the standard property listener interfaces.
 * This listener is bound like any standard PropertyListener and it would receive
 * the additional notifications implicitly.
 *
 * @author Shai Almog
 */
public interface IndexedPropertyListener extends PropertyListener {
    /**
     * Invoked when a new property is added
     */
    public void propertyInserted(IndexedProperty prop, Object value, int index);
    
    /**
     * Invoked when a property is removed
     */
    public void propertyRemoved(IndexedProperty prop, Object value, int index);
}
