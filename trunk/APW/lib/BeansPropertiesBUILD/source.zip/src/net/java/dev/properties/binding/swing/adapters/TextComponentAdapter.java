/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements toggle button support for the state change/ui
 *
 * @author Shai Almog
 */
class TextComponentAdapter extends SwingAdapter<String, JTextComponent> implements DocumentListener {
    protected void bindListener(BaseProperty<String> property, JTextComponent cmp) {
        cmp.getDocument().addDocumentListener(this);
    }

    protected void unbindListener(BaseProperty<String> property, JTextComponent cmp) {
        cmp.getDocument().removeDocumentListener(this);
    }

    protected void updateUI(String newValue) {
        getComponent().setText(newValue);
    }            

    public void removeUpdate(DocumentEvent e) {
        callWhenUIChanged(getComponent().getText());
    }

    public void insertUpdate(DocumentEvent e) {
        callWhenUIChanged(getComponent().getText());
    }

    public void changedUpdate(DocumentEvent e) {
        callWhenUIChanged(getComponent().getText());
    }

    protected Class getType() {
        return String.class;
    }

    protected Class getComponentType() {
        return JTextComponent.class;
    }
}