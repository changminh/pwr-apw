package net.java.dev.properties.annotations;

import java.lang.annotation.*;
import net.java.dev.properties.constraints.Constraint;

/**
 * Constraint specifying a regular expression value that automatically installs an instance of the 
 * class {@link net.java.dev.properties.constraints.RegexConstraint} onto the given
 * property.
 *
 * @author Shai Almog
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Regex {
    /**
     * The regular expression against which this constraint would be validated
     */
    String exp() default "";

    /**
     * The validation messae passed into the constraint object
     */
    String message() default "Validation failed";

    /**
     * The localizable validation messae passed into the constraint object
     */
    String messageL() default "";
}
