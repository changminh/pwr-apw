package net.java.dev.properties.test.demos.orm;

import java.util.List;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.PropertyListener;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.test.DemoGUI;
import net.java.dev.properties.test.binding.studio.*;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;

/**
 * An extension of the YogaStudio demo adding Database persistance to the demo
 *
 * @author Shai Almog
 */
public class ORMStudioDemo extends Main {
    private PersistantStudioBean studio;
    private int val = 1;
    public String demoName() {
        return "ORM Yoga Studio";
    }

    public String demoDescription() {
        return "<html><body><h1>ORM Yoga Studio</h1>This is a preliminary demo showing how the Yoga Studio demo could be " +
                "mapped to a relational database.";
    }
    
    public String[] fileNames() {
        return DemoGUI.demoFiles(new Class[]{ getClass(), AttendanceBean.class, StudentBean.class, PersistantStudioBean.class, 
                YogaClassBean.class, Main.class, TimeComponent.class});
    }

    @Override
    protected StudioBeanInterface createStudio() {
        ConnectionFactory.initSimpleDriver("org.hsqldb.jdbcDriver", "jdbc:hsqldb:/Users/shai/temp/test", "sa", "");
        SessionConfiguration.getInstance().connectionFactory.get().verbose.set(true);

        Session session = CurrentSession.get();
        SessionConfiguration configuration = SessionConfiguration.getInstance();

        configuration.addClass(PersistantStudent.class).createTable();
        configuration.addClass(PersistantYogaClass.class).createTable();
        configuration.addClass(PersistantAttendance.class).createTable();
        configuration.addClass(PersistantStudioBean.class).createTable();

        List<PersistantStudioBean> l = session.fetchAll(PersistantStudioBean.class);
        if(l.size() == 0) {
            studio = new PersistantStudioBean();
            session.insert(studio);
        } else {
            studio = l.get(0);
        }

        PropertyListener listener = new PropertyListener() {
            private boolean lock = false;
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                if(!lock) 
                {
                    try {
                        lock = true;
                        Session session = CurrentSession.get();
                        session.flush();
                        SessionConfiguration.getInstance().connectionFactory.get().commit();
                    } finally {
                        lock = false;
                    }
                }
            }
        };
        BeanContainer.get().addContextListener(new PersistantStudent(), listener);
        BeanContainer.get().addContextListener(new PersistantAttendance(), listener);
        BeanContainer.get().addContextListener(new PersistantYogaClass(), listener);
        
        return studio;
    }

    @Override
    protected void createBean(IndexedProperty property) {
        if(property == studio.students) {
            PersistantStudent s = new PersistantStudent();
            s.id.set(val);
            addObj(s, property);
            return;
        }
        if(property == studio.attendance) {
            PersistantAttendance s = new PersistantAttendance();
            s.id.set(val);
            addObj(s, property);
            return;
        }
        PersistantYogaClass s = new PersistantYogaClass();
        s.id.set(val);
        addObj(s, property);
    }
    
    /**
     * Adds the bean and makes sure to save the DB on state change
     */
    private void addObj(Object bean, IndexedProperty property) {
        val++;
        Session session = CurrentSession.get();
        session.insert(bean);
        property.add(bean);
        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
    }
}
