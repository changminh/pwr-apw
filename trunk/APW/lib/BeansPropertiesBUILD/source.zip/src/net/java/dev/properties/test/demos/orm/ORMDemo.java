/*
 * ORMDemo.java
 *
 * Created on April 17, 2007, 1:13 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.demos.orm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.test.DemoGUI;
import net.java.dev.properties.test.DemoInterface;
import net.java.dev.properties.jdbc.CurrentSession;
import net.java.dev.properties.jdbc.Session;
import net.java.dev.properties.jdbc.SessionConfiguration;

/**
 * A simple demo of mapping the bean to a database table
 *
 * @author shai
 */
public class ORMDemo extends DemoInterface.DefaultConsoleDemo {
    
    /** Creates a new instance of ORMDemo */
    public ORMDemo() {
        super("Simple ORM (Perliminary)", "<html><head></head><body><h1>Simple ORM</h1>" +
                "A simple demo of mapping to an SQL database using " +
                "the bean properties API and the console. This is a very basic " +
                "demo that does not cover relations, lazy loading, client transactions " +
                "and other advanced features available in bean-properties ORM.", DemoGUI.demoFiles(new Class[] { ORMDemo.class }));
    }

    public void run() {
        // Normally this should use ConnectionFactory.initSimpleDriver() but in this
        // case we also want to override the "log" method...
        try {
            // build an in-memory HSQL database on which we can run the tests
            Class.forName("org.hsqldb.jdbcDriver");
            //Class.forName("org.apache.derby.jdbc.ClientDriver");
            //Class.forName("com.mysql.jdbc.Driver");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        SessionConfiguration.getInstance().connectionFactory.set( new ConnectionFactory() {
        	public Connection newConnection() throws SQLException {
                Connection con = DriverManager.getConnection ("jdbc:hsqldb:.", "sa", "");
                //Connection con = DriverManager.getConnection ("jdbc:derby://localhost:1527/test", null, null);
                //Connection con = DriverManager.getConnection ("jdbc:mysql://localhost/test", "root", "");
                con.setAutoCommit(false);
                return con;
            }

            public void log(String output) {
                getOutput().print("ORM: ");
                getOutput().println(output);
            }
        });
        SessionConfiguration.getInstance().connectionFactory.get().verbose.set(true);
        PersistantStudent bean = new PersistantStudent();

        Session session = CurrentSession.get();
        SessionConfiguration configuration = SessionConfiguration.getInstance();

        configuration.addClass(PersistantStudent.class);
        configuration.getPersister(PersistantStudent.class).createTable();
        
        
        bean.id.set(1);
        bean.firstName.set("Shai");
        bean.surname.set("Almog");
        session.insert(bean);

        bean = new PersistantStudent();
        bean.id.set(2);
        bean.firstName.set("Maya");
        bean.surname.set("Gross");
        session.insert(bean);
        
        session.flush();
        SessionConfiguration.getInstance().connectionFactory.get().commit();
        
        List<PersistantStudent> entries = session.fetchAll(PersistantStudent.class);
        getOutput().println(entries);
    }
}
