/*
 * BaseProperty.java
 *
 * Created on February 20, 2007, 10:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.PropertyContext;

/**
 * Base class for a property which supports none of the interfaces 
 * of a property. The main reason is to generalize the property implementation
 * for subclasses as much as possible. This class is mostly for internal use.
 * The default implementation completely ignores constraints!
 *
 * @author Shai Almog
 */
public class BasePropertyImpl<T> implements BaseProperty<T>, java.io.Externalizable {
    private T t;
    private transient PropertyContext context;
    private Object parent;
    
    public BasePropertyImpl() {
    }
    
    public BasePropertyImpl(T t) {
        this.t = t;
    }

    /**
     * Sets a new value to the property
     */
    protected void set(T t) {
        this.t = t;
    }
    
    /**
     * Returns the value of the property
     */
    protected T get() {
        return t;
    }
    
    /**
     * @inheritDoc
     */
    public PropertyContext getContext() {
        // possible in case of serialization which doesn't call constructors and
        // would need rebinding
        if(context == null) {
            if(parent != null) {
                BeanContainer.bind(parent);
            } else {
                // initially a fail fast mentality is in order, however this point
                // might occur at an inconvenient time due to static properties so
                // this might not always be a failure...
                System.err.println("Warning: Bean not bound. Check the constructors of your beans for calls to BeanContainer.bind(this)! It is not sufficient for your baseclass to perform this operation for you!\nThis might not be a failure if you are using static properties...");
                //throw new BeanBindException("Bean not bound! Check the constructors of your beans for calls to BeanContainer.bind(this)! It is not sufficient for your baseclass to perform this operation for you!");
            }
        }
        return context;
    }

    /**
     * @inheritDoc
     */
    public void setContext(PropertyContext context) {
        this.context = context;
    }

    /**
     * @inheritDoc
     */
    public Object getParent() {
        return parent;
    }

    /**
     * @inheritDoc
     */
    public void setParent(Object parent) {
        this.parent = parent;
    }
    
    /**
     * @inheritDoc
     */
    public String toString() {
        return getContext().getName() + " = " + t;
    }

    /**
     * @inheritDoc
     */
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(t);
    }

    /**
     * @inheritDoc
     */
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        t = (T)in.readObject();
    }
}
