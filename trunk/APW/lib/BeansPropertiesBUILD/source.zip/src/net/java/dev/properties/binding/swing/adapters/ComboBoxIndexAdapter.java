/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JComboBox;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements combo box support for propagating UI changes
 *
 * @author Shai Almog
 */
class ComboBoxIndexAdapter extends SwingAdapter<Integer, JComboBox> implements ItemListener {
    protected void bindListener(BaseProperty<Integer> property, JComboBox cmp) {
        cmp.addItemListener(this);
    }

    protected void unbindListener(BaseProperty<Integer> property, JComboBox cmp) {
        cmp.removeItemListener(this);
    }

    protected void updateUI(Integer newValue) {
        getComponent().setSelectedIndex(newValue);
    }            

    public void itemStateChanged(ItemEvent e) {
        callWhenUIChanged(getComponent().getSelectedIndex());
    }

    protected Class getType() {
        return Integer.class;
    }

    protected Class getComponentType() {
        return JComboBox.class;
    }

    /**
     * Invoked when the value is null
     */
    protected void setEmptyValue() {
        updateUI(0);
    }
}