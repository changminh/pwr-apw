/*
 * RemoteServer.java
 * 
 * Created on Jul 21, 2007, 11:43:17 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.java.dev.properties.net;

import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;

/**
 * <p>The remote interface should be implemented by the developer to allow a remote
 * bean the means of communicating to a server via the given protocol. The identifier
 * for the bean should be set into the remote server thus removing the need for the
 * bean to transfer identifying information with the communication. This probably
 * requires a RemoteServer instance to exist per remote bean instance.
 * <p>This interface is synchronious and is invoked on a separate thread, 
 * fetching and sending should complete once the method is finished.
 * <p>A communication protocol should work with as few "batches" as necessary for requests
 * to increase efficiency (both compression and network). Thus elements are added to
 * a request batch and sent as a single batch.
 * 
 * @author Shai Almog
 */
interface RemoteServer {
    /**
     * Adds the given property of the remote bean to the request
     */
    public void addRequest(PropertyContext p);
    
    /**
     * Adds the given index range to the request from the server. Notice that 
     * begin/end might be out of bounds in which case no failure should occur, this
     * is a valid situation since often an index range is requested before size 
     * information is available. Response is returned as an array.
     */
    public void addRequestIndexRange(PropertyContext index, int beginOffset, int endOffset);
    
    /**
     * Requests the size of the given indexed property
     */
    public void addRequestIndexSize(PropertyContext p);
    
    /**
     * Removes the properties matching the given values from the indexed property. Notice that
     * values might indicate offsets although this isn't advised due to concurrent modification...
     * However the implementation can treat values as identifiers rather than the actual object
     * values. Returns the number of values removed.
     */
    public void removeIndexValues(PropertyContext index, Object[] values);
    
    /**
     * Adds the given values to the indexed property. Returns the number of values added.
     * Offsets are set to a negative value if no offset was given.
     */
    public void insetIndexValues(PropertyContext index, Object[] values, int[] offsets);
    
    /**
     * Sends the given property to the server
     */
    public void updateProperty(PropertyContext p);
    
    /**
     * Sends the given indexed property update to the server. Offset values correspond to the
     * behavior described in the removeIndexValues method.
     */
    public void updateIndexProperties(PropertyContext p, Object[] offsetValues, Object[] newValues);
    
    /**
     * Synchroniously sends all the requests above to the server and returns responses
     * in the order in which they were submitted.
     */
    public Object[] performBatchRequests();
    
    /**
     * Returns the unique identifier for the given bean that would allow us to recognize it 
     * when a delete command is sent or when we need to refresh the bean.
     */
    public Object getBeanId(Object bean);
    
    public void create(Object bean);
    public void read(Object beanId);
    public void update(Object bean);
    public void delete(Object beanId);
    
    /**
     * Returns the server implementation for the given bean type or null if the given
     * bean type is transient and shouldn't be serialized
     */
    public RemoteServer getServer(BeanContext type);
}
