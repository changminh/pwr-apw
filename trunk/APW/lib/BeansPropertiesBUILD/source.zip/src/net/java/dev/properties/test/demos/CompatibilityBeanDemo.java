package net.java.dev.properties.test.demos;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import net.java.dev.properties.test.CompatibilityBean;
import net.java.dev.properties.test.DemoInterface;

/**
 * A demo of using a new bean that matches the functionality of the legacy bean
 *
 * @author shai
 */
public class CompatibilityBeanDemo extends DemoInterface.DefaultConsoleDemo {
    public CompatibilityBeanDemo() {
        super("Compatibility Bean", "<html><body><h1>Compatibility Bean</h1>" +
                "Demonstrates a new bean that implements compatibility to legacy beans manually " +
                "notice that this bean can be identical in functionality to the legacy bean in fewer lines of code " +
                "(the difference becomes more pronounced with complex beans). All the methods in this example can " +
                "be automatically generate by static bytecode instrumentation which means <b>you don't have to " +
                "manually write compatibility beans in order to get 100% backwards compatibility</b> from a simple new bean. " +
                "The only reason to manually write a compatibility bean is if you need JavaBeans compatibility and " +
                "don't want to use instrumentation for some reason. The purpose of this demo is mostly to help you " +
                "understand what instrumentation does and how JavaBeans compare to new beans.", 
                new Class[] {CompatibilityBean.class, CompatibilityBeanDemo.class});
    }

    public void run() {
        CompatibilityBean compat = new CompatibilityBean();
        compat.setX(1);
        getOutput().println("Compatibility x is: " + compat.getX());
        PropertyChangeListener l = new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent ev) {
               getOutput().println("Compatibility " + ev.getPropertyName() + " was changed " + ev.getNewValue());
            }
        };
        compat.addPropertyChangeListener(l);
        compat.setX(2);
        compat.removePropertyChangeListener(l);
        compat.addPropertyChangeListener("x", l);
        compat.setX(3);
        //compat.removePropertyChangeListener("x", l);
    }
}
