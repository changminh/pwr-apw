package net.java.dev.properties.jdbc.handlers;

import java.util.ArrayList;
import java.util.List;

import net.java.dev.properties.RProperty;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.jdbc.EntityPersister;

/**
 * A base implementation of a TypeHandler that handles much of the basic of
 * holding references to columns, a context and a handlerFactory
 * 
 * @author Glen Marchesani
 */
public abstract class AbstractTypeHandler<T> implements LifecycleAwareTypeHandler<T> {

	private BeanContext _beanContext;
	private PropertyContext _propertyContext;
	private EntityPersister<Object> _parentEntityPersister;

	private List<ColumnContext> _columns;

	private TypeHandlerFactory _handlerFactory;

	public PropertyContext getPropertyContext() {
		return _propertyContext;
	}
	public void setPropertyContext(PropertyContext context) {
		_propertyContext = context;
	}
	
	public BeanContext getBeanContext() {
		return _beanContext;
	}
	public void setBeanContext(BeanContext beanContext) {
		_beanContext = beanContext;
	}

	public void setColumn(ColumnContext column) {
		_columns = new ArrayList<ColumnContext>();
		_columns.add(column);
	}

	public List<ColumnContext> getColumns() {
		if (_columns == null) {
			initColumns();
		}
		return _columns;
	}

	protected void setColumns(List<ColumnContext> columns) {
		_columns = columns;
	}

	public TypeHandlerFactory getHandlerFactory() {
		return _handlerFactory;
	}

	public void setHandlerFactory(TypeHandlerFactory handlerFactory) {
		_handlerFactory = handlerFactory;
	}

	public void activated() {
	}

	protected void initColumns() {
	}

	public void loadColumnValues(RProperty<T> property, Object[] columnValues, int columnValuesOffset) {
		if (getColumns().size() > 1) {
			throw new RuntimeException("this method must be overridden for " + getClass().getName() + " handler since it supports more than one column");
		}
		if (property != null) {
			columnValues[columnValuesOffset] = property.get();
		} else {
			columnValues[columnValuesOffset] = null;
		}
	}

	/**
	 * Unlike canHandleType this is a fallback method that will be called if no
	 * other type handler can handle the type. This may be useful for a generic
	 * handler that can handle a base class of an entity.
	 */
	public boolean canHandleTypeFallback(Class<?> type) {
		return false;
	}
	
	public EntityPersister<Object> getParentEntityPersister() {
		return _parentEntityPersister;
	}
	public void setParentEntityPersister(EntityPersister<?> entityPersister) {
		_parentEntityPersister = (EntityPersister<Object>) entityPersister;
	}
}
