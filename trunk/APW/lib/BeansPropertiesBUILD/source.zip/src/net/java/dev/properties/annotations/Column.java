package net.java.dev.properties.annotations;

import static java.lang.annotation.ElementType.FIELD;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import net.java.dev.properties.jdbc.handlers.TypeHandler;

/**
 * Used by the ORM code allows us to specify database specific elements for mapping
 * to a column
 *
 * @author Glen Marchesani
 */

@Target(FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Column {
	
	/**
	 * name of the column (this can be a comma seperated list of names) for 
	 * properties that map to multiple DB columns. By default the property
         * name is used if nothing is specified here.
	 */
	String name() default "";
	
	/**
	 * Is this column a primary key?
	 */
	boolean key() default false;
	
	/**
	 * Default key ordering is the order that they appear in source.  This
	 * attribute allows the default ordering to be overridden.
	 * 
	 * <p>It is recommended that you either use default ordering for all keys 
         * or specify a compositeKeySequence() for all keys
	 * 
	 */
	int compositeKeySequence() default 10000;
	
        /**
         * The name for the relation if this is a relation bidirectional or otherwise
         */
        String relationName() default "";
        
	/**
	 * Can override the TypeHandler used to map the property to/from the db columns.
	 * Using this overrides any other TypeHandler mapping in the TypeHanderFactory.
	 * 
	 * <p>For example if you have a custom type let's call it Money and a TypeHandler for
	 * mapping that to/from the DB let's call it MoneyTypeHandler.  This should be mapped
	 * via  TypeHandlerFactory.add(TypeHandler handler) or even better if you have access to the source for Money
	 * you can add this annotation to the Money class {@code @Bean( typeHandler=StatusHandler.class ) }
	 * 
	 * <p>In some corner cases you may want to just override the TypeHandler for a single property and in that
	 * case that is what this annotation is for.
	 * 
	 * <p>So we have three methods the effective differences are:
	 * <ol>
         * <li>using {@code @Bean( typeHandler=StatusHandler.class ) } is the global and best if you have source
	 * <li>lacking source you can at runtime before bootstrapping ORM use TypeHandlerFactory.add(TypeHandler handler)
	 * <li>for specific cases you can override teh previous options by using @Column(typeHandler=Xyz.class) 
         * </ol>
	 *  
	 */
	Class<? extends TypeHandler> typeHandler() default TypeHandler.class;
	
	/**
	 * suffix() allows you to define the column name by take the suffix() and pre-pending it
	 * with the prefix() defined in the {@code @Table() } annotation defined at the class level. 
	 * Can be column seperated in which case each value will have the prefix pre-pended.
	 */
	String suffix() default "";

	/**
	 * by default all columns are persisted.  In some cases (for example with composite foreign keys)
	 * it is desirable to specify that some columns are not actually persisted.  
	 * 
	 * <p>Take the example where you have 
	 * Company with primary key companyId.  
	 * A Company can have many divisions Division A Division has one Company
	 * Division has the primary key of Company (so by inference companyId) and divisionId. 
	 * A Person will be in a company and optionally will have a division (that division must be in that company).
	 * 
	 * <p>From a DB perspective you can enfore that division is within the company at the DB level.
	 * So assuming we have the Person table with a personId, companyId and divisionId columns. 
	 * Company would be mapped to companyId
	 * Division would be mapped to divisionId
	 * 
	 * <p>So now we get to the crux of this Division and Company are sharing the companyId column.  On
	 * an update who wins?  The answer is use readOnlyColumns() to specify which columns should not be
	 * persisted.
	 * <pre>
	 * class Company {
         *
         *     &#064;Column( key=true )
         *     &#064;NotNull
	 *     public final Property<String> companyId = . . .;
	 *     
	 *     . . . 
	 * 
	 * }
	 * 
	 * 
	 * class Division {
         *
         *     &#064;Column( key=true )
         *     &#064;NotNull
	 *     public final Property<Company> company = . . .;
	 *     
	 *     &#064;Column( key=true )
         *     &#064;NotNull
	 *     public final Property<String> divisionId = . . .;
	 *     
	 *     . . . 
	 * 
	 * }
	 * 
	 * 
	 * class Persion {
	 *     &#064;Column( key=true )
	 *     public final Property<String> personId = . . .;
         * 
         *     &#064;Column( name="companyId" )
         *     &#064;NotNull
	 *     public final Property<Company> company = . . .;
         *
         *     &#064;Column( name="companyId, divisionId", transientColumns="companyId" )
         *     // omitted is the code to make sure that division is in the company
	 *     public final Property<Division> division = . . .;
	 * 
	 *     . . . 
	 * 
	 * }
         * </pre>
	 * 
	 * So when a Person is persisted companyId column is persisted from Company.companyId
	 * divisionId is persisted from  Division and the companyId that is part of Division is 
	 * dropped (so the Object model needs to ensure that on.division.get().company.get() is the same
	 * as Person.company.get()  (a good way to do this is with a validator or a ORM listener depending on whether 
	 * you are coding a UI or middleware) 
	 * 
	 * This is really meant as a tool for supporting legacy DB's elegantly.  If the DB schema is being developed 
	 * alongside the object model use of transient columns is not recommended. 
	 * 
	 */
	String readOnlyColumns() default "";
		
}
