package net.java.dev.properties.binding.swing.adapters;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.MapPropertyListener;
import net.java.dev.properties.MapProperty;

/**
 * This model allows us to bind a mapped property to a table with two columns for
 * the key and the value.
 * 
 * @author Shai Almog
 */
class TableMapAdapterModel extends AbstractTableModel {
    private MapProperty<?, ?> map;
    private boolean lock = false;
    private List<Object> keys = new ArrayList<Object>();
    private String keyLabel;
    private String valueLabel;
    
    public TableMapAdapterModel(MapProperty<?, ?> map, String keyLabel, String valueLabel) {
        this.map = map;
        this.keyLabel = keyLabel;
        this.valueLabel = valueLabel;
        updateKeys();
        BeanContainer.get().addListener(map,new MapPropertyListener() {
            public void propertyInserted(MapProperty prop, Object key, Object value) {
                if(!lock) {
                    lock = true;
                    updateKeys();
                    int index = indexOf(key);
                    fireTableRowsUpdated(index, index);
                    lock = false;
                }                
            }

            public void propertyRemoved(MapProperty prop, Object key) {
                if(!lock) {
                    lock = true;
                    updateKeys();
                    int index = indexOf(key);
                    fireTableRowsDeleted(index, index);
                    lock = false;
                }
            }

            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                // need to think this through...
                /*if(!lock) {
                    lock = true;
                    updateKeys();
                    int index = indexOf(key);
                    fireTableRowsInserted(index, index);
                    lock = false;
                }*/
            }
            
        });
    }

    private int indexOf(Object key) {
        return keys.indexOf(key);
    }
    
    private void updateKeys() {
        keys.clear();
        Iterator<?> iter = map.keyIterator();
        while(iter.hasNext()) {
            keys.add(iter.next());
        }
    }

    /**
     * Uses reflection
     */
    public Object getValueAt(int rowIndex, int columnIndex) {
        // no other choice:
        MapProperty<Object, Object> map = (MapProperty<Object, Object>)this.map;

        Object obj = keys.get(rowIndex);
        if(columnIndex == 1) {
            obj = map.get(obj);
        } 
        return obj;
    }

    public int getRowCount() {
        return map.size();
    }

    public int getColumnCount() {
        return 2;
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    /**
     * Uses reflection
     * @param aValue 
     * @param rowIndex 
     * @param columnIndex 
     */
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        // no other choice:
        MapProperty<Object, Object> map = (MapProperty<Object, Object>)this.map;
        
        Object obj = keys.get(rowIndex);
        if(columnIndex == 1) {
            map.set(obj, aValue);
        } else {
            Object val = map.get(obj);
            map.remove(obj);
            map.set(aValue, val);
        }
    }

    public String getColumnName(int column) {
        if(column == 0) {
            return keyLabel;
        }
        return valueLabel;
    }

    /**
     * Uses reflection
     */
    public Class<?> getColumnClass(int columnIndex) {
        if(columnIndex == 0) {
            return map.getContext().getType();
        }
        return map.getContext().getMapValueType();
    }
}
