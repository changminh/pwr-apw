/*
 * Generator.java
 *
 * Created on February 22, 2007, 8:43 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.generator;

import java.awt.Container;
import java.beans.PropertyChangeListener;
import java.io.*;
import java.lang.reflect.Method;
import java.util.*;
import net.java.dev.properties.*;
import net.java.dev.properties.container.BeanContainer;
import org.cojen.classfile.*;

/**
 * This is the main class for the generator tool, it accepts a directory in
 * which it looks for class objects which it then proceeds to check for 
 * "properties" and instrument appropriately. Multiple directories can
 * be submitted.
 *
 * @author Shai Almog
 */
public class Generator {
    /**
     * Builds the actual listener code called by addListeners)
     */
    private void buildListenerCode(ClassFile file, TypeDesc[] params, String methodName, Method[] methods, Class cls) {
        // generate the equivalent of:
        //     BeanContainer.get().$methodName(this, l);
        // or
        //     BeanContainer.get().$methodName(this, $property,l);
        Method m = findMethod(methods, methodName, params.length);
        
        // if the method is defined within this class then we can't generate anything
        // since it will be a duplicate method with the same name
        if(m != null && m.getDeclaringClass() == cls) {
            return;
        }
        
        MethodInfo method = file.addMethod(Modifiers.PUBLIC, methodName, null, params);
        CodeBuilder builder = new CodeBuilder(method);
        
        // if we derive from java.awt.Container we must invoke the super class version of the
        // add/remove property changes
        if(m != null) {
            builder.loadThis();
            builder.loadLocal(builder.getParameter(0));
            if(params.length == 2) {
                builder.loadLocal(builder.getParameter(1));
            }
            builder.invokeSuper(file.getSuperClassName(), methodName, null, params);
        }
        
        TypeDesc beanContainerType = TypeDesc.forClass(BeanContainer.class);
        builder.invokeStatic(BeanContainer.class.getName(), "get", beanContainerType, null);
        TypeDesc[] beanParams = new TypeDesc[] {TypeDesc.OBJECT, TypeDesc.forClass(PropertyChangeListener.class)};
        builder.loadThis();
        builder.loadLocal(builder.getParameter(0));
        if(params.length == 2) {
            builder.loadLocal(builder.getParameter(1));
        }
        builder.invokeVirtual(BeanContainer.class.getName(), "addPropertyChangeListener", null, beanParams);
        builder.returnVoid();
    }

    /**
     * We don't check the actual parameter type, only that the basic signature is right
     */
    private boolean hasMethod(Method[] methods, String name, int paramCount) {
        for(Method m : methods) {
            if(m.getName().equals(name) && m.getParameterTypes().length == paramCount) {
                return true;
            }
        }
        return false;
    }

    /**
     * We don't check the actual parameter type, only that the basic signature is right
     */
    private Method findMethod(Method[] methods, String name, int paramCount) {
        for(Method m : methods) {
            if(m.getName().equals(name) && m.getParameterTypes().length == paramCount) {
                return m;
            }
        }
        return null;
    }
    
    private void addListeners(ClassFile file, Method[] methods, Class cls) {        
        // generate the equivalent of:
        // public void addPropertyChangeListener(PropertyChangeListener l) {
        //     BeanContainer.get().addPropertyChangeListener(this, l);
        // }        
        TypeDesc[] params = new TypeDesc[]{TypeDesc.forClass(PropertyChangeListener.class)};
        buildListenerCode(file, params, "addPropertyChangeListener", methods, cls);
        
        // generate the equivalent of:
        // public void removePropertyChangeListener(PropertyChangeListener l) {
        //     BeanContainer.get().removePropertyChangeListener(this, l);
        // }
        buildListenerCode(file, params, "removePropertyChangeListener", methods, cls);

        // generate the equivalent of:
        // public void addPropertyChangeListener(String n, PropertyChangeListener l) {
        //     BeanContainer.get().addPropertyChangeListener(this, n, l);
        // }
        params = new TypeDesc[]{TypeDesc.STRING, TypeDesc.forClass(PropertyChangeListener.class)};
        buildListenerCode(file, params, "addPropertyChangeListener", methods, cls);

        // generate the equivalent of:
        // public void removePropertyChangeListener(String n, PropertyChangeListener l) {
        //     BeanContainer.get().removePropertyChangeListener(this, n, l);
        // }    
        buildListenerCode(file, params, "removePropertyChangeListener", methods, cls);
    }
    
    private void addMethods(ClassFile file, FieldInfo[] fields, Method[] methods) {
        for(FieldInfo field : fields) {
            String name = field.getName();
            name = Character.toUpperCase(name.charAt(0)) + name.substring(1);
            
            // right now we ignore the whole "is" for boolean types and don't try
            // to convert fields to primitive types            
            Class fieldClass = field.getType().toClass();
            if(Property.class.isAssignableFrom(fieldClass)) {
                generateGetter(file, field, name, Property.class, methods);
                generateSetter(file, field, name, Property.class, methods);
                continue;
            } 

            if(RProperty.class.isAssignableFrom(fieldClass)) {
                generateGetter(file, field, name, RProperty.class, methods);
                continue;
            } 

            if(WProperty.class.isAssignableFrom(fieldClass)) {
                generateSetter(file, field, name, WProperty.class, methods);
            } 
        }
    }
    
    private void generateGetter(ClassFile file, FieldInfo field, String name, Class interfaceClass, Method[] methods) {
        String getterName = "get" + name;
        if(hasMethod(methods, getterName, 0)) {
            return;
        }
        MethodInfo getterMethod = file.addMethod(Modifiers.PUBLIC, getterName, field.getType(), null);
        CodeBuilder builder = new CodeBuilder(getterMethod);
        builder.loadThis();
        builder.loadField(field.getName(), field.getType());
        builder.invokeInterface(interfaceClass.getName(), "get", field.getType(), null);
        builder.checkCast(field.getType());
        builder.returnValue(field.getType());
    }

    private void generateSetter(ClassFile file, FieldInfo field, String name, Class interfaceClass, Method[] methods) {
        String setterName = "set" + name;
        if(hasMethod(methods, setterName, 1)) {
            return;
        }
        MethodInfo setterMethod = file.addMethod(Modifiers.PUBLIC, setterName, null, new TypeDesc[] {field.getType()});
        CodeBuilder builder = new CodeBuilder(setterMethod);
        builder.loadThis();
        builder.loadField(field.getName(), field.getType());
        builder.loadLocal(builder.getParameter(0));
        builder.invokeInterface(interfaceClass.getName(), "set", null, new TypeDesc[]{field.getType()});
        builder.returnVoid();
    }
        
    public void instrument(File file) throws IOException {
        if(file.isDirectory()) {
            File[] list = file.listFiles(new FileFilter() {
                public boolean accept(File pathname) {
                    return pathname.isDirectory() || pathname.getName().endsWith(".class");
                }
            });
            for(File f : list) {
                instrument(f);
            }
            return;
        }
        
        // instrument the class
        ClassFile classFile = ClassFile.readFrom(new FileInputStream(file));
        Class cls = classFile.getType().toClass();
        Method[] methods = cls.getMethods();
        
        FieldInfo[] fields = extractProperties(classFile.getFields());
        if(fields != null) {
            addListeners(classFile, methods, cls);
            addMethods(classFile, fields, methods);
        }
        classFile.writeTo(new FileOutputStream(file));
    }
    
    /**
     * Goes over the field array, if any of them are properties then this
     * is a new JavaBean and we should build them into an array and return them
     */
    private FieldInfo[] extractProperties(FieldInfo[] fields) {
        List list = new ArrayList();
        for(FieldInfo f : fields) {
            Class c = f.getType().toClass();
            if(c != null && BaseProperty.class.isAssignableFrom(c)) {
                list.add(f);
            }
        }
        if(list.size() == 0) {
            return null;
        }
        FieldInfo[] array = new FieldInfo[list.size()];
        list.toArray(array);
        return array;
    }
    
    public void instrument(String directory) throws IOException  {
        File f = new File(directory);
        if(f.exists()) {
            instrument(f);
        } else {
            printHelp();
        }
    }
    
    private static void printHelp() {
        System.out.println("This tool accepts a directory name containing " +
            "class files to instrument for compatibility with the old java " +
            "beans API");
        System.exit(1);
    }
    
    public static void main(String[] argv) throws Exception {
        //argv = new String[] {"C:\\dev\\java\\projects\\bean-properties\\build\\classes\\net\\java\\dev\\properties\\test\\NewBean.class"};
        if(argv.length == 0) {
            printHelp();
            return;
        }
        Generator g = new Generator();
        for(int iter = 0 ; iter < argv.length ; iter++) {
            g.instrument(argv[iter]);
        }
    }
}
