/*
 * OnGetListener.java
 * 
 * Created on Aug 24, 2007, 3:33:55 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.java.dev.properties.events;


/**
 * The on get listener allows us to "track" calls to the get method in order to
 * implement features such as lazy initialization and ORM relationships. 
 * This is an optional feature that may be implemented by properties, but it is
 * required for any property that needs ORM.
 *
 * @author Shai Almog
 */
public interface OnGetListener {
    /**
     * Invoked before get for a particular property is invoked
     */
    public void setOnGet(OnGet onGet);

}
