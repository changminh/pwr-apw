/*
 * LegacyDelegateProperty.java
 *
 * Created on March 1, 2007, 8:37 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import net.java.dev.properties.container.AbstractObservable;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.container.PropertyContextFactory;

/**
 * Allows a property to delegate work to a legacy JavaBean property
 * via reflection thus allowing the wrapping new bean to selectively expose
 * features of an embedded legacy JavaBean with very little code. The downside
 * is the use of runtime reflection for the invocation and creation of the bean.
 * The property mapped must carry the same name in order for the mapping to
 * be completely transparent.
 *
 * @author Shai Almog
 */
public class LegacyDelegateProperty<T> extends AbstractObservable.ReadWrite<T> implements PropertyContextFactory {
    
    private Object legacyBean;
    
    /**
     * The constructor accepts a pointer to the legacy bean
     */
    public LegacyDelegateProperty(Object legacyBean) {
        this.legacyBean = legacyBean;
    }

    private Method lookup(String prefix, Class[] params) throws NoSuchMethodException {
        String name = getContext().getName();
        name = Character.toUpperCase(name.charAt(0)) + name.substring(1);
        Method m = legacyBean.getClass().getMethod(prefix + name, params);
        return m;
    }
    
    /**
     * @inheritDoc
     */
    public T get() {
        try {
            return (T)((ExtendedPropertyContext)getContext()).
                getter.invoke(legacyBean, (Object[])null);
        } catch(Exception err) {
            throw new LegacyDelegateException(err);
        }
    }

    /**
     * @inheritDoc
     */
    public void set(T t) {
        try {
            // notice that the method never fires the property change event
            // since it will always be fired by the legacy bean...
            ((ExtendedPropertyContext)getContext()).
                setter.invoke(legacyBean, new Object[]{t});
        } catch(Exception err) {
            throw new LegacyDelegateException(err);
        }
    }

    /**
     * @inheritDoc
     */
    public void setContext(PropertyContext context) {
        super.setContext(context);
        try {
            Method listener = legacyBean.getClass().getMethod("addPropertyChangeListener", new Class[] {String.class, PropertyChangeListener.class});
            listener.invoke(legacyBean, new Object[] {
                context.getName(),
                new PropertyChangeListener() {
                    public void propertyChange(PropertyChangeEvent evt) {
                        firePropertyChanged(evt.getOldValue(), evt.getNewValue());
                    }
                }
            });
            
            // if this is the first time then initialize the getter and setter
            ExtendedPropertyContext extended = (ExtendedPropertyContext)context;
            if(extended.getter == null) {
                extended.getter = lookup("get", null);
                extended.setter = lookup("set", new Class[]{extended.type});
            }
        } catch(Exception err) {
            throw new LegacyDelegateException(err);
        }
    }
    
    /**
     * This method will be invoked once to create a property context instance
     */
    public PropertyContext createContext(Field f) {
        return new ExtendedPropertyContext(f);
    }
    
    static final class ExtendedPropertyContext extends PropertyContext {
        transient Class type;
        transient Method getter;
        transient Method setter;
        ExtendedPropertyContext(Field f) {
            type = (Class)((ParameterizedType)f.getGenericType()).getActualTypeArguments()[0];
        }
    }
    
    /**
     * This exception is thrown when a setter/getter method lookup or invocation
     * fails. This prevents the need of a try/catch pair for checked exceptions
     */
    static class LegacyDelegateException extends BeanBindException {
        public LegacyDelegateException(Exception cause) {
            super(cause);
        }
    }
}
