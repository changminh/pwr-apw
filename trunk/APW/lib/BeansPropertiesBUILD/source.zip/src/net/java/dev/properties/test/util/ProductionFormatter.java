package net.java.dev.properties.test.util;


import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.MessageFormat;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;

/**
 * 
 * A JDK logging formatter tht is appropriate for production environments it logs the following
 * 
 *   date and time
 *   thread name
 *   level
 *   logger name
 *   message
 *   throwable (if there is one atached to the message)
 *   
 * 
 * @author Glen Marchesani
 */

public class ProductionFormatter extends Formatter {

	Date dat = new Date();

	private final static String format = "{0,date} {0,time}";

	private MessageFormat formatter;

	private String fieldSeparator = " -- ";
	private String lineSeparator = "\n";

	/**
	 * Format the given LogRecord.
	 * 
	 * @param record
	 *            the log record to be formatted.
	 * @return a formatted log record
	 */
	@Override
	public synchronized String format(LogRecord record) {
		StringBuilder sb = new StringBuilder();
		
		// Minimize memory allocations here.
		dat.setTime(record.getMillis());
		
		StringBuffer text = new StringBuffer();
		if (formatter == null) {
			formatter = new MessageFormat(format);
		}
		
		// DATE and TIME
		formatter.format(new Object[] { dat }, text, null);
		sb.append(text);

		// THREAD NAME
		sb.append(fieldSeparator);
		sb.append(Thread.currentThread().getName());		
		
		// LEVEL
		String level = record.getLevel().getLocalizedName();
		sb.append(fieldSeparator);
		sb.append(level);

		// LOGGER NAME
		sb.append(fieldSeparator);
		String loggerName = record.getLoggerName();
		if ( loggerName.startsWith( "gov.sensornet.isp" ) ) {
			loggerName = loggerName.substring( "gov.sensornet.isp".length() );
		}
		sb.append( loggerName );
		sb.append(fieldSeparator);
		
		// MESSAGE
		String message = formatMessage(record);
		sb.append(message);
		sb.append(lineSeparator);
		if (record.getThrown() != null) {
			try {
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				pw.print( "   " );
				record.getThrown().printStackTrace(pw);
				pw.close();
				sb.append(sw.toString());
			} catch (Exception ex) {
			}
		}
		return sb.toString();
	}
}
