/*
 * SwingBind.java
 *
 * Created on March 2, 2007, 1:50 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import net.java.dev.properties.binding.swing.adapters.impl.TextComponentFormatAdapter;
import net.java.dev.properties.binding.swing.adapters.impl.ListItemAdapter;
import java.awt.Color;
import java.awt.Component;
import java.text.Format;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.Action;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JToggleButton;
import javax.swing.JTree;
import javax.swing.text.JTextComponent;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.binding.BindManager;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.events.PropertyListener;
import net.java.dev.properties.MapProperty;

/**
 * A singleton allowing Swing developers to bind components and create models
 * that match beans and bean properties.
 *
 * @author Shai Almog
 */
public class SwingBind extends BindManager<JComponent> {
    private static SwingBind instance;
    private List<SwingAdapter> adapters = new ArrayList<SwingAdapter>(Arrays.asList(new SwingAdapter[]{
        new ColorChooserAdapter(),
        new ComboBoxIndexAdapter(),
        new ComboBoxItemAdapter(),
        new LabelAdapter(),
        new ListIndexAdapter(),
        new ListIndicesAdapter(),
        new ListItemAdapter(),
        new SpinnerAdapter(),
        new TableIndexAdapter(),
        new ToggleButtonAdapter(),
        new TextComponentAdapter(),
        new TextComponentFormatAdapter()
    }));
    
    /** Creates a new instance of SwingBind */
    protected SwingBind() {
    }
    
    protected void addAdapter(SwingAdapter a) {
        adapters.add(0, a);
    }
    
    /**
     * Binds a generic component, this method isn't nearly as efficient or "safe"
     * as the standard methods and so it is used mostly for dynamic UI construction
     * rather than as the default type safe methods
     * @param property 
     * @param selection 
     * @param cmp 
     */
    public void bindGeneric(BaseProperty property, BaseProperty selection, JComponent cmp) {
        if(property instanceof IndexedProperty) {
            if(cmp instanceof JList) {
                bindContent((IndexedProperty)property, (JList)cmp);
                if(selection != null) {
                    bindSelectionIndices((IndexedProperty<Integer>)selection, (JList)cmp);
                }
                return;
            } 
              
            if(cmp instanceof JComboBox) {
                bindContent((IndexedProperty)property, (JComboBox)cmp);
                if(selection != null) {
                    bindItem((BaseProperty<Object>)selection, (JComboBox)cmp);
                }
                return;
            } 
            
            if(cmp instanceof JTable) {
                bindContent((IndexedProperty)property, property.getContext().getType(), (JTable)cmp);
                return;
            }
        } else {
            for(SwingAdapter adapter : adapters) {
                if(adapter.canHandle(property, cmp)) {
                    adapter.createBoundInstance(property, cmp);
                    return;
                }
            }
        }
        throw new BeanBindException("Couldn't bind the property: " + property + " to the component " + cmp.getClass().getName());
    }
    
    /**
     * Allows a sublcass to override the Swing binding, specifically designed for SwingX
     * but theoretically can be used for any custom build binding
     */
    protected static void set(SwingBind bind) {
        instance = bind;
    }
    
    public static SwingBind get() {
        if(instance == null) {
            instance = new SwingBind();
        }
        return instance;
    }

    public void bind(BaseProperty<Boolean> property, JToggleButton button) {
        new ToggleButtonAdapter().bind(property, button);
    }

    public void bind(BaseProperty<Color> property, JColorChooser cmp) {
        new ColorChooserAdapter().bind(property, cmp);
    }
    
    public void bindItem(BaseProperty<?> property, JComboBox cmp) {
        new ComboBoxItemAdapter().bind((BaseProperty<Object>)property, cmp);
    }

    public void bindIndex(BaseProperty<Integer> property, JComboBox cmp) {
        new ComboBoxIndexAdapter().bind(property, cmp);
    }

    public void bind(BaseProperty<String> property, JTextComponent cmp) {
        new TextComponentAdapter().bind(property, cmp);
    }

    public void bind(BaseProperty property, JTextComponent cmp, Format format) {
        TextComponentFormatAdapter a = new TextComponentFormatAdapter();
        a.format.set(format);
        a.bind((BaseProperty<Object>)property, cmp);
    }

    public void bind(BaseProperty property, JTextComponent cmp, Format format, JLabel label) {
        bind(property, cmp, format);
        bindLabel(property, label, cmp);
    }

    public void bindItem(BaseProperty<Object> property, JComboBox cmp, JLabel label) {
        bindItem(property, cmp);
        bindLabel(property, label, cmp);
    }

    public void bindIndex(BaseProperty<Integer> property, JComboBox cmp, JLabel label) {
        bindIndex(property, cmp);
        bindLabel(property, label, cmp);
    }

    public void bind(BaseProperty<String> property, JTextComponent cmp, JLabel label) {
        bind(property, cmp);
        bindLabel(property, label, cmp);
    }
    
    public void bind(BaseProperty<String> property, JLabel cmp) {
        new LabelAdapter().bind(property, cmp);
    }

    public void bind(BaseProperty<?> property, JSpinner cmp) {
        new SpinnerAdapter().bind((BaseProperty<Object>)property, cmp);
    }

    public void bind(BaseProperty<Integer> property, JSlider cmp) {
        new SliderAdapter().bind(property, cmp);
    }

    /**
     * A one way bind that assigns to the label the value of the display property
     * for the given property.
     */
    public void bindLabel(BaseProperty<?> property, JLabel cmp) {
        bindLabel(property.getContext(), cmp);
    }

    /**
     * A one way bind that assigns to the label the value of the display property
     * for the given property.
     */
    public void bindLabel(PropertyContext property, JLabel cmp) {
        cmp.setText(property.getDisplayName());
    }

    /**
     * A one way bind that assigns to the label the value of the display property
     * for the given property.
     */
    public void bindLabel(BaseProperty property, JLabel cmp, JComponent c) {
        bindLabel(property.getContext(), cmp, c);
    }

    /**
     * A one way bind that assigns to the label the value of the display property
     * for the given property.
     */
    public void bindLabel(PropertyContext property, JLabel cmp, JComponent c) {
        cmp.setText(property.getDisplayName());
        cmp.setLabelFor(c);
    }

    public void bindSelectionIndex(BaseProperty<Integer> property, JList cmp) {
        new ListIndexAdapter().bind(property, cmp);
    }
    
    public void bindSelectionItem(BaseProperty<?> property, JList cmp, boolean shouldScroll) {
        ListItemAdapter a = new ListItemAdapter();
        a.shouldScroll.set(true);
        a.bind((BaseProperty<Object>)property, cmp);
    }

    public void bindSelectionItems(IndexedProperty<?> property, JList cmp) {
        new ListItemsAdapter().bind((IndexedProperty<Object>)property, cmp);
    }

    public void bindSelectionIndices(IndexedProperty<Integer> property, JList cmp) {
        new ListIndicesAdapter().bind(property, cmp);
    }

    public void bindSelectionIndex(BaseProperty<Integer> property, JList cmp, JLabel label) {
        bindSelectionIndex(property, cmp);
        bindLabel(property, label, cmp);
    }

    public void bindSelectionItem(BaseProperty<?> property, JList cmp, boolean shouldScroll, JLabel label) {
        bindSelectionItem(property, cmp, shouldScroll);
        bindLabel((BaseProperty<Object>)property, label, cmp);
    }

    public void bindSelectionIndices(IndexedProperty<Integer> property, JList cmp, JLabel label) {
        bindSelectionIndices(property, cmp);
        bindLabel(property, label, cmp);
    }

    /**
     * This method will install the ComboAndListModel on cmp
     */
    public void bindContent(IndexedProperty<?> property, JList cmp, JLabel label) {
        bindContent(property, cmp);
        bindLabel(property, label, cmp);
    }

    public void bindSelectionItems(IndexedProperty<?> property, JTree cmp) {
        new TreeItemsAdapter().bind((IndexedProperty<Object>)property, cmp);
    }

    public void bindSelectionItem(BaseProperty<?> property, JTree cmp) {
        new TreeItemAdapter().bind((BaseProperty<Object>)property, cmp);
    }

    public void bindSelectionItems(IndexedProperty<?> property, JTree cmp, JLabel label) {
        bindSelectionItems(property, cmp);
        bindLabel(property, label, cmp);
    }

    public void bindSelectionItem(BaseProperty<?> property, JTree cmp, JLabel label) {
        bindSelectionItem(property, cmp);
        bindLabel(property, label, cmp);
    }
    
    /**
     * This method will install the ComboAndListModel on cmp
     */
    public void bindContent(IndexedProperty<?> property, JComboBox cmp, JLabel label) {
        bindContent(property, cmp);
        bindLabel(property, label, cmp);
    }

    /**
     * This method will install the ComboAndListModel on cmp.
     * An additional null value will appear in the list (but won't exist in the property).
     */
    public void bindContentAddNull(IndexedProperty<?> property, JComboBox cmp, JLabel label) {
        bindContentAddNull(property, cmp);
        bindLabel(property, label, cmp);
    }
    
    
    public void bindContent(Object root, PropertyContext[] children, JTree cmp) {
        cmp.setModel(new TreeAdapterModel(root, children, null));
    }

    public void bindContent(Object root, PropertyContext[] children, PropertyContext leafProperty, JTree cmp) {
        cmp.setModel(new TreeAdapterModel(root, children, leafProperty));
    }

    public void bindContentNoLeaf(Object root, PropertyContext[] children, JTree cmp) {
        TreeAdapterModel m = new TreeAdapterModel(root, children, null);
        m.setAutomateLeafDetection(false);
        cmp.setModel(m);
    }

    /**
     * This method will install the ComboAndListModel on cmp
     */
    public void bindContent(IndexedProperty<?> property, JList cmp) {
        cmp.putClientProperty("Property", property);
        cmp.setModel(new ComboAndListModel(property));
    }
    
    /**
     * This method will install the ComboAndListModel on cmp
     */
    public void bindContent(IndexedProperty<?> property, JComboBox cmp) {
        cmp.putClientProperty("Property", property);
        cmp.setModel(new ComboAndListModel(property));
    }

    /**
     * This method will install the ComboAndListModel on cmp.
     * An additional null value will appear in the list (but won't exist in the property).
     */
    public void bindContentAddNull(IndexedProperty<?> property, JComboBox cmp) {
        cmp.putClientProperty("Property", property);
        cmp.setModel(new ComboAndListModel(property, true));
    }

    /**
     * This method will install the TableModel on cmp
     */
    public void bindContent(IndexedProperty<?> beans, PropertyContext[] columns, JTable cmp) {
        cmp.putClientProperty("Property", beans);
        cmp.setModel(new TableAdapterModel(beans, columns));
    }

    /**
     * This method will install the TableModel on cmp
     */
    public void bindContent(IndexedProperty<?> beans, JTable cmp, PropertyContext... columns) {
        bindContent(beans, columns, cmp);
    }

    /**
     * This method will install the TableModel on cmp, it extracts the context from all the properties 
     * as a shorthand for the version that accepts property context
     */
    public void bindContent(IndexedProperty<?> beans, JTable cmp, BaseProperty<?>... columns) {
        PropertyContext[] arr = new PropertyContext[columns.length];
        for(int iter = 0 ; iter < arr.length ; iter++) {
            arr[iter] = columns[iter].getContext();
        }
        bindContent(beans, arr, cmp);
    }

    /**
     * This method will install the TableModel on cmp
     */
    public void bindContent(IndexedProperty<?> beans, BeanContext bean, JTable cmp) {
        bindContent(beans, bean.getPropertiesArray(), cmp);
    }

    /**
     * This method will install the TableModel on cmp
     */
    public void bindContent(IndexedProperty<?> beans, Class bean, JTable cmp) {
        bindContent(beans, BeanContainer.get().getContext(bean).getPropertiesArray(), cmp);
    }

    public void bindContent(MapProperty<?, ?> map, JTable cmp, String keyColumnLabel, String valueColumnLabel) {
        cmp.putClientProperty("Property", map);
        cmp.setModel(new TableMapAdapterModel(map, keyColumnLabel, valueColumnLabel));
    }
    
    public void bindSelectionIndex(BaseProperty<Integer> property, JTable cmp) {
        new TableIndexAdapter().bind(property, cmp);
    }

    public void bindSelectionIndices(IndexedProperty<Integer> property, JTable cmp) {
        new TableIndicesAdapter().bind(property, cmp);
    }

    public void bindSelectionItem(BaseProperty<?> property, JTable cmp, int column) {
        new TableItemAdapter(column).bind((BaseProperty<Object>)property, cmp);
    }
    
    public void bindSelectionItem(BaseProperty<?> property, JTable cmp, PropertyContext pc) {
        int column = ((TableAdapterModel)cmp.getModel()).getColumn(pc);
        new TableItemAdapter(column).bind((BaseProperty<Object>)property, cmp);
    }
    
    /**
     * Binds the enabled state of a component to a property
     */
    public void bindEnabled(BaseProperty<Boolean> property, JComponent enabled) {
        new EnabledAdapter().bind(property, enabled);
    }

    /**
     * Binds the enabled state of an action to a property
     */
    public void bindEnabled(BaseProperty<Boolean> property, final Action enabled) {
        enabled.setEnabled(((RProperty<Boolean>)property).get());
        BeanContainer.get().addListener(property, new PropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                enabled.setEnabled(((RProperty<Boolean>)prop).get());
            }
        });
    }
    
    /**
     * This method is purely optional, binding a new value to a component will automatically unbind
     * and a GC will not be blocked by bound components if both the UI and beans are no longer used.
     * This method is here for completeness and for some edge cases where manual unbinding is necessary.
     */
    public void unbind(JComponent cmp) {
        SwingAdapter.unbindComponent(cmp);
    }
    
    /**
     * Searches within the tree for the component bound to the given property
     */
    public JComponent findComponent(JComponent root, BaseProperty property) {
        if(root.getClientProperty("Property") == property) {
            return root;
        }
        for(Component c : root.getComponents()) {
            if(c instanceof JComponent) {
                JComponent cmp = findComponent((JComponent)c, property);
                if(cmp != null) {
                    return cmp;
                }
            }
        }
        return null;
    }
}
