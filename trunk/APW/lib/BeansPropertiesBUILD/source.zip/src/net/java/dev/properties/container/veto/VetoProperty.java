/*
 * VetoProperty.java
 *
 * Created on April 23, 2007, 11:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.container.veto;

import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.container.ObservableDelegate;
import net.java.dev.properties.container.VetoInterface;
import net.java.dev.properties.events.VetoListener;

/**
 * A simple non-observable property that supports vetoing
 *
 * @author Shai Almog
 */
public class VetoProperty<T> extends PropertyImpl<T> implements VetoInterface {
    
    private ObservableDelegate<VetoListener> veto;
    
    public VetoProperty() {
    }
    
    public VetoProperty(T t) {
        super(t);
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> VetoProperty<K> create() {
        return new VetoProperty<K>();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> VetoProperty<K> create(K k) {
        return new VetoProperty<K>(k);
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void set(T t) {
        if(!getContext().onVetoCheck(this, get(), t, -1)) {
            return;
        }
        super.set(t);
    }

    /**
     * @inheritDoc
     */
    @Override
    public ObservableDelegate<VetoListener> getVetoDelegate() {
        if(veto == null) {
            veto = new ObservableDelegate<VetoListener>();
        }
        return veto;
    }
}
