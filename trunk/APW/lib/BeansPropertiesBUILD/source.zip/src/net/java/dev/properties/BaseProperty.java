/*
 * Property.java
 *
 * Created on February 21, 2007, 1:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import net.java.dev.properties.container.PropertyContext;

/**
 * Base interface for all properties that doesn't include any information about
 * setting or getting the property. This interface exposes the container contract
 * that allows a property to be "bootstrapped", normally methods from this interface
 * shouldn't be invoked by developers and should only be invoked by the container.
 *
 * @author Shai Almog
 */
public interface BaseProperty<T> extends java.io.Serializable {
    /**
     * Returns the context object for the property, the context object allows us
     * to inquire regarding the meta-data of this property.
     */
    public PropertyContext getContext();
    
    /**
     * The context is set by the binding process in the container and should
     * not be manually modified for most cases.
     */    
    public void setContext(PropertyContext context);

    /**
     * The bean in which this property instance resides, this should not be
     * mutated at runtime for normal use cases however that is possible
     * in some use cases.
     */
    public Object getParent();

    /**
     * Invoked automatically by the container to indicate the parent bean
     * upon the binding process.
     */
    public void setParent(Object parent);
}
