/*
 * BindingDemoBean.java
 *
 * Created on March 2, 2007, 7:39 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.binding;

import java.awt.Color;
import net.java.dev.properties.*;
import net.java.dev.properties.annotations.Attributes;
import net.java.dev.properties.annotations.Bean;
import net.java.dev.properties.container.*;
import net.java.dev.properties.events.IndexedPropertyListener;
import net.java.dev.properties.events.PropertyListener;

/**
 * This is the data model representing the binding of the demo GUI
 *
 * @author Shai Almog
 */
public class BindingDemoBean {
    public final Property<Boolean> check1 = ObservableProperty.create();
    public final Property<Boolean> check2 = ObservableProperty.create();
    public final Property<Boolean> check3 = ObservableProperty.create();
    public final Property<Boolean> radio1 = ObservableProperty.create();
    public final Property<Boolean> radio2 = ObservableProperty.create();
    public final Property<Boolean> radio3 = ObservableProperty.create();
    public final Property<String> text = ObservableProperty.create();
    public final Property<Color> colors = ObservableProperty.create();
    public final Property<String> moreText = ObservableProperty.create();
    public final IndexedProperty<Integer> listSelection = ObservableIndexed.create();
    public final IndexedProperty<String> listContent = ObservableIndexed.create("Item 1", "Item 2", "Item 3", "Item 4");
    public final IndexedProperty<Integer> comboContent = ObservableIndexed.create(1, 3, 5, 7, 11, 13);
    public final Property<Integer> comboSelectionIndex = ObservableProperty.create();
    public final IndexedProperty<TableData> table = ObservableIndexed.create();
    
    
    /** Creates a new instance of BindingDemoBean */
    public BindingDemoBean() {
        BeanContainer.bind(this);
        TableData t = new TableData();
        t.check.set(true);
        t.text.set("AAA");
        t.number.set(15);
        t.decimal.set(33.33);
        table.add(t);
        BeanContainer.get().addListener(this, new IndexedPropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                System.out.println(prop);
            }

            public void propertyRemoved(IndexedProperty prop, Object value, int index) {
                System.out.println(prop + " removed at " + index);
            }

            public void propertyInserted(IndexedProperty prop, Object value, int index) {
                System.out.println(prop + " inserted at " + index);
            }
        });
    }

    @Bean(resourceBundle="net.java.dev.properties.test.binding.Resources")
    public static class TableData {
        @Attributes(displayNameL="CheckboxKey")
        public final Property<Boolean> check = new ObservableProperty<Boolean>();

        @Attributes(displayName="Text")
        public final Property<String> text = new ObservableProperty<String>();
        public final Property<Integer> number = new ObservableProperty<Integer>();
        public final Property<Double> decimal = new ObservableProperty<Double>();
        
        public TableData() {
            BeanContainer.bind(this);
            BeanContainer.get().addListener(this, new PropertyListener() {
                public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                    System.out.println("Table value changed: " + prop);
                }
            });
        }
    }
}
