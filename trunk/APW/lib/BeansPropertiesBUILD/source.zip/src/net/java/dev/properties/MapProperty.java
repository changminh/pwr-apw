package net.java.dev.properties;

import java.util.Iterator;
import java.util.Map;

/**
 * Allows access to a property as a hashtable of elements, this
 * interface is more restricted than the java.util.Map interface yet allows
 * features not enabled in the Collection interface. The main reason for this
 * duplication (rather than exposing java.util.Map) is property change support.
 * <p>Notice that MapProperty derives from Property rather than BaseProperty,
 * this simplifies and enables many use cases (such as using set that accepts a map)
 * however the use of the set(Map) or Map get() methods is discoraged. These methods
 * will not have the behavior you might expect since they return an unmodifiable map
 * or copy the entire content of the submitted map to avoid "issues".
 *
 * @param K Key type
 * @param T Value type
 * @author Shai Almog
 */
public interface MapProperty<K, T> extends BaseProperty<Map<K, T>> {
    /**
     * Returns the value mapped to the given key
     */
    public T get(K key);

    /**
     * Maps the submitted key to the appropriate value
     */
    public void set(K key, T t);
    
    /**
     * Returns an iterator for the keys that does not enable removal
     * @return Iterator for the keys
     */
    public Iterator<K> keyIterator();

    /**
     * Removes the key and the value associated with key
     */
    public void remove(K key);
    
    /**
     * Returns the amount of keys in the map
     */
    public int size();
}
