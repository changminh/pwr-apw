/*
 * Property.java
 *
 * Created on February 20, 2007, 9:57 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

/**
 * A read/write property interface, this is what most standard properties should
 * implement in order to allow a property to be modified and read.
 *
 * @author Shai Almog
 */
public interface Property<T> extends WProperty<T>, RProperty<T> {
}
