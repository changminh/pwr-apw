/*
 * Adapter.java
 *
 * Created on March 2, 2007, 1:22 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding;

import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.WProperty;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.PropertyListener;

/**
 * The adapter class is an abstract notion of how to connect a property to the
 * GUI view
 *
 * @author Shai Almog
 */
public abstract class Adapter<T, V> implements PropertyListener {
    private V component;
    private boolean lock = false;
    private BaseProperty<T> property;

    /** 
     * This is a special version of the constructor that bypasses the initialization
     * of the component (from a value within the field) so subclasses that need additional
     * before the updateUI method occurs can do that before invoking the init() method.
     */
    protected Adapter() {
    }
    
    /**
     * Binds this adapter appropriately
     */
    public void bind(BaseProperty<T> property, V component) {
        unbind(component);
        this.component = component;
        this.property = property;
        BeanContainer.get().addListener(property, this);
        initFromProperty(property);
        bindUI(property, component);
    }

    /**
     * Unbinds this component from any previous bindings it might have
     */
    public void unbind(V component) {
        Adapter<T, V> a = getBoundAdapter(component);
        if(a != null) {
            a.unbind();
        }
        a = getBoundSelectionAdapter(component);
        if(a != null) {
            a.unbind();
        }
    }

    /**
     * Unbinds this adapter from any previous bindings it might have
     */
    private void unbind() {
        BeanContainer.get().removeListener(property, this);
        unbindUI(property, component);
    }
    
    protected abstract Adapter<T, V> getBoundAdapter(V component);

    protected abstract Adapter<T, V> getBoundSelectionAdapter(V component);
    
    /**
     * Returns true if this instance of the adapter class can potentially handle
     * this pair of component/property
     */
    public boolean canHandle(BaseProperty property, V component) {
        return getType().isAssignableFrom(property.getContext().getType()) && 
            getComponentType().isAssignableFrom(component.getClass());
    }
    
    /**
     * Returns the class of the property within this adapter
     */
    protected abstract Class getType();

    /**
     * Returns the class of the component within this adapter
     */
    protected abstract Class getComponentType();
    
    /**
     * Creates a new instance of this class and binds it appropriately
     */
    public void createBoundInstance(BaseProperty property, V component) {
        try {
            Adapter<T,V> newInstance = (Adapter<T, V>)getClass().newInstance();
            newInstance.bind((BaseProperty<T>)property, component);
        } catch(Exception err) {
            throw new BeanBindException(err);
        }
    }
    
    /**
     * Binds the listeners in the subclass appropriately
     */
    protected abstract void bindUI(BaseProperty<T> property, V component);

    /**
     * Unbinds the listeners in the subclass appropriately
     */
    protected abstract void unbindUI(BaseProperty<T> property, V component);
    
    protected void initFromProperty(BaseProperty<T> property) {
        // initialize the component to the initial value of the property assuming
        // it is not null.
        if(property instanceof RProperty) {
            T value = ((RProperty<T>)property).get();
            if(value != null) {
                updateUI(value);
            } else {
                setEmptyValue();
            }
        }
    }
    
    /**
     * Invoked when the value is null
     */
    protected void setEmptyValue() {
        updateUI(null);
    }

    public final void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        if(!obtain()) return;
        updateUI((T)newValue);
        release();
    }
    
    /**
     * This method must be implemented by the adapter to update the UI widget
     */
    protected abstract void updateUI(T newValue);

    /**
     * This method must be invoked by the UI when the data in the widget changes
     */
    public final void callWhenUIChanged(T newValue) {
        if(!obtain()) return;
        if(property instanceof WProperty) {
            ((WProperty)property).set(newValue);
        }
        release();
    }

    /**
     * Obtain the lock object that would just ignore future calls, if the lock
     * is taken it would return false.
     */
    public boolean obtain() {
        if(!lock) {
            lock = true;
            return true;
        }
        return false;
    }

    /**
     * Release the lock
     */
    public void release() {
        lock = false;
    }
    
    protected V getComponent() {
        return component;
    }
    
    protected BaseProperty<T> getProperty() {
        return property;
    }

    protected void setComponent(V component) {
        this.component = component;
    }

    protected void setProperty(BaseProperty<T> property) {
        this.property = property;
    }
}
