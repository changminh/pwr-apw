/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JLabel;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements UI update for the JLabel
 *
 * @author Shai Almog
 */
class LabelAdapter extends SwingAdapter<String, JLabel> implements PropertyChangeListener {
    protected void bindListener(BaseProperty<String> property, JLabel cmp) {
        cmp.addPropertyChangeListener("text", this);
    }

    protected void unbindListener(BaseProperty<String> property, JLabel cmp) {
        cmp.removePropertyChangeListener("text", this);
    }

    protected void updateUI(String newValue) {
        getComponent().setText(newValue);
    }            

    public void propertyChange(PropertyChangeEvent evt) {
        callWhenUIChanged(getComponent().getText());
    }

    protected Class getType() {
        return String.class;
    }

    protected Class getComponentType() {
        return JLabel.class;
    }
}