/*
 * OnGet.java
 * 
 * Created on Aug 17, 2007, 5:29:33 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.java.dev.properties.events;

import net.java.dev.properties.RProperty;

/**
 * A callback interface that can be bound to observable properties indicating
 * that a get operation is in progress. This interface is useful for lazy initialization
 * of said property and is used by the ORM implementation. There can be only one
 * OnGet instance installed per property.
 * 
 * @author Shai Almog
 */
public interface OnGet {
    /**
     * Invoked whenever the get method of p is invoked
     */
    public void onGet(RProperty<?> p);
}
