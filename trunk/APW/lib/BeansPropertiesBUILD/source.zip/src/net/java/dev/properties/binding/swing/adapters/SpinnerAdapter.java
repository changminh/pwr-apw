/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.math.BigDecimal;
import java.util.Date;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.binding.Adapter;
import net.java.dev.properties.util.Utils;

/**
 * Implements spinner support for the state change/ui
 *
 * @author Shai Almog
 */
class SpinnerAdapter extends SwingAdapter<Object, JSpinner> implements ChangeListener {
    protected void bindListener(BaseProperty<Object> property, JSpinner cmp) {
        cmp.addChangeListener(this);
    }

    protected void unbindListener(BaseProperty<Object> property, JSpinner component) {
        component.removeChangeListener(this);
    }

    protected void updateUI(Object newValue) {
        if(newValue != null) {
            getComponent().setValue(newValue);
        } else {
            Class type = getProperty().getContext().getType();
            if(type.isAssignableFrom(Date.class)) {
                getComponent().setValue(new Date());
                return;
            }
            if(type.isAssignableFrom(Number.class)) {
                getComponent().setValue(Utils.createZero(type));
                return;
            }
        }
    }            

    public void stateChanged(ChangeEvent e) {
        Object val = getComponent().getValue();
        Class type = getProperty().getContext().getType();
        if(Number.class.isAssignableFrom(type)) {
            callWhenUIChanged(Utils.normalizeType((Number)val, type));
        } else {
            callWhenUIChanged(val);
        }
    }    

    protected Class getType() {
        return Object.class;
    }

    protected Class getComponentType() {
        return JSpinner.class;
    }
}