package net.java.dev.properties.container.thread;

import java.util.List;
import java.util.ArrayList;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.IndexedPropertyImpl;
import net.java.dev.properties.container.BeanContainer;

/**
 * This is a thread manager that creates a new thread into which it dispatches
 * the events as necessary. In order to use this dispatcher just add a listener
 * class into an instance of SimpleThreadManager.managedListeners
 *
 * @author Shai Almog
 */
public class SimpleThreadManager extends ThreadManager {
    /**
     * Add all the listener Classes that should be dispatched on this thread into
     * this property
     */
    public static final IndexedProperty<Class> managedListeners = IndexedPropertyImpl.create();
    private boolean stopThread;
    private Thread thread;
    private List<Runnable> queue = new ArrayList<Runnable>();
    
    public SimpleThreadManager() {
        BeanContainer.bind(this);
        
        // hides the run method from subclasses
        thread = new Thread() {
            public void run() {
                synchronized(this) {
                    while(!stopThread) {
                        try {
                            wait();
                        } catch(InterruptedException ignore) {}
                        for(Runnable r : queue) {
                            r.run();
                        }
                        queue.clear();
                        notifyAll();
                    }
                }
            }
        };
        thread.start();
        ThreadManager.managers.add(this);
    }
    
    /**
     * Kills the thread manager and makes it invalid, no events would be dispatched
     * from this manager any more.
     */
    public void stopThread() {
        synchronized(thread) {
            stopThread = true;
            thread.notifyAll();
        }
    }

    /**
     * This method should be overriden to indicate if this manager should be used for 
     * a particular listener instance. 
     */
    protected boolean isRightManager(Object listener) {
        Class currentClass = listener.getClass();
        for(Class c : managedListeners) {
            if(c == currentClass) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Invokes r on the thread represented by this manager and waits on the current thread for r to complete.
     * If the current thread is already the destination (isRightThread() returns true) the behavior of this
     * method is undefined and it might fail/block forever.
     */
    public void invokeAndWait(Runnable r) {
        try {
            synchronized(thread) {
                queue.add(r);
                thread.notifyAll();
                while(queue.contains(r)) {
                    thread.wait();
                }
            }
        } catch(InterruptedException i) {
            // not much to do
            i.printStackTrace();
            return;
        }
    }
    
    /**
     * Returns true if the current thread is the "right thread" for this type of 
     * dispatch
     */
    public boolean isRightThread() {
        return Thread.currentThread() == thread;
    }    
}
