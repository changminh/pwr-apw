/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.util.Arrays;
import java.util.List;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;

/**
 * Implements list support for propagating UI changes
 *
 * @author Shai Almog
 */
class ListItemsAdapter extends SwingAdapter<List<Object>, JList> implements ListSelectionListener {
    protected void bindListener(BaseProperty<List<Object>> property, JList cmp) {
        cmp.addListSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<List<Object>> property, JList cmp) {
        cmp.removeListSelectionListener(this);
    }

    private int getOffset(Object o) {
        IndexedProperty<Object> p = (IndexedProperty<Object>)getProperty();
        for(int iter = 0 ; iter < p.size() ; iter++) {
            if(p.get(iter).equals(o)) {
                return iter;
            }
        }
        return -1;
    }
    
    protected void updateUI(List<Object> newValue) {
        int[] array = new int[newValue.size()];
        for(int iter = 0 ; iter < array.length ; iter++) {
            array[iter] = getOffset(newValue.get(iter));
        }
        getComponent().setSelectedIndices(array);
    }            

    public void valueChanged(ListSelectionEvent e) {
        callWhenUIChanged(Arrays.asList(getComponent().getSelectedValues()));
    }

    protected Class getType() {
        return List.class;
    }

    protected Class getComponentType() {
        return JList.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}