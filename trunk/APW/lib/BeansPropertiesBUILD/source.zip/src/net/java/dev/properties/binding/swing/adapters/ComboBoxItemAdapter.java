/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JComboBox;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements combo box support for propagating UI changes
 *
 * @author Shai Almog
 */
class ComboBoxItemAdapter extends SwingAdapter<Object, JComboBox> implements ItemListener {
    protected void bindListener(BaseProperty<Object> property, JComboBox cmp) {
        cmp.addItemListener(this);
    }

    protected void unbindListener(BaseProperty<Object> property, JComboBox cmp) {
        cmp.removeItemListener(this);
    }

    protected void updateUI(Object newValue) {
        getComponent().setSelectedItem(newValue);
    }            

    public void itemStateChanged(ItemEvent e) {
        callWhenUIChanged(getComponent().getSelectedItem());
    }

    protected Class getType() {
        return Object.class;
    }

    protected Class getComponentType() {
        return JComboBox.class;
    }
}