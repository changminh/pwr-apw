/*
 * ComboAndListModel.java
 *
 * Created on March 3, 2007, 4:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.events.IndexedPropertyListener;

/**
 * Model installed to bound combo boxes and lists, it is
 * only necessary to have this model installed if the data for the combo or list
 * is bound. If the data is hardcoded in the application then this model is
 * unnecessary.
 * <p>When binding the combo or list this model will be installed automatically
 * overriding any existing model so technically a user doesn't need to be aware
 * of its existence. It is however exposed via the API to allow some manual 
 * manipulation.
 *
 * @author Shai Almog
 */
public class ComboAndListModel<T> extends AbstractListModel implements ComboBoxModel {
    private Object selection;
    private IndexedProperty<T> prop;
    private boolean forceNull;
    
    public ComboAndListModel(IndexedProperty<T> prop) {
        this(prop, false);
    }

    /**
     * The second argument will add a null value at the beginning of the list/combo
     * allowing the user to pick a null option (this won't modify prop).
     */
    public ComboAndListModel(IndexedProperty<T> prop, boolean forceNull) {
        this.prop = prop;
        this.forceNull = forceNull;
        BeanContainer.get().addListener(prop, new IndexedPropertyListener() {
            public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
                fireContentsChanged(ComboAndListModel.this, index, index);
            }
            public void propertyInserted(IndexedProperty prop, Object value, int index) {
                fireIntervalAdded(ComboAndListModel.this, index, index);
            }
            public void propertyRemoved(IndexedProperty prop, Object value, int index) {
                fireIntervalRemoved(ComboAndListModel.this, index, index);
            }
        });
    }

    public int getSize() {
        if(forceNull) {
            return prop.size() + 1;
        }
        return prop.size();
    }

    public Object getSelectedItem() {
        return selection;
    }

    public void setSelectedItem(Object anItem) {
        this.selection = anItem;
    }

    public Object getElementAt(int index) {
        if(forceNull) {
            if(index == 0) {
                return null;
            }
            return prop.get(index - 1);
        }
        return prop.get(index);
    }
    

    public IndexedProperty<T> getProperty() {
        return prop;
    }
}
