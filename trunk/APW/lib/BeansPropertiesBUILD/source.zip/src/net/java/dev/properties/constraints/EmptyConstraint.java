package net.java.dev.properties.constraints;

import net.java.dev.properties.BaseProperty;

/**
 * Indicates that no constraint should be used in the validation attribute, this
 * class is only useful for the Validation annotation purposes
 *
 * @author Shai Almog
 */
public class EmptyConstraint implements Constraint {
    public boolean validate(BaseProperty prop, Object value) {
        return true;
    }
}
