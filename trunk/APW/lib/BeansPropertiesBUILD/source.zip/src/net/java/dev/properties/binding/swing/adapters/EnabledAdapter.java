/*
 * ToggleButtonAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JComponent;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements toggle button support for the state change/ui
 *
 * @author Shai Almog
 */
class EnabledAdapter extends SwingAdapter<Boolean, JComponent>  implements PropertyChangeListener {
    protected void bindListener(BaseProperty<Boolean> property, JComponent cmp) {
        cmp.addPropertyChangeListener("enabled", this);
    }

    protected void unbindListener(BaseProperty<Boolean> property, JComponent cmp) {
        cmp.removePropertyChangeListener("enabled", this);
    }

    public void propertyChange(PropertyChangeEvent evt) {
        callWhenUIChanged(getComponent().isEnabled());
    }

    protected void updateUI(Boolean newValue) {
        getComponent().setEnabled(newValue);
    }            

    protected Class getType() {
        return Boolean.class;
    }

    protected Class getComponentType() {
        return JComponent.class;
    }

    protected void setEmptyValue() {
        getComponent().setEnabled(false);
    }
}