package net.java.dev.properties.jdbc.handlers;

public interface TableGeneration {
        /**
         * Adds foreign keys to other tables for unidirectional relations
         */
        void prepareForCreate();
	void createTable();
	void dropTable();
	void clearTable();
}
