package net.java.dev.properties.jdbc;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.jdbc.ConnectionFactory;

/**
 * 
 * A query executor for handling queries that return a result set.
 * 
 * The generic type is the type of object that is generated from each row in the result set
 * 
 * @author Glen Marchesani
 * 
 */

public abstract class QueryExecutor<T> extends SQLExecutor {

    private ResultSet _jdbcResultSet;
    private List<T> _responses;
    
    public QueryExecutor(String sql) {
		this(sql,null);
    }
    
    public QueryExecutor(String sql,Connection connection) {
        this(sql,connection,true);
    }
    
    public QueryExecutor(String query,boolean callExecute) {
        this(query,null,callExecute);
    }
    
    public QueryExecutor(String sql,Connection connection,boolean callExecute) {
    	super(sql,connection,callExecute);
    }

    protected void clean() {
        
    	try {
        	if ( _jdbcResultSet != null ) {
        		_jdbcResultSet.close();
        	}
        } catch(Exception err) {}

        super.clean();
        
    }

    protected void processResultSet(ResultSet rs) throws SQLException {
    	_responses = new ArrayList<T>();
    	while( rs.next() ) {
    		_responses.add(processRow(rs));
    	}
    }

    protected abstract T processRow(ResultSet row) throws SQLException;

    /**
     * 	If the query executed returns a  
     * 
     *  Gets a single result.  If the query returned now results null is returned, if the query returned
     *  a single row an object is returned, if multiple rows a TooManyResultsException is thrown.
     *  
     * @return the result of the query
     */
    public final T getResult() {
    	switch ( getResults().size() ) {
    		case 0:
    			return null;
    			
    		case 1:
    			return getResults().get(0);
    			
    		default:
    			throw new TooManyResultsException( "query returned too many (" + getResults().size() + ")  -  " + getSql() );
    		
    	}
	}
    
    /**
     *  Gets multiple results
     *  
     * @return list containing the results of the query
     */
    public List<T> getResults() {
    	if ( _responses == null ) {
    		throw new JdbcException( "query did not return a result set  -  " + getSql() );
    	}
		return _responses;
	}
    
    protected void postQuery() throws SQLException {    	
       	_jdbcResultSet = getStatement().getResultSet();
       	processResultSet(_jdbcResultSet);
    }
}