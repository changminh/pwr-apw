/*
 * PropertyBuilder.java
 *
 * Created on June 26, 2007, 8:39 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

/**
 * A builder pattern that allows us to initialize properties via a single call
 * as in: <br>
 * StudentBean bean = new StudentBean();<br>
 * bean = PropertyBuilder.create(bean).set(bean.active, true).set(bean.birthDay, 
 * new java.util.Date()).set(bean.comment, "Something").result();
 *
 * @author Shai Almog
 */
public class PropertyBuilder<T> {
    private T parent;
    
    /** Creates a new instance of PropertyBuilder */
    public PropertyBuilder(T parent) {
        this.parent = parent;
    }
    
    public T result() {
        return parent;
    }
    
    /**
     * Initializes properties using the builder patern
     */
    public PropertyBuilder<T> set(BaseProperty<?> prop, Object val) {
        if(prop instanceof WProperty) {
            ((WProperty)prop).set(val);
        } else {
            ((PropertyImpl)prop).set(val);
        }
        return this;
    }
    
    /**
     * Factory method that allows a base class to implement a generic property
     * builder for the type of the subclass without knowing anything about 
     * the subclass.
     */
    public static <X> PropertyBuilder<X> create(X instance) {
        return new PropertyBuilder<X>(instance);
    }
}
