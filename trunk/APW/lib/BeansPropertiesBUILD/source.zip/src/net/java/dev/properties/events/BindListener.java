package net.java.dev.properties.events;

import net.java.dev.properties.container.BeanContext;

/**
 * Invoked to indicate that a bind operation occured, this allows us to initialize
 * properties etc. for every instance of a bean immediately after it is bound.
 *
 * @author Shai Almog
 */
public interface BindListener {
    /**
     * Invoked by the bean container when the given bean which is an instance of the
     * given context was bound. Notice that a bean can be bound several times and this
     * is a valid use case! (base classes invoking BeanContainer.bind(this)).
     */
    public void beanBound(Object bean, BeanContext context);
}
