/*
 * PropertyWrapper.java
 *
 * Created on April 5, 2007, 8:53 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import net.java.dev.properties.events.OnGetListener;
import java.util.Iterator;
import java.util.List;
import net.java.dev.properties.events.OnGet;

/**
 * A property wrapper for an indexed property for more details on wrappers see the
 * property wrapper class
 *
 * @see PropertyWrapper
 * @author Shai Almog
 */
public class IndexedPropertyWrapper<T> extends PropertyWrapper.ReadWrite<List<T>> implements IndexedProperty<T>, OnGetListener {
    public IndexedPropertyWrapper(IndexedProperty<T> property) {
        super(property);
    }

    /**
     * @inheritDoc
     */
    @Override
    public IndexedProperty<T> getProperty() {
        return ((IndexedProperty<T>)super.getProperty());
    }
    
    /**
     * @inheritDoc
     */
    public void remove(T t) {
        getProperty().remove(t);
    }

    /**
     * @inheritDoc
     */
    public void add(T t) {
        getProperty().add(t);
    }

    /**
     * @inheritDoc
     */
    public void remove(int index) {
        getProperty().remove(index);
    }

    /**
     * @inheritDoc
     */
    public T get(int index) {
        return getProperty().get(index);
    }

    /**
     * @inheritDoc
     */
    public void set(int index, T t) {
        getProperty().set(index, t);
    }

    /**
     * @inheritDoc
     */
    public void add(int index, T t) {
        getProperty().add(index, t);
    }

    /**
     * @inheritDoc
     */
    public int size() {
        return getProperty().size();
    }

    /**
     * @inheritDoc
     */
    public Iterator<T> iterator() {
        return getProperty().iterator();
    }    

    /**
     * @inheritDoc
     */
    public void setOnGet(OnGet onGet) {
        if(getProperty() instanceof OnGetListener) {
            ((OnGetListener)getProperty()).setOnGet(onGet);
        } else {
            throw new UnsupportedOperationException("Underlying property does not implement OnGetListener: " + getProperty().getContext());
        }
    }
}