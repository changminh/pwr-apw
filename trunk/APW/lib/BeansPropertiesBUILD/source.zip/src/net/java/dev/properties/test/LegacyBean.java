/*
 * LegacyBean.java
 *
 * Created on February 21, 2007, 3:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import java.beans.*;

/**
 * This is a bean using the old style of coding using get/set which is used
 * as a reference to the new beans.
 *
 * @author Shai Almog
 */
public class LegacyBean {
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private int x;
    
    public int getX() {
        return x;
    }

    public void setX(int x) {
        int oldX = this.x;
        this.x = x;
        changeSupport.firePropertyChange("x", oldX, x);
    }
    
    public void addPropertyChangeListener(PropertyChangeListener l) {
        changeSupport.addPropertyChangeListener(l);
    }

    public void addPropertyChangeListener(String n, PropertyChangeListener l) {
        changeSupport.addPropertyChangeListener(n, l);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener l) {
        changeSupport.removePropertyChangeListener(l);
    }

    public void removePropertyChangeListener(String n, PropertyChangeListener l) {
        changeSupport.removePropertyChangeListener(n, l);
    }
}
