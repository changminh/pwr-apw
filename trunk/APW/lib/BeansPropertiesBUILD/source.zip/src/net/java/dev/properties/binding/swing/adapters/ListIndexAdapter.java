/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.binding.Adapter;

/**
 * Implements list support for propagating UI changes
 *
 * @author Shai Almog
 */
class ListIndexAdapter extends SwingAdapter<Integer, JList> implements ListSelectionListener {
    protected void bindListener(BaseProperty<Integer> property, JList cmp) {
        cmp.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cmp.addListSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<Integer> property, JList cmp) {
        cmp.removeListSelectionListener(this);
    }

    protected void updateUI(Integer newValue) {
        getComponent().setSelectedIndex(newValue);
    }            

    public void valueChanged(ListSelectionEvent e) {
        callWhenUIChanged(getComponent().getSelectedIndex());
    }

    protected Class getType() {
        return Integer.class;
    }

    protected Class getComponentType() {
        return JList.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}