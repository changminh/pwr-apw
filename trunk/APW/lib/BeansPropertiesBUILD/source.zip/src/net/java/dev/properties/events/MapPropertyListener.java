package net.java.dev.properties.events;

import net.java.dev.properties.MapProperty;

/**
 * Allows additional events unique only to map properties, instances of this 
 * interface can be bound just like the standard property listener interfaces
 * This listener is bound like any standard PropertyListener and it would receive
 * the additional notifications implicitly.
 *
 * @author Shai Almog
 */
public interface MapPropertyListener extends PropertyListener {
    /**
     * Invoked when a new property is added or an existing property is modified
     */
    public void propertyInserted(MapProperty prop, Object key, Object value);
    
    /**
     * Invoked when a property is removed
     */
    public void propertyRemoved(MapProperty prop, Object key);
}
