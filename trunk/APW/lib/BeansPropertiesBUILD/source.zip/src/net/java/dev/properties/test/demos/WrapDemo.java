package net.java.dev.properties.test.demos;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.Property;
import net.java.dev.properties.RProperty;
import net.java.dev.properties.container.ObservableWrapper;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.test.DemoInterface;

/**
 * A demo for the wrapper properties that allow wrapping a property 
 * with another property thus providing a "calculated" property without
 * modifying the original.
 *
 * @author Shai Almog
 */
public class WrapDemo extends DemoInterface.DefaultConsoleDemo {

    public WrapDemo() {
        super("Wrapped Properties", "<html><body><h1>Wrapped Properties</h1>Wrapped properties allow " +
                "us to encapsulate a property or set of properties with a single property " +
                "instance this enables us to calculate values on the fly. Wrapped properties provides " +
                "an encapsulation layer that doesn't require inheritance.", 
                new Class[] {WrapDemo.class, WrapBean.class});
    }

    public void run() {
        final WrapBean bean = new WrapBean();
        
        // read only property, there would be no meaning to "set" in this case
        RProperty<String> fullName = new ObservableWrapper.Read<String>(bean.firstName, bean.surname) {
            public String get() {
                RProperty<String> firstName = (RProperty<String>)getProperties()[0];
                RProperty<String> surname = (RProperty<String>)getProperties()[1];
                return firstName.get() + " " + surname.get();
            }
        };
        
        // setting the age would set the date of birth although not accurately only the year...
        // notice that a Date property is mapped to a Short wrapper.
        Property<Short> age = new ObservableWrapper.ReadWrite<Short>(bean.dateOfBirth) {
            private GregorianCalendar cal = new GregorianCalendar();
            public Short get() {
                cal.setTimeInMillis(System.currentTimeMillis());
                int year = cal.get(Calendar.YEAR);
                cal.setTime(bean.dateOfBirth.get());
                int birth = cal.get(Calendar.YEAR);
                return (short) (year - birth);
            }
            
            public void set(Short age) {
                cal.setTimeInMillis(System.currentTimeMillis());
                int year = cal.get(Calendar.YEAR);
                cal.setTime(bean.dateOfBirth.get());
                cal.set(Calendar.YEAR, year - age);
                bean.dateOfBirth.set(cal.getTime());
            }
        };
        
        bean.firstName.set("First");
        bean.surname.set("Surname");
        getOutput().println("Full name is: " + fullName);
        
        PropertyContext context = new PropertyContext();
        context.setName("fullName");
        context.setDisplayName("Full Name");
        fullName.setContext(context);
        getOutput().println("Full name after installing a context: " + fullName);
        
        GregorianCalendar cal = new GregorianCalendar();
        cal.set(1977, 2, 2);
        bean.dateOfBirth.set(cal.getTime());
        getOutput().println("Age is: " + age.get());
        age.set((short)12);
        getOutput().println("Date of birth for 12 year old: " + bean.dateOfBirth.get());        

        class SumProperty extends ObservableWrapper.Read<Integer> {
            public SumProperty(BaseProperty... prop) {
                super(prop);
            }
            
            public Integer get() {
                BaseProperty[] arr = getProperties();
                int sum = 0;
                for(BaseProperty b : arr) {
                    sum += ((RProperty<Number>)b).get().intValue();
                }
                return sum;
            }
        }
        RProperty<Integer> sum = new SumProperty(bean.value1, bean.value2, bean.value3);
        getOutput().println("Sum: " + sum.get());
    }
}
