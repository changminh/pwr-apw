/*
 * ConnectionFactory.java
 *
 * Created on April 3, 2007, 8:08 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.container.BeanContainer;

/**
 * This is a class that should be subclassed by the user in order to allow callers
 * to obtain a JDBC connection. The implementation of the getConnection() method
 * can return a pooled connection or simply connect directly to the database
 * the optional dispose method can recycle or close the connection.
 * <p>Subclasses should invoke the register method with a pointer to themselves...
 *
 * @author Shai Almog
 */
public abstract class ConnectionFactory {

	public final Property<Boolean> verbose = new PropertyImpl<Boolean>(false);
	
	
    private final ThreadLocal<Connection> _threadLocalConnection = new ThreadLocal<Connection>();
    
    public ConnectionFactory() {
        BeanContainer.bind(this);
    }

    public final Connection getConnection() throws SQLException {
    	Connection c = getCurrentConnection();
        if ( c == null ) {
            if(verbose.get()) {
                log("Creating connection");
            }
	    	_threadLocalConnection.set(c = newConnection());
        }
        return c;
    }
	
    /**
     * returns null if there is no active connection
     * @return the current connection
     */
	public Connection getCurrentConnection() {
		return _threadLocalConnection.get();
	}
    
    /**
     * This method should return a connection to the database, it can be implemented
     * using JNDI or just a direct driver connection. Ideally pooling should be
     * used.
     */
    public abstract Connection newConnection() throws SQLException;

    public void commit() {
        try {
            getConnection().commit();
        } catch(SQLException err) {
            throw new BeanBindException(err);
        }
    }

    public void rollback() {
        try {
            if(verbose.get()) {
                log("Rollback");
            }
            getConnection().rollback();
        } catch(SQLException err) {
            throw new BeanBindException(err);
        }
    }

    /**
     * Special case of dispose that can optionally try to rollback the transaction
     * as some databases require before closing a connection with an exception...
     */
    public void disposeFailed() {
        try {
            rollback();
        } catch(Exception err) {}
        dispose();
    }
    
    /**
     * Allows writing custom code for disposing of a connection, normally this
     * method just closes the connection and prints out an error if such an error
     * occured.
     */
    public void dispose() {
        try {
            if(verbose.get()) {
                log("Closing connection");
            }
            Connection connection = getCurrentConnection();
            if ( connection != null ) {
            	connection.close();
            	_threadLocalConnection.set(null);
            }
        } catch(SQLException err) {
            err.printStackTrace();
        }
    }
    
    /**
     * This will be invoked only when logging is active
     */
    public void log(String output) {
        System.out.print("ORM: ");
        System.out.println(output);
    }
    
    /**
     * Simple utility method thats good mostly for standalone applications and tests
     * (shouldn't be used in Java EE since it does no pooling) that just implements
     * a connection manager based on the driver manager. It disables autocommit on
     * the manufactured connections.
     */
    public static void initSimpleDriver(String driver, final String url, final String username, final String password) {
        try {
            Class.forName(driver);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        SessionConfiguration.getInstance().connectionFactory.set(new ConnectionFactory() {
        	public Connection newConnection() throws SQLException {
                Connection con = DriverManager.getConnection (url, username, password);
                con.setAutoCommit(false);
                return con;
            }
        });
    }
}
