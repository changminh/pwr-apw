/*
 * ColorChooserAdapter.java
 *
 * Created on March 3, 2007, 1:14 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.binding.swing.adapters;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.IndexedProperty;
import net.java.dev.properties.util.Utils;

/**
 * Implements list support for propagating UI changes
 *
 * @author Shai Almog
 */
class ListIndicesAdapter extends SwingAdapter<List<Integer>, JList> implements ListSelectionListener {
    protected void bindListener(BaseProperty<List<Integer>> property, JList cmp) {
        cmp.addListSelectionListener(this);
    }

    protected void unbindListener(BaseProperty<List<Integer>> property, JList cmp) {
        cmp.removeListSelectionListener(this);
    }

    protected void updateUI(List<Integer> newValue) {
        getComponent().setSelectedIndices((int[])
        Utils.asArray((IndexedProperty<Integer>)getProperty(), Integer.TYPE));
    }            

    public void valueChanged(ListSelectionEvent e) {
        callWhenUIChanged((List<Integer>)
            Utils.addToCollection(getComponent().getSelectedIndices(), new ArrayList<Integer>()));
    }

    protected Class getType() {
        return List.class;
    }

    protected Class getComponentType() {
        return JList.class;
    }

    protected boolean isSelectionBind() {
        return true;
    }
}