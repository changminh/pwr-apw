package net.java.dev.properties.jdbc;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import net.java.dev.properties.container.BeanBindException;
import net.java.dev.properties.jdbc.ConnectionFactory;

/**
 * Base class for other query executing needs.  It handles cleanup in an elegant fashion.
 * 
 * The class will create a prepared statement from the passed in sql.  Then do the following sequence of calls
 * in the execute() method.
 * 
 * create a connection (if one wasn't pass in)
 * create the prepared statement from the passed in sql
 * prepareQuery()
 * runQuery();
 * postQuery();
 * 
 * All three of these methods can be overridden.  The only method that must be overriden is run query since this base class doesn't know
 * if the query is a result set, ddl or update/insert/delete query.
 * 
 * Also home of getSqlTypeName() sql type number to sql type name mapping used when creating a table
 * from a bean.  This method should move to some class that is DB specific.
 * 
 * @author Glen Marchesani
 * 
 */
public abstract class SQLExecutor {

    private PreparedStatement _statement;
    private String _sql;
	private Connection _connection;
    private Boolean _queryExecutionResponse;
    
    private boolean _disposeSuccessfulConnections = false;
    
    public SQLExecutor(String sql) {
		this(sql,null,false);
    }
    
    public SQLExecutor(String sql,Connection connection) {
        this(sql,connection,false);
    }
    
    public SQLExecutor(String query,boolean callExecute) {
        this(query,null,callExecute);
    }
    
    public SQLExecutor(String sql,Connection connection,boolean callExecute) {
		_sql = sql;
		setConnection(connection);
        ConnectionFactory connectionFactory = SessionConfiguration.getInstance().connectionFactory.get();
        if(connectionFactory.verbose.get()) {
            connectionFactory.log("Executing SQL query - " + sql);
        }
        if ( callExecute ) {
        	execute();
        }
    }

    protected void clean() {
        try {
            _statement.close();
        } catch(Exception err) {}
    }
    
    protected void prepareQuery() throws SQLException {    	
    }

    public void execute() {
    	
		boolean connectionIsFromFactory = false;
    	boolean failed = false;

    	try {
    		
    	    ConnectionFactory factory = SessionConfiguration.getInstance().connectionFactory.get();
        	if ( getConnection() == null ) {
                connectionIsFromFactory = true;
                setConnection(factory.getConnection());
        	}

	        _statement = getConnection().prepareStatement(_sql);
	        
	        prepareQuery();
	        	        
	        runQuery();
	        
	        postQuery();
	        
    	} catch (SQLException e) {
    		failed = true;
    		throw new JdbcException(e);
    	} finally {
    		try {
    			clean();
    		} catch (Exception e) {    			
    		}
    		if ( connectionIsFromFactory ) {
    			if ( failed ) {
    	    		try {
    	    			SessionConfiguration.getInstance().connectionFactory.get().disposeFailed();
    	    		} catch (Exception e) {    			
    	    		}
    			} else {
    				if (_disposeSuccessfulConnections ) {
	    	    		try {    	    			
	    	    			SessionConfiguration.getInstance().connectionFactory.get().dispose();    				
	    	    		} catch (Exception e) {    			
	    	    		}
    				}
    			}
    		} else if (failed) {
	    		try {
	    			_connection.rollback();
	    		} catch (Exception e) {    			
	    		}    			
				if (_disposeSuccessfulConnections ) {
    	    		try {    	    			
    	    			_connection.close();    				
    	    		} catch (Exception e) {    			
    	    		}
				}
    		}
    	}
    	
    }
    
    protected void runQuery() throws SQLException {
    	boolean response = getStatement().execute();
        setQueryExecutionResponse(response);
    }
    
    protected void postQuery() throws SQLException {    	
    }
    
    public PreparedStatement getStatement() {
		return _statement;
	}
    
    public String getSql() {
		return _sql;
	}
    
	public void setConnection(Connection connection) {
		this._connection = connection;
	}
	public Connection getConnection() {
		return _connection;
	}
	
	public void setQueryExecutionResponse(Boolean queryExecutionResponse) {
		_queryExecutionResponse = queryExecutionResponse;
	}
	
	public void setDisposeSuccessfulConnections(boolean disposeSuccessfulConnections) {
		_disposeSuccessfulConnections = disposeSuccessfulConnections;
	}
	
	public static String getSqlTypeName( int sqlType, int size ) {
    	
    	switch ( sqlType ) {
    		case Types.BIGINT:
    			return "bigint";
    	    	
    		case Types.BIT:
    			return "bit";
    	    	
    		case Types.BOOLEAN:
    			return "boolean";

    		case Types.DATE:
    			return "date";
    	    	
    		case Types.FLOAT:
    			return "float";
    	    	
    		case Types.INTEGER:
    			return "integer";
    	    	
    		case Types.TINYINT:
    			return "smallint";

                case Types.SMALLINT:
    			return "smallint";
    	    	
    		case Types.TIME:
    			return "time";
    	    	
    		case Types.TIMESTAMP:
    			return "timestamp";
    	    	
    		case Types.VARCHAR:
    			return "VARCHAR(" + size + ")";

    	}
    	
    	throw new RuntimeException( "don't know how to handle type " + sqlType );

    }
}