/*
 * IndexedProperty.java
 *
 * Created on February 22, 2007, 8:38 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import java.util.Iterator;
import java.util.List;

/**
 * Allows access to a property as a set of elements, this
 * interface is more restricted than the java.util.List interface yet allows
 * features not enabled in the Collection interface. The main reason for this
 * duplication (rather than exposing java.util.List) is property change support.
 * The indexed property can be obseved properly and thus can enjoy all the features
 * of bean-properties and binding.
 * <p>Through support to iteratable the new for loop syntax in Java 5
 * can be used on an indexed property: for(MyObj obj : indexedProp) {...}
 * <p>Notice that IndexedProperty derives from Property rather than BaseProperty,
 * this simplifies and enables many use cases (such as using set that accepts a list)
 * however the use of the set(List) or List get() methods is discoraged. These methods
 * will not have the behavior you might expect since they return an unmodifiable list
 * or copy the entire content of the submitted list to avoid "issues".
 *
 * @author Shai Almog, Glen Marchesani
 */
public interface IndexedProperty<T> extends Property<List<T>>, Iterable<T> {
    /**
     * Returns the property at the given index
     */
    public T get(int index);

    /**
     * Sets the property at the given index
     */
    public void set(int index, T t);
    
    /**
     * Returns an iterator that does not enable removal
     */
    public Iterator<T> iterator();
    
    /**
     * Add t into the given index
     */
    public void add(int index, T t);

    /**
     * Adds the element at the most convenient index for the underlying structure
     */
    public void add(T t);
        
    /**
     * Removes the element
     */
    public void remove(T t);

    /**
     * Removes the element
     */
    public void remove(int index);

    /**
     * Returns the size of the indexed property
     */
    public int size();
}
