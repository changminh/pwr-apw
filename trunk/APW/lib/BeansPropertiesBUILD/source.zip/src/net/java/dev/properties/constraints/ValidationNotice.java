/*
 * ValidationNotice.java
 *
 * Created on March 6, 2007, 11:17 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.constraints;

import net.java.dev.properties.BaseProperty;

/**
 * This interface allows a UI to communicate the validation status visually, this
 * allows pluggable error notices into different UI types
 *
 * @author Shai Almog
 */
public interface ValidationNotice<C> {
    /**
     * Invoked by the UI so the given component can be marked as valid/invalid for the
     * given property.
     */
    public void updateValidationStatus(BaseProperty property, C component, boolean valid, String message);
}
