/*
 * Attributes.java
 *
 * Created on February 21, 2007, 6:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.annotations;

import java.beans.PropertyEditor;
import java.lang.annotation.*;

/**
 * Allows us to define attributes for a property such
 * as name, description etc. Property editors can optionally be defined as well,
 * they use the same interface of the old JavaBeans property editor for simplicity
 * sake.
 * <p>See the bean annotation for further details about localization
 *
 * @see Bean
 * @author Shai Almog
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Attributes {
    /**
     * The name of the property, this defaults to the name of the field to which
     * the property is assigned
     * 
     * @see net.java.dev.properties.container.PropertyContext
     * @see net.java.dev.properties.container.ObservableContext#getName
     * @see net.java.dev.properties.container.ObservableContext#setName
     */
    String name() default "";

    /**
     * The display name of the property, this can be automatically extracted from
     * a resource bundle. This defaults to the name of the field to which
     * the property is assigned with upper case letters receiving a space and
     * lowercase state e.g. firstName would become First name
     * 
     * @see net.java.dev.properties.container.PropertyContext
     * @see net.java.dev.properties.container.ObservableContext#getDisplayName
     * @see net.java.dev.properties.container.ObservableContext#setDisplayName
     */
    String displayName() default "";
    
    /**
     * Description for the property used by GUI tools for elements such as tooltips,
     * this is a localized attribute.
     * 
     * @see net.java.dev.properties.container.PropertyContext
     * @see net.java.dev.properties.container.ObservableContext#getDescription
     * @see net.java.dev.properties.container.ObservableContext#setDescription
     */
    String description() default "";        

    Class<? extends PropertyEditor> editor() default PropertyEditor.class;

    /**
     * Allows manually defining resource bundle keys for display name
     * 
     * @see net.java.dev.properties.container.PropertyContext
     * @see net.java.dev.properties.container.ObservableContext#getDisplayName
     * @see net.java.dev.properties.container.ObservableContext#setDisplayName
     * @see Bean For further details about localization
     */
    String displayNameL() default "";

    /**
     * Allows manually defining resource bundle keys for description
     * 
     * @see net.java.dev.properties.container.PropertyContext
     * @see net.java.dev.properties.container.ObservableContext#getDescription
     * @see net.java.dev.properties.container.ObservableContext#setDescription
     * @see Bean For further details about localization
     */
    String descriptionL() default "";
}
