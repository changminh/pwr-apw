/*
 * I18nDemo.java
 *
 * Created on April 15, 2007, 6:22 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test.demos;

import java.awt.ComponentOrientation;
import java.util.Locale;
import javax.swing.JComponent;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.test.DemoGUI;
import net.java.dev.properties.test.binding.studio.*;

/**
 * This is the Yoga studio demo localized to hebrew
 *
 * @author shai
 */
public class I18nDemo extends Main {
    private Locale oldLocale = null;
    public JComponent execute() {
        if(oldLocale == null) {
            oldLocale = Locale.getDefault();
            Locale newLocale = new Locale("iw", "IL");
            Locale.setDefault(newLocale);
            BeanContainer.get().refreshLocale(newLocale);
        }
        JComponent c = new Main().execute();
        c.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        return c;
    }

    public String demoName() {
        return "Internationalization";
    }

    public String demoDescription() {
        return "<html><body><h1>Internationalization</h1>This demo is identical to the Yoga studio demo, only in Hebrew. " +
                "Notice how the UI is mirrored, this is due to Hebrew being written " +
                "from right to left (bidi). The content of the demo wasn't modified so the names are still in English and " +
                "alignment of Swing renderers (such as the JTable cells and headers) is still left to right due to a bug " +
                "in Swing's PLAF's (which is fixed by some PLAF's such as Substance). Both are easy to fix we just didn't " +
                "want to clutter the demo code.";
    }
    
    public String[] fileNames() {
        return DemoGUI.demoFiles(new Class[]{ getClass(), AttendanceBean.class, StudentBean.class, StudioBean.class, 
                YogaClassBean.class, Main.class, TimeComponent.class});
    }

    public void cleanup() {
        // Allows us to run other demos with a more probable locale.
        if(oldLocale != null) {
            Locale.setDefault(oldLocale);
            BeanContainer.get().refreshLocale(Locale.getDefault());
            oldLocale = null;
        }
    }
}
