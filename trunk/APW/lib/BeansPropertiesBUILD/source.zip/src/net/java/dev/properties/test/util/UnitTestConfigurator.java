package net.java.dev.properties.test.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.java.dev.properties.jdbc.ConnectionFactory;
import net.java.dev.properties.jdbc.SessionConfiguration;

/**
 * 
 * UnitTestConfigurator is a place to consolidate unit test configuration code that before 
 * UnitTestConfigurator's existence was getting duplicated in every unit test.  It currently
 * can configure logging, simple logging of sql, verbose logging of sql, and initialize an in memory
 * database.
 * 
 * Normal use would be to first use this class to configure logging via configureLogging() then if 
 * you want to see sql use logSqlOnly() or if you want 
 * 
 * 
 * 
 * @author Glen Marchesani
 */
public class UnitTestConfigurator {
	
	/**
	 * This configures the ConnectionFactory to use an in memory hsqldb.  This is ideal
	 * for unit testing.  The DB will have no tables so these must be created on the fly with
	 * each run.
	 * 
	 * The hsqldb driver is wrapped in a log4jdbc driver.  This driver is what allows the 
	 * logging of jdbc activity (queries, rsult set actions, query timings and audit info).
	 * 
	 * The steps needed to activate the log4jdbc driver are
	 *    - make sure the actual jdbc driver is loaded via DriverManager.registerDriver(new org.hsqldb.jdbcDriver());
	 *    - make sure the log4jdbc driver is loaded DriverManager.registerDriver(new net.sf.log4jdbc.DriverSpy());
	 *    - prepend the jdbc url with jdbc:log4...  So "jdbc:hsqldb:." becomes "jdbc:log4jdbc:hsqldb:."
	 *    
	 * The log4jdbc jar used has to be matched to the version of jdbc driver needed.  The jar in the
	 * bean properties lib directory is JDBC 3.  Which currently is compatible with every driver out there
	 * that I know of besides Derby (which needs jdbc 4).  So if jdbc 4 is needed then gooogle log4jdbc and 
	 * download and use the log4jdbc4-xxxx.jar found on that site. 
	 *  
	 */	
	public static void configureInMemoryJbc() {
		
        // Normally this should use ConnectionFactory.initSimpleDriver() but in this
        // case we also want to override the "log" method...
        try {
            // build an in-memory HSQL database on which we can run the tests
        	DriverManager.registerDriver(new org.hsqldb.jdbcDriver());
        	DriverManager.registerDriver(new net.sf.log4jdbc.DriverSpy());
            //Class.forName("org.apache.derby.jdbc.ClientDriver");
//            Class.forName("com.mysql.jdbc.Driver");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        SessionConfiguration.getInstance().connectionFactory.set(new ConnectionFactory() {
        	public Connection newConnection() throws SQLException {
//                Connection con = DriverManager.getConnection ("jdbc:hsqldb:file:./testdb", "sa", "");
                Connection con = DriverManager.getConnection ("jdbc:log4jdbc:hsqldb:.", "sa", "");
                //Connection con = DriverManager.getConnection ("jdbc:derby://localhost:1527/test", null, null);
//                Connection con = DriverManager.getConnection ("jdbc:mysql://localhost/test", "root", "sim753");
                con.setAutoCommit(false);
                return con;
            }

            public void log(String output) {
            }
        });
        SessionConfiguration.getInstance().connectionFactory.get().verbose.set(true);

	}
	
	
	/**
	 * Show every sql query and none of the result set, auditting or timing info.
	 */	
	public static void configureLogging() {
		boolean hasHandlers = false;
		for( Handler loggingHandler : Logger.getLogger( "" ).getHandlers() ) {
			loggingHandler.setFormatter(new SimpleFormatter());
			hasHandlers = true;
		}
		if ( !hasHandlers ) {
			SystemDotOutConsoleHandler handler = new SystemDotOutConsoleHandler();
			Logger.getLogger("").addHandler(handler);
			handler.setFormatter(new SimpleFormatter());
		}
		
		logSqlOnly();
		
	}
	
	/**
	 * Show every sql query and none of the result set, auditting or timing info.
	 */	
	public static void logSqlOnly() {
		logSqlQueries();
		Logger.getLogger( "jdbc.audit" ).setLevel(Level.WARNING);
		Logger.getLogger( "jdbc.sqltiming" ).setLevel(Level.WARNING);
		Logger.getLogger( "jdbc.resultset" ).setLevel(Level.WARNING);
	}
	
	/**
	 * Name says it all turn on logging of all sql executed by the jdbc driver
	 */	
	public static void logSqlQueries() {
		Logger.getLogger( "jdbc.sqlonly" ).setLevel(Level.INFO);
	}
	
	/**
	 * Turn on logging of all calls to the ResultSet
	 */	
	public static void logSqlResultSet() {
		Logger.getLogger( "jdbc.resultset" ).setLevel(Level.INFO);		
	}
	
	/**
	 * Turn on logging of timing of all queries
	 */	
	public static void logSqlTimings() {
		Logger.getLogger( "jdbc.sqltiming" ).setLevel(Level.INFO);		
	}

	/**
	 * Turn on all logging for all jdbc/sql activity (this is quite verbose) 
	 */	
	public static void logEverythingSql() {
		Logger.getLogger( "jdbc.sqlonly" ).setLevel(Level.CONFIG);
		Logger.getLogger( "jdbc.audit" ).setLevel(Level.CONFIG);
		Logger.getLogger( "jdbc.sqltiming" ).setLevel(Level.CONFIG);
		Logger.getLogger( "jdbc.resultset" ).setLevel(Level.CONFIG);
		
	}
}
