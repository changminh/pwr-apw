package net.java.dev.properties.jdbc;

import java.util.ArrayList;
import java.util.List;

import net.java.dev.properties.jdbc.handlers.ColumnContext;
import net.java.dev.properties.jdbc.handlers.TypeHandler;

/**
 * A class to help building sql queries...  It can take either
 * ColumnContext instances or TypeHandler instances and construct properly seperated sql. 
 * 
 * @author Glen Marchesani
 *
 */
public class QueryBuilder implements Cloneable {
	
	private StringBuilder _stringBuilder = new StringBuilder();
	
	private List<ColumnContext> _columns = new ArrayList<ColumnContext>();
	
	
	public QueryBuilder() {
	}
	
	public void resetColumns() {
		_columns.clear();
	}
	
	public void append(String s) {
		_stringBuilder.append(s);
	}

	public void appendColumns(List<ColumnContext> columns, String seperator) {
		appendColumns(columns, "", seperator);
	}
	
	public void appendColumns(List<ColumnContext> columns, String columnPostFix, String seperator) {
		String seperatorHolder = "";
		for ( ColumnContext column : columns ) {
			_columns.add(column);
			_stringBuilder.append( seperatorHolder );
			_stringBuilder.append( column.getName() );
			_stringBuilder.append( columnPostFix );
			seperatorHolder = seperator;
		}
	}

	public void appendHandlerColumns(List<TypeHandler<Object>> handlers, String seperator, boolean includeReadOnlyColumns) {
		appendHandlerColumns(handlers,"",seperator, includeReadOnlyColumns);
	}
	
	public void appendHandlerColumns(List<TypeHandler<Object>> handlers, String columnPostFix, String seperator, boolean includeReadOnlyColumns) {
		String seperatorHolder = "";
		for( TypeHandler<Object> handler : handlers ) {
			for ( ColumnContext column : handler.getColumns() ) {
				if ( includeReadOnlyColumns || !column.getReadOnly() ) {
					_columns.add(column);
					_stringBuilder.append( seperatorHolder );
					_stringBuilder.append( column.getName() );
					_stringBuilder.append( columnPostFix );
					seperatorHolder = seperator;
				}
			}
		}
	}
	
	public int getColumnCount() {
		return _columns.size();
	}
	
	@Override
	public QueryBuilder clone() {
		try {
			return (QueryBuilder) super.clone();
		} catch ( CloneNotSupportedException e ) {
			throw new RuntimeException(e);
		}
	}

    public String getSql() {
    	return _stringBuilder.toString();
    }
    
    @Override
    public String toString() {
    	return getSql();
    }

}
