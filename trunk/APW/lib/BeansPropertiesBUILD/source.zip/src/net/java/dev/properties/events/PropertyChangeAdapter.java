/*
 * PropertyChangeAdapter.java
 *
 * Created on February 21, 2007, 1:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.events;

import net.java.dev.properties.container.PropertyContext;
import java.beans.*;
import net.java.dev.properties.BaseProperty;

/**
 * A small tool to simplify the conversion of existing property change support
 * code to the new properties approach
 *
 * @author Shai Almog
 */
public class PropertyChangeAdapter implements PropertyListener {
    private PropertyChangeListener listener;
    
    /** Creates a new instance of PropertyChangeAdapter */
    public PropertyChangeAdapter(PropertyChangeListener listener) {
        this.listener = listener;
    }

    /**
     * @inheritDoc
     */
    @Override
    public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        PropertyContext context = prop.getContext();
        if(index > -1) {
            listener.propertyChange(new IndexedPropertyChangeEvent(prop.getParent(), context.getName(), oldValue, newValue, index));
        } else {
            listener.propertyChange(new PropertyChangeEvent(prop.getParent(), context.getName(), oldValue, newValue));
        }
    }    

    public PropertyChangeListener getListener() {
        return listener;
    }
}
