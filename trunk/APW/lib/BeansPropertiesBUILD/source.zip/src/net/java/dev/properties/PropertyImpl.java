/*
 * Property.java
 *
 * Created on February 20, 2007, 9:57 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties;

import net.java.dev.properties.constraints.ConstraintFailedException;
import net.java.dev.properties.constraints.Failed;
import net.java.dev.properties.container.PropertyContext;

/**
 * A base class for a non-observable properties, this class and its subclasses
 * contain validation code so all properties deriving from this class will respect
 * validation rules.
 *
 * @author Shai Almog
 */
public class PropertyImpl<T> extends BasePropertyImpl<T> implements Property<T> {
    public PropertyImpl() {
    }
    
    public PropertyImpl(T t) {
        super(t);
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> PropertyImpl<K> create() {
        return new PropertyImpl<K>();
    }

    /**
     * Factory method that allows a simpler creation syntax without repeating the 
     * generic code.
     */
    public static <K> PropertyImpl<K> create(K k) {
        return new PropertyImpl<K>(k);
    }
    
    /**
     * @inheritDoc
     */
    public void set(T t) {
        // validate constraint
        PropertyContext pc = getContext();
        if(pc != null && !pc.validate(this, t)) {
            if(pc.getOnConstraintFail() == Failed.DO_NOTHING) {
                return;
            }
            if(pc.getOnConstraintFail() == Failed.THROW_EXCEPTION) {
                throw new ConstraintFailedException(this, t);
            }
            
            // Failed.CHANGE_AS_USUAL allows the value to be set so validation
            // will fail later on in introspection
        }
        
        super.set(t);
    }

    /**
     * @inheritDoc
     */
    public T get() {
        return super.get();
    }
}
