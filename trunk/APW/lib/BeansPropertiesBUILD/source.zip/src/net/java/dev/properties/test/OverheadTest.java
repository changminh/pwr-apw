/*
 * OverheadTest.java
 *
 * Created on February 28, 2007, 6:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package net.java.dev.properties.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import javax.swing.*;
import net.java.dev.properties.BaseProperty;
import net.java.dev.properties.LegacyDelegateProperty;
import net.java.dev.properties.Property;
import net.java.dev.properties.PropertyImpl;
import net.java.dev.properties.container.BeanContainer;
import net.java.dev.properties.container.ObservableProperty;
import net.java.dev.properties.events.PropertyListener;

/**
 * A class that tests the memory overhead paid by the new beans when compared
 * to standard JavaBeans and provides statistics under the current VM.
 *
 * @author Shai Almog
 */
public class OverheadTest {
    private static final Class[] classes = {
        PrimitiveBean.class,
        ObjectBean.class,
        NewBean.class,
        UnboundNewBean.class,
        PrimitiveObservableBean.class,
        ObjectObservableBean.class,
        ObservableNewBean.class,
        ObservableCompatibilityNewBean.class,
        PrimitiveObservableBeanWithListener.class,
        ObjectObservableBeanWithListener.class,
        ObservableNewBeanWithListener.class,
        ObservableCompatibilityNewBeanWithNewListener.class,
        ObservableCompatibilityNewBeanWithOldListener.class,
        PrimitiveObservableBeanWithListenerOnProperty.class,
        ObjectObservableBeanWithListenerOnProperty.class,
        ObservableNewBeanWithListenerOnProperty.class,
        ObservableCompatibilityNewBeanWithListenerOnProperty.class,
        NewGUIBean.class,
        OldGUIBean.class
    };
    
    /**
     * Commented out since I didn't get permission from Heinz to publish this
     * code. If you intend to check on my numbers make sure to ignore the
     * PropertyContext and BeanContext classes.
     */
    private MemoryCounter memoryCounter = new MemoryCounter();
        
    private Factory findFactory(Class c) throws Exception {
        Class inner = c.getClasses()[0];
        return Factory.class.cast(inner.newInstance());
    }
    
    public long getSize(Factory factory) throws Exception {

        Object handle = factory.make();
      long mem0 = Runtime.getRuntime().totalMemory() -
        Runtime.getRuntime().freeMemory();
      long mem1 = Runtime.getRuntime().totalMemory() -
        Runtime.getRuntime().freeMemory();
      
      handle = null;
      for (int i=0; i<10; i++) {
          try { byte[] big = new byte[1024 * 1024 * 1024]; } catch(OutOfMemoryError er) {}
        System.gc(); Thread.sleep(1000);
      }
      
      
      mem0 = Runtime.getRuntime().totalMemory() -
        Runtime.getRuntime().freeMemory();
      handle = factory.make();
      for (int i=0; i<10; i++) {
          try { byte[] big = new byte[1024 * 1024 * 1024]; } catch(OutOfMemoryError er) {}
        System.gc(); Thread.sleep(1000);
      }
      mem1 = Runtime.getRuntime().totalMemory() -
        Runtime.getRuntime().freeMemory();
      return mem1 - mem0;
    }

        
    /**
     * Checks the memory overhead for the given bean class. To elimnate the costs
     * of first initialization (such as context object etc.) the class is loaded
     * twice. Since context object size isn't very important when compared to the
     * instance overhead.
     */
    public void runTest(Class cls) throws Exception {
        long beanContainerBefore = memoryCounter.estimate(BeanContainer.get());
        Factory factory = findFactory(cls);
        long size = getSize(factory);
        long heinzSize = memoryCounter.estimate(factory.make());
        
        long beanContainerAfter = memoryCounter.estimate(BeanContainer.get());
        System.out.println(cls.getSimpleName() + ": " + size + " and according to memoryCounter: " + heinzSize + " BeanContainer diff: " + (beanContainerAfter - beanContainerBefore));
    }
    
    public static void main(String[] argv) throws Exception {
        OverheadTest test = new OverheadTest();
        // default doesn't work very well
        for(int iter = 0 ; iter < classes.length ; iter++) {
            test.runTest(classes[iter]);
        }
    }
    
    public static interface Factory {
        Object make();
    }
    
    public static class PrimitiveBean {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new PrimitiveBean();
            }
        }
        
        private int x;
        
        public int getX() {
            return x;
        }
        
        public void setX(int x) {
            this.x = x;
        }
    }
    
    public static class ObjectBean {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObjectBean();
            }
        }
        private Integer x;
        
        public Integer getX() {
            return x;
        }
        
        public void setX(Integer x) {
            this.x = x;
        }
    }
    
    public static class NewBean {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new NewBean();
            }
        }
        public final Property<Integer> x = new PropertyImpl<Integer>();
        
        /** Creates a new instance of NewBean */
        public NewBean() {
            BeanContainer.bind(this);
        }
    }
    
    public static class UnboundNewBean {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new UnboundNewBean();
            }
        }
        public final Property<Integer> x = new PropertyImpl<Integer>();
    }
    
    public static class PrimitiveObservableBean {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new PrimitiveObservableBean();
            }
        }
        private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
        private int x;
        
        public int getX() {
            return x;
        }
        
        public void setX(int x) {
            int oldX = this.x;
            this.x = x;
            changeSupport.firePropertyChange("x", oldX, x);
        }
        
        public void addPropertyChangeListener(PropertyChangeListener l) {
            changeSupport.addPropertyChangeListener(l);
        }
        
        public void addPropertyChangeListener(String n, PropertyChangeListener l) {
            changeSupport.addPropertyChangeListener(n, l);
        }
        
        public void removePropertyChangeListener(PropertyChangeListener l) {
            changeSupport.removePropertyChangeListener(l);
        }
        
        public void removePropertyChangeListener(String n, PropertyChangeListener l) {
            changeSupport.removePropertyChangeListener(n, l);
        }
    }
    
    public static class ObjectObservableBean {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObjectObservableBean();
            }
        }
        private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
        private Integer x;
        
        public Integer getX() {
            return x;
        }
        
        public void setX(Integer x) {
            int oldX = this.x;
            this.x = x;
            changeSupport.firePropertyChange("x", (Object)oldX, (Object)x);
        }
        
        public void addPropertyChangeListener(PropertyChangeListener l) {
            changeSupport.addPropertyChangeListener(l);
        }
        
        public void addPropertyChangeListener(String n, PropertyChangeListener l) {
            changeSupport.addPropertyChangeListener(n, l);
        }
        
        public void removePropertyChangeListener(PropertyChangeListener l) {
            changeSupport.removePropertyChangeListener(l);
        }
        
        public void removePropertyChangeListener(String n, PropertyChangeListener l) {
            changeSupport.removePropertyChangeListener(n, l);
        }
    }
    
    public static class ObservableNewBean {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObservableNewBean();
            }
        }
        public final ObservableProperty<Integer> x = new ObservableProperty<Integer>();
        
        /** Creates a new instance of NewBean */
        public ObservableNewBean() {
            BeanContainer.bind(this);
        }
    }
    
    public static class ObservableCompatibilityNewBean {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObservableCompatibilityNewBean ();
            }
        }
        public final ObservableProperty<Integer> x = new ObservableProperty<Integer>();
        
        /** Creates a new instance of NewBean */
        public ObservableCompatibilityNewBean() {
            BeanContainer.bind(this);
        }
        
        public Integer getX() {
            return x.get();
        }
        
        public void setX(Integer x) {
            this.x.set(x);
        }
        
        public void addPropertyChangeListener(PropertyChangeListener l) {
            BeanContainer.get().addPropertyChangeListener(this, l);
        }
        
        public void addPropertyChangeListener(String n, PropertyChangeListener l) {
            BeanContainer.get().addPropertyChangeListener(this, n, l);
        }
        
        public void removePropertyChangeListener(PropertyChangeListener l) {
            BeanContainer.get().removePropertyChangeListener(this, l);
        }
        
        public void removePropertyChangeListener(String n, PropertyChangeListener l) {
            BeanContainer.get().removePropertyChangeListener(this, n, l);
        }
    }
    
    public static class PrimitiveObservableBeanWithListener extends PrimitiveObservableBean implements PropertyChangeListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new PrimitiveObservableBeanWithListener ();
            }
        }
        public PrimitiveObservableBeanWithListener() {
            addPropertyChangeListener(this);
        }
        
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }
    
    public static class ObjectObservableBeanWithListener extends ObjectObservableBean implements PropertyChangeListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObjectObservableBeanWithListener ();
            }
        }
        public ObjectObservableBeanWithListener() {
            addPropertyChangeListener(this);
        }
        
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }
    
    public static class ObservableNewBeanWithListener extends ObservableNewBean implements PropertyListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObservableNewBeanWithListener ();
            }
        }
        public ObservableNewBeanWithListener() {
            BeanContainer.get().addListener(this, this);
        }
        
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        }
    }
    
    public static class ObservableCompatibilityNewBeanWithNewListener extends ObservableCompatibilityNewBean implements PropertyListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObservableCompatibilityNewBeanWithNewListener ();
            }
        }
        public ObservableCompatibilityNewBeanWithNewListener() {
            BeanContainer.get().addListener(this, this);
        }
        
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        }
    }
    
    public static class ObservableCompatibilityNewBeanWithOldListener extends ObservableCompatibilityNewBean implements PropertyChangeListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObservableCompatibilityNewBeanWithOldListener ();
            }
        }
        public ObservableCompatibilityNewBeanWithOldListener() {
            addPropertyChangeListener(this);
        }
        
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }
    
    public static class PrimitiveObservableBeanWithListenerOnProperty extends PrimitiveObservableBean implements PropertyChangeListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new PrimitiveObservableBeanWithListenerOnProperty ();
            }
        }
        public PrimitiveObservableBeanWithListenerOnProperty() {
            addPropertyChangeListener("x", this);
        }
        
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }
    
    public static class ObjectObservableBeanWithListenerOnProperty extends ObjectObservableBean implements PropertyChangeListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObjectObservableBeanWithListenerOnProperty ();
            }
        }
        public ObjectObservableBeanWithListenerOnProperty() {
            addPropertyChangeListener("x", this);
        }
        
        public void propertyChange(PropertyChangeEvent evt) {
        }
    }
    
    public static class ObservableNewBeanWithListenerOnProperty extends ObservableNewBean implements PropertyListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObservableNewBeanWithListenerOnProperty ();
            }
        }
        public ObservableNewBeanWithListenerOnProperty() {
            BeanContainer.get().addListener(x, this);
        }
        
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        }
    }
    
    public static class ObservableCompatibilityNewBeanWithListenerOnProperty extends ObservableCompatibilityNewBean implements PropertyListener {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new ObservableCompatibilityNewBeanWithListenerOnProperty ();
            }
        }
        public ObservableCompatibilityNewBeanWithListenerOnProperty() {
            BeanContainer.get().addListener(x, this);
        }
        
        public void propertyChanged(BaseProperty prop, Object oldValue, Object newValue, int index) {
        }
    }

    public static class NewGUIBean extends JPanel {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new NewGUIBean ();
            }
        }
        private JLabel content = new JLabel("Test Color");

        public final LegacyDelegateProperty<Color> foreground = new LegacyDelegateProperty<Color>(content);

        public final LegacyDelegateProperty<Color> background = new LegacyDelegateProperty<Color>(content);

        public NewGUIBean() {
            BeanContainer.bind(this);
            setLayout(new BorderLayout());
            content.setOpaque(true);
            add(content, BorderLayout.CENTER);
            JPanel buttons = new JPanel();
            buttons.add(createButton("Foreground", foreground));
            buttons.add(createButton("Background", background));
            add(buttons, BorderLayout.SOUTH);
        }

        /**
         * Notice that because we have a property object we can generalize the code for
         * the background and foreground...
         */
        public JButton createButton(final String label, final Property<Color> color) {
            JButton btn = new JButton(label);
            btn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    color.set(JColorChooser.showDialog(NewGUIBean.this, label, color.get()));
                }
            });
            return btn;
        }
    }

    public static class OldGUIBean extends JPanel {
        public static class FactoryImpl implements Factory {
            public Object make() {
                return new OldGUIBean ();
            }
        }
        private JLabel content = new JLabel("Test Color");

        /** Creates a new instance of GUIBean */
        public OldGUIBean() {
            setLayout(new BorderLayout());
            content.setOpaque(true);
            add(content, BorderLayout.CENTER);
            JPanel buttons = new JPanel();
            JButton btn = new JButton("Foreground");
            btn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    setFore(JColorChooser.showDialog(OldGUIBean.this, "Foreground", getFore()));
                }
            });
            buttons.add(btn);
            btn = new JButton("Background");
            btn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    setBack(JColorChooser.showDialog(OldGUIBean.this, "Background", getBack()));
                }
            });
            buttons.add(btn);
            add(buttons, BorderLayout.SOUTH);
        }

        public Color getFore() {
            return content.getForeground();
        }

        public void setFore(Color c) {
            content.setForeground(c);
        }

        public void setBack(Color c) {
            content.setBackground(c);
        }

        public Color getBack() {
            return content.getBackground();
        }

        public void addPropertyChangeListener(PropertyChangeListener l) {
            content.addPropertyChangeListener(l);
            super.addPropertyChangeListener(l);
        }

        public void addPropertyChangeListener(String s, PropertyChangeListener l) {
            content.addPropertyChangeListener(s, l);
            super.addPropertyChangeListener(s, l);
        }

        public void removePropertyChangeListener(PropertyChangeListener l) {
            content.removePropertyChangeListener(l);
            super.removePropertyChangeListener(l);
        }

        public void removePropertyChangeListener(String s, PropertyChangeListener l) {
            content.removePropertyChangeListener(s, l);
            super.removePropertyChangeListener(s, l);
        }
    }
}
