package net.java.dev.properties.jdbc.handlers;

import net.java.dev.properties.container.BeanContext;
import net.java.dev.properties.container.PropertyContext;
import net.java.dev.properties.jdbc.EntityPersister;

/**
 * 
 * Handler's that implement this interface and are instantiated by the TypeHandlerFactory
 * will have all these set methods called and then the activedated() method called.
 * 
 * The reason for this being seperate from TypeHandler() is to reduce the number of 
 * methods a custom TypeHandler needs to implement.  All the bean props internal TypeHandler's
 * implement this interface.
 * 
 */
public interface LifecycleAwareTypeHandler<T> extends TypeHandler<T> {
	
	void setBeanContext( BeanContext beanContext );
	void setPropertyContext( PropertyContext propertyContext );
	void setHandlerFactory(TypeHandlerFactory handlerFactory);
	void setParentEntityPersister(EntityPersister<?> entityPersister);

	/**
	 * activated is called after all the set methods
	 */
	void activated();

}
